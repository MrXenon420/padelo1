import { RequestHandler } from "express";
import { 
  Tournament, 
  TournamentMatch, 
  PlayerRanking, 
  LPTransaction,
  TIER_REQUIREMENTS,
  ADVANCEMENT_POINTS,
  BONUS_POINTS
} from "@shared/tournament";

// Mock database - in real app would use actual database
let tournaments: Tournament[] = [];
let matches: TournamentMatch[] = [];
let rankings: PlayerRanking[] = [];
let lpTransactions: LPTransaction[] = [];

// Calculate LP gain/loss based on team strength differential
function calculateLPChange(
  winnerTeamLP: number, 
  loserTeamLP: number, 
  isOfficial: boolean
): { winnerLP: number; loserLP: number } {
  const baseLPGain = 25;
  const lpDifference = winnerTeamLP - loserTeamLP;
  
  // Adjust based on relative strength
  let lpAdjustment = 0;
  if (lpDifference > 200) {
    // Stronger team wins - less LP
    lpAdjustment = -10;
  } else if (lpDifference < -200) {
    // Weaker team wins - more LP
    lpAdjustment = 15;
  }
  
  const actualGain = Math.max(5, baseLPGain + lpAdjustment);
  const actualLoss = Math.max(5, Math.floor(actualGain * 0.7));
  
  // Apply official tournament multiplier
  const multiplier = isOfficial ? 1.0 : 0.1;
  
  return {
    winnerLP: Math.floor(actualGain * multiplier),
    loserLP: -Math.floor(actualLoss * multiplier)
  };
}

// Calculate tournament advancement points
function calculateAdvancementPoints(
  bracketSize: 8 | 16 | 32,
  round: string,
  isWinner: boolean,
  isChampion: boolean = false
): number {
  const pointsConfig = ADVANCEMENT_POINTS.find(config => config.bracketSize === bracketSize);
  if (!pointsConfig) return 0;
  
  let points = 0;
  
  // Base match win
  if (isWinner) {
    points += pointsConfig.points.matchWin;
    
    // Round-specific bonuses
    switch (round) {
      case 'round_of_16':
        points += pointsConfig.points.roundOf16 || 0;
        break;
      case 'quarterfinal':
        points += pointsConfig.points.quarterfinal;
        break;
      case 'semifinal':
        points += pointsConfig.points.semifinal;
        break;
      case 'final':
        points += pointsConfig.points.final;
        if (isChampion) {
          points += pointsConfig.points.champion;
        }
        break;
    }
  }
  
  return points;
}

// Check for bonus points scenarios
function checkBonusPoints(
  playerId: string,
  matchResult: TournamentMatch,
  playerStats: PlayerRanking
): number {
  let bonusPoints = 0;
  
  // Check if won without dropping a set
  if (matchResult.score && matchResult.winner) {
    const winnerTeam = matchResult.winner;
    const winnerSets = winnerTeam === 'team1' ? matchResult.score.team1Sets : matchResult.score.team2Sets;
    const loserSets = winnerTeam === 'team1' ? matchResult.score.team2Sets : matchResult.score.team1Sets;
    
    if (loserSets === 0) {
      bonusPoints += BONUS_POINTS.find(bp => bp.scenario === 'winning_without_dropping_set')?.points || 0;
    }
  }
  
  // Additional bonus point checks would go here
  // - beating_higher_ranked_team
  // - participating_5_tournaments_season
  // - fastest_rise_of_month
  
  return bonusPoints;
}

// Update player ranking after match
function updatePlayerRanking(
  playerId: string,
  lpChange: number,
  tournamentId: string,
  matchId: string,
  isWin: boolean
): void {
  const playerRanking = rankings.find(r => r.playerId === playerId);
  if (!playerRanking) return;
  
  const previousLP = playerRanking.lp;
  playerRanking.lp = Math.max(0, playerRanking.lp + lpChange);
  
  // Update stats
  playerRanking.matchesPlayed += 1;
  if (isWin) {
    playerRanking.currentStreak += 1;
    playerRanking.longestWinStreak = Math.max(playerRanking.longestWinStreak, playerRanking.currentStreak);
  } else {
    playerRanking.currentStreak = 0;
  }
  
  playerRanking.winRate = calculateWinRate(playerId);
  playerRanking.lastMatchDate = new Date().toISOString();
  
  // Check for tier/division promotion
  updateTierAndDivision(playerRanking);
  
  // Create LP transaction record
  const transaction: LPTransaction = {
    id: `lp_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    playerId,
    tournamentId,
    matchId,
    type: isWin ? 'match_win' : 'match_loss',
    lpChange,
    previousLP,
    newLP: playerRanking.lp,
    reason: isWin ? 'Match victory' : 'Match defeat',
    createdAt: new Date().toISOString(),
    isOfficial: true // Set based on tournament type
  };
  
  lpTransactions.push(transaction);
}

// Update tier and division based on LP
function updateTierAndDivision(playerRanking: PlayerRanking): void {
  const currentLP = playerRanking.lp;
  
  for (let i = TIER_REQUIREMENTS.length - 1; i >= 0; i--) {
    const tierReq = TIER_REQUIREMENTS[i];
    
    for (let j = tierReq.divisions.length - 1; j >= 0; j--) {
      const divisionReq = tierReq.divisions[j];
      
      if (currentLP >= divisionReq.lpRequired) {
        playerRanking.tier = tierReq.tier as any;
        playerRanking.division = divisionReq.division as any;
        
        // Calculate LP required for next promotion
        const nextDivisionIndex = j + 1;
        const nextTierIndex = nextDivisionIndex >= tierReq.divisions.length ? i + 1 : i;
        
        if (nextTierIndex < TIER_REQUIREMENTS.length) {
          const nextTier = TIER_REQUIREMENTS[nextTierIndex];
          const nextDivision = nextDivisionIndex >= tierReq.divisions.length ? 
            nextTier.divisions[0] : 
            tierReq.divisions[nextDivisionIndex];
          
          playerRanking.lpRequiredForPromotion = nextDivision.lpRequired - currentLP;
        } else {
          playerRanking.lpRequiredForPromotion = 0; // Already at max tier
        }
        
        return;
      }
    }
  }
}

function calculateWinRate(playerId: string): number {
  // Mock calculation - in real app would query match history
  return Math.floor(Math.random() * 30) + 70; // Random 70-100% for demo
}

// Anti-cheat: Check for LP farming
function checkLPFarming(playerId1: string, playerId2: string): boolean {
  // Check if these players have played more than 6 matches in the last month
  // and one player wins > 84% of the time
  const oneMonthAgo = new Date();
  oneMonthAgo.setMonth(oneMonthAgo.getMonth() - 1);
  
  const recentMatches = matches.filter(match => {
    const matchDate = new Date(match.startTime);
    return matchDate >= oneMonthAgo && 
           ((match.team1.player1 === playerId1 && match.team2.player1 === playerId2) ||
            (match.team1.player1 === playerId2 && match.team2.player1 === playerId1));
  });
  
  if (recentMatches.length >= 6) {
    const player1Wins = recentMatches.filter(match => 
      (match.team1.player1 === playerId1 && match.winner === 'team1') ||
      (match.team2.player1 === playerId1 && match.winner === 'team2')
    ).length;
    
    const winRate = player1Wins / recentMatches.length;
    
    // If either player wins more than 84% of matches, flag as potential farming
    return winRate > 0.84 || (1 - winRate) > 0.84;
  }
  
  return false;
}

// API Endpoints

export const getTournaments: RequestHandler = (req, res) => {
  const { status, type, region } = req.query;
  
  let filteredTournaments = tournaments.filter(t => t.isApproved);
  
  if (status && status !== 'all') {
    filteredTournaments = filteredTournaments.filter(t => t.status === status);
  }
  
  if (type && type !== 'all') {
    filteredTournaments = filteredTournaments.filter(t => t.tournamentType === type);
  }
  
  res.json(filteredTournaments);
};

export const createTournament: RequestHandler = (req, res) => {
  const tournamentData = req.body;
  
  const tournament: Tournament = {
    id: `tournament_${Date.now()}`,
    ...tournamentData,
    currentParticipants: 0,
    status: 'upcoming',
    isApproved: false, // Requires owner approval
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  
  tournaments.push(tournament);
  
  res.status(201).json(tournament);
};

export const getLeaderboard: RequestHandler = (req, res) => {
  const { region, gender, ageGroup, limit = 50 } = req.query;
  
  let filteredRankings = rankings.filter(r => !r.isUnderReview);
  
  if (region && region !== 'all') {
    filteredRankings = filteredRankings.filter(r => r.region === region);
  }
  
  if (gender && gender !== 'all') {
    filteredRankings = filteredRankings.filter(r => r.gender === gender);
  }
  
  if (ageGroup && ageGroup !== 'all') {
    filteredRankings = filteredRankings.filter(r => r.ageGroup === ageGroup);
  }
  
  // Sort by LP (descending), then by tie-breaker rules
  filteredRankings.sort((a, b) => {
    if (b.lp !== a.lp) return b.lp - a.lp;
    if (b.officialTournamentWins !== a.officialTournamentWins) {
      return b.officialTournamentWins - a.officialTournamentWins;
    }
    if (a.matchesPlayed !== b.matchesPlayed) {
      return a.matchesPlayed - b.matchesPlayed; // Fewer matches = higher rank
    }
    return 0; // Additional tie-breakers would go here
  });
  
  const limitNum = parseInt(limit as string);
  const leaderboard = filteredRankings.slice(0, limitNum).map((ranking, index) => ({
    ...ranking,
    rank: index + 1
  }));
  
  res.json(leaderboard);
};

export const recordMatchResult: RequestHandler = (req, res) => {
  const { matchId, winner, score, refereeCode } = req.body;
  
  const match = matches.find(m => m.id === matchId);
  if (!match) {
    return res.status(404).json({ error: 'Match not found' });
  }
  
  // Verify referee code
  if (match.refereeCode !== refereeCode) {
    return res.status(401).json({ error: 'Invalid referee code' });
  }
  
  // Update match result
  match.winner = winner;
  match.score = score;
  match.status = 'completed';
  match.endTime = new Date().toISOString();
  
  // Calculate and award LP
  const tournament = tournaments.find(t => t.id === match.tournamentId);
  if (tournament) {
    const isOfficial = tournament.tournamentType === 'official';
    
    // Get team LP averages (simplified - would calculate team average in real app)
    const team1Players = [match.team1.player1, match.team1.player2];
    const team2Players = [match.team2.player1, match.team2.player2];
    
    const team1LP = team1Players.reduce((sum, playerId) => {
      const ranking = rankings.find(r => r.playerId === playerId);
      return sum + (ranking?.lp || 0);
    }, 0) / team1Players.length;
    
    const team2LP = team2Players.reduce((sum, playerId) => {
      const ranking = rankings.find(r => r.playerId === playerId);
      return sum + (ranking?.lp || 0);
    }, 0) / team2Players.length;
    
    // Calculate LP changes
    const lpChanges = winner === 'team1' 
      ? calculateLPChange(team1LP, team2LP, isOfficial)
      : calculateLPChange(team2LP, team1LP, isOfficial);
    
    // Check for LP farming
    const isFarming = checkLPFarming(match.team1.player1, match.team2.player1);
    
    if (!isFarming) {
      // Award LP to winners
      const winnerPlayers = winner === 'team1' ? team1Players : team2Players;
      const loserPlayers = winner === 'team1' ? team2Players : team1Players;
      
      winnerPlayers.forEach(playerId => {
        updatePlayerRanking(playerId, lpChanges.winnerLP, match.tournamentId, matchId, true);
      });
      
      loserPlayers.forEach(playerId => {
        updatePlayerRanking(playerId, lpChanges.loserLP, match.tournamentId, matchId, false);
      });
      
      // Award advancement points if tournament match
      if (isOfficial) {
        const advancementPoints = calculateAdvancementPoints(
          tournament.bracketSize,
          match.round,
          true,
          match.round === 'final'
        );
        
        if (advancementPoints > 0) {
          winnerPlayers.forEach(playerId => {
            updatePlayerRanking(playerId, advancementPoints, match.tournamentId, matchId, true);
          });
        }
      }
    }
  }
  
  res.json({ success: true, match });
};

export const getPlayerStats: RequestHandler = (req, res) => {
  const { playerId } = req.params;
  
  const ranking = rankings.find(r => r.playerId === playerId);
  if (!ranking) {
    return res.status(404).json({ error: 'Player not found' });
  }
  
  const playerTransactions = lpTransactions
    .filter(t => t.playerId === playerId)
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 20); // Last 20 transactions
  
  res.json({
    ranking,
    recentTransactions: playerTransactions
  });
};
