import { RequestHandler } from "express";
import { 
  Court, 
  Booking, 
  CourtStrike, 
  PlayerWarning, 
  CourtBilling,
  NearExpiringSlot,
  DEFAULT_BOOKING_POLICY
} from "@shared/court";

// Mock database - in real app would use actual database
let courts: Court[] = [];
let bookings: Booking[] = [];
let courtStrikes: CourtStrike[] = [];
let playerWarnings: PlayerWarning[] = [];
let courtBillings: CourtBilling[] = [];

// Policy enforcement functions

function canPlayerBook(playerId: string, newBookingDate: string): { allowed: boolean; reason?: string } {
  const playerBookings = bookings.filter(b => 
    b.playerId === playerId && 
    ['confirmed', 'pending'].includes(b.status)
  );
  
  // Check max active reservations
  if (playerBookings.length >= DEFAULT_BOOKING_POLICY.maxActiveReservations) {
    return { 
      allowed: false, 
      reason: `Maximum ${DEFAULT_BOOKING_POLICY.maxActiveReservations} active reservations reached` 
    };
  }
  
  // Check advance booking limit
  const bookingDate = new Date(newBookingDate);
  const maxAdvanceDate = new Date();
  maxAdvanceDate.setDate(maxAdvanceDate.getDate() + DEFAULT_BOOKING_POLICY.maxAdvanceBookingDays);
  
  if (bookingDate > maxAdvanceDate) {
    return { 
      allowed: false, 
      reason: `Cannot book more than ${DEFAULT_BOOKING_POLICY.maxAdvanceBookingDays} days in advance` 
    };
  }
  
  // Check if player is banned
  const activeWarnings = playerWarnings.filter(w => 
    w.playerId === playerId && 
    w.isActive && 
    w.penalty !== 'warning'
  );
  
  const activeBan = activeWarnings.find(w => {
    if (w.penalty === 'permanent_ban') return true;
    if (w.penalty === 'one_week_ban' && w.penaltyEndDate) {
      return new Date() < new Date(w.penaltyEndDate);
    }
    return false;
  });
  
  if (activeBan) {
    return { 
      allowed: false, 
      reason: activeBan.penalty === 'permanent_ban' ? 'Account permanently banned' : 'Account temporarily banned' 
    };
  }
  
  return { allowed: true };
}

function calculateCancellationPenalty(
  booking: Booking,
  cancellationTime: string,
  cancelledBy: 'player' | 'owner'
): { penalty: string; amount: number; reason: string } {
  const bookingStart = new Date(`${booking.date}T${booking.startTime}`);
  const cancellation = new Date(cancellationTime);
  const hoursUntilStart = (bookingStart.getTime() - cancellation.getTime()) / (1000 * 60 * 60);
  
  if (cancelledBy === 'player') {
    if (hoursUntilStart < DEFAULT_BOOKING_POLICY.cancellationWindowHours) {
      return {
        penalty: 'late_cancellation',
        amount: 0,
        reason: `Cancelled less than ${DEFAULT_BOOKING_POLICY.cancellationWindowHours} hours before start time`
      };
    }
    return { penalty: 'none', amount: 0, reason: 'Cancelled within allowed window' };
  }
  
  // Owner cancellation penalties
  if (hoursUntilStart >= 48) {
    return { penalty: 'none', amount: 0, reason: 'Cancelled 48+ hours in advance' };
  } else if (hoursUntilStart >= 24) {
    return { 
      penalty: '25_percent_voucher', 
      amount: booking.totalAmount * 0.25, 
      reason: 'Cancelled 24-48 hours before start' 
    };
  } else if (hoursUntilStart >= 4) {
    return { 
      penalty: '50_percent_voucher', 
      amount: booking.totalAmount * 0.5, 
      reason: 'Cancelled 4-24 hours before start' 
    };
  } else {
    return { 
      penalty: 'full_refund_plus_credit', 
      amount: booking.totalAmount * 2, 
      reason: 'Cancelled less than 4 hours before start' 
    };
  }
}

function issueStrikeToCourt(
  courtId: string, 
  reason: string, 
  bookingId?: string
): CourtStrike | null {
  const court = courts.find(c => c.id === courtId);
  if (!court) return null;
  
  const strike: CourtStrike = {
    id: `strike_${Date.now()}`,
    courtId,
    reason: reason as any,
    description: reason,
    bookingId,
    penalty: 'warning',
    penaltyStartDate: new Date().toISOString(),
    isActive: true,
    createdAt: new Date().toISOString()
  };
  
  // Count recent strikes
  const sixtyDaysAgo = new Date();
  sixtyDaysAgo.setDate(sixtyDaysAgo.getDate() - 60);
  
  const ninetyDaysAgo = new Date();
  ninetyDaysAgo.setDate(ninetyDaysAgo.getDate() - 90);
  
  const oneEightyDaysAgo = new Date();
  oneEightyDaysAgo.setDate(oneEightyDaysAgo.getDate() - 180);
  
  const recentStrikes = courtStrikes.filter(s => 
    s.courtId === courtId && 
    s.isActive && 
    new Date(s.createdAt) >= oneEightyDaysAgo
  );
  
  const strikesIn60Days = recentStrikes.filter(s => new Date(s.createdAt) >= sixtyDaysAgo).length;
  const strikesIn90Days = recentStrikes.filter(s => new Date(s.createdAt) >= ninetyDaysAgo).length;
  const strikesIn180Days = recentStrikes.length;
  
  // Determine penalty based on strike count
  if (strikesIn180Days >= 5) {
    strike.penalty = 'suspend_until_review';
    court.isActive = false;
  } else if (strikesIn90Days >= 3) {
    strike.penalty = 'suspend_new_bookings';
    strike.penaltyEndDate = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(); // 7 days
  } else if (strikesIn60Days >= 2) {
    strike.penalty = 'lower_ranking';
    strike.penaltyEndDate = new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString(); // 14 days
  }
  
  courtStrikes.push(strike);
  court.strikes = courtStrikes.filter(s => s.courtId === courtId && s.isActive);
  
  return strike;
}

function issueWarningToPlayer(
  playerId: string, 
  bookingId: string, 
  type: string, 
  description: string
): PlayerWarning {
  const warning: PlayerWarning = {
    id: `warning_${Date.now()}`,
    playerId,
    bookingId,
    type: type as any,
    description,
    penalty: 'warning',
    isActive: true,
    createdAt: new Date().toISOString()
  };
  
  // Count recent warnings
  const oneMonthAgo = new Date();
  oneMonthAgo.setMonth(oneMonthAgo.getMonth() - 1);
  
  const recentWarnings = playerWarnings.filter(w => 
    w.playerId === playerId && 
    w.isActive && 
    new Date(w.createdAt) >= oneMonthAgo
  );
  
  // Check if this is second consecutive warning or third in month
  if (recentWarnings.length >= 1) {
    const lastWarning = recentWarnings[recentWarnings.length - 1];
    const isConsecutive = lastWarning.penalty !== 'warning';
    
    if (isConsecutive || recentWarnings.length >= 2) {
      warning.penalty = 'permanent_ban';
    } else {
      warning.penalty = 'one_week_ban';
      warning.penaltyStartDate = new Date().toISOString();
      warning.penaltyEndDate = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();
    }
  }
  
  playerWarnings.push(warning);
  return warning;
}

function calculateCourtBilling(courtId: string, billingPeriodStart: string, billingPeriodEnd: string): CourtBilling {
  const court = courts.find(c => c.id === courtId);
  if (!court) throw new Error('Court not found');
  
  const periodBookings = bookings.filter(b => 
    b.courtId === courtId &&
    b.paymentStatus === 'paid' &&
    b.date >= billingPeriodStart &&
    b.date <= billingPeriodEnd
  );
  
  const totalProfit = periodBookings.reduce((sum, booking) => sum + booking.totalAmount, 0);
  
  let amountDue: number;
  if (court.subscriptionType === 'percentage') {
    const rate = court.subscriptionDetails.percentageRate || 0.1;
    amountDue = totalProfit * rate;
  } else {
    amountDue = court.subscriptionDetails.fixedRate || 5000;
  }
  
  const billing: CourtBilling = {
    id: `billing_${Date.now()}`,
    courtId,
    billingPeriodStart,
    billingPeriodEnd,
    subscriptionType: court.subscriptionType,
    totalReservations: periodBookings.length,
    totalProfit,
    amountDue,
    paymentStatus: 'pending',
    reservationDetails: periodBookings.map(b => ({
      bookingId: b.id,
      amount: b.totalAmount,
      bookingDate: b.date
    })),
    createdAt: new Date().toISOString()
  };
  
  return billing;
}

// API Endpoints

export const getCourts: RequestHandler = (req, res) => {
  const { location, date, minRating, maxPrice } = req.query;
  
  let filteredCourts = courts.filter(c => c.isActive && c.isApproved);
  
  if (location && location !== 'all') {
    filteredCourts = filteredCourts.filter(c => 
      c.location.city.toLowerCase().includes((location as string).toLowerCase())
    );
  }
  
  if (minRating) {
    filteredCourts = filteredCourts.filter(c => c.rating >= parseFloat(minRating as string));
  }
  
  if (maxPrice) {
    filteredCourts = filteredCourts.filter(c => c.hourlyRate <= parseFloat(maxPrice as string));
  }
  
  // Add availability info if date provided
  if (date) {
    filteredCourts = filteredCourts.map(court => ({
      ...court,
      availableSlots: [] // Would calculate actual availability based on bookings
    }));
  }
  
  res.json(filteredCourts);
};

export const createBooking: RequestHandler = (req, res) => {
  const { courtId, playerId, date, startTime, endTime, duration } = req.body;
  
  // Validate player can book
  const canBook = canPlayerBook(playerId, date);
  if (!canBook.allowed) {
    return res.status(400).json({ error: canBook.reason });
  }
  
  const court = courts.find(c => c.id === courtId);
  if (!court) {
    return res.status(404).json({ error: 'Court not found' });
  }
  
  // Check slot availability
  const existingBooking = bookings.find(b => 
    b.courtId === courtId &&
    b.date === date &&
    b.startTime === startTime &&
    ['confirmed', 'pending'].includes(b.status)
  );
  
  if (existingBooking) {
    return res.status(400).json({ error: 'Time slot not available' });
  }
  
  const totalAmount = court.hourlyRate * duration;
  
  const booking: Booking = {
    id: `booking_${Date.now()}`,
    courtId,
    playerId,
    playerDetails: {
      name: 'Player Name', // Would get from user profile
      phone: '+1234567890',
      email: 'player@example.com'
    },
    date,
    startTime,
    endTime,
    duration,
    totalAmount,
    status: 'pending',
    paymentStatus: 'pending',
    bookingTime: new Date().toISOString(),
    qrCode: `qr_${Date.now()}`,
    playerWarnings: [],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  
  bookings.push(booking);
  
  res.status(201).json(booking);
};

export const cancelBooking: RequestHandler = (req, res) => {
  const { bookingId } = req.params;
  const { cancelledBy, reason } = req.body;
  
  const booking = bookings.find(b => b.id === bookingId);
  if (!booking) {
    return res.status(404).json({ error: 'Booking not found' });
  }
  
  const cancellationTime = new Date().toISOString();
  const penalty = calculateCancellationPenalty(booking, cancellationTime, cancelledBy);
  
  // Update booking
  booking.status = cancelledBy === 'player' ? 'cancelled_by_player' : 'cancelled_by_owner';
  booking.cancellationReason = reason;
  booking.cancellationTime = cancellationTime;
  booking.updatedAt = cancellationTime;
  
  if (cancelledBy === 'player' && penalty.penalty === 'late_cancellation') {
    // Issue warning to player
    const warning = issueWarningToPlayer(
      booking.playerId,
      bookingId,
      'late_cancellation',
      'Cancelled booking less than 24 hours before start time'
    );
    booking.playerWarnings.push(warning);
  } else if (cancelledBy === 'owner' && penalty.penalty !== 'none') {
    // Issue strike to court and set compensation
    const strike = issueStrikeToCourt(
      booking.courtId,
      `Late cancellation: ${reason}`,
      bookingId
    );
    
    booking.ownerCancellationPenalty = {
      type: penalty.penalty as any,
      amount: penalty.amount,
      reason: penalty.reason
    };
    
    // Process refund/compensation
    booking.paymentStatus = 'refunded';
  }
  
  res.json({ booking, penalty });
};

export const getNearExpiringSlots: RequestHandler = (req, res) => {
  const { location, maxHours = 24 } = req.query;
  
  const now = new Date();
  const maxExpiryTime = new Date(now.getTime() + (parseInt(maxHours as string) * 60 * 60 * 1000));
  
  // Mock data for near-expiring slots
  const nearExpiringSlots: NearExpiringSlot[] = courts
    .filter(court => {
      if (location && location !== 'all') {
        return court.location.city.toLowerCase().includes((location as string).toLowerCase());
      }
      return true;
    })
    .flatMap(court => {
      // Generate mock expiring slots
      return [{
        courtId: court.id,
        courtName: court.name,
        date: now.toISOString().split('T')[0],
        startTime: '18:00',
        endTime: '20:00',
        originalPrice: court.hourlyRate * 2,
        salePrice: Math.floor(court.hourlyRate * 2 * 0.7),
        discountPercentage: 30,
        hoursUntilExpiry: Math.floor(Math.random() * 12) + 1,
        location: court.location.address
      }];
    });
  
  res.json(nearExpiringSlots);
};

export const getCourtBilling: RequestHandler = (req, res) => {
  const { courtId, month, year } = req.query;
  
  if (!courtId || !month || !year) {
    return res.status(400).json({ error: 'Court ID, month and year are required' });
  }
  
  const billingStart = `${year}-${month.toString().padStart(2, '0')}-01`;
  const nextMonth = parseInt(month as string) === 12 ? 1 : parseInt(month as string) + 1;
  const nextYear = parseInt(month as string) === 12 ? parseInt(year as string) + 1 : parseInt(year as string);
  const billingEnd = `${nextYear}-${nextMonth.toString().padStart(2, '0')}-01`;
  
  try {
    const billing = calculateCourtBilling(courtId as string, billingStart, billingEnd);
    res.json(billing);
  } catch (error) {
    res.status(404).json({ error: (error as Error).message });
  }
};

export const getPlayerBookings: RequestHandler = (req, res) => {
  const { playerId } = req.params;
  const { status } = req.query;
  
  let playerBookings = bookings.filter(b => b.playerId === playerId);
  
  if (status && status !== 'all') {
    playerBookings = playerBookings.filter(b => b.status === status);
  }
  
  // Sort by date (newest first)
  playerBookings.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  
  res.json(playerBookings);
};

export const createCourt: RequestHandler = (req, res) => {
  const courtData = req.body;
  
  const court: Court = {
    id: `court_${Date.now()}`,
    ...courtData,
    rating: 0,
    reviewCount: 0,
    isActive: true,
    isApproved: false, // Requires owner approval
    cancellationRate: 0,
    emergencyCancellationsUsed: 0,
    strikes: [],
    badges: [],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  
  courts.push(court);
  
  res.status(201).json(court);
};
