import { RequestHandler } from "express";
import { 
  User, 
  UserProfile, 
  RegisterData, 
  LoginCredentials,
  AuthResponse,
  ROLE_PERMISSIONS,
  VALIDATION_RULES,
  DuplicateAccountCheck,
  RoleAssignment,
  UserBan
} from "@shared/auth";
import crypto from "crypto";
import jwt from "jsonwebtoken";

// Mock database - in real app would use actual database
let users: User[] = [];
let roleAssignments: RoleAssignment[] = [];
let userBans: UserBan[] = [];

// JWT secret - in production this would be in environment variables
const JWT_SECRET = process.env.JWT_SECRET || "padelo_secret_key_change_in_production";
const JWT_REFRESH_SECRET = process.env.JWT_REFRESH_SECRET || "padelo_refresh_secret_change_in_production";

// Utility functions
function hashPassword(password: string): string {
  return crypto.createHash('sha256').update(password + 'padelo_salt').digest('hex');
}

function verifyPassword(password: string, hash: string): boolean {
  return hashPassword(password) === hash;
}

function generateToken(userId: string, type: 'access' | 'refresh' = 'access'): string {
  const secret = type === 'access' ? JWT_SECRET : JWT_REFRESH_SECRET;
  const expiresIn = type === 'access' ? '24h' : '7d';
  
  return jwt.sign({ userId, type }, secret, { expiresIn });
}

function verifyToken(token: string, type: 'access' | 'refresh' = 'access'): { userId: string } {
  const secret = type === 'access' ? JWT_SECRET : JWT_REFRESH_SECRET;
  return jwt.verify(token, secret) as { userId: string };
}

function validateRegisterData(data: RegisterData): { isValid: boolean; errors: string[] } {
  const errors: string[] = [];

  // Username validation
  if (!VALIDATION_RULES.username.pattern.test(data.username)) {
    errors.push(VALIDATION_RULES.username.message);
  }

  // Password validation
  if (!VALIDATION_RULES.password.pattern.test(data.password)) {
    errors.push(VALIDATION_RULES.password.message);
  }

  // Password confirmation
  if (data.password !== data.confirmPassword) {
    errors.push('Passwords do not match');
  }

  // Phone number validation
  if (!VALIDATION_RULES.phoneNumber.pattern.test(data.phoneNumber)) {
    errors.push(VALIDATION_RULES.phoneNumber.message);
  }

  // Email validation (if provided)
  if (data.email && !VALIDATION_RULES.email.pattern.test(data.email)) {
    errors.push(VALIDATION_RULES.email.message);
  }

  return { isValid: errors.length === 0, errors };
}

function checkDuplicateAccount(phoneNumber: string, email?: string): DuplicateAccountCheck {
  const existingUser = users.find(u => 
    u.phoneNumber === phoneNumber || 
    (email && u.email === email)
  );

  return {
    phoneNumber,
    existingAccountId: existingUser?.id,
    isDuplicate: !!existingUser,
    confidence: existingUser ? 100 : 0
  };
}

function isUserBanned(userId: string): { banned: boolean; reason?: string; expiryDate?: string } {
  const activeBan = userBans.find(ban => 
    ban.userId === userId && 
    ban.isActive && 
    (ban.duration === 'permanent' || !ban.expiryDate || new Date(ban.expiryDate) > new Date())
  );

  return {
    banned: !!activeBan,
    reason: activeBan?.reason,
    expiryDate: activeBan?.expiryDate
  };
}

function sanitizeUser(user: User): Omit<User, 'password'> {
  const { password, ...sanitized } = user;
  return sanitized;
}

// Middleware for authentication
export const authenticateToken: RequestHandler = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1]; // Bearer TOKEN

  if (!token) {
    return res.status(401).json({ error: 'Access token required' });
  }

  try {
    const decoded = verifyToken(token);
    const user = users.find(u => u.id === decoded.userId);
    
    if (!user) {
      return res.status(401).json({ error: 'Invalid token' });
    }

    // Check if user is banned
    const banStatus = isUserBanned(user.id);
    if (banStatus.banned) {
      return res.status(403).json({ 
        error: 'Account banned', 
        reason: banStatus.reason,
        expiryDate: banStatus.expiryDate 
      });
    }

    req.user = sanitizeUser(user);
    next();
  } catch (error) {
    return res.status(403).json({ error: 'Invalid token' });
  }
};

// Routes

export const register: RequestHandler = (req, res) => {
  const registerData: RegisterData = req.body;

  // Validate input data
  const validation = validateRegisterData(registerData);
  if (!validation.isValid) {
    return res.status(400).json({ 
      error: 'Validation failed', 
      details: validation.errors 
    });
  }

  // Check for duplicate accounts
  const duplicateCheck = checkDuplicateAccount(registerData.phoneNumber, registerData.email);
  if (duplicateCheck.isDuplicate) {
    return res.status(409).json({ 
      error: 'Account already exists with this phone number or email' 
    });
  }

  // Create new user
  const user: User = {
    id: `user_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
    username: registerData.username,
    email: registerData.email,
    phoneNumber: registerData.phoneNumber,
    password: hashPassword(registerData.password),
    role: 'player', // Default role
    profile: {
      firstName: registerData.profile.firstName,
      lastName: registerData.profile.lastName,
      preferredHand: registerData.profile.preferredHand,
      preferredCourtPosition: registerData.profile.preferredCourtPosition,
      gender: registerData.profile.gender,
      location: {
        city: registerData.profile.city,
        country: registerData.profile.country
      },
      preferences: {
        language: registerData.profile.language,
        notifications: {
          email: true,
          push: true,
          sms: false
        },
        privacy: {
          showEmail: false,
          showPhone: false,
          showLocation: true
        }
      }
    },
    isActive: true,
    isBanned: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    loginAttempts: 0,
    isVerified: false
  };

  users.push(user);

  // Generate tokens
  const token = generateToken(user.id);
  const refreshToken = generateToken(user.id, 'refresh');

  const response: AuthResponse = {
    user: sanitizeUser(user),
    token,
    refreshToken,
    permissions: ROLE_PERMISSIONS[user.role]
  };

  res.status(201).json(response);
};

export const login: RequestHandler = (req, res) => {
  const { phoneOrEmail, password }: LoginCredentials = req.body;

  if (!phoneOrEmail || !password) {
    return res.status(400).json({ error: 'Phone/email and password are required' });
  }

  // Find user by phone or email
  const user = users.find(u => 
    u.phoneNumber === phoneOrEmail || u.email === phoneOrEmail
  );

  if (!user) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }

  // Check if user is banned
  const banStatus = isUserBanned(user.id);
  if (banStatus.banned) {
    return res.status(403).json({ 
      error: 'Account banned', 
      reason: banStatus.reason,
      expiryDate: banStatus.expiryDate 
    });
  }

  // Verify password
  if (!verifyPassword(password, user.password!)) {
    // Increment login attempts
    user.loginAttempts += 1;
    user.updatedAt = new Date().toISOString();

    // Temporary lockout after 5 failed attempts
    if (user.loginAttempts >= 5) {
      return res.status(429).json({ 
        error: 'Too many failed login attempts. Please try again later.' 
      });
    }

    return res.status(401).json({ error: 'Invalid credentials' });
  }

  // Reset login attempts on successful login
  user.loginAttempts = 0;
  user.lastLoginAt = new Date().toISOString();
  user.updatedAt = new Date().toISOString();

  // Generate tokens
  const token = generateToken(user.id);
  const refreshToken = generateToken(user.id, 'refresh');

  const response: AuthResponse = {
    user: sanitizeUser(user),
    token,
    refreshToken,
    permissions: ROLE_PERMISSIONS[user.role]
  };

  res.json(response);
};

export const validateToken: RequestHandler = (req, res) => {
  // This route uses the authenticateToken middleware
  const user = req.user;
  if (!user) {
    return res.status(401).json({ error: 'Invalid token' });
  }

  res.json({
    user,
    permissions: ROLE_PERMISSIONS[user.role]
  });
};

export const logout: RequestHandler = (req, res) => {
  // In a real app, you might want to blacklist the token
  res.json({ message: 'Logged out successfully' });
};

export const updateProfile: RequestHandler = (req, res) => {
  const user = req.user;
  if (!user) {
    return res.status(401).json({ error: 'Not authenticated' });
  }

  const profileUpdates: Partial<UserProfile> = req.body;
  const userRecord = users.find(u => u.id === user.id);
  
  if (!userRecord) {
    return res.status(404).json({ error: 'User not found' });
  }

  // Update profile
  userRecord.profile = { ...userRecord.profile, ...profileUpdates };
  userRecord.updatedAt = new Date().toISOString();

  res.json(sanitizeUser(userRecord));
};

export const changePassword: RequestHandler = (req, res) => {
  const user = req.user;
  if (!user) {
    return res.status(401).json({ error: 'Not authenticated' });
  }

  const { currentPassword, newPassword, confirmPassword } = req.body;

  if (!currentPassword || !newPassword || !confirmPassword) {
    return res.status(400).json({ error: 'All password fields are required' });
  }

  if (newPassword !== confirmPassword) {
    return res.status(400).json({ error: 'New passwords do not match' });
  }

  // Validate new password
  if (!VALIDATION_RULES.password.pattern.test(newPassword)) {
    return res.status(400).json({ error: VALIDATION_RULES.password.message });
  }

  const userRecord = users.find(u => u.id === user.id);
  if (!userRecord || !verifyPassword(currentPassword, userRecord.password!)) {
    return res.status(401).json({ error: 'Current password is incorrect' });
  }

  // Update password
  userRecord.password = hashPassword(newPassword);
  userRecord.updatedAt = new Date().toISOString();

  res.json({ message: 'Password changed successfully' });
};

export const assignRole: RequestHandler = (req, res) => {
  const assignerUser = req.user;
  if (!assignerUser || assignerUser.role !== 'owner') {
    return res.status(403).json({ error: 'Only owners can assign roles' });
  }

  const { userId, newRole, reason }: { userId: string; newRole: string; reason: string } = req.body;

  const targetUser = users.find(u => u.id === userId);
  if (!targetUser) {
    return res.status(404).json({ error: 'User not found' });
  }

  const oldRole = targetUser.role;
  targetUser.role = newRole as any;
  targetUser.updatedAt = new Date().toISOString();

  // Create role assignment record
  const assignment: RoleAssignment = {
    id: `role_${Date.now()}`,
    assignerId: assignerUser.id,
    userId,
    oldRole,
    newRole: newRole as any,
    reason,
    assignedAt: new Date().toISOString()
  };

  roleAssignments.push(assignment);

  res.json({
    user: sanitizeUser(targetUser),
    assignment
  });
};

export const banUser: RequestHandler = (req, res) => {
  const bannerUser = req.user;
  if (!bannerUser || bannerUser.role !== 'owner') {
    return res.status(403).json({ error: 'Only owners can ban users' });
  }

  const { userId, reason, duration, expiryDate }: { 
    userId: string; 
    reason: string; 
    duration: 'temporary' | 'permanent'; 
    expiryDate?: string;
  } = req.body;

  const targetUser = users.find(u => u.id === userId);
  if (!targetUser) {
    return res.status(404).json({ error: 'User not found' });
  }

  // Deactivate previous bans for this user
  userBans.forEach(ban => {
    if (ban.userId === userId) {
      ban.isActive = false;
    }
  });

  // Create new ban
  const ban: UserBan = {
    id: `ban_${Date.now()}`,
    bannerId: bannerUser.id,
    userId,
    reason,
    duration,
    expiryDate,
    isActive: true,
    createdAt: new Date().toISOString()
  };

  userBans.push(ban);

  // Update user record
  targetUser.isBanned = true;
  targetUser.banReason = reason;
  targetUser.banExpiryDate = expiryDate;
  targetUser.updatedAt = new Date().toISOString();

  res.json({
    user: sanitizeUser(targetUser),
    ban
  });
};

export const getUsers: RequestHandler = (req, res) => {
  const user = req.user;
  if (!user || user.role !== 'owner') {
    return res.status(403).json({ error: 'Only owners can view all users' });
  }

  const { role, status, limit = 50, offset = 0 } = req.query;

  let filteredUsers = users.map(sanitizeUser);

  if (role && role !== 'all') {
    filteredUsers = filteredUsers.filter(u => u.role === role);
  }

  if (status && status !== 'all') {
    if (status === 'active') {
      filteredUsers = filteredUsers.filter(u => u.isActive && !u.isBanned);
    } else if (status === 'banned') {
      filteredUsers = filteredUsers.filter(u => u.isBanned);
    } else if (status === 'inactive') {
      filteredUsers = filteredUsers.filter(u => !u.isActive);
    }
  }

  const limitNum = parseInt(limit as string);
  const offsetNum = parseInt(offset as string);
  const paginatedUsers = filteredUsers.slice(offsetNum, offsetNum + limitNum);

  res.json({
    users: paginatedUsers,
    total: filteredUsers.length,
    limit: limitNum,
    offset: offsetNum
  });
};

// Add type declaration for Express Request
declare global {
  namespace Express {
    interface Request {
      user?: Omit<User, 'password'>;
    }
  }
}
