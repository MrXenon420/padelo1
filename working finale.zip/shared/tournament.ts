export interface Tournament {
  id: string;
  name: string;
  description: string;
  location: string;
  startDate: string;
  endDate: string;
  entryFee: number;
  maxParticipants: number;
  currentParticipants: number;
  tournamentType: 'official' | 'unofficial';
  bracketSize: 8 | 16 | 32;
  status: 'upcoming' | 'ongoing' | 'completed' | 'cancelled';
  organizerId: string;
  organizerRole: 'owner' | 'court_owner' | 'tournament_organizer';
  prizes: {
    first: number;
    second: number;
    third: number;
  };
  image?: string;
  rules: string;
  createdAt: string;
  updatedAt: string;
  isApproved: boolean; // For owner approval
}

export interface TournamentMatch {
  id: string;
  tournamentId: string;
  round: 'round_of_32' | 'round_of_16' | 'quarterfinal' | 'semifinal' | 'final';
  team1: {
    player1: string;
    player2: string;
  };
  team2: {
    player1: string;
    player2: string;
  };
  winner?: 'team1' | 'team2';
  score?: {
    team1Sets: number;
    team2Sets: number;
    sets: Array<{
      team1Games: number;
      team2Games: number;
    }>;
  };
  lpAwarded?: number;
  qrCode: string; // For match verification
  refereeCode?: string; // One-time code for result confirmation
  startTime: string;
  endTime?: string;
  courtId: string;
  status: 'scheduled' | 'in_progress' | 'completed' | 'cancelled';
}

export interface PlayerRanking {
  playerId: string;
  tier: 'rookie' | 'beginner' | 'intermediate' | 'advanced' | 'elite' | 'master' | 'pro_players';
  division: 1 | 2 | 3 | 4; // Division I to Division IV
  lp: number; // League Points
  lpRequiredForPromotion: number;
  officialTournamentWins: number;
  matchesPlayed: number;
  winRate: number;
  currentStreak: number;
  longestWinStreak: number;
  totalTournamentsPlayed: number;
  sportsmanshipRating: number; // 1-5 scale
  isUnderReview: boolean;
  lastMatchDate: string;
  inactivityPenaltyDate?: string;
  bonusPoints: number;
  achievements: string[];
  region: string;
  ageGroup: string;
  gender: 'male' | 'female' | 'other';
}

export interface LPTransaction {
  id: string;
  playerId: string;
  tournamentId?: string;
  matchId?: string;
  type: 'match_win' | 'match_loss' | 'tournament_win' | 'advancement' | 'bonus' | 'penalty' | 'inactivity';
  lpChange: number;
  previousLP: number;
  newLP: number;
  reason: string;
  createdAt: string;
  isOfficial: boolean; // true for official tournaments, false for unofficial
}

export interface TierRequirements {
  tier: string;
  divisions: {
    division: number;
    lpRequired: number;
  }[];
  lpGainMultiplier: number; // Higher tiers gain more LP
  lpLossMultiplier: number; // Higher tiers lose less LP
}

export const TIER_REQUIREMENTS: TierRequirements[] = [
  {
    tier: 'rookie',
    divisions: [
      { division: 4, lpRequired: 0 },
      { division: 3, lpRequired: 100 },
      { division: 2, lpRequired: 200 },
      { division: 1, lpRequired: 300 }
    ],
    lpGainMultiplier: 1.0,
    lpLossMultiplier: 1.0
  },
  {
    tier: 'beginner',
    divisions: [
      { division: 4, lpRequired: 400 },
      { division: 3, lpRequired: 700 },
      { division: 2, lpRequired: 1000 },
      { division: 1, lpRequired: 1300 }
    ],
    lpGainMultiplier: 1.1,
    lpLossMultiplier: 0.9
  },
  {
    tier: 'intermediate',
    divisions: [
      { division: 4, lpRequired: 1600 },
      { division: 3, lpRequired: 2100 },
      { division: 2, lpRequired: 2600 },
      { division: 1, lpRequired: 3100 }
    ],
    lpGainMultiplier: 1.2,
    lpLossMultiplier: 0.8
  },
  {
    tier: 'advanced',
    divisions: [
      { division: 4, lpRequired: 3600 },
      { division: 3, lpRequired: 4300 },
      { division: 2, lpRequired: 5000 },
      { division: 1, lpRequired: 5700 }
    ],
    lpGainMultiplier: 1.3,
    lpLossMultiplier: 0.7
  },
  {
    tier: 'elite',
    divisions: [
      { division: 4, lpRequired: 6400 },
      { division: 3, lpRequired: 7400 },
      { division: 2, lpRequired: 8400 },
      { division: 1, lpRequired: 9400 }
    ],
    lpGainMultiplier: 1.4,
    lpLossMultiplier: 0.6
  },
  {
    tier: 'master',
    divisions: [
      { division: 4, lpRequired: 10400 },
      { division: 3, lpRequired: 11900 },
      { division: 2, lpRequired: 13400 },
      { division: 1, lpRequired: 14900 }
    ],
    lpGainMultiplier: 1.5,
    lpLossMultiplier: 0.5
  },
  {
    tier: 'pro_players',
    divisions: [
      { division: 1, lpRequired: 16400 } // Invite only
    ],
    lpGainMultiplier: 1.6,
    lpLossMultiplier: 0.4
  }
];

export interface TournamentAdvancementPoints {
  bracketSize: 8 | 16 | 32;
  points: {
    matchWin: number;
    roundOf16?: number;
    quarterfinal: number;
    semifinal: number;
    final: number;
    champion: number;
  };
}

export const ADVANCEMENT_POINTS: TournamentAdvancementPoints[] = [
  {
    bracketSize: 32,
    points: {
      matchWin: 1,
      roundOf16: 4,
      quarterfinal: 4,
      semifinal: 4,
      final: 4,
      champion: 10
    }
  },
  {
    bracketSize: 16,
    points: {
      matchWin: 1,
      quarterfinal: 4,
      semifinal: 4,
      final: 4,
      champion: 10
    }
  },
  {
    bracketSize: 8,
    points: {
      matchWin: 1,
      semifinal: 4,
      final: 4,
      champion: 10
    }
  }
];

export interface BonusPoints {
  scenario: string;
  points: number;
}

export const BONUS_POINTS: BonusPoints[] = [
  { scenario: 'winning_without_dropping_set', points: 20 },
  { scenario: 'beating_higher_ranked_team', points: 15 },
  { scenario: 'participating_5_tournaments_season', points: 50 },
  { scenario: 'fastest_rise_of_month', points: 25 }
];
