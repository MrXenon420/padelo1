export interface Court {
  id: string;
  name: string;
  description: string;
  location: {
    address: string;
    city: string;
    coordinates: {
      lat: number;
      lng: number;
    };
  };
  ownerId: string;
  images: string[];
  amenities: string[];
  hourlyRate: number;
  subscriptionType: 'percentage' | 'fixed';
  subscriptionDetails: {
    percentageRate?: number; // Default 10%
    fixedRate?: number; // Default 5000 EGP
    subscriptionStartDate: string;
    subscriptionEndDate?: string;
  };
  rating: number;
  reviewCount: number;
  isActive: boolean;
  isApproved: boolean; // For owner approval
  cancellationRate: number;
  lastCancellationDate?: string;
  emergencyCancellationsUsed: number; // Max 2 per 6 months
  strikes: CourtStrike[];
  badges: string[]; // e.g., "Reliable Court"
  availabilitySchedule: WeeklySchedule;
  createdAt: string;
  updatedAt: string;
}

export interface CourtStrike {
  id: string;
  courtId: string;
  reason: 'late_cancellation' | 'no_show' | 'poor_conditions' | 'policy_violation';
  description: string;
  bookingId?: string;
  penalty: 'warning' | 'lower_ranking' | 'suspend_new_bookings' | 'suspend_until_review';
  penaltyStartDate: string;
  penaltyEndDate?: string;
  isActive: boolean;
  createdAt: string;
}

export interface WeeklySchedule {
  monday: DaySchedule;
  tuesday: DaySchedule;
  wednesday: DaySchedule;
  thursday: DaySchedule;
  friday: DaySchedule;
  saturday: DaySchedule;
  sunday: DaySchedule;
}

export interface DaySchedule {
  isAvailable: boolean;
  slots: TimeSlot[];
}

export interface TimeSlot {
  startTime: string; // "09:00"
  endTime: string; // "10:00"
  isAvailable: boolean;
  price?: number; // Override default hourly rate
  isOnSale?: boolean;
  salePrice?: number;
  salePercentage?: number;
}

export interface Booking {
  id: string;
  courtId: string;
  playerId: string;
  playerDetails: {
    name: string;
    phone: string;
    email: string;
  };
  date: string; // "2024-03-15"
  startTime: string; // "14:00"
  endTime: string; // "16:00"
  duration: number; // hours
  totalAmount: number;
  status: 'pending' | 'confirmed' | 'completed' | 'cancelled_by_player' | 'cancelled_by_owner' | 'no_show';
  cancellationReason?: string;
  cancellationTime?: string;
  paymentStatus: 'pending' | 'paid' | 'refunded' | 'partial_refund';
  bookingTime: string; // When booking was made
  qrCode: string; // For court access
  playerWarnings: PlayerWarning[];
  ownerCancellationPenalty?: {
    type: 'no_penalty' | 'discount_voucher_25' | 'discount_voucher_50' | 'full_refund_plus_credit';
    amount: number;
    reason: string;
  };
  createdAt: string;
  updatedAt: string;
}

export interface PlayerWarning {
  id: string;
  playerId: string;
  bookingId: string;
  type: 'late_cancellation' | 'no_show' | 'property_damage' | 'dispute';
  description: string;
  penalty: 'warning' | 'one_week_ban' | 'permanent_ban';
  penaltyStartDate?: string;
  penaltyEndDate?: string;
  isActive: boolean;
  createdAt: string;
}

export interface CourtBilling {
  id: string;
  courtId: string;
  billingPeriodStart: string;
  billingPeriodEnd: string;
  subscriptionType: 'percentage' | 'fixed';
  totalReservations: number;
  totalProfit: number; // Sum of all paid reservations
  amountDue: number; // Either commission or fixed fee
  paymentStatus: 'pending' | 'paid' | 'overdue';
  paymentDate?: string;
  reservationDetails: {
    bookingId: string;
    amount: number;
    bookingDate: string;
  }[];
  createdAt: string;
}

export interface BookingPolicy {
  // Player policies
  maxAdvanceBookingDays: number; // 7 days
  maxActiveReservations: number; // 4
  cancellationWindowHours: number; // 24 hours
  arrivalWindowMinutes: number; // 10 minutes before
  
  // Court owner policies
  ownerCancellationPolicies: {
    noRestriction: { minHours: 48, penalty: 'none' };
    discountVoucher25: { minHours: 24, maxHours: 48, penalty: '25_percent_voucher' };
    discountVoucher50: { minHours: 4, maxHours: 24, penalty: '50_percent_voucher' };
    fullRefundCredit: { maxHours: 4, penalty: 'full_refund_plus_credit' };
  };
  
  // Strike system
  maxStrikesBeforeSuspension: {
    warning: 1;
    lowerRanking: 2; // in 60 days
    suspendBookings: 3; // in 90 days
    suspendUntilReview: 5; // in 180 days
  };
  
  emergencyCancellationsPerSixMonths: number; // 2
  reliableCourtBadgeRequirement: number; // 0 cancellations in 90 days
}

export const DEFAULT_BOOKING_POLICY: BookingPolicy = {
  maxAdvanceBookingDays: 7,
  maxActiveReservations: 4,
  cancellationWindowHours: 24,
  arrivalWindowMinutes: 10,
  ownerCancellationPolicies: {
    noRestriction: { minHours: 48, penalty: 'none' },
    discountVoucher25: { minHours: 24, maxHours: 48, penalty: '25_percent_voucher' },
    discountVoucher50: { minHours: 4, maxHours: 24, penalty: '50_percent_voucher' },
    fullRefundCredit: { maxHours: 4, penalty: 'full_refund_plus_credit' }
  },
  maxStrikesBeforeSuspension: {
    warning: 1,
    lowerRanking: 2,
    suspendBookings: 3,
    suspendUntilReview: 5
  },
  emergencyCancellationsPerSixMonths: 2,
  reliableCourtBadgeRequirement: 0
};

export interface NearExpiringSlot {
  courtId: string;
  courtName: string;
  date: string;
  startTime: string;
  endTime: string;
  originalPrice: number;
  salePrice: number;
  discountPercentage: number;
  hoursUntilExpiry: number;
  location: string;
}
