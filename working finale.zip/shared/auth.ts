export interface User {
  id: string;
  username: string;
  email?: string;
  phoneNumber: string;
  password?: string; // Not returned in API responses
  role: UserRole;
  profile: UserProfile;
  isActive: boolean;
  isBanned: boolean;
  banReason?: string;
  banExpiryDate?: string;
  createdAt: string;
  updatedAt: string;
  lastLoginAt?: string;
  loginAttempts: number;
  isVerified: boolean;
  verificationCode?: string;
  resetPasswordToken?: string;
  resetPasswordExpiry?: string;
}

export type UserRole = 'owner' | 'court_owner' | 'tournament_organizer' | 'coach' | 'player';

export interface UserProfile {
  firstName: string;
  lastName: string;
  dateOfBirth?: string;
  gender: 'male' | 'female' | 'other';
  preferredHand: 'left' | 'right';
  preferredCourtPosition: 'left' | 'right' | 'both';
  profilePicture?: string;
  bio?: string;
  location: {
    city: string;
    country: string;
    coordinates?: {
      lat: number;
      lng: number;
    };
  };
  socialMedia?: {
    instagram?: string;
    facebook?: string;
    twitter?: string;
  };
  preferences: {
    language: 'en' | 'ar';
    notifications: {
      email: boolean;
      push: boolean;
      sms: boolean;
    };
    privacy: {
      showEmail: boolean;
      showPhone: boolean;
      showLocation: boolean;
    };
  };
}

export interface UserPermissions {
  canCreateTournaments: boolean;
  canManageCourts: boolean;
  canAssignRoles: boolean;
  canBanUsers: boolean;
  canViewAllBookings: boolean;
  canViewBilling: boolean;
  canResponseToSupport: boolean;
  canModerateCommunity: boolean;
  canPostTraining: boolean;
  canSellMarketplace: boolean;
  canAccessAdminPanel: boolean;
}

export const ROLE_PERMISSIONS: Record<UserRole, UserPermissions> = {
  owner: {
    canCreateTournaments: true,
    canManageCourts: true,
    canAssignRoles: true,
    canBanUsers: true,
    canViewAllBookings: true,
    canViewBilling: true,
    canResponseToSupport: true,
    canModerateCommunity: true,
    canPostTraining: true,
    canSellMarketplace: true,
    canAccessAdminPanel: true,
  },
  court_owner: {
    canCreateTournaments: true,
    canManageCourts: true, // Only their own courts
    canAssignRoles: false,
    canBanUsers: false,
    canViewAllBookings: false, // Only their court bookings
    canViewBilling: false, // Only their billing
    canResponseToSupport: false,
    canModerateCommunity: false,
    canPostTraining: true,
    canSellMarketplace: true,
    canAccessAdminPanel: false,
  },
  tournament_organizer: {
    canCreateTournaments: true,
    canManageCourts: false,
    canAssignRoles: false,
    canBanUsers: false,
    canViewAllBookings: false,
    canViewBilling: false,
    canResponseToSupport: false,
    canModerateCommunity: false,
    canPostTraining: true,
    canSellMarketplace: true,
    canAccessAdminPanel: false,
  },
  coach: {
    canCreateTournaments: false,
    canManageCourts: false,
    canAssignRoles: false,
    canBanUsers: false,
    canViewAllBookings: false,
    canViewBilling: false,
    canResponseToSupport: false,
    canModerateCommunity: false,
    canPostTraining: true,
    canSellMarketplace: true,
    canAccessAdminPanel: false,
  },
  player: {
    canCreateTournaments: false,
    canManageCourts: false,
    canAssignRoles: false,
    canBanUsers: false,
    canViewAllBookings: false,
    canViewBilling: false,
    canResponseToSupport: false,
    canModerateCommunity: false,
    canPostTraining: false,
    canSellMarketplace: true,
    canAccessAdminPanel: false,
  },
};

export interface AuthResponse {
  user: Omit<User, 'password'>;
  token: string;
  refreshToken: string;
  permissions: UserPermissions;
}

export interface LoginCredentials {
  phoneOrEmail: string;
  password: string;
}

export interface RegisterData {
  phoneNumber: string;
  email?: string;
  password: string;
  confirmPassword: string;
  username: string;
  profile: {
    firstName: string;
    lastName: string;
    preferredHand: 'left' | 'right';
    preferredCourtPosition: 'left' | 'right' | 'both';
    gender: 'male' | 'female' | 'other';
    city: string;
    country: string;
    language: 'en' | 'ar';
  };
}

export interface PasswordResetRequest {
  phoneOrEmail: string;
}

export interface PasswordReset {
  token: string;
  newPassword: string;
  confirmPassword: string;
}

export interface ChangePassword {
  currentPassword: string;
  newPassword: string;
  confirmPassword: string;
}

export interface UserFollow {
  id: string;
  followerId: string;
  followingId: string;
  createdAt: string;
}

export interface UserStats {
  totalFollowers: number;
  totalFollowing: number;
  matchesPlayed: number;
  tournamentsJoined: number;
  tournamentsWon: number;
  winRate: number;
  currentRank: number;
  currentLP: number;
  currentTier: string;
  currentDivision: number;
  achievements: string[];
  joinDate: string;
}

export interface RoleAssignment {
  id: string;
  assignerId: string; // Only owners can assign roles
  userId: string;
  oldRole: UserRole;
  newRole: UserRole;
  reason: string;
  assignedAt: string;
}

export interface UserBan {
  id: string;
  bannerId: string; // Only owners can ban
  userId: string;
  reason: string;
  duration: 'temporary' | 'permanent';
  expiryDate?: string;
  isActive: boolean;
  createdAt: string;
}

export interface DuplicateAccountCheck {
  phoneNumber: string;
  deviceFingerprint?: string;
  ipAddress?: string;
  existingAccountId?: string;
  isDuplicate: boolean;
  confidence: number; // 0-100
}

// Validation rules
export const VALIDATION_RULES = {
  username: {
    minLength: 3,
    maxLength: 20,
    pattern: /^[a-zA-Z0-9_]+$/,
    message: 'Username must be 3-20 characters and contain only letters, numbers, and underscores'
  },
  password: {
    minLength: 8,
    maxLength: 128,
    pattern: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]/,
    message: 'Password must be at least 8 characters with uppercase, lowercase, number, and special character'
  },
  phoneNumber: {
    pattern: /^\+?[1-9]\d{1,14}$/,
    message: 'Please enter a valid phone number'
  },
  email: {
    pattern: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
    message: 'Please enter a valid email address'
  }
};

export interface AuthContextType {
  user: Omit<User, 'password'> | null;
  token: string | null;
  permissions: UserPermissions | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  login: (credentials: LoginCredentials) => Promise<void>;
  register: (data: RegisterData) => Promise<void>;
  logout: () => void;
  updateProfile: (profile: Partial<UserProfile>) => Promise<void>;
  changePassword: (data: ChangePassword) => Promise<void>;
  requestPasswordReset: (data: PasswordResetRequest) => Promise<void>;
  resetPassword: (data: PasswordReset) => Promise<void>;
}
