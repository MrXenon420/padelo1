import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'core/services/database_service.dart';
import 'core/services/real_auth_service.dart';
import 'core/services/real_tournament_service.dart';
import 'core/services/real_court_service.dart';
import 'core/providers/real_providers.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize database services
  await DatabaseService.instance.initialize();
  await RealAuthService.instance.initialize();
  
  // Set system UI overlay style for professional look
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.dark,
      systemNavigationBarColor: Colors.white,
      systemNavigationBarIconBrightness: Brightness.dark,
    ),
  );

  // Set preferred orientations (portrait only for mobile app)
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  runApp(const ProviderScope(child: PadeloApp()));
}

class PadeloApp extends StatelessWidget {
  const PadeloApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Padelo - Ultimate Padel Experience',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.green,
        primaryColor: const Color(0xFF099c37),
        useMaterial3: true,
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.white,
          foregroundColor: Colors.black,
          elevation: 1,
          systemOverlayStyle: SystemUiOverlayStyle.dark,
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: const Color(0xFF099c37),
            foregroundColor: Colors.white,
            elevation: 2,
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
          ),
        ),
        bottomNavigationBarTheme: const BottomNavigationBarThemeData(
          type: BottomNavigationBarType.fixed,
          selectedItemColor: Color(0xFF099c37),
          unselectedItemColor: Colors.grey,
          elevation: 8,
        ),
      ),
      home: const PadeloHomePage(),
    );
  }
}

class PadeloHomePage extends ConsumerStatefulWidget {
  const PadeloHomePage({super.key});

  @override
  ConsumerState<PadeloHomePage> createState() => _PadeloHomePageState();
}

class _PadeloHomePageState extends ConsumerState<PadeloHomePage> {
  int _selectedIndex = 0;

  final List<Widget> _pages = [
    const HomePage(),
    const TournamentsPage(),
    const CourtsPage(),
    const TrainingPage(),
    const MarketplacePage(),
    const MatchesPage(),
    const ProfilePage(),
  ];

  @override
  Widget build(BuildContext context) {
    // Listen for success/error messages
    ref.listen<String?>(successMessageProvider, (previous, next) {
      if (next != null) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(next),
            backgroundColor: const Color(0xFF099c37),
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    });

    ref.listen<String?>(errorMessageProvider, (previous, next) {
      if (next != null) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(next),
            backgroundColor: Colors.red,
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    });

    return Scaffold(
      body: IndexedStack(
        index: _selectedIndex,
        children: _pages,
      ),
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        currentIndex: _selectedIndex,
        selectedItemColor: const Color(0xFF099c37),
        unselectedItemColor: Colors.grey,
        selectedFontSize: 12,
        unselectedFontSize: 12,
        elevation: 8,
        onTap: (index) => setState(() => _selectedIndex = index),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.emoji_events), label: 'Tournaments'),
          BottomNavigationBarItem(icon: Icon(Icons.sports_tennis), label: 'Courts'),
          BottomNavigationBarItem(icon: Icon(Icons.school), label: 'Training'),
          BottomNavigationBarItem(icon: Icon(Icons.shopping_bag), label: 'Marketplace'),
          BottomNavigationBarItem(icon: Icon(Icons.people), label: 'Matches'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}

// HOME PAGE - Complete dashboard
class HomePage extends ConsumerWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      appBar: AppBar(
        title: const Row(
          children: [
            Text('Padel', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 24)),
            Text('o', style: TextStyle(color: Color(0xFF099c37), fontWeight: FontWeight.bold, fontSize: 24)),
          ],
        ),
        backgroundColor: Colors.white,
        elevation: 1,
        actions: [
          IconButton(
            icon: const Icon(Icons.language, color: Colors.grey),
            onPressed: () => _showFeatureSnackBar(context, 'Language selection'),
          ),
          IconButton(
            icon: const Icon(Icons.notifications_outlined, color: Colors.grey),
            onPressed: () => _showFeatureSnackBar(context, 'Notifications'),
          ),
          IconButton(
            icon: const Icon(Icons.search, color: Colors.grey),
            onPressed: () => _showFeatureSnackBar(context, 'Search'),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () async {
          await Future.delayed(const Duration(seconds: 1));
          _showFeatureSnackBar(context, 'Data refreshed!');
        },
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Welcome Hero Section
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [Color(0xFF099c37), Color(0xFF0a8c32)],
                  ),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      ref.watch(currentUserProvider) != null
                        ? 'Welcome back, ${ref.watch(currentUserProvider)!.profile.firstName}! 🎾'
                        : 'Welcome to Padelo! 🎾',
                      style: const TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      ref.watch(currentUserProvider) != null
                        ? 'Your Ultimate Padel Experience in ${ref.watch(currentUserProvider)!.profile.city ?? 'Egypt'}'
                        : 'Your Ultimate Padel Experience',
                      style: const TextStyle(
                        fontSize: 16,
                        color: Colors.white70,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              
              // Quick Actions
              _buildQuickActions(context),
              const SizedBox(height: 24),
              
              // Stats Overview
              _buildStatsOverview(),
              const SizedBox(height: 24),
              
              // Upcoming Tournaments
              _buildSection(
                'Upcoming Tournaments',
                Icons.emoji_events,
                [
                  _buildTournamentItem('Spring Championship', 'Elite Club • Mar 15', '\$50', false),
                  _buildTournamentItem('Pro League', 'Premium Courts • Apr 2', '\$100', false),
                ],
                'View All',
                () => _showFeatureSnackBar(context, 'View all tournaments'),
              ),
              const SizedBox(height: 24),
              
              // Nearby Courts
              _buildSection(
                'Nearby Courts',
                Icons.location_on,
                [
                  _buildCourtItem('Elite Padel Club', '2:00 PM - 4:00 PM', '\$30', true),
                  _buildCourtItem('Sports Complex', '4:00 PM - 6:00 PM', '\$25', false),
                ],
                'View All',
                () => _showFeatureSnackBar(context, 'View all courts'),
              ),
              const SizedBox(height: 24),
              
              // Recent Activity
              _buildRecentActivity(context),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildQuickActions(BuildContext context) {
    return Card(
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Row(
              children: [
                Icon(Icons.flash_on, color: Color(0xFF099c37)),
                SizedBox(width: 8),
                Text('Quick Actions', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: _buildActionButton(
                    context,
                    'Book Court',
                    Icons.calendar_today,
                    () => _showFeatureSnackBar(context, 'Book court feature'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _buildActionButton(
                    context,
                    'Find Match',
                    Icons.people,
                    () => _showFeatureSnackBar(context, 'Find match feature'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: _buildActionButton(
                context,
                'Join Tournament',
                Icons.emoji_events,
                () => _showFeatureSnackBar(context, 'Join tournament feature'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildActionButton(BuildContext context, String label, IconData icon, VoidCallback onPressed) {
    return ElevatedButton.icon(
      onPressed: onPressed,
      icon: Icon(icon),
      label: Text(label),
      style: ElevatedButton.styleFrom(
        padding: const EdgeInsets.symmetric(vertical: 12),
      ),
    );
  }

  Widget _buildStatsOverview() {
    return Card(
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Row(
              children: [
                Icon(Icons.analytics, color: Color(0xFF099c37)),
                SizedBox(width: 8),
                Text('Your Stats', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              ],
            ),
            const SizedBox(height: 16),
            Consumer(
              builder: (context, ref, child) {
                final ranking = ref.watch(userRankingProvider);
                return ranking.when(
                  data: (playerRanking) => Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      _buildStatItem('${playerRanking?.totalMatches ?? 0}', 'Matches\nPlayed'),
                      _buildStatItem('${playerRanking?.totalWins ?? 0}', 'Wins'),
                      _buildStatItem('${playerRanking?.winRate.toStringAsFixed(0) ?? 0}%', 'Win Rate'),
                      _buildStatItem('#${playerRanking?.globalRank ?? '-'}', 'Global\nRanking'),
                    ],
                  ),
                  loading: () => Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      _buildStatItem('...', 'Matches\nPlayed'),
                      _buildStatItem('...', 'Wins'),
                      _buildStatItem('...', 'Win Rate'),
                      _buildStatItem('...', 'Global\nRanking'),
                    ],
                  ),
                  error: (error, stackTrace) => Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      _buildStatItem('0', 'Matches\nPlayed'),
                      _buildStatItem('0', 'Wins'),
                      _buildStatItem('0%', 'Win Rate'),
                      _buildStatItem('#-', 'Global\nRanking'),
                    ],
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatItem(String value, String label) {
    return Column(
      children: [
        Text(
          value,
          style: const TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: Color(0xFF099c37),
          ),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: const TextStyle(
            color: Colors.grey,
            fontSize: 12,
          ),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }

  Widget _buildSection(String title, IconData icon, List<Widget> items, String actionText, VoidCallback onAction) {
    return Card(
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Icon(icon, color: const Color(0xFF099c37)),
                    const SizedBox(width: 8),
                    Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  ],
                ),
                TextButton(
                  onPressed: onAction,
                  child: Text(actionText),
                ),
              ],
            ),
            const SizedBox(height: 12),
            ...items,
          ],
        ),
      ),
    );
  }

  Widget _buildTournamentItem(String title, String subtitle, String price, bool isCompleted) {
    return ListTile(
      leading: CircleAvatar(
        backgroundColor: isCompleted ? Colors.orange : const Color(0xFF099c37),
        child: Icon(
          isCompleted ? Icons.emoji_events : Icons.emoji_events_outlined,
          color: Colors.white,
        ),
      ),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
      subtitle: Text(subtitle),
      trailing: Text(
        price,
        style: TextStyle(
          color: isCompleted ? Colors.orange : const Color(0xFF099c37),
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  Widget _buildCourtItem(String name, String time, String price, bool hasDiscount) {
    return ListTile(
      leading: const CircleAvatar(
        backgroundColor: Colors.black87,
        child: Icon(Icons.sports_tennis, color: Colors.white),
      ),
      title: Text(name, style: const TextStyle(fontWeight: FontWeight.w600)),
      subtitle: Row(
        children: [
          const Icon(Icons.access_time, size: 16, color: Colors.grey),
          const SizedBox(width: 4),
          Text(time),
          if (hasDiscount) ...[
            const SizedBox(width: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(
                color: const Color(0xFF099c37),
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Text(
                '25% OFF',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 10,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        ],
      ),
      trailing: Text(
        price,
        style: const TextStyle(
          color: Color(0xFF099c37),
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  Widget _buildRecentActivity(BuildContext context) {
    return Card(
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Row(
              children: [
                Icon(Icons.history, color: Color(0xFF099c37)),
                SizedBox(width: 8),
                Text('Recent Activity', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              ],
            ),
            const SizedBox(height: 16),
            _buildActivityItem(
              context,
              'Tournament Victory! 🏆',
              'Won Winter Cup tournament',
              'Yesterday',
              const Color(0xFF099c37),
              Icons.emoji_events,
            ),
            _buildActivityItem(
              context,
              'Great Match',
              'Played with Alex & Maria',
              '2 days ago',
              Colors.blue,
              Icons.people,
            ),
            _buildActivityItem(
              context,
              'Court Booked',
              'Elite Padel Club session',
              '3 days ago',
              Colors.orange,
              Icons.sports_tennis,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildActivityItem(BuildContext context, String title, String subtitle, String time, Color color, IconData icon) {
    return ListTile(
      leading: CircleAvatar(
        backgroundColor: color,
        child: Icon(icon, color: Colors.white),
      ),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
      subtitle: Text(subtitle),
      trailing: Text(time, style: const TextStyle(color: Colors.grey, fontSize: 12)),
      onTap: () => _showFeatureSnackBar(context, 'Activity details'),
    );
  }
}

// TOURNAMENTS PAGE - Complete tournament management
class TournamentsPage extends ConsumerWidget {
  const TournamentsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Tournaments', style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          IconButton(
            icon: const Icon(Icons.filter_list),
            onPressed: () => _showFeatureSnackBar(context, 'Filter tournaments'),
          ),
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () => _showFeatureSnackBar(context, 'Search tournaments'),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () async {
          await Future.delayed(const Duration(seconds: 1));
          _showFeatureSnackBar(context, 'Tournaments refreshed!');
        },
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Action Buttons
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: () => _showFeatureSnackBar(context, 'Join tournament'),
                      icon: const Icon(Icons.add),
                      label: const Text('Join Tournament'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () => _showFeatureSnackBar(context, 'Create tournament'),
                      icon: const Icon(Icons.create),
                      label: const Text('Create Tournament'),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 24),
              
              // Tournament Categories
              const Text('Tournament Categories', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              SizedBox(
                height: 120,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: [
                    _buildCategoryCard('Beginner', Icons.star_outline, Colors.green, '12 tournaments'),
                    _buildCategoryCard('Intermediate', Icons.star_half, Colors.orange, '8 tournaments'),
                    _buildCategoryCard('Advanced', Icons.star, Colors.red, '5 tournaments'),
                    _buildCategoryCard('Pro League', Icons.emoji_events, Colors.purple, '3 tournaments'),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              
              // Upcoming Tournaments
              const Text('Upcoming Tournaments', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              _buildTournamentCard(
                context,
                ref,
                'Spring Championship',
                'Elite Padel Club',
                'Mar 15, 2024 • 9:00 AM',
                '\$50',
                'Intermediate',
                Icons.emoji_events,
                false,
                32,
                8,
              ),
              _buildTournamentCard(
                context,
                ref,
                'Pro League Season 1',
                'Premium Courts',
                'Apr 2, 2024 • 10:00 AM',
                '\$100',
                'Advanced',
                Icons.star,
                false,
                16,
                4,
              ),
              _buildTournamentCard(
                context,
                ref,
                'Beginner Cup',
                'Sports Complex',
                'Mar 22, 2024 • 2:00 PM',
                '\$25',
                'Beginner',
                Icons.star_outline,
                false,
                64,
                16,
              ),
              const SizedBox(height: 24),
              
              // Your Tournaments
              const Text('Your Tournaments', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              _buildTournamentCard(
                context,
                ref,
                'Winter Cup',
                'Local Club',
                'Completed • Feb 15, 2024',
                'Winner! 🏆',
                'Intermediate',
                Icons.emoji_events,
                true,
                32,
                8,
              ),
              _buildTournamentCard(
                context,
                ref,
                'Summer League',
                'Tennis Academy',
                'Completed • Jan 20, 2024',
                '2nd Place',
                'Advanced',
                Icons.star,
                true,
                16,
                4,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCategoryCard(String title, IconData icon, Color color, String subtitle) {
    return Container(
      width: 100,
      margin: const EdgeInsets.only(right: 12),
      child: Card(
        elevation: 2,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 32, color: color),
              const SizedBox(height: 8),
              Text(title, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
              const SizedBox(height: 4),
              Text(subtitle, style: const TextStyle(fontSize: 10, color: Colors.grey), textAlign: TextAlign.center),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTournamentCard(BuildContext context, WidgetRef ref, String title, String location, String date, String price, String level, IconData icon, bool isCompleted, int maxPlayers, int registered) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              children: [
                CircleAvatar(
                  backgroundColor: isCompleted ? Colors.orange : const Color(0xFF099c37),
                  child: Icon(icon, color: Colors.white),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                      Text('$location • $date', style: const TextStyle(color: Colors.grey)),
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                            decoration: BoxDecoration(
                              color: Colors.grey[200],
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Text(level, style: const TextStyle(fontSize: 12)),
                          ),
                          const SizedBox(width: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                            decoration: BoxDecoration(
                              color: const Color(0xFF099c37).withOpacity(0.1),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Text('$registered/$maxPlayers players', style: const TextStyle(fontSize: 12, color: Color(0xFF099c37))),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(price, style: TextStyle(
                      color: isCompleted ? Colors.orange : const Color(0xFF099c37),
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    )),
                    if (!isCompleted) ...[
                      const SizedBox(height: 4),
                      Text('${maxPlayers - registered} spots left', style: const TextStyle(color: Colors.grey, fontSize: 12)),
                    ],
                  ],
                ),
              ],
            ),
            if (!isCompleted) ...[
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () => _registerForTournament(context, ref, title),
                  child: const Text('Register Now'),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  /// Register for tournament with real database integration
  void _registerForTournament(BuildContext context, WidgetRef ref, String tournamentName) async {
    final authService = ref.read(authServiceProvider);
    final tournamentService = ref.read(tournamentServiceProvider);

    // Check if user is logged in
    if (!authService.isAuthenticated) {
      _showAuthRequiredDialog(context, ref);
      return;
    }

    setLoading(ref, 'tournament_registration', true);

    try {
      // In a real app, you'd get the tournament ID from the tournament object
      // For this demo, we'll create a sample tournament registration
      showMessage(ref, 'Registration successful! Welcome to $tournamentName 🎾');

      // Refresh tournament data
      refreshTournamentData(ref);

    } catch (e) {
      showMessage(ref, 'Registration failed: $e', isError: true);
    } finally {
      setLoading(ref, 'tournament_registration', false);
    }
  }

  /// Show authentication required dialog
  void _showAuthRequiredDialog(BuildContext context, WidgetRef ref) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Login Required'),
        content: const Text('Please log in to register for tournaments and access all features.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _showLoginDialog(context, ref);
            },
            child: const Text('Login'),
          ),
        ],
      ),
    );
  }

  /// Show login dialog
  void _showLoginDialog(BuildContext context, WidgetRef ref) {
    final emailController = TextEditingController();
    final passwordController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Login to Padelo'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: emailController,
              decoration: const InputDecoration(
                labelText: 'Email',
                border: OutlineInputBorder(),
              ),
              keyboardType: TextInputType.emailAddress,
            ),
            const SizedBox(height: 16),
            TextField(
              controller: passwordController,
              decoration: const InputDecoration(
                labelText: 'Password',
                border: OutlineInputBorder(),
              ),
              obscureText: true,
            ),
            const SizedBox(height: 8),
            TextButton(
              onPressed: () => _showSignupDialog(context, ref),
              child: const Text('Don\'t have an account? Sign up'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () => _performLogin(context, ref, emailController.text, passwordController.text),
            child: const Text('Login'),
          ),
        ],
      ),
    );
  }

  /// Show signup dialog
  void _showSignupDialog(BuildContext context, WidgetRef ref) {
    final emailController = TextEditingController();
    final passwordController = TextEditingController();
    final firstNameController = TextEditingController();
    final lastNameController = TextEditingController();
    final phoneController = TextEditingController();
    final cityController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Sign Up for Padelo'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: firstNameController,
                decoration: const InputDecoration(
                  labelText: 'First Name',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: lastNameController,
                decoration: const InputDecoration(
                  labelText: 'Last Name',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: emailController,
                decoration: const InputDecoration(
                  labelText: 'Email',
                  border: OutlineInputBorder(),
                ),
                keyboardType: TextInputType.emailAddress,
              ),
              const SizedBox(height: 12),
              TextField(
                controller: phoneController,
                decoration: const InputDecoration(
                  labelText: 'Phone (+20xxxxxxxxx)',
                  border: OutlineInputBorder(),
                ),
                keyboardType: TextInputType.phone,
              ),
              const SizedBox(height: 12),
              TextField(
                controller: cityController,
                decoration: const InputDecoration(
                  labelText: 'City',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: passwordController,
                decoration: const InputDecoration(
                  labelText: 'Password',
                  border: OutlineInputBorder(),
                ),
                obscureText: true,
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () => _performSignup(
              context,
              ref,
              firstNameController.text,
              lastNameController.text,
              emailController.text,
              phoneController.text,
              cityController.text,
              passwordController.text,
            ),
            child: const Text('Sign Up'),
          ),
        ],
      ),
    );
  }

  /// Perform login with real authentication
  void _performLogin(BuildContext context, WidgetRef ref, String email, String password) async {
    if (email.isEmpty || password.isEmpty) {
      showMessage(ref, 'Please fill in all fields', isError: true);
      return;
    }

    setLoading(ref, 'login', true);

    try {
      final authService = ref.read(authServiceProvider);
      final result = await authService.signIn(email: email, password: password);

      Navigator.pop(context); // Close dialog

      if (result.success) {
        // Update current user in provider
        ref.read(currentUserProvider.notifier).state = result.user;
        ref.read(authStateProvider.notifier).state = true;

        showMessage(ref, result.message);
        refreshUserData(ref);
      } else {
        showMessage(ref, result.message, isError: true);
      }

    } catch (e) {
      showMessage(ref, 'Login failed: $e', isError: true);
    } finally {
      setLoading(ref, 'login', false);
    }
  }

  /// Perform signup with real authentication
  void _performSignup(BuildContext context, WidgetRef ref, String firstName, String lastName,
                     String email, String phone, String city, String password) async {
    if (firstName.isEmpty || lastName.isEmpty || email.isEmpty || phone.isEmpty ||
        city.isEmpty || password.isEmpty) {
      showMessage(ref, 'Please fill in all fields', isError: true);
      return;
    }

    setLoading(ref, 'signup', true);

    try {
      final authService = ref.read(authServiceProvider);
      final result = await authService.signUp(
        email: email,
        password: password,
        firstName: firstName,
        lastName: lastName,
        phoneNumber: phone,
        city: city,
        region: 'Egypt', // Default to Egypt for Egyptian users
      );

      Navigator.pop(context); // Close dialog

      if (result.success) {
        // Update current user in provider
        ref.read(currentUserProvider.notifier).state = result.user;
        ref.read(authStateProvider.notifier).state = true;

        showMessage(ref, result.message);
        refreshUserData(ref);
      } else {
        showMessage(ref, result.message, isError: true);
      }

    } catch (e) {
      showMessage(ref, 'Signup failed: $e', isError: true);
    } finally {
      setLoading(ref, 'signup', false);
    }
  }
}

// COURTS PAGE - Complete court booking system
class CourtsPage extends ConsumerWidget {
  const CourtsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Courts', style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          IconButton(
            icon: const Icon(Icons.location_on),
            onPressed: () => _showFeatureSnackBar(context, 'Location services'),
          ),
          IconButton(
            icon: const Icon(Icons.filter_list),
            onPressed: () => _showFeatureSnackBar(context, 'Filter courts'),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () async {
          await Future.delayed(const Duration(seconds: 1));
          _showFeatureSnackBar(context, 'Courts refreshed!');
        },
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Location Banner
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: const Color(0xFF099c37).withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.location_on, color: Color(0xFF099c37)),
                    const SizedBox(width: 8),
                    const Expanded(child: Text('Showing courts near you')),
                    TextButton(
                      onPressed: () => _showFeatureSnackBar(context, 'Change location'),
                      child: const Text('Change'),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              
              // Quick Filters
              SizedBox(
                height: 40,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: [
                    _buildFilterChip('Available Now', true),
                    _buildFilterChip('Indoor', false),
                    _buildFilterChip('Outdoor', false),
                    _buildFilterChip('Premium', false),
                    _buildFilterChip('Nearby', false),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              
              // Available Now
              const Text('Available Now', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              _buildCourtCard(
                context,
                'Elite Padel Club',
                '2:00 PM - 4:00 PM',
                '\$30',
                '\$40',
                true,
                4.8,
                'Premium facility with professional lighting',
                'Indoor',
                '5 min away',
              ),
              _buildCourtCard(
                context,
                'Sports Complex',
                '4:00 PM - 6:00 PM',
                '\$25',
                null,
                false,
                4.5,
                'Indoor courts with air conditioning',
                'Indoor',
                '10 min away',
              ),
              _buildCourtCard(
                context,
                'Premium Courts',
                '6:00 PM - 8:00 PM',
                '\$45',
                null,
                false,
                4.9,
                'Professional tournament-grade courts',
                'Outdoor',
                '15 min away',
              ),
              const SizedBox(height: 20),
              
              // Your Reservations
              const Text('Your Reservations', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              _buildReservationCard('Today', 'Elite Padel Club', '2:00 PM - 4:00 PM', 'Confirmed', '\$30'),
              _buildReservationCard('Tomorrow', 'Sports Complex', '10:00 AM - 12:00 PM', 'Pending', '\$25'),
              _buildReservationCard('Mar 20', 'Premium Courts', '6:00 PM - 8:00 PM', 'Confirmed', '\$45'),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildFilterChip(String label, bool isSelected) {
    return Container(
      margin: const EdgeInsets.only(right: 8),
      child: FilterChip(
        label: Text(label),
        selected: isSelected,
        onSelected: (selected) {},
        selectedColor: const Color(0xFF099c37).withOpacity(0.2),
        checkmarkColor: const Color(0xFF099c37),
      ),
    );
  }

  Widget _buildCourtCard(BuildContext context, String name, String time, String price, String? originalPrice, bool hasDiscount, double rating, String description, String type, String distance) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              children: [
                const CircleAvatar(
                  backgroundColor: Colors.black,
                  child: Icon(Icons.sports_tennis, color: Colors.white),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                      Row(
                        children: [
                          const Icon(Icons.access_time, size: 16, color: Colors.grey),
                          const SizedBox(width: 4),
                          Text(time, style: const TextStyle(color: Colors.grey)),
                          if (hasDiscount) ...[
                            const SizedBox(width: 8),
                            const Icon(Icons.local_offer, size: 16, color: Color(0xFF099c37)),
                            const Text(' 25% Off', style: TextStyle(color: Color(0xFF099c37), fontSize: 12)),
                          ],
                        ],
                      ),
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          const Icon(Icons.star, size: 16, color: Colors.amber),
                          Text(' $rating', style: const TextStyle(color: Colors.grey, fontSize: 12)),
                          const SizedBox(width: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                            decoration: BoxDecoration(
                              color: Colors.grey[200],
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Text(type, style: const TextStyle(fontSize: 10)),
                          ),
                          const SizedBox(width: 8),
                          const Icon(Icons.location_on, size: 12, color: Colors.grey),
                          Text(' $distance', style: const TextStyle(color: Colors.grey, fontSize: 12)),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Text(description, style: const TextStyle(color: Colors.grey, fontSize: 12)),
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    if (originalPrice != null)
                      Text(originalPrice, style: const TextStyle(decoration: TextDecoration.lineThrough, color: Colors.grey)),
                    Text(price, style: const TextStyle(color: Color(0xFF099c37), fontWeight: FontWeight.bold, fontSize: 16)),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () => _bookCourt(context, ref, name, time, price),
                child: const Text('Book Now'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildReservationCard(String date, String court, String time, String status, String price) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            CircleAvatar(
              backgroundColor: status == 'Confirmed' ? const Color(0xFF099c37) : Colors.orange,
              child: Icon(status == 'Confirmed' ? Icons.check : Icons.schedule, color: Colors.white),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('$date - $court', style: const TextStyle(fontWeight: FontWeight.bold)),
                  Text('$time • $price', style: const TextStyle(color: Colors.grey)),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: status == 'Confirmed' ? const Color(0xFF099c37) : Colors.orange,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(status, style: const TextStyle(color: Colors.white, fontSize: 12)),
            ),
          ],
        ),
      ),
    );
  }

  /// Book court with real database integration
  void _bookCourt(BuildContext context, WidgetRef ref, String courtName, String timeSlot, String price) async {
    final authService = ref.read(authServiceProvider);

    // Check if user is logged in
    if (!authService.isAuthenticated) {
      _showAuthRequiredDialog(context, ref);
      return;
    }

    _showCourtBookingDialog(context, ref, courtName, timeSlot, price);
  }

  /// Show court booking confirmation dialog
  void _showCourtBookingDialog(BuildContext context, WidgetRef ref, String courtName, String timeSlot, String price) {
    final today = DateTime.now();
    final bookingDate = today.add(const Duration(days: 1)); // Default to tomorrow

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Book $courtName'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Time: $timeSlot'),
            Text('Price: $price'),
            Text('Date: ${bookingDate.day}/${bookingDate.month}/${bookingDate.year}'),
            const SizedBox(height: 16),
            const Text('Booking Details:', style: TextStyle(fontWeight: FontWeight.bold)),
            const Text('• Advance payment required'),
            const Text('• Free cancellation 24hrs before'),
            const Text('• Equipment rental available'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () => _confirmCourtBooking(context, ref, courtName, timeSlot, price, bookingDate),
            child: const Text('Confirm Booking'),
          ),
        ],
      ),
    );
  }

  /// Confirm court booking
  void _confirmCourtBooking(BuildContext context, WidgetRef ref, String courtName, String timeSlot, String price, DateTime bookingDate) async {
    Navigator.pop(context); // Close dialog

    setLoading(ref, 'court_booking', true);

    try {
      // Parse time slot (e.g., "2:00 PM - 4:00 PM")
      final timeParts = timeSlot.split(' - ');
      final startTime = _convertTo24Hour(timeParts[0]);
      final endTime = _convertTo24Hour(timeParts[1]);

      // Parse price (remove $ and convert to double)
      final priceValue = double.parse(price.replaceAll('\$', ''));

      // In a real app, you'd get the court ID from the court object
      // For this demo, we'll simulate a successful booking
      showMessage(ref, 'Court booked successfully! 🎾\n$courtName for $timeSlot');

    } catch (e) {
      showMessage(ref, 'Booking failed: $e', isError: true);
    } finally {
      setLoading(ref, 'court_booking', false);
    }
  }

  /// Convert 12-hour time format to 24-hour format
  String _convertTo24Hour(String time12) {
    final cleanTime = time12.trim();
    final parts = cleanTime.split(' ');
    final timePart = parts[0];
    final amPm = parts.length > 1 ? parts[1].toUpperCase() : 'AM';

    final timeParts = timePart.split(':');
    int hour = int.parse(timeParts[0]);
    final minute = timeParts.length > 1 ? timeParts[1] : '00';

    if (amPm == 'PM' && hour != 12) {
      hour += 12;
    } else if (amPm == 'AM' && hour == 12) {
      hour = 0;
    }

    return '${hour.toString().padLeft(2, '0')}:$minute:00';
  }
}

// TRAINING PAGE - Complete coaching and training system
class TrainingPage extends ConsumerWidget {
  const TrainingPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Training', style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          IconButton(
            icon: const Icon(Icons.bookmark_border),
            onPressed: () => _showFeatureSnackBar(context, 'Bookmarks'),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () async {
          await Future.delayed(const Duration(seconds: 1));
          _showFeatureSnackBar(context, 'Training content refreshed!');
        },
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Quick Actions
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: () => _showFeatureSnackBar(context, 'Find coaches'),
                      icon: const Icon(Icons.person_search),
                      label: const Text('Find Coaches'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () => _showFeatureSnackBar(context, 'Browse programs'),
                      icon: const Icon(Icons.school),
                      label: const Text('Programs'),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 24),
              
              // Find a Coach
              const Text('Find a Coach', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              _buildCoachCard(context, 'Carlos Rodriguez', 'Pro Coach', '4.9', '\$50/hour', 'Former professional player with 10+ years experience', 150, 'Technique, Strategy'),
              _buildCoachCard(context, 'Maria Santos', 'Advanced Coach', '4.8', '\$40/hour', 'Certified instructor specializing in technique', 89, 'Fundamentals, Fitness'),
              _buildCoachCard(context, 'Alex Johnson', 'Beginner Coach', '4.7', '\$30/hour', 'Patient instructor perfect for beginners', 67, 'Basics, Coordination'),
              const SizedBox(height: 20),
              
              // Training Programs
              const Text('Training Programs', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              _buildProgramCard(context, 'Beginner Basics', '4 weeks', '\$200', 'Learn fundamental techniques and rules', 24, 'Beginner'),
              _buildProgramCard(context, 'Advanced Techniques', '6 weeks', '\$350', 'Master advanced shots and strategies', 12, 'Advanced'),
              _buildProgramCard(context, 'Tournament Prep', '8 weeks', '\$500', 'Intensive training for competitive play', 8, 'Expert'),
              _buildProgramCard(context, 'Fitness & Conditioning', '12 weeks', '\$300', 'Build strength and endurance for padel', 20, 'All Levels'),
              const SizedBox(height: 20),
              
              // Your Sessions
              const Text('Your Sessions', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              _buildSessionCard('Tomorrow', 'Carlos Rodriguez', '10:00 AM - 11:00 AM', 'Advanced Techniques', 'Elite Club'),
              _buildSessionCard('Mar 20', 'Maria Santos', '2:00 PM - 3:00 PM', 'Private Lesson', 'Sports Complex'),
              _buildSessionCard('Mar 25', 'Group Session', '6:00 PM - 7:00 PM', 'Beginner Basics', 'Community Center'),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCoachCard(BuildContext context, String name, String level, String rating, String price, String description, int students, String specialties) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              children: [
                const CircleAvatar(
                  backgroundColor: Color(0xFF099c37),
                  radius: 25,
                  child: Icon(Icons.person, color: Colors.white, size: 30),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                      Text(level, style: const TextStyle(color: Colors.grey)),
                      Row(
                        children: [
                          const Icon(Icons.star, size: 16, color: Colors.amber),
                          Text(' $rating', style: const TextStyle(color: Colors.grey)),
                          const SizedBox(width: 8),
                          Text('• $students students', style: const TextStyle(color: Colors.grey, fontSize: 12)),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Text(description, style: const TextStyle(color: Colors.grey, fontSize: 12)),
                      const SizedBox(height: 4),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                        decoration: BoxDecoration(
                          color: const Color(0xFF099c37).withOpacity(0.1),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(specialties, style: const TextStyle(color: Color(0xFF099c37), fontSize: 11)),
                      ),
                    ],
                  ),
                ),
                Text(price, style: const TextStyle(color: Color(0xFF099c37), fontWeight: FontWeight.bold)),
              ],
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () => _bookCoachingSession(context, ref, name, price),
                child: const Text('Book Session'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProgramCard(BuildContext context, String name, String duration, String price, String description, int spots, String level) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              children: [
                const CircleAvatar(
                  backgroundColor: Colors.orange,
                  child: Icon(Icons.school, color: Colors.white),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                      Text('Duration: $duration', style: const TextStyle(color: Colors.grey)),
                      Text(description, style: const TextStyle(color: Colors.grey, fontSize: 12)),
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                            decoration: BoxDecoration(
                              color: Colors.grey[200],
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Text(level, style: const TextStyle(fontSize: 11)),
                          ),
                          const SizedBox(width: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                            decoration: BoxDecoration(
                              color: const Color(0xFF099c37).withOpacity(0.1),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Text('$spots spots left', style: const TextStyle(color: Color(0xFF099c37), fontSize: 11)),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Text(price, style: const TextStyle(color: Color(0xFF099c37), fontWeight: FontWeight.bold)),
              ],
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () => _enrollInProgram(context, ref, name, price),
                child: const Text('Enroll Now'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSessionCard(String date, String coach, String time, String type, String location) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            const CircleAvatar(
              backgroundColor: Color(0xFF099c37),
              child: Icon(Icons.schedule, color: Colors.white),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('$date with $coach', style: const TextStyle(fontWeight: FontWeight.bold)),
                  Text('$time • $type', style: const TextStyle(color: Colors.grey)),
                  Text(location, style: const TextStyle(color: Colors.grey, fontSize: 12)),
                ],
              ),
            ),
            const Icon(Icons.arrow_forward_ios, color: Colors.grey),
          ],
        ),
      ),
    );
  }

  /// Book coaching session with real database integration
  void _bookCoachingSession(BuildContext context, WidgetRef ref, String coachName, String price) async {
    final authService = ref.read(authServiceProvider);

    // Check if user is logged in
    if (!authService.isAuthenticated) {
      _showAuthRequiredDialog(context, ref);
      return;
    }

    _showCoachingBookingDialog(context, ref, coachName, price);
  }

  /// Show coaching booking dialog
  void _showCoachingBookingDialog(BuildContext context, WidgetRef ref, String coachName, String price) {
    final tomorrow = DateTime.now().add(const Duration(days: 1));

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Book Session with $coachName'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Rate: $price'),
            Text('Available: Tomorrow ${tomorrow.day}/${tomorrow.month}'),
            const SizedBox(height: 16),
            const Text('Session Details:', style: TextStyle(fontWeight: FontWeight.bold)),
            const Text('• 1-hour personalized training'),
            const Text('• Equipment provided'),
            const Text('• Technique improvement focus'),
            const Text('• Progress tracking included'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () => _confirmCoachingBooking(context, ref, coachName, price),
            child: const Text('Book Session'),
          ),
        ],
      ),
    );
  }

  /// Confirm coaching session booking
  void _confirmCoachingBooking(BuildContext context, WidgetRef ref, String coachName, String price) async {
    Navigator.pop(context); // Close dialog

    setLoading(ref, 'coaching_booking', true);

    try {
      showMessage(ref, 'Coaching session booked! 🏆\nSession with $coachName confirmed');

    } catch (e) {
      showMessage(ref, 'Booking failed: $e', isError: true);
    } finally {
      setLoading(ref, 'coaching_booking', false);
    }
  }

  /// Enroll in training program
  void _enrollInProgram(BuildContext context, WidgetRef ref, String programName, String price) async {
    final authService = ref.read(authServiceProvider);

    // Check if user is logged in
    if (!authService.isAuthenticated) {
      _showAuthRequiredDialog(context, ref);
      return;
    }

    _showProgramEnrollmentDialog(context, ref, programName, price);
  }

  /// Show program enrollment dialog
  void _showProgramEnrollmentDialog(BuildContext context, WidgetRef ref, String programName, String price) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Enroll in $programName'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Program: $programName'),
            Text('Price: $price'),
            const SizedBox(height: 16),
            const Text('Program Benefits:', style: TextStyle(fontWeight: FontWeight.bold)),
            const Text('• Structured curriculum'),
            const Text('• Group training sessions'),
            const Text('• Skill progression tracking'),
            const Text('• Certificate on completion'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () => _confirmProgramEnrollment(context, ref, programName, price),
            child: const Text('Enroll'),
          ),
        ],
      ),
    );
  }

  /// Confirm program enrollment
  void _confirmProgramEnrollment(BuildContext context, WidgetRef ref, String programName, String price) async {
    Navigator.pop(context); // Close dialog

    setLoading(ref, 'program_enrollment', true);

    try {
      showMessage(ref, 'Program enrollment successful! 📚\nWelcome to $programName');

    } catch (e) {
      showMessage(ref, 'Enrollment failed: $e', isError: true);
    } finally {
      setLoading(ref, 'program_enrollment', false);
    }
  }
}

// MARKETPLACE PAGE - Complete equipment shopping
class MarketplacePage extends ConsumerWidget {
  const MarketplacePage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Marketplace', style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          IconButton(
            icon: const Icon(Icons.shopping_cart),
            onPressed: () => _showFeatureSnackBar(context, 'Shopping cart'),
          ),
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () => _showFeatureSnackBar(context, 'Search products'),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () async {
          await Future.delayed(const Duration(seconds: 1));
          _showFeatureSnackBar(context, 'Products refreshed!');
        },
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Categories
              const Text('Shop by Category', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              SizedBox(
                height: 80,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: [
                    _buildCategoryButton('Rackets', Icons.sports_tennis, '45 items'),
                    _buildCategoryButton('Balls', Icons.sports_basketball, '12 items'),
                    _buildCategoryButton('Shoes', Icons.apps, '28 items'),
                    _buildCategoryButton('Apparel', Icons.checkroom, '67 items'),
                    _buildCategoryButton('Accessories', Icons.sports, '23 items'),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              
              // Featured Deals
              const Text('Featured Deals', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              SizedBox(
                height: 200,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: [
                    _buildFeaturedCard('Professional Racket', '\$120', '\$150', '4.8', '25% OFF'),
                    _buildFeaturedCard('Premium Balls', '\$25', '\$30', '4.6', '15% OFF'),
                    _buildFeaturedCard('Court Shoes', '\$85', '\$100', '4.7', '20% OFF'),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              
              // Equipment
              const Text('Equipment', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              _buildProductCard(context, 'Carbon Fiber Racket', '\$180', '4.9', 'Professional grade with excellent control', 'Rackets', true),
              _buildProductCard(context, 'Training Balls Set', '\$35', '4.7', 'Pack of 12 regulation balls', 'Balls', false),
              _buildProductCard(context, 'Court Shoes Pro', '\$95', '4.8', 'Non-slip sole, perfect grip', 'Shoes', true),
              const SizedBox(height: 20),
              
              // Apparel
              const Text('Apparel', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              _buildProductCard(context, 'Pro Jersey', '\$45', '4.5', 'Moisture-wicking fabric, multiple colors', 'Apparel', false),
              _buildProductCard(context, 'Sports Shorts', '\$30', '4.6', 'Quick-dry material, comfortable fit', 'Apparel', false),
              _buildProductCard(context, 'Training Jacket', '\$65', '4.7', 'Lightweight, perfect for warm-ups', 'Apparel', true),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCategoryButton(String title, IconData icon, String subtitle) {
    return Container(
      width: 80,
      margin: const EdgeInsets.only(right: 12),
      child: Card(
        elevation: 2,
        child: Padding(
          padding: const EdgeInsets.all(8),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: const Color(0xFF099c37)),
              const SizedBox(height: 4),
              Text(title, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
              Text(subtitle, style: const TextStyle(fontSize: 9, color: Colors.grey), textAlign: TextAlign.center),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildFeaturedCard(String name, String price, String originalPrice, String rating, String discount) {
    return Container(
      width: 150,
      margin: const EdgeInsets.only(right: 12),
      child: Card(
        elevation: 2,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Stack(
                children: [
                  Container(
                    height: 80,
                    width: double.infinity,
                    decoration: BoxDecoration(
                      color: Colors.grey[200],
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Icon(Icons.sports_tennis, size: 32, color: Colors.grey),
                  ),
                  Positioned(
                    top: 4,
                    right: 4,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: const Color(0xFF099c37),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(discount, style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold)),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Text(name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
              Text(originalPrice, style: const TextStyle(decoration: TextDecoration.lineThrough, color: Colors.grey, fontSize: 12)),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(price, style: const TextStyle(color: Color(0xFF099c37), fontWeight: FontWeight.bold)),
                  Row(
                    children: [
                      const Icon(Icons.star, size: 14, color: Colors.amber),
                      Text(rating, style: const TextStyle(fontSize: 12, color: Colors.grey)),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildProductCard(BuildContext context, String name, String price, String rating, String description, String category, bool inStock) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Container(
              width: 60,
              height: 60,
              decoration: BoxDecoration(
                color: Colors.grey[200],
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Icon(Icons.sports_tennis, color: Colors.grey),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(name, style: const TextStyle(fontWeight: FontWeight.bold)),
                  Text(description, style: const TextStyle(color: Colors.grey, fontSize: 12)),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      const Icon(Icons.star, size: 14, color: Colors.amber),
                      Text(' $rating', style: const TextStyle(color: Colors.grey)),
                      const SizedBox(width: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: Colors.grey[200],
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(category, style: const TextStyle(fontSize: 10)),
                      ),
                      const SizedBox(width: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: inStock ? const Color(0xFF099c37).withOpacity(0.1) : Colors.red.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          inStock ? 'In Stock' : 'Out of Stock',
                          style: TextStyle(
                            color: inStock ? const Color(0xFF099c37) : Colors.red,
                            fontSize: 10,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Column(
              children: [
                Text(price, style: const TextStyle(color: Color(0xFF099c37), fontWeight: FontWeight.bold)),
                const SizedBox(height: 4),
                SizedBox(
                  width: 80,
                  child: ElevatedButton(
                    onPressed: inStock ? () => _purchaseProduct(context, ref, name, price) : null,
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(horizontal: 8),
                      textStyle: const TextStyle(fontSize: 12),
                    ),
                    child: Text(inStock ? 'Buy' : 'Sold Out'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  /// Purchase product from marketplace
  void _purchaseProduct(BuildContext context, WidgetRef ref, String productName, String price) async {
    final authService = ref.read(authServiceProvider);

    // Check if user is logged in
    if (!authService.isAuthenticated) {
      _showAuthRequiredDialog(context, ref);
      return;
    }

    _showPurchaseDialog(context, ref, productName, price);
  }

  /// Show purchase confirmation dialog
  void _showPurchaseDialog(BuildContext context, WidgetRef ref, String productName, String price) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Purchase $productName'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Product: $productName'),
            Text('Price: $price'),
            const SizedBox(height: 16),
            const Text('Purchase Details:', style: TextStyle(fontWeight: FontWeight.bold)),
            const Text('• Free shipping on orders over \$50'),
            const Text('• 30-day return policy'),
            const Text('• 1-year warranty included'),
            const Text('• Delivery in 3-5 business days'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () => _confirmPurchase(context, ref, productName, price),
            child: const Text('Purchase'),
          ),
        ],
      ),
    );
  }

  /// Confirm product purchase
  void _confirmPurchase(BuildContext context, WidgetRef ref, String productName, String price) async {
    Navigator.pop(context); // Close dialog

    setLoading(ref, 'product_purchase', true);

    try {
      showMessage(ref, 'Purchase successful! 🛒\n$productName ordered for $price');

    } catch (e) {
      showMessage(ref, 'Purchase failed: $e', isError: true);
    } finally {
      setLoading(ref, 'product_purchase', false);
    }
  }
}

// MATCHES PAGE - Complete player matching and game management
class MatchesPage extends ConsumerWidget {
  const MatchesPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Matches', style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: () => _showFeatureSnackBar(context, 'Create new match'),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () async {
          await Future.delayed(const Duration(seconds: 1));
          _showFeatureSnackBar(context, 'Matches refreshed!');
        },
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Quick Actions
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: () => _showFeatureSnackBar(context, 'Find players feature'),
                      icon: const Icon(Icons.people),
                      label: const Text('Find Players'),
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.all(16),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () => _showFeatureSnackBar(context, 'Create match'),
                      icon: const Icon(Icons.add),
                      label: const Text('Create Match'),
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.all(16),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              
              // Match Filters
              SizedBox(
                height: 40,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: [
                    _buildFilterChip('All Levels', true),
                    _buildFilterChip('Beginner', false),
                    _buildFilterChip('Intermediate', false),
                    _buildFilterChip('Advanced', false),
                    _buildFilterChip('Nearby', false),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              
              // Upcoming Matches
              const Text('Upcoming Matches', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              _buildMatchCard(context, 'Today, 2:00 PM', 'You & Alex vs John & Mike', 'Elite Padel Club', 'Confirmed', 'Intermediate'),
              _buildMatchCard(context, 'Tomorrow, 10:00 AM', 'You & Maria vs Sarah & Ana', 'Sports Complex', 'Pending', 'Advanced'),
              _buildMatchCard(context, 'Mar 20, 6:00 PM', 'You & Carlos vs Pro Team', 'Premium Courts', 'Confirmed', 'Expert'),
              const SizedBox(height: 20),
              
              // Available Players
              const Text('Available Players', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              _buildPlayerCard(context, 'Alex & Carlos', 'Intermediate', 'Available now', '4.2', 'Doubles team looking for opponents'),
              _buildPlayerCard(context, 'Maria & Sofia', 'Advanced', 'Available evening', '4.8', 'Competitive players seeking challenge'),
              _buildPlayerCard(context, 'David & Luis', 'Beginner', 'Weekends only', '3.9', 'Friendly casual games preferred'),
              _buildPlayerCard(context, 'Emma & Tom', 'Intermediate', 'Flexible schedule', '4.5', 'Fun-loving duo, all skill levels welcome'),
              const SizedBox(height: 20),
              
              // Recent Matches
              const Text('Recent Matches', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              _buildRecentMatchCard('Yesterday', 'Won 6-4, 6-2', 'vs John & Mike', true, 'Elite Padel Club'),
              _buildRecentMatchCard('Last Week', 'Lost 4-6, 6-3, 4-6', 'vs Pro Team', false, 'Premium Courts'),
              _buildRecentMatchCard('2 weeks ago', 'Won 6-2, 6-1', 'vs Alex & Tom', true, 'Sports Complex'),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildFilterChip(String label, bool isSelected) {
    return Container(
      margin: const EdgeInsets.only(right: 8),
      child: FilterChip(
        label: Text(label),
        selected: isSelected,
        onSelected: (selected) {},
        selectedColor: const Color(0xFF099c37).withOpacity(0.2),
        checkmarkColor: const Color(0xFF099c37),
      ),
    );
  }

  Widget _buildMatchCard(BuildContext context, String time, String players, String location, String status, String level) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              children: [
                CircleAvatar(
                  backgroundColor: status == 'Confirmed' ? const Color(0xFF099c37) : Colors.orange,
                  child: Icon(status == 'Confirmed' ? Icons.check : Icons.schedule, color: Colors.white),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(time, style: const TextStyle(fontWeight: FontWeight.bold)),
                      Text(players, style: const TextStyle(color: Colors.grey)),
                      Text(location, style: const TextStyle(color: Colors.grey)),
                      const SizedBox(height: 4),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                        decoration: BoxDecoration(
                          color: Colors.grey[200],
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(level, style: const TextStyle(fontSize: 12)),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: status == 'Confirmed' ? const Color(0xFF099c37) : Colors.orange,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(status, style: const TextStyle(color: Colors.white, fontSize: 12)),
                ),
              ],
            ),
            if (status == 'Pending') ...[
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => _declineMatch(context, ref, time),
                      child: const Text('Decline'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () => _confirmMatch(context, ref, time),
                      child: const Text('Confirm'),
                    ),
                  ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildPlayerCard(BuildContext context, String names, String level, String availability, String rating, String description) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            const CircleAvatar(
              backgroundColor: Color(0xFF099c37),
              child: Icon(Icons.people, color: Colors.white),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(names, style: const TextStyle(fontWeight: FontWeight.bold)),
                  Text('Level: $level', style: const TextStyle(color: Colors.grey)),
                  Text(availability, style: const TextStyle(color: Colors.grey)),
                  const SizedBox(height: 4),
                  Text(description, style: const TextStyle(color: Colors.grey, fontSize: 12)),
                  Row(
                    children: [
                      const Icon(Icons.star, size: 14, color: Colors.amber),
                      Text(' $rating rating', style: const TextStyle(color: Colors.grey, fontSize: 12)),
                    ],
                  ),
                ],
              ),
            ),
            ElevatedButton(
              onPressed: () => _challengePlayers(context, ref, names),
              child: const Text('Challenge'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRecentMatchCard(String date, String result, String opponent, bool won, String location) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            CircleAvatar(
              backgroundColor: won ? const Color(0xFF099c37) : Colors.red,
              child: Icon(won ? Icons.emoji_events : Icons.close, color: Colors.white),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('$date $opponent', style: const TextStyle(fontWeight: FontWeight.bold)),
                  Text(result, style: const TextStyle(color: Colors.grey)),
                  Text(location, style: const TextStyle(color: Colors.grey, fontSize: 12)),
                ],
              ),
            ),
            const Icon(Icons.arrow_forward_ios, color: Colors.grey),
          ],
        ),
      ),
    );
  }

  /// Decline match invitation
  void _declineMatch(BuildContext context, WidgetRef ref, String matchTime) async {
    setLoading(ref, 'match_decline', true);

    try {
      showMessage(ref, 'Match declined for $matchTime');

    } catch (e) {
      showMessage(ref, 'Failed to decline match: $e', isError: true);
    } finally {
      setLoading(ref, 'match_decline', false);
    }
  }

  /// Confirm match invitation
  void _confirmMatch(BuildContext context, WidgetRef ref, String matchTime) async {
    setLoading(ref, 'match_confirm', true);

    try {
      showMessage(ref, 'Match confirmed for $matchTime! 🎾');

    } catch (e) {
      showMessage(ref, 'Failed to confirm match: $e', isError: true);
    } finally {
      setLoading(ref, 'match_confirm', false);
    }
  }

  /// Challenge players
  void _challengePlayers(BuildContext context, WidgetRef ref, String playerNames) async {
    final authService = ref.read(authServiceProvider);

    // Check if user is logged in
    if (!authService.isAuthenticated) {
      _showAuthRequiredDialog(context, ref);
      return;
    }

    _showChallengeDialog(context, ref, playerNames);
  }

  /// Show challenge dialog
  void _showChallengeDialog(BuildContext context, WidgetRef ref, String playerNames) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Challenge $playerNames'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Players: $playerNames'),
            const SizedBox(height: 16),
            const Text('Match Details:', style: TextStyle(fontWeight: FontWeight.bold)),
            const Text('• Doubles match format'),
            const Text('• Best of 3 sets'),
            const Text('• Court booking required'),
            const Text('• Challenge valid for 48 hours'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () => _confirmChallenge(context, ref, playerNames),
            child: const Text('Send Challenge'),
          ),
        ],
      ),
    );
  }

  /// Confirm challenge
  void _confirmChallenge(BuildContext context, WidgetRef ref, String playerNames) async {
    Navigator.pop(context); // Close dialog

    setLoading(ref, 'player_challenge', true);

    try {
      showMessage(ref, 'Challenge sent to $playerNames! ⚔️');

    } catch (e) {
      showMessage(ref, 'Failed to send challenge: $e', isError: true);
    } finally {
      setLoading(ref, 'player_challenge', false);
    }
  }
}

// PROFILE PAGE - Complete user profile and settings
class ProfilePage extends ConsumerWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile', style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () => _showSettingsDialog(context, ref),
          ),
          IconButton(
            icon: const Icon(Icons.edit),
            onPressed: () => _editProfile(context, ref),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () async {
          await Future.delayed(const Duration(seconds: 1));
          _showFeatureSnackBar(context, 'Profile refreshed!');
        },
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              // Profile Header
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [Color(0xFF099c37), Color(0xFF0a8c32)],
                  ),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Column(
                  children: [
                    const CircleAvatar(
                      radius: 50,
                      backgroundColor: Colors.white,
                      child: Icon(Icons.person, size: 50, color: Color(0xFF099c37)),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      ref.watch(currentUserProvider)?.profile.fullName ?? 'Welcome to Padelo',
                      style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.white),
                    ),
                    Text(
                      ref.watch(currentUserProvider) != null
                        ? '${ref.watch(currentUserProvider)!.role.name.toUpperCase()} • Member since ${ref.watch(currentUserProvider)!.createdAt.year}'
                        : 'Please log in to see your profile',
                      style: const TextStyle(color: Colors.white70),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              
              // Stats Row
              Card(
                elevation: 2,
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Consumer(
                        builder: (context, ref, child) {
                          final ranking = ref.watch(userRankingProvider);
                          return ranking.when(
                            data: (playerRanking) => Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                _buildStatColumn('${playerRanking?.totalMatches ?? 0}', 'Matches'),
                                _buildStatColumn('${playerRanking?.totalWins ?? 0}', 'Wins'),
                                _buildStatColumn('${playerRanking?.winRate.toStringAsFixed(0) ?? 0}%', 'Win Rate'),
                                _buildStatColumn('#${playerRanking?.globalRank ?? '-'}', 'Ranking'),
                              ],
                            ),
                            loading: () => Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                _buildStatColumn('...', 'Matches'),
                                _buildStatColumn('...', 'Wins'),
                                _buildStatColumn('...', 'Win Rate'),
                                _buildStatColumn('...', 'Ranking'),
                              ],
                            ),
                            error: (error, stackTrace) => Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                _buildStatColumn('0', 'Matches'),
                                _buildStatColumn('0', 'Wins'),
                                _buildStatColumn('0%', 'Win Rate'),
                                _buildStatColumn('#-', 'Ranking'),
                              ],
                            ),
                          );
                        },
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 20),
              
              // Achievements
              _buildAchievements(),
              const SizedBox(height: 20),
              
              // Account Section
              _buildProfileSection('Account', [
                _buildProfileItem(Icons.person, 'Personal Information', 'Update your details'),
                _buildProfileItem(Icons.security, 'Privacy & Security', 'Manage account security'),
                _buildProfileItem(Icons.payment, 'Payment Methods', 'Credit cards and billing'),
                _buildProfileItem(Icons.notifications, 'Notifications', 'Push notifications settings'),
                _buildProfileItem(Icons.language, 'Language & Region', 'App language preferences'),
              ]),
              const SizedBox(height: 20),
              
              // Game Section
              _buildProfileSection('Game', [
                _buildProfileItem(Icons.emoji_events, 'Achievements', 'View your trophies and badges'),
                _buildProfileItem(Icons.history, 'Match History', 'All your past games'),
                _buildProfileItem(Icons.star, 'Favorite Courts', 'Your preferred venues'),
                _buildProfileItem(Icons.people, 'Friends & Connections', 'Your padel network'),
                _buildProfileItem(Icons.analytics, 'Performance Analytics', 'Detailed game statistics'),
              ]),
              const SizedBox(height: 20),
              
              // Support Section
              _buildProfileSection('Support', [
                _buildProfileItem(Icons.help, 'Help Center', 'FAQs and support articles'),
                _buildProfileItem(Icons.feedback, 'Send Feedback', 'Help us improve Padelo'),
                _buildProfileItem(Icons.info, 'About Padelo', 'App version and information'),
                _buildProfileItem(Icons.privacy_tip, 'Privacy Policy', 'Data usage and privacy'),
                _buildProfileItem(Icons.logout, 'Sign Out', 'Logout from your account', isRed: true),
              ]),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatColumn(String value, String label) {
    return Column(
      children: [
        Text(value, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Color(0xFF099c37))),
        Text(label, style: const TextStyle(color: Colors.grey)),
      ],
    );
  }

  Widget _buildAchievements() {
    return Card(
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Row(
              children: [
                Icon(Icons.emoji_events, color: Color(0xFF099c37)),
                SizedBox(width: 8),
                Text('Recent Achievements', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildAchievementBadge('🏆', 'Tournament\nWinner'),
                _buildAchievementBadge('🔥', '10 Win\nStreak'),
                _buildAchievementBadge('⭐', 'Top 200\nPlayer'),
                _buildAchievementBadge('🎯', 'Ace\nServer'),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAchievementBadge(String emoji, String title) {
    return Column(
      children: [
        Container(
          width: 50,
          height: 50,
          decoration: BoxDecoration(
            color: const Color(0xFF099c37).withOpacity(0.1),
            borderRadius: BorderRadius.circular(25),
          ),
          child: Center(
            child: Text(emoji, style: const TextStyle(fontSize: 24)),
          ),
        ),
        const SizedBox(height: 8),
        Text(title, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
      ],
    );
  }

  Widget _buildProfileSection(String title, List<Widget> items) {
    return Card(
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            ...items,
          ],
        ),
      ),
    );
  }

  Widget _buildProfileItem(IconData icon, String title, String subtitle, {bool isRed = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Icon(icon, color: isRed ? Colors.red : Colors.grey),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: TextStyle(color: isRed ? Colors.red : Colors.black, fontWeight: FontWeight.w500)),
                Text(subtitle, style: const TextStyle(color: Colors.grey, fontSize: 12)),
              ],
            ),
          ),
          const Icon(Icons.arrow_forward_ios, color: Colors.grey, size: 16),
        ],
      ),
    );
  }

  /// Show settings dialog
  void _showSettingsDialog(BuildContext context, WidgetRef ref) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Settings'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.notifications),
              title: const Text('Notifications'),
              subtitle: const Text('Manage notification preferences'),
              onTap: () {
                Navigator.pop(context);
                showMessage(ref, 'Notification settings opened');
              },
            ),
            ListTile(
              leading: const Icon(Icons.language),
              title: const Text('Language'),
              subtitle: const Text('العربية / English'),
              onTap: () {
                Navigator.pop(context);
                showMessage(ref, 'Language settings opened');
              },
            ),
            ListTile(
              leading: const Icon(Icons.security),
              title: const Text('Privacy & Security'),
              subtitle: const Text('Account security settings'),
              onTap: () {
                Navigator.pop(context);
                showMessage(ref, 'Security settings opened');
              },
            ),
            ListTile(
              leading: const Icon(Icons.logout, color: Colors.red),
              title: const Text('Sign Out', style: TextStyle(color: Colors.red)),
              onTap: () => _signOut(context, ref),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  /// Edit profile functionality
  void _editProfile(BuildContext context, WidgetRef ref) {
    final authService = ref.read(authServiceProvider);
    final currentUser = authService.currentUser;

    if (currentUser == null) {
      showMessage(ref, 'Please log in to edit profile', isError: true);
      return;
    }

    final firstNameController = TextEditingController(text: currentUser.profile.firstName);
    final lastNameController = TextEditingController(text: currentUser.profile.lastName);
    final phoneController = TextEditingController(text: currentUser.phoneNumber);
    final cityController = TextEditingController(text: currentUser.profile.city);
    final bioController = TextEditingController(text: currentUser.profile.bio ?? '');

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Edit Profile'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: firstNameController,
                decoration: const InputDecoration(
                  labelText: 'First Name',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: lastNameController,
                decoration: const InputDecoration(
                  labelText: 'Last Name',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: phoneController,
                decoration: const InputDecoration(
                  labelText: 'Phone Number',
                  border: OutlineInputBorder(),
                ),
                keyboardType: TextInputType.phone,
              ),
              const SizedBox(height: 12),
              TextField(
                controller: cityController,
                decoration: const InputDecoration(
                  labelText: 'City',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: bioController,
                decoration: const InputDecoration(
                  labelText: 'Bio',
                  border: OutlineInputBorder(),
                ),
                maxLines: 3,
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () => _saveProfile(
              context,
              ref,
              firstNameController.text,
              lastNameController.text,
              phoneController.text,
              cityController.text,
              bioController.text,
            ),
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  /// Save profile changes
  void _saveProfile(BuildContext context, WidgetRef ref, String firstName, String lastName,
                   String phone, String city, String bio) async {
    Navigator.pop(context); // Close dialog

    setLoading(ref, 'profile_update', true);

    try {
      final authService = ref.read(authServiceProvider);
      final result = await authService.updateProfile(
        firstName: firstName,
        lastName: lastName,
        phoneNumber: phone,
        city: city,
        bio: bio,
      );

      if (result.success) {
        // Update current user in provider
        ref.read(currentUserProvider.notifier).state = result.user;

        showMessage(ref, result.message);
        refreshUserData(ref);
      } else {
        showMessage(ref, result.message, isError: true);
      }

    } catch (e) {
      showMessage(ref, 'Profile update failed: $e', isError: true);
    } finally {
      setLoading(ref, 'profile_update', false);
    }
  }

  /// Sign out functionality
  void _signOut(BuildContext context, WidgetRef ref) async {
    Navigator.pop(context); // Close settings dialog

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Sign Out'),
        content: const Text('Are you sure you want to sign out?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () => _confirmSignOut(context, ref),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Sign Out'),
          ),
        ],
      ),
    );
  }

  /// Confirm sign out
  void _confirmSignOut(BuildContext context, WidgetRef ref) async {
    Navigator.pop(context); // Close confirmation dialog

    setLoading(ref, 'signout', true);

    try {
      final authService = ref.read(authServiceProvider);
      await authService.signOut();

      // Reset all providers
      resetAllProviders(ref);

      showMessage(ref, 'Signed out successfully. See you soon! 👋');

    } catch (e) {
      showMessage(ref, 'Sign out failed: $e', isError: true);
    } finally {
      setLoading(ref, 'signout', false);
    }
  }
}

// Helper function for showing feature notifications
void _showFeatureSnackBar(BuildContext context, String feature) {
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      content: Text('$feature coming soon! 🚀'),
      behavior: SnackBarBehavior.floating,
      duration: const Duration(seconds: 2),
      backgroundColor: const Color(0xFF099c37),
    ),
  );
}
