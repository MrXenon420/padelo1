import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:easy_localization/easy_localization.dart';

import 'core/theme/app_theme.dart';
import 'core/router/app_router.dart';
import 'core/providers/auth_provider.dart';
import 'core/providers/app_provider.dart';
import 'core/models/user_model.dart';
import 'presentation/screens/language_selection/language_selection_screen.dart';
import 'presentation/screens/splash/splash_screen.dart';

class PadeloApp extends ConsumerWidget {
  const PadeloApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final appState = ref.watch(appProvider);
    final authState = ref.watch(authProvider);
    
    return MaterialApp.router(
      title: 'Padelo',
      debugShowCheckedModeBanner: false,
      
      // Theme Configuration
      theme: AppTheme.lightTheme,
      darkTheme: AppTheme.darkTheme,
      themeMode: ThemeMode.light,
      
      // Localization
      localizationsDelegates: context.localizationDelegates,
      supportedLocales: context.supportedLocales,
      locale: context.locale,
      
      // Routing
      routerConfig: AppRouter.router,
      
      // Builder for handling app state
      builder: (context, child) {
        return _AppStateBuilder(
          appState: appState,
          authState: authState,
          child: child,
        );
      },
    );
  }
}

class _AppStateBuilder extends StatelessWidget {
  final AsyncValue<bool> appState;
  final AsyncValue<User?> authState;
  final Widget? child;
  
  const _AppStateBuilder({
    required this.appState,
    required this.authState,
    this.child,
  });

  @override
  Widget build(BuildContext context) {
    return appState.when(
      data: (isInitialized) {
        if (!isInitialized) {
          return const SplashScreen();
        }
        
        // Check if language is selected
        final isLanguageSelected = context.locale != const Locale('en') ||
            // Add logic to check if language was explicitly selected
            true; // Temporary - would check SharedPreferences
            
        if (!isLanguageSelected) {
          return const LanguageSelectionScreen();
        }
        
        return child ?? const SizedBox.shrink();
      },
      loading: () => const SplashScreen(),
      error: (error, stack) => MaterialApp(
        home: Scaffold(
          body: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(
                  Icons.error_outline,
                  size: 64,
                  color: Colors.red,
                ),
                const SizedBox(height: 16),
                Text(
                  'Something went wrong',
                  style: Theme.of(context).textTheme.headlineSmall,
                ),
                const SizedBox(height: 8),
                Text(
                  error.toString(),
                  style: Theme.of(context).textTheme.bodyMedium,
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
