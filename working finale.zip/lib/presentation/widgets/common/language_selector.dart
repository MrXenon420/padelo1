import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:easy_localization/easy_localization.dart';

import '../../../core/providers/language_provider.dart';

class LanguageSelector extends ConsumerWidget {
  const LanguageSelector({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final currentLanguage = ref.watch(languageProvider);
    
    return PopupMenuButton<String>(
      onSelected: (languageCode) async {
        final locale = Locale(languageCode, languageCode == 'ar' ? 'SA' : 'US');
        await context.setLocale(locale);
        await ref.read(languageProvider.notifier).setLanguage(languageCode);
      },
      itemBuilder: (context) => [
        PopupMenuItem(
          value: 'en',
          child: Row(
            children: [
              const Text('🇺🇸', style: TextStyle(fontSize: 20)),
              const SizedBox(width: 12),
              const Text('English'),
              if (currentLanguage == 'en') ...[
                const Spacer(),
                const Icon(Icons.check, color: Color(0xFF099c37)),
              ],
            ],
          ),
        ),
        PopupMenuItem(
          value: 'ar',
          child: Row(
            children: [
              const Text('🇸🇦', style: TextStyle(fontSize: 20)),
              const SizedBox(width: 12),
              const Text('العربية'),
              if (currentLanguage == 'ar') ...[
                const Spacer(),
                const Icon(Icons.check, color: Color(0xFF099c37)),
              ],
            ],
          ),
        ),
      ],
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        decoration: BoxDecoration(
          border: Border.all(color: Colors.grey[300]!),
          borderRadius: BorderRadius.circular(6),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.language, size: 16, color: Colors.grey),
            const SizedBox(width: 4),
            Text(
              currentLanguage == 'ar' ? '🇸🇦' : '🇺🇸',
              style: const TextStyle(fontSize: 16),
            ),
          ],
        ),
      ),
    );
  }
}
