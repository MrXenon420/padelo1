import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

enum LogoSize { small, medium, large }

class PadeloLogo extends StatelessWidget {
  final LogoSize size;
  final bool textOnly;
  final Color? color;

  const PadeloLogo({
    super.key,
    this.size = LogoSize.medium,
    this.textOnly = false,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final logoColor = color ?? theme.colorScheme.onSurface;
    
    if (textOnly) {
      return _buildTextLogo(context, logoColor);
    }

    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        _buildPadelBall(context),
        SizedBox(width: _getSpacing()),
        _buildTextLogo(context, logoColor),
      ],
    );
  }

  Widget _buildPadelBall(BuildContext context) {
    final ballSize = _getBallSize();
    
    return CustomPaint(
      size: Size(ballSize, ballSize),
      painter: PadelBallPainter(),
    );
  }

  Widget _buildTextLogo(BuildContext context, Color logoColor) {
    final theme = Theme.of(context);
    final fontSize = _getFontSize();
    
    return RichText(
      text: TextSpan(
        style: theme.textTheme.headlineLarge?.copyWith(
          fontSize: fontSize,
          fontWeight: FontWeight.w700,
          color: logoColor,
          fontFamily: 'Inter',
        ),
        children: [
          const TextSpan(text: 'Padel'),
          TextSpan(
            text: 'o',
            style: TextStyle(
              color: const Color(0xFF099c37),
              fontSize: fontSize,
            ),
          ),
        ],
      ),
    );
  }

  double _getFontSize() {
    switch (size) {
      case LogoSize.small:
        return 18;
      case LogoSize.medium:
        return 24;
      case LogoSize.large:
        return 32;
    }
  }

  double _getBallSize() {
    switch (size) {
      case LogoSize.small:
        return 20;
      case LogoSize.medium:
        return 28;
      case LogoSize.large:
        return 36;
    }
  }

  double _getSpacing() {
    switch (size) {
      case LogoSize.small:
        return 6;
      case LogoSize.medium:
        return 8;
      case LogoSize.large:
        return 12;
    }
  }
}

class PadelBallPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = size.width / 2;
    
    // Main ball circle
    final ballPaint = Paint()
      ..color = const Color(0xFF099c37)
      ..style = PaintingStyle.fill;
    
    canvas.drawCircle(center, radius, ballPaint);
    
    // Ball border
    final borderPaint = Paint()
      ..color = const Color(0xFF087830)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.0;
    
    canvas.drawCircle(center, radius, borderPaint);
    
    // Padel ball pattern - curved lines
    final linePaint = Paint()
      ..color = Colors.white
      ..style = PaintingStyle.stroke
      ..strokeWidth = size.width * 0.06
      ..strokeCap = StrokeCap.round;
    
    // Top curve
    final topPath = Path();
    topPath.moveTo(size.width * 0.25, size.height * 0.3);
    topPath.quadraticBezierTo(
      size.width * 0.5, size.height * 0.35,
      size.width * 0.75, size.height * 0.3,
    );
    canvas.drawPath(topPath, linePaint);
    
    // Bottom curve
    final bottomPath = Path();
    bottomPath.moveTo(size.width * 0.25, size.height * 0.7);
    bottomPath.quadraticBezierTo(
      size.width * 0.5, size.height * 0.65,
      size.width * 0.75, size.height * 0.7,
    );
    canvas.drawPath(bottomPath, linePaint);
    
    // Vertical line
    canvas.drawLine(
      Offset(size.width * 0.5, size.height * 0.15),
      Offset(size.width * 0.5, size.height * 0.85),
      linePaint,
    );
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}
