import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';

import '../../../core/models/tournament_model.dart';
import '../../../core/utils/constants.dart';
import '../../../core/utils/extensions.dart';

class LeaderboardItem extends StatelessWidget {
  final LeaderboardEntry entry;
  final VoidCallback? onTap;

  const LeaderboardItem({
    super.key,
    required this.entry,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              _buildRankBadge(),
              const SizedBox(width: 16),
              _buildAvatar(),
              const SizedBox(width: 12),
              Expanded(
                child: _buildPlayerInfo(context),
              ),
              _buildStats(context),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildRankBadge() {
    Color backgroundColor;
    Color textColor;

    if (entry.globalRank <= 3) {
      backgroundColor = entry.globalRank == 1
          ? Colors.amber
          : entry.globalRank == 2
              ? Colors.grey[400]!
              : Colors.orange[400]!;
      textColor = Colors.white;
    } else {
      backgroundColor = Colors.grey[100]!;
      textColor = Colors.black;
    }

    return Container(
      width: 40,
      height: 40,
      decoration: BoxDecoration(
        color: backgroundColor,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Center(
        child: Text(
          '#${entry.globalRank}',
          style: TextStyle(
            fontWeight: FontWeight.w700,
            fontSize: entry.globalRank <= 3 ? 14 : 12,
            color: textColor,
          ),
        ),
      ),
    );
  }

  Widget _buildAvatar() {
    return CircleAvatar(
      radius: 24,
      backgroundColor: Colors.grey[200],
      backgroundImage: entry.profilePicture != null
          ? NetworkImage(entry.profilePicture!)
          : null,
      child: entry.profilePicture == null
          ? Text(
              _getInitials(entry.playerName),
              style: const TextStyle(
                fontWeight: FontWeight.w600,
                color: Colors.grey,
              ),
            )
          : null,
    );
  }

  Widget _buildPlayerInfo(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(
              child: Text(
                entry.playerName,
                style: const TextStyle(
                  fontWeight: FontWeight.w600,
                  fontSize: 16,
                ),
              ),
            ),
            _buildTierBadge(),
          ],
        ),
        const SizedBox(height: 4),
        Row(
          children: [
            if (entry.globalRank <= 3) _buildTopThreeBadge(),
            Text(
              entry.ranking.region,
              style: TextStyle(
                color: Colors.grey[600],
                fontSize: 12,
              ),
            ),
            const SizedBox(width: 8),
            Text(
              entry.ranking.gender.name.capitalize(),
              style: TextStyle(
                color: Colors.grey[600],
                fontSize: 12,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildTierBadge() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: _getTierColor(entry.ranking.tier),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          _getTierIcon(entry.ranking.tier),
          const SizedBox(width: 4),
          Text(
            entry.ranking.fullRankDisplay,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 10,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTopThreeBadge() {
    if (entry.globalRank > 3) return const SizedBox.shrink();

    String emoji;
    switch (entry.globalRank) {
      case 1:
        emoji = '🥇';
        break;
      case 2:
        emoji = '🥈';
        break;
      case 3:
        emoji = '🥉';
        break;
      default:
        emoji = '';
    }

    return Container(
      margin: const EdgeInsets.only(right: 8),
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: Colors.grey[100],
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(emoji, style: const TextStyle(fontSize: 12)),
          const SizedBox(width: 2),
          const Text(
            'Top 3',
            style: TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStats(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Text(
          '${entry.ranking.lp}',
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w700,
            color: Color(0xFF099c37),
          ),
        ),
        Text(
          'LP',
          style: TextStyle(
            fontSize: 10,
            color: Colors.grey[600],
          ),
        ),
        const SizedBox(height: 4),
        Text(
          '${entry.ranking.winRate.toStringAsFixed(0)}%',
          style: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w600,
          ),
        ),
        Text(
          'Win Rate',
          style: TextStyle(
            fontSize: 10,
            color: Colors.grey[600],
          ),
        ),
      ],
    );
  }

  String _getInitials(String name) {
    final parts = name.split(' ');
    if (parts.length >= 2) {
      return '${parts[0][0]}${parts[1][0]}'.toUpperCase();
    } else if (parts.isNotEmpty) {
      return parts[0][0].toUpperCase();
    }
    return 'U';
  }

  Color _getTierColor(UserTier tier) {
    switch (tier) {
      case UserTier.rookie:
        return Colors.grey[600]!;
      case UserTier.beginner:
        return Colors.green[600]!;
      case UserTier.intermediate:
        return Colors.blue[600]!;
      case UserTier.advanced:
        return Colors.purple[600]!;
      case UserTier.elite:
        return Colors.orange[600]!;
      case UserTier.master:
        return Colors.red[600]!;
      case UserTier.proPlayers:
        return Colors.black;
    }
  }

  Widget _getTierIcon(UserTier tier) {
    IconData iconData;
    
    switch (tier) {
      case UserTier.rookie:
      case UserTier.beginner:
      case UserTier.intermediate:
        iconData = Icons.military_tech;
        break;
      case UserTier.advanced:
      case UserTier.elite:
        iconData = Icons.emoji_events;
        break;
      case UserTier.master:
      case UserTier.proPlayers:
        iconData = Icons.workspace_premium;
        break;
    }

    return Icon(
      iconData,
      color: Colors.white,
      size: 12,
    );
  }
}
