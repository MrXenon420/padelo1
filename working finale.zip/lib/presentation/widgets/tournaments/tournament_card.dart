import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';

import '../../../core/models/tournament_model.dart';
import '../../../core/utils/constants.dart';

class TournamentCard extends StatelessWidget {
  final Tournament tournament;
  final VoidCallback? onJoin;
  final VoidCallback? onLeave;
  final VoidCallback? onTap;

  const TournamentCard({
    super.key,
    required this.tournament,
    this.onJoin,
    this.onLeave,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildHeader(context),
              const SizedBox(height: 12),
              _buildDetails(context),
              const SizedBox(height: 12),
              _buildPrizePool(context),
              const SizedBox(height: 12),
              _buildLPInfo(context),
              const SizedBox(height: 16),
              _buildActions(context),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      tournament.name,
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  _buildStatusBadge(),
                ],
              ),
              const SizedBox(height: 4),
              Row(
                children: [
                  _buildTypeBadge(),
                  const SizedBox(width: 8),
                  if (tournament.isOfficial) _buildOfficialBadge(),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildStatusBadge() {
    Color backgroundColor;
    Color textColor = Colors.white;
    IconData icon;

    switch (tournament.status) {
      case TournamentStatus.upcoming:
        backgroundColor = Colors.blue;
        icon = Icons.schedule;
        break;
      case TournamentStatus.ongoing:
        backgroundColor = const Color(0xFF099c37);
        icon = Icons.play_arrow;
        break;
      case TournamentStatus.completed:
        backgroundColor = Colors.grey;
        icon = Icons.check_circle;
        break;
      case TournamentStatus.cancelled:
        backgroundColor = Colors.red;
        icon = Icons.cancel;
        break;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: backgroundColor,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 14, color: textColor),
          const SizedBox(width: 4),
          Text(
            tournament.status.name.toUpperCase(),
            style: TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w600,
              color: textColor,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTypeBadge() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: tournament.isOfficial ? const Color(0xFF099c37) : Colors.grey[300],
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        tournament.tournamentType.name.toUpperCase(),
        style: TextStyle(
          fontSize: 10,
          fontWeight: FontWeight.w500,
          color: tournament.isOfficial ? Colors.white : Colors.grey[700],
        ),
      ),
    );
  }

  Widget _buildOfficialBadge() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: const Color(0xFF099c37),
        borderRadius: BorderRadius.circular(8),
      ),
      child: const Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.bolt, size: 10, color: Colors.white),
          SizedBox(width: 2),
          Text(
            'OFFICIAL',
            style: TextStyle(
              fontSize: 9,
              fontWeight: FontWeight.w600,
              color: Colors.white,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDetails(BuildContext context) {
    return Column(
      children: [
        Row(
          children: [
            Expanded(
              child: _buildDetailItem(
                context,
                Icons.location_pin,
                'tournaments.location'.tr(),
                tournament.location,
              ),
            ),
            Expanded(
              child: _buildDetailItem(
                context,
                Icons.calendar_today,
                'tournaments.startDate'.tr(),
                DateFormat('MMM dd').format(tournament.startDate),
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(
              child: _buildDetailItem(
                context,
                Icons.group,
                'tournaments.participants'.tr(),
                '${tournament.currentParticipants}/${tournament.maxParticipants}',
              ),
            ),
            Expanded(
              child: _buildDetailItem(
                context,
                Icons.attach_money,
                'tournaments.entryFee'.tr(),
                '\$${tournament.entryFee.toStringAsFixed(0)}',
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildDetailItem(BuildContext context, IconData icon, String label, String value) {
    return Row(
      children: [
        Icon(icon, size: 16, color: Colors.grey[600]),
        const SizedBox(width: 4),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: TextStyle(
                  fontSize: 10,
                  color: Colors.grey[600],
                ),
              ),
              Text(
                value,
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildPrizePool(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.grey[50],
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'tournaments.prizePool'.tr(),
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w500,
              color: Colors.grey[700],
            ),
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _buildPrizeItem('🥇', '\$${tournament.prizes.first.toStringAsFixed(0)}'),
              _buildPrizeItem('🥈', '\$${tournament.prizes.second.toStringAsFixed(0)}'),
              _buildPrizeItem('🥉', '\$${tournament.prizes.third.toStringAsFixed(0)}'),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildPrizeItem(String emoji, String amount) {
    return Column(
      children: [
        Text(emoji, style: const TextStyle(fontSize: 20)),
        const SizedBox(height: 2),
        Text(
          amount,
          style: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }

  Widget _buildLPInfo(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: tournament.isOfficial 
            ? const Color(0xFF099c37).withOpacity(0.1)
            : Colors.grey[100],
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                Icons.trending_up,
                size: 16,
                color: tournament.isOfficial ? const Color(0xFF099c37) : Colors.grey[600],
              ),
              const SizedBox(width: 4),
              Text(
                'tournaments.leaguePoints'.tr(),
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                  color: tournament.isOfficial ? const Color(0xFF099c37) : Colors.grey[700],
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text(
            tournament.isOfficial
                ? 'tournaments.fullRanking'.tr()
                : 'tournaments.limitedRanking'.tr(),
            style: TextStyle(
              fontSize: 11,
              color: tournament.isOfficial ? const Color(0xFF099c37) : Colors.grey[600],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActions(BuildContext context) {
    if (tournament.status == TournamentStatus.completed || 
        tournament.status == TournamentStatus.cancelled) {
      return SizedBox(
        width: double.infinity,
        child: OutlinedButton(
          onPressed: onTap,
          child: Text('tournaments.viewDetails'.tr()),
        ),
      );
    }

    return Row(
      children: [
        Expanded(
          child: ElevatedButton(
            onPressed: tournament.isFull ? null : onJoin,
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF099c37),
              disabledBackgroundColor: Colors.grey[300],
            ),
            child: Text(
              tournament.isFull 
                  ? 'tournaments.full'.tr()
                  : 'tournaments.joinTournament'.tr(),
              style: TextStyle(
                color: tournament.isFull ? Colors.grey[600] : Colors.white,
              ),
            ),
          ),
        ),
        const SizedBox(width: 12),
        OutlinedButton(
          onPressed: onTap,
          child: Text('tournaments.viewDetails'.tr()),
        ),
      ],
    );
  }
}
