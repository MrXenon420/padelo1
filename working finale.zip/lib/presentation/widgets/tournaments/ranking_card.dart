import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';

import '../../../core/models/tournament_model.dart';
import '../../../core/utils/constants.dart';

class RankingCard extends StatelessWidget {
  final PlayerRanking ranking;

  const RankingCard({
    super.key,
    required this.ranking,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            const Color(0xFF099c37).withOpacity(0.1),
            Colors.white,
          ],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: const Color(0xFF099c37).withOpacity(0.2),
          width: 1.5,
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildHeader(context),
            const SizedBox(height: 20),
            _buildStats(context),
            const SizedBox(height: 16),
            _buildProgressBar(context),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'tournaments.yourRanking'.tr(),
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              'Compete to climb higher!',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Colors.grey[600],
              ),
            ),
          ],
        ),
        _buildTierBadge(context),
      ],
    );
  }

  Widget _buildTierBadge(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: _getTierColors(ranking.tier),
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: _getTierColors(ranking.tier)[0].withOpacity(0.3),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          _getTierIcon(ranking.tier),
          const SizedBox(width: 6),
          Text(
            ranking.fullRankDisplay,
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w600,
              fontSize: 14,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStats(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: _buildStatItem(
            context,
            '#${_getFormattedRank()}',
            'tournaments.globalRank'.tr(),
            Colors.black,
          ),
        ),
        Expanded(
          child: _buildStatItem(
            context,
            '${ranking.lp}',
            'tournaments.lpPoints'.tr(),
            const Color(0xFF099c37),
          ),
        ),
        Expanded(
          child: _buildStatItem(
            context,
            '${ranking.winRate.toStringAsFixed(0)}%',
            'tournaments.winRate'.tr(),
            Colors.black,
          ),
        ),
        Expanded(
          child: _buildStatItem(
            context,
            '${ranking.officialTournamentWins}',
            'tournaments.tournamentsWon'.tr(),
            const Color(0xFF099c37),
          ),
        ),
      ],
    );
  }

  Widget _buildStatItem(BuildContext context, String value, String label, Color valueColor) {
    return Column(
      children: [
        Text(
          value,
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.w700,
            color: valueColor,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: TextStyle(
            fontSize: 12,
            color: Colors.grey[600],
          ),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }

  Widget _buildProgressBar(BuildContext context) {
    final progressPercentage = ranking.lpRequiredForPromotion > 0
        ? (ranking.lp % 500) / 500.0  // Simplified calculation
        : 1.0;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'tournaments.progressToNext'.tr(),
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w500,
                color: Colors.grey[700],
              ),
            ),
            Text(
              ranking.lpRequiredForPromotion > 0
                  ? '${ranking.lpRequiredForPromotion} ${'tournaments.lpNeeded'.tr()}'
                  : 'Max tier reached',
              style: TextStyle(
                fontSize: 12,
                color: Colors.grey[600],
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Container(
          height: 8,
          decoration: BoxDecoration(
            color: Colors.grey[200],
            borderRadius: BorderRadius.circular(4),
          ),
          child: FractionallySizedBox(
            alignment: Alignment.centerLeft,
            widthFactor: progressPercentage,
            child: Container(
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF099c37), Color(0xFF0FB849)],
                ),
                borderRadius: BorderRadius.circular(4),
              ),
            ),
          ),
        ),
      ],
    );
  }

  List<Color> _getTierColors(UserTier tier) {
    switch (tier) {
      case UserTier.rookie:
        return [Colors.grey[600]!, Colors.grey[400]!];
      case UserTier.beginner:
        return [Colors.green[600]!, Colors.green[400]!];
      case UserTier.intermediate:
        return [Colors.blue[600]!, Colors.blue[400]!];
      case UserTier.advanced:
        return [Colors.purple[600]!, Colors.purple[400]!];
      case UserTier.elite:
        return [Colors.orange[600]!, Colors.orange[400]!];
      case UserTier.master:
        return [Colors.red[600]!, Colors.red[400]!];
      case UserTier.proPlayers:
        return [Colors.black, Colors.grey[800]!];
    }
  }

  Widget _getTierIcon(UserTier tier) {
    IconData iconData;
    
    switch (tier) {
      case UserTier.rookie:
      case UserTier.beginner:
      case UserTier.intermediate:
        iconData = Icons.military_tech;
        break;
      case UserTier.advanced:
      case UserTier.elite:
        iconData = Icons.emoji_events;
        break;
      case UserTier.master:
      case UserTier.proPlayers:
        iconData = Icons.workspace_premium;
        break;
    }

    return Icon(
      iconData,
      color: Colors.white,
      size: 16,
    );
  }

  String _getFormattedRank() {
    // Mock rank calculation - in real app would come from API
    final mockRank = 247; // This would be calculated based on LP and region
    
    if (mockRank >= 1000000) {
      return '${(mockRank / 1000000).toStringAsFixed(1)}M';
    } else if (mockRank >= 1000) {
      return '${(mockRank / 1000).toStringAsFixed(1)}K';
    } else {
      return mockRank.toString();
    }
  }
}
