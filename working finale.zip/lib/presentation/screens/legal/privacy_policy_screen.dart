import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:go_router/go_router.dart';

class PrivacyPolicyScreen extends StatelessWidget {
  const PrivacyPolicyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('privacy_policy'.tr()),
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header Card
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: Colors.green.shade100,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Icon(
                            Icons.shield_outlined,
                            color: Colors.green.shade700,
                            size: 32,
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'privacy_policy'.tr(),
                                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              Text(
                                'last_updated'.tr() + ': ${DateFormat.yMMMd().format(DateTime.now())}',
                                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                  color: Colors.grey[600],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Text(
                      'privacy_policy_intro'.tr(),
                      style: Theme.of(context).textTheme.bodyLarge,
                    ),
                  ],
                ),
              ),
            ),
            
            const SizedBox(height: 16),
            
            // Information Collection Section
            _buildPolicySection(
              context,
              icon: Icons.storage_outlined,
              title: 'information_we_collect'.tr(),
              content: _getInformationCollectionContent(),
            ),
            
            const SizedBox(height: 16),
            
            // How We Use Information Section
            _buildPolicySection(
              context,
              icon: Icons.visibility_outlined,
              title: 'how_we_use_information'.tr(),
              content: _getInformationUsageContent(),
            ),
            
            const SizedBox(height: 16),
            
            // Information Sharing Section
            _buildPolicySection(
              context,
              icon: Icons.group_outlined,
              title: 'information_sharing'.tr(),
              content: _getInformationSharingContent(),
            ),
            
            const SizedBox(height: 16),
            
            // Data Security Section
            _buildPolicySection(
              context,
              icon: Icons.lock_outlined,
              title: 'data_security'.tr(),
              content: _getDataSecurityContent(),
            ),
            
            const SizedBox(height: 16),
            
            // Your Rights Section
            _buildPolicySection(
              context,
              icon: Icons.verified_user_outlined,
              title: 'your_privacy_rights'.tr(),
              content: _getYourRightsContent(),
            ),
            
            const SizedBox(height: 16),
            
            // Cookies Section
            _buildPolicySection(
              context,
              icon: Icons.cookie_outlined,
              title: 'cookies_tracking'.tr(),
              content: _getCookiesContent(),
            ),
            
            const SizedBox(height: 16),
            
            // Children's Privacy Section
            _buildPolicySection(
              context,
              icon: Icons.child_care_outlined,
              title: 'children_privacy'.tr(),
              content: _getChildrenPrivacyContent(),
            ),
            
            const SizedBox(height: 16),
            
            // Policy Changes Section
            _buildPolicySection(
              context,
              icon: Icons.update_outlined,
              title: 'policy_changes'.tr(),
              content: _getPolicyChangesContent(),
            ),
            
            const SizedBox(height: 16),
            
            // Contact Information Section
            _buildPolicySection(
              context,
              icon: Icons.contact_support_outlined,
              title: 'contact_information'.tr(),
              content: _getContactInformationContent(),
            ),
            
            const SizedBox(height: 32),
            
            // Footer
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    Text(
                      'privacy_policy_footer'.tr(),
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Colors.grey[600],
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 16),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        onPressed: () => Navigator.of(context).pop(),
                        icon: const Icon(Icons.arrow_back),
                        label: Text('back_to_app'.tr()),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.green,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 12),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            
            const SizedBox(height: 32),
          ],
        ),
      ),
    );
  }
  
  Widget _buildPolicySection(
    BuildContext context, {
    required IconData icon,
    required String title,
    required Widget content,
  }) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  icon,
                  color: Colors.green.shade700,
                  size: 24,
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    title,
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            content,
          ],
        ),
      ),
    );
  }
  
  Widget _getInformationCollectionContent() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('personal_information'.tr()),
        const SizedBox(height: 8),
        _buildBulletPoint('• Name, email address, and phone number'),
        _buildBulletPoint('• Profile information including photo and preferences'),
        _buildBulletPoint('• Payment information (processed securely by third-party providers)'),
        _buildBulletPoint('• Communication history and support interactions'),
        
        const SizedBox(height: 16),
        Text('activity_information'.tr()),
        const SizedBox(height: 8),
        _buildBulletPoint('• Court bookings and match participation'),
        _buildBulletPoint('• Tournament registrations and results'),
        _buildBulletPoint('• Training sessions and coaching interactions'),
        _buildBulletPoint('• Marketplace transactions and listings'),
        
        const SizedBox(height: 16),
        Text('technical_information'.tr()),
        const SizedBox(height: 8),
        _buildBulletPoint('• Device information and IP address'),
        _buildBulletPoint('• App usage patterns and performance data'),
        _buildBulletPoint('• Location data (when you grant permission)'),
        _buildBulletPoint('• Crash reports and error logs'),
      ],
    );
  }
  
  Widget _getInformationUsageContent() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('service_provision'.tr()),
        const SizedBox(height: 8),
        _buildBulletPoint('• Process court bookings and tournament registrations'),
        _buildBulletPoint('• Facilitate connections between players, coaches, and venues'),
        _buildBulletPoint('• Handle payment processing and financial transactions'),
        _buildBulletPoint('• Provide customer support and resolve issues'),
        
        const SizedBox(height: 16),
        Text('communication'.tr()),
        const SizedBox(height: 8),
        _buildBulletPoint('• Send booking confirmations and reminders'),
        _buildBulletPoint('• Notify you of tournament updates and matches'),
        _buildBulletPoint('• Share important service announcements'),
        _buildBulletPoint('• Send promotional offers (with your consent)'),
        
        const SizedBox(height: 16),
        Text('platform_improvement'.tr()),
        const SizedBox(height: 8),
        _buildBulletPoint('• Analyze usage patterns to enhance user experience'),
        _buildBulletPoint('• Develop new features and services'),
        _buildBulletPoint('• Prevent fraud and ensure platform security'),
        _buildBulletPoint('• Conduct research and analytics'),
      ],
    );
  }
  
  Widget _getInformationSharingContent() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('We never sell your personal information. We may share your information only in these limited circumstances:'),
        const SizedBox(height: 16),
        
        Text('Service Partners'),
        const SizedBox(height: 8),
        _buildBulletPoint('• Payment processors for secure transaction handling'),
        _buildBulletPoint('• Cloud service providers for data storage and backup'),
        _buildBulletPoint('• Communication services for notifications and emails'),
        _buildBulletPoint('• Analytics providers for service improvement'),
        
        const SizedBox(height: 16),
        Text('Legal Requirements'),
        const SizedBox(height: 8),
        _buildBulletPoint('• When required by law or government authorities'),
        _buildBulletPoint('• To protect against fraud and security threats'),
        _buildBulletPoint('• To enforce our terms of service'),
        _buildBulletPoint('• In case of business transfer or merger'),
      ],
    );
  }
  
  Widget _getDataSecurityContent() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('We implement comprehensive security measures to protect your personal information:'),
        const SizedBox(height: 16),
        
        Text('Technical Safeguards'),
        const SizedBox(height: 8),
        _buildBulletPoint('• End-to-end encryption for sensitive data'),
        _buildBulletPoint('• Secure SSL/TLS connections'),
        _buildBulletPoint('• Regular security audits and testing'),
        _buildBulletPoint('• Multi-factor authentication options'),
        
        const SizedBox(height: 16),
        Text('Operational Security'),
        const SizedBox(height: 8),
        _buildBulletPoint('• Limited access to personal data'),
        _buildBulletPoint('• Employee security training'),
        _buildBulletPoint('• Regular data backups'),
        _buildBulletPoint('• Incident response procedures'),
        
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.orange.shade50,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: Colors.orange.shade200),
          ),
          child: Text(
            'Important: While we strive to protect your information, no system is 100% secure. Please use strong passwords and keep your account credentials confidential.',
            style: TextStyle(color: Colors.orange.shade800),
          ),
        ),
      ],
    );
  }
  
  Widget _getYourRightsContent() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('You have the following rights regarding your personal information:'),
        const SizedBox(height: 16),
        
        Text('Access and Control'),
        const SizedBox(height: 8),
        _buildBulletPoint('• View and download your personal data'),
        _buildBulletPoint('• Update or correct your information'),
        _buildBulletPoint('• Delete your account and data'),
        _buildBulletPoint('• Opt out of marketing communications'),
        
        const SizedBox(height: 16),
        Text('Data Portability'),
        const SizedBox(height: 8),
        _buildBulletPoint('• Export your data in common formats'),
        _buildBulletPoint('• Transfer data to other services'),
        _buildBulletPoint('• Receive copies of your information'),
        _buildBulletPoint('• Restrict processing of your data'),
        
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.blue.shade50,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: Colors.blue.shade200),
          ),
          child: Text(
            'To exercise these rights, contact us at privacy@padelo.com or use the settings in your account.',
            style: TextStyle(color: Colors.blue.shade800),
          ),
        ),
      ],
    );
  }
  
  Widget _getCookiesContent() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('We use cookies and similar technologies to enhance your experience:'),
        const SizedBox(height: 16),
        
        _buildCookieType('Essential Cookies', 'Required for basic app functionality, authentication, and security.', Colors.green),
        const SizedBox(height: 8),
        _buildCookieType('Performance Cookies', 'Help us understand how you use the app and improve its performance.', Colors.blue),
        const SizedBox(height: 8),
        _buildCookieType('Functional Cookies', 'Remember your preferences and provide personalized features.', Colors.purple),
        const SizedBox(height: 8),
        _buildCookieType('Marketing Cookies', 'Used for targeted advertising (only with your consent).', Colors.orange),
        
        const SizedBox(height: 16),
        Text('Managing Cookies'),
        const SizedBox(height: 8),
        Text('You can control cookies through your browser settings or app preferences. Note that disabling essential cookies may affect app functionality.'),
      ],
    );
  }
  
  Widget _buildCookieType(String title, String description, Color color) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: 12,
          height: 12,
          margin: const EdgeInsets.only(top: 4),
          decoration: BoxDecoration(
            color: color,
            shape: BoxShape.circle,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
              Text(description),
            ],
          ),
        ),
      ],
    );
  }
  
  Widget _getChildrenPrivacyContent() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Padelo is intended for users aged 13 and older. We do not knowingly collect personal information from children under 13.'),
        const SizedBox(height: 16),
        
        Text('Parental Consent'),
        const SizedBox(height: 8),
        _buildBulletPoint('• Users aged 13-17 should have parental permission to use our services'),
        _buildBulletPoint('• Parents can contact us to review or delete their child\'s information'),
        _buildBulletPoint('• We may require age verification for certain features'),
        _buildBulletPoint('• Special protections apply to accounts of minors'),
        
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.red.shade50,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: Colors.red.shade200),
          ),
          child: Text(
            'If you believe we have collected information from a child under 13, please contact us immediately at privacy@padelo.com',
            style: TextStyle(color: Colors.red.shade800),
          ),
        ),
      ],
    );
  }
  
  Widget _getPolicyChangesContent() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('We may update this privacy policy from time to time to reflect changes in our practices, technology, or legal requirements.'),
        const SizedBox(height: 16),
        
        Text('How We Notify You'),
        const SizedBox(height: 8),
        _buildBulletPoint('• Email notification for significant changes'),
        _buildBulletPoint('• In-app notifications and announcements'),
        _buildBulletPoint('• Updated date at the top of this policy'),
        _buildBulletPoint('• Prominent notice on our website'),
        
        const SizedBox(height: 16),
        Text('Your continued use of our services after changes become effective constitutes acceptance of the updated policy.'),
      ],
    );
  }
  
  Widget _getContactInformationContent() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('If you have questions about this privacy policy or our data practices, please contact us:'),
        const SizedBox(height: 16),
        
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Privacy Officer', style: const TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      const Icon(Icons.email, size: 16, color: Colors.green),
                      const SizedBox(width: 8),
                      Text('privacy@padelo.com', style: TextStyle(color: Colors.green.shade700)),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      const Icon(Icons.phone, size: 16, color: Colors.green),
                      const SizedBox(width: 8),
                      Text('+1 (555) 123-4567'),
                    ],
                  ),
                ],
              ),
            ),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Mailing Address', style: const TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Text('Padelo Inc.\n123 Sports Avenue\nTech City, TC 12345\nUnited States'),
                ],
              ),
            ),
          ],
        ),
        
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.green.shade50,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: Colors.green.shade200),
          ),
          child: Text(
            'Response Time: We typically respond to privacy inquiries within 5 business days.',
            style: TextStyle(color: Colors.green.shade800),
          ),
        ),
      ],
    );
  }
  
  Widget _buildBulletPoint(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Text(text),
    );
  }
}
