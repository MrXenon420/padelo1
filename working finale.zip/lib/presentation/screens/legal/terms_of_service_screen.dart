import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:go_router/go_router.dart';

class TermsOfServiceScreen extends StatelessWidget {
  const TermsOfServiceScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('terms_of_service'.tr()),
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header Card
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: Colors.green.shade100,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Icon(
                            Icons.description_outlined,
                            color: Colors.green.shade700,
                            size: 32,
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'terms_of_service'.tr(),
                                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              Text(
                                'last_updated'.tr() + ': ${DateFormat.yMMMd().format(DateTime.now())}',
                                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                  color: Colors.grey[600],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    Text(
                      'Welcome to Padelo! These terms govern your use of our platform and services. Please read them carefully before using our application.',
                      style: Theme.of(context).textTheme.bodyLarge,
                    ),
                  ],
                ),
              ),
            ),
            
            const SizedBox(height: 16),
            
            // Acceptance of Terms Section
            _buildTermsSection(
              context,
              icon: Icons.gavel_outlined,
              title: 'Acceptance of Terms',
              content: _getAcceptanceContent(),
            ),
            
            const SizedBox(height: 16),
            
            // Service Description Section
            _buildTermsSection(
              context,
              icon: Icons.description_outlined,
              title: 'Service Description',
              content: _getServiceDescriptionContent(),
            ),
            
            const SizedBox(height: 16),
            
            // User Accounts Section
            _buildTermsSection(
              context,
              icon: Icons.person_outlined,
              title: 'User Accounts',
              content: _getUserAccountsContent(),
            ),
            
            const SizedBox(height: 16),
            
            // User Conduct Section
            _buildTermsSection(
              context,
              icon: Icons.shield_outlined,
              title: 'User Conduct',
              content: _getUserConductContent(),
            ),
            
            const SizedBox(height: 16),
            
            // Bookings and Payments Section
            _buildTermsSection(
              context,
              icon: Icons.payment_outlined,
              title: 'Bookings and Payments',
              content: _getBookingsPaymentsContent(),
            ),
            
            const SizedBox(height: 16),
            
            // Intellectual Property Section
            _buildTermsSection(
              context,
              icon: Icons.copyright_outlined,
              title: 'Intellectual Property',
              content: _getIntellectualPropertyContent(),
            ),
            
            const SizedBox(height: 16),
            
            // Disclaimers Section
            _buildTermsSection(
              context,
              icon: Icons.warning_outlined,
              title: 'Disclaimers',
              content: _getDisclaimersContent(),
            ),
            
            const SizedBox(height: 16),
            
            // Limitation of Liability Section
            _buildTermsSection(
              context,
              icon: Icons.policy_outlined,
              title: 'Limitation of Liability',
              content: _getLimitationContent(),
            ),
            
            const SizedBox(height: 16),
            
            // Termination Section
            _buildTermsSection(
              context,
              icon: Icons.exit_to_app_outlined,
              title: 'Termination',
              content: _getTerminationContent(),
            ),
            
            const SizedBox(height: 16),
            
            // Governing Law Section
            _buildTermsSection(
              context,
              icon: Icons.balance_outlined,
              title: 'Governing Law',
              content: _getGoverningLawContent(),
            ),
            
            const SizedBox(height: 32),
            
            // Footer
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    Text(
                      'Thank you for taking the time to read our Terms of Service. These terms help ensure a safe, fair, and enjoyable experience for all members of the Padelo community.',
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Colors.grey[600],
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton.icon(
                            onPressed: () => Navigator.of(context).pop(),
                            icon: const Icon(Icons.arrow_back),
                            label: Text('back_to_app'.tr()),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: ElevatedButton.icon(
                            onPressed: () => Navigator.of(context).pushNamed('/privacy-policy'),
                            icon: const Icon(Icons.privacy_tip_outlined),
                            label: Text('privacy_policy'.tr()),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.green,
                              foregroundColor: Colors.white,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            
            const SizedBox(height: 32),
          ],
        ),
      ),
    );
  }
  
  Widget _buildTermsSection(
    BuildContext context, {
    required IconData icon,
    required String title,
    required Widget content,
  }) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  icon,
                  color: Colors.green.shade700,
                  size: 24,
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    title,
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            content,
          ],
        ),
      ),
    );
  }
  
  Widget _getAcceptanceContent() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('By accessing or using the Padelo application ("Service"), you agree to be bound by these Terms of Service ("Terms"). If you disagree with any part of these terms, then you may not access the Service.'),
        const SizedBox(height: 16),
        
        Text('Agreement Components', style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        _buildBulletPoint('• These Terms of Service'),
        _buildBulletPoint('• Our Privacy Policy'),
        _buildBulletPoint('• Community Guidelines'),
        _buildBulletPoint('• Any additional terms for specific features'),
        
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.blue.shade50,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: Colors.blue.shade200),
          ),
          child: Text(
            'Age Requirement: You must be at least 13 years old to use this service. Users under 18 should have parental consent.',
            style: TextStyle(color: Colors.blue.shade800, fontWeight: FontWeight.bold),
          ),
        ),
      ],
    );
  }
  
  Widget _getServiceDescriptionContent() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Padelo is a comprehensive platform for padel enthusiasts that connects players, coaches, court owners, and tournament organizers in one unified ecosystem.'),
        const SizedBox(height: 16),
        
        Text('Core Services', style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('For Players', style: const TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 4),
                  _buildBulletPoint('• Court booking and scheduling'),
                  _buildBulletPoint('• Tournament participation'),
                  _buildBulletPoint('• Training session booking'),
                  _buildBulletPoint('• Equipment marketplace'),
                  _buildBulletPoint('• Community networking'),
                ],
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('For Businesses', style: const TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 4),
                  _buildBulletPoint('• Court management and bookings'),
                  _buildBulletPoint('• Tournament organization'),
                  _buildBulletPoint('• Coaching service management'),
                  _buildBulletPoint('• Revenue analytics'),
                  _buildBulletPoint('• Customer relationship tools'),
                ],
              ),
            ),
          ],
        ),
        
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.yellow.shade50,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: Colors.yellow.shade200),
          ),
          child: Text(
            'Service Availability: We strive to maintain 99.9% uptime but cannot guarantee uninterrupted service due to maintenance, updates, or external factors beyond our control.',
            style: TextStyle(color: Colors.yellow.shade800),
          ),
        ),
      ],
    );
  }
  
  Widget _getUserAccountsContent() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Account Creation', style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        _buildBulletPoint('• You must provide accurate and complete information during registration'),
        _buildBulletPoint('• All new users are assigned the "Player" role by default'),
        _buildBulletPoint('• Additional roles can only be assigned by platform owners'),
        _buildBulletPoint('• You are responsible for maintaining the confidentiality of your account'),
        
        const SizedBox(height: 16),
        Text('Account Security', style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        _buildBulletPoint('• Use a strong, unique password for your account'),
        _buildBulletPoint('• Enable two-factor authentication when available'),
        _buildBulletPoint('• Notify us immediately of any unauthorized access'),
        _buildBulletPoint('• You are liable for all activities under your account'),
        
        const SizedBox(height: 16),
        Text('Account Types and Roles', style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        _buildRoleType('Player', 'Standard user with access to booking, tournaments, and marketplace features.', Colors.blue),
        _buildRoleType('Coach', 'Certified instructors who can offer training services and manage students.', Colors.green),
        _buildRoleType('Court Owner', 'Venue operators who can manage facilities and bookings.', Colors.purple),
        _buildRoleType('Tournament Organizer', 'Event coordinators who can create and manage tournaments.', Colors.orange),
      ],
    );
  }
  
  Widget _buildRoleType(String title, String description, Color color) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 12,
            height: 12,
            margin: const EdgeInsets.only(top: 4),
            decoration: BoxDecoration(
              color: color,
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
                Text(description),
              ],
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _getUserConductContent() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Acceptable Use', style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        _buildBulletPoint('• Use the service for its intended purpose only'),
        _buildBulletPoint('• Respect other users and maintain professional conduct'),
        _buildBulletPoint('• Provide accurate information in bookings and profiles'),
        _buildBulletPoint('• Honor your commitments and booking agreements'),
        _buildBulletPoint('• Report any issues or violations promptly'),
        
        const SizedBox(height: 16),
        Text('Prohibited Activities', style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.red.shade50,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: Colors.red.shade200),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildBulletPoint('• Fraudulent or deceptive practices'),
              _buildBulletPoint('• Harassment, discrimination, or hate speech'),
              _buildBulletPoint('• Sharing false or misleading information'),
              _buildBulletPoint('• Attempting to hack or compromise the platform'),
              _buildBulletPoint('• Creating multiple accounts to circumvent restrictions'),
              _buildBulletPoint('• Commercial spam or unauthorized advertising'),
              _buildBulletPoint('• Violating any applicable laws or regulations'),
            ],
          ),
        ),
        
        const SizedBox(height: 16),
        Text('Content Guidelines', style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        _buildBulletPoint('• Keep all content appropriate and family-friendly'),
        _buildBulletPoint('• Respect intellectual property rights'),
        _buildBulletPoint('• Do not share personal contact information publicly'),
        _buildBulletPoint('• Use accurate photos in your profile and listings'),
      ],
    );
  }
  
  Widget _getBookingsPaymentsContent() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Booking Terms', style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        _buildBulletPoint('• All bookings are subject to availability and confirmation'),
        _buildBulletPoint('• Court owners set their own pricing and availability'),
        _buildBulletPoint('• You agree to arrive on time for your reserved sessions'),
        _buildBulletPoint('• No-shows may result in charges and account restrictions'),
        
        const SizedBox(height: 16),
        Text('Payment Processing', style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        _buildBulletPoint('• All payments are processed through secure third-party providers'),
        _buildBulletPoint('• We do not store credit card information on our servers'),
        _buildBulletPoint('• Payment is required at the time of booking confirmation'),
        _buildBulletPoint('• Additional fees may apply for premium services'),
        
        const SizedBox(height: 16),
        Text('Cancellations and Refunds', style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        _buildCancellationPolicy('24+ hours', 'Full refund available', Colors.green),
        _buildCancellationPolicy('2-24 hours', '50% refund (subject to court owner policy)', Colors.yellow),
        _buildCancellationPolicy('Less than 2 hours', 'No refund available', Colors.red),
        
        const SizedBox(height: 8),
        Text(
          'Individual court owners may have different cancellation policies, which will be clearly displayed at booking time.',
          style: TextStyle(fontSize: 12, color: Colors.grey[600]),
        ),
      ],
    );
  }
  
  Widget _buildCancellationPolicy(String timeframe, String policy, Color color) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Row(
        children: [
          Container(
            width: 12,
            height: 12,
            decoration: BoxDecoration(
              color: color,
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 12),
          Text('$timeframe: ', style: const TextStyle(fontWeight: FontWeight.bold)),
          Expanded(child: Text(policy)),
        ],
      ),
    );
  }
  
  Widget _getIntellectualPropertyContent() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Our Rights', style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        _buildBulletPoint('• The Padelo platform, logo, and branding are our property'),
        _buildBulletPoint('• All software, designs, and functionality are protected by copyright'),
        _buildBulletPoint('• Users may not copy, modify, or distribute our intellectual property'),
        _buildBulletPoint('• We reserve all rights not expressly granted to users'),
        
        const SizedBox(height: 16),
        Text('User Content', style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        _buildBulletPoint('• You retain ownership of content you create and upload'),
        _buildBulletPoint('• By uploading content, you grant us a license to use it for service operation'),
        _buildBulletPoint('• You represent that you have the right to share any content you upload'),
        _buildBulletPoint('• We may remove content that violates these terms or applicable laws'),
        
        const SizedBox(height: 16),
        Text('Third-Party Content', style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        _buildBulletPoint('• Respect copyrights and trademarks of third parties'),
        _buildBulletPoint('• Only use images and content you have permission to use'),
        _buildBulletPoint('• Report any copyright violations to our support team'),
        _buildBulletPoint('• We will respond to valid DMCA takedown requests'),
      ],
    );
  }
  
  Widget _getDisclaimersContent() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.yellow.shade50,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: Colors.yellow.shade200),
          ),
          child: Text(
            'IMPORTANT: The following disclaimers limit our liability and your remedies:',
            style: TextStyle(color: Colors.yellow.shade800, fontWeight: FontWeight.bold),
          ),
        ),
        
        const SizedBox(height: 16),
        Text('Service Disclaimers', style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        _buildBulletPoint('• The service is provided "as is" without warranties of any kind'),
        _buildBulletPoint('• We do not guarantee continuous, uninterrupted, or error-free operation'),
        _buildBulletPoint('• We are not responsible for third-party content or services'),
        _buildBulletPoint('• Court availability and quality are determined by individual owners'),
        
        const SizedBox(height: 16),
        Text('Safety and Health', style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        _buildBulletPoint('• Padel is a physical sport with inherent injury risks'),
        _buildBulletPoint('• Players participate at their own risk and responsibility'),
        _buildBulletPoint('• We recommend appropriate insurance coverage for sports activities'),
        _buildBulletPoint('• Courts and equipment safety are the responsibility of venue owners'),
        
        const SizedBox(height: 16),
        Text('User Interactions', style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        _buildBulletPoint('• We do not screen users or verify their identities'),
        _buildBulletPoint('• Use caution when meeting or interacting with other users'),
        _buildBulletPoint('• We are not responsible for disputes between users'),
        _buildBulletPoint('• Report any concerning behavior to our support team'),
      ],
    );
  }
  
  Widget _getLimitationContent() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.red.shade50,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: Colors.red.shade200),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'LIMITATION OF LIABILITY NOTICE',
                style: TextStyle(color: Colors.red.shade800, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              Text(
                'To the maximum extent permitted by law, Padelo shall not be liable for any indirect, incidental, special, consequential, or punitive damages, including without limitation, loss of profits, data, use, goodwill, or other intangible losses.',
                style: TextStyle(color: Colors.red.shade800),
              ),
            ],
          ),
        ),
        
        const SizedBox(height: 16),
        Text('Liability Limits', style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        _buildBulletPoint('• Our total liability is limited to the amount you paid for services in the past 12 months'),
        _buildBulletPoint('• We are not liable for actions or omissions of third-party service providers'),
        _buildBulletPoint('• Force majeure events are excluded from our liability'),
        _buildBulletPoint('• Some jurisdictions do not allow liability limitations, so these may not apply to you'),
        
        const SizedBox(height: 16),
        Text('Indemnification', style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Text('You agree to indemnify and hold harmless Padelo from any claims, damages, or expenses arising from your use of the service, violation of these terms, or infringement of any rights.'),
      ],
    );
  }
  
  Widget _getTerminationContent() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Termination by You', style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        _buildBulletPoint('• You may delete your account at any time through app settings'),
        _buildBulletPoint('• Account deletion is permanent and cannot be undone'),
        _buildBulletPoint('• You remain liable for any outstanding obligations'),
        _buildBulletPoint('• Some information may be retained as required by law'),
        
        const SizedBox(height: 16),
        Text('Termination by Us', style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        _buildBulletPoint('• We may suspend or terminate accounts for terms violations'),
        _buildBulletPoint('• Serious violations may result in immediate termination'),
        _buildBulletPoint('• We will provide notice when possible, but immediate action may be necessary'),
        _buildBulletPoint('• We may discontinue the service with 30 days\' notice'),
        
        const SizedBox(height: 16),
        Text('Effect of Termination', style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        _buildBulletPoint('• Your right to use the service immediately ceases'),
        _buildBulletPoint('• Pending bookings may be canceled with appropriate refunds'),
        _buildBulletPoint('• Survival clauses continue to apply after termination'),
        _buildBulletPoint('• We may retain some data as required by law or policy'),
      ],
    );
  }
  
  Widget _getGoverningLawContent() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Applicable Law', style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Text('These terms are governed by and construed in accordance with the laws of the jurisdiction where Padelo is incorporated, without regard to conflict of law principles.'),
        
        const SizedBox(height: 16),
        Text('Dispute Resolution', style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        _buildBulletPoint('• We encourage resolving disputes through direct communication first'),
        _buildBulletPoint('• Formal disputes will be resolved through binding arbitration'),
        _buildBulletPoint('• Class action lawsuits are waived where legally permissible'),
        _buildBulletPoint('• Small claims court remains available for qualifying disputes'),
        
        const SizedBox(height: 16),
        Text('Changes to Terms', style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        _buildBulletPoint('• We may modify these terms at any time with notice'),
        _buildBulletPoint('• Significant changes will be announced prominently'),
        _buildBulletPoint('• Continued use constitutes acceptance of modified terms'),
        _buildBulletPoint('• You should review terms periodically for updates'),
      ],
    );
  }
  
  Widget _buildBulletPoint(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Text(text),
    );
  }
}
