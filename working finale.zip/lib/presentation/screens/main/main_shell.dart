import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:easy_localization/easy_localization.dart';

import '../../../core/router/app_routes.dart';

class MainShell extends StatelessWidget {
  final Widget child;

  const MainShell({
    super.key,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: child,
      bottomNavigationBar: const PadeloBottomNavigationBar(),
    );
  }
}

class PadeloBottomNavigationBar extends StatelessWidget {
  const PadeloBottomNavigationBar({super.key});

  @override
  Widget build(BuildContext context) {
    final currentLocation = GoRouterState.of(context).uri.path;
    
    return BottomNavigationBar(
      currentIndex: _calculateSelectedIndex(currentLocation),
      onTap: (index) => _onItemTapped(context, index),
      type: BottomNavigationBarType.fixed,
      backgroundColor: Colors.white,
      selectedItemColor: const Color(0xFF099c37),
      unselectedItemColor: Colors.grey[500],
      selectedFontSize: 12,
      unselectedFontSize: 12,
      iconSize: 24,
      elevation: 8,
      items: [
        BottomNavigationBarItem(
          icon: const Icon(Icons.home_rounded),
          activeIcon: const Icon(Icons.home_rounded),
          label: context.tr('navigation.home'),
        ),
        BottomNavigationBarItem(
          icon: const Icon(Icons.emoji_events_outlined),
          activeIcon: const Icon(Icons.emoji_events),
          label: context.tr('navigation.tournaments'),
        ),
        BottomNavigationBarItem(
          icon: const Icon(Icons.sports_tennis_outlined),
          activeIcon: const Icon(Icons.sports_tennis),
          label: context.tr('navigation.courts'),
        ),
        BottomNavigationBarItem(
          icon: const Icon(Icons.school_outlined),
          activeIcon: const Icon(Icons.school),
          label: context.tr('navigation.training'),
        ),
        BottomNavigationBarItem(
          icon: const Icon(Icons.shopping_bag_outlined),
          activeIcon: const Icon(Icons.shopping_bag),
          label: context.tr('navigation.marketplace'),
        ),
        BottomNavigationBarItem(
          icon: const Icon(Icons.group_outlined),
          activeIcon: const Icon(Icons.group),
          label: context.tr('navigation.matches'),
        ),
        BottomNavigationBarItem(
          icon: const Icon(Icons.person_outline),
          activeIcon: const Icon(Icons.person),
          label: context.tr('navigation.profile'),
        ),
      ],
    );
  }

  int _calculateSelectedIndex(String location) {
    if (location.startsWith(AppRoutes.home)) return 0;
    if (location.startsWith(AppRoutes.tournaments)) return 1;
    if (location.startsWith(AppRoutes.courts)) return 2;
    if (location.startsWith(AppRoutes.training)) return 3;
    if (location.startsWith(AppRoutes.marketplace)) return 4;
    if (location.startsWith(AppRoutes.matches)) return 5;
    if (location.startsWith(AppRoutes.profile)) return 6;
    return 0;
  }

  void _onItemTapped(BuildContext context, int index) {
    switch (index) {
      case 0:
        context.go(AppRoutes.home);
        break;
      case 1:
        context.go(AppRoutes.tournaments);
        break;
      case 2:
        context.go(AppRoutes.courts);
        break;
      case 3:
        context.go(AppRoutes.training);
        break;
      case 4:
        context.go(AppRoutes.marketplace);
        break;
      case 5:
        context.go(AppRoutes.matches);
        break;
      case 6:
        context.go(AppRoutes.profile);
        break;
    }
  }
}
