import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:go_router/go_router.dart';

import '../../../core/providers/auth_provider.dart';
import '../../../core/router/app_routes.dart';
import '../../widgets/common/padelo_logo.dart';
import '../../widgets/common/language_selector.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(currentUserProvider);
    
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const PadeloLogo(size: LogoSize.medium),
                  Row(
                    children: [
                      const LanguageSelector(),
                      const SizedBox(width: 12),
                      CircleAvatar(
                        radius: 20,
                        backgroundColor: Colors.grey[200],
                        child: user?.profile.profilePicture != null
                            ? ClipOval(
                                child: Image.network(
                                  user!.profile.profilePicture!,
                                  width: 40,
                                  height: 40,
                                  fit: BoxFit.cover,
                                ),
                              )
                            : Text(
                                user?.initials ?? 'U',
                                style: const TextStyle(
                                  fontWeight: FontWeight.w600,
                                  color: Colors.grey,
                                ),
                              ),
                      ),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 24),
              
              // Welcome Section
              Text(
                '${'common.welcome'.tr()}, ${user?.profile.firstName ?? 'Player'}!',
                style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                'home.subtitle'.tr(),
                style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                  color: Colors.grey[600],
                ),
              ),
              const SizedBox(height: 32),
              
              // Quick Actions
              _buildQuickActions(context),
              const SizedBox(height: 32),
              
              // Upcoming Tournaments
              _buildSection(
                context,
                title: 'home.upcomingTournaments'.tr(),
                child: _buildTournamentsCard(context),
              ),
              const SizedBox(height: 24),
              
              // Nearby Reservations
              _buildSection(
                context,
                title: 'home.nearbyReservations'.tr(),
                child: _buildReservationsCard(context),
              ),
              const SizedBox(height: 24),
              
              // Marketplace Deals
              _buildSection(
                context,
                title: 'home.marketplaceDeals'.tr(),
                child: _buildMarketplaceCard(context),
              ),
              const SizedBox(height: 24),
              
              // Your Stats
              _buildSection(
                context,
                title: 'home.yourStats'.tr(),
                child: _buildStatsCard(context),
              ),
              const SizedBox(height: 100), // Bottom padding for navigation
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildQuickActions(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'home.quickActions'.tr(),
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton(
                    onPressed: () => context.go(AppRoutes.courts),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF099c37),
                      padding: const EdgeInsets.symmetric(vertical: 16),
                    ),
                    child: Column(
                      children: [
                        const Icon(Icons.calendar_month, color: Colors.white),
                        const SizedBox(height: 4),
                        Text(
                          'home.bookCourt'.tr(),
                          style: const TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w500,
                            color: Colors.white,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => context.go(AppRoutes.matches),
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      side: const BorderSide(color: Color(0xFF099c37)),
                    ),
                    child: Column(
                      children: [
                        const Icon(Icons.group, color: Color(0xFF099c37)),
                        const SizedBox(height: 4),
                        Text(
                          'home.findMatch'.tr(),
                          style: const TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w500,
                            color: Color(0xFF099c37),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton(
                onPressed: () => context.go(AppRoutes.tournaments),
                style: OutlinedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.emoji_events),
                    const SizedBox(width: 8),
                    Text('home.joinTournament'.tr()),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSection(BuildContext context, {required String title, required Widget child}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              title,
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
            TextButton(
              onPressed: () {},
              child: Text('tournaments.viewAll'.tr()),
            ),
          ],
        ),
        const SizedBox(height: 12),
        child,
      ],
    );
  }

  Widget _buildTournamentsCard(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            _buildTournamentItem(
              context,
              'Spring Championship',
              'Sports Club',
              'Mar 15',
              '\$50',
            ),
            const Divider(),
            _buildTournamentItem(
              context,
              'Friday Night Cup',
              'Elite Center',
              'Mar 20',
              '\$25',
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTournamentItem(
    BuildContext context,
    String name,
    String location,
    String date,
    String fee,
  ) {
    return Row(
      children: [
        Container(
          width: 48,
          height: 48,
          decoration: BoxDecoration(
            color: const Color(0xFF099c37),
            borderRadius: BorderRadius.circular(8),
          ),
          child: const Icon(
            Icons.emoji_events,
            color: Colors.white,
            size: 24,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                name,
                style: const TextStyle(
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 2),
              Row(
                children: [
                  Icon(Icons.location_pin, size: 14, color: Colors.grey[600]),
                  const SizedBox(width: 4),
                  Text(location, style: TextStyle(color: Colors.grey[600], fontSize: 12)),
                  const SizedBox(width: 12),
                  Icon(Icons.calendar_today, size: 14, color: Colors.grey[600]),
                  const SizedBox(width: 4),
                  Text(date, style: TextStyle(color: Colors.grey[600], fontSize: 12)),
                ],
              ),
            ],
          ),
        ),
        Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(
              fee,
              style: const TextStyle(
                fontWeight: FontWeight.w600,
                color: Color(0xFF099c37),
              ),
            ),
            Text(
              'tournaments.entryFee'.tr(),
              style: TextStyle(
                color: Colors.grey[500],
                fontSize: 12,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildReservationsCard(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            _buildReservationItem(
              context,
              'Elite Padel Club',
              '2:00 PM - 4:00 PM',
              '25% Off',
              '\$40',
              '\$30',
            ),
            const Divider(),
            _buildReservationItem(
              context,
              'Sports Complex',
              '6:00 PM - 8:00 PM',
              '30% Off',
              '\$60',
              '\$42',
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildReservationItem(
    BuildContext context,
    String courtName,
    String time,
    String discount,
    String originalPrice,
    String salePrice,
  ) {
    return Row(
      children: [
        Container(
          width: 48,
          height: 48,
          decoration: BoxDecoration(
            color: Colors.black,
            borderRadius: BorderRadius.circular(8),
          ),
          child: const Icon(
            Icons.sports_tennis,
            color: Colors.white,
            size: 24,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                courtName,
                style: const TextStyle(
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 2),
              Row(
                children: [
                  Icon(Icons.access_time, size: 14, color: Colors.grey[600]),
                  const SizedBox(width: 4),
                  Text(time, style: TextStyle(color: Colors.grey[600], fontSize: 12)),
                  const SizedBox(width: 12),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: const Color(0xFF099c37),
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: Text(
                      discount,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 10,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text(
              originalPrice,
              style: TextStyle(
                color: Colors.grey[500],
                fontSize: 12,
                decoration: TextDecoration.lineThrough,
              ),
            ),
            Text(
              salePrice,
              style: const TextStyle(
                fontWeight: FontWeight.w600,
                color: Color(0xFF099c37),
                fontSize: 16,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildMarketplaceCard(BuildContext context) {
    return SizedBox(
      height: 160,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: 3,
        itemBuilder: (context, index) {
          return Container(
            width: 120,
            margin: const EdgeInsets.only(right: 12),
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      height: 80,
                      decoration: BoxDecoration(
                        color: Colors.grey[200],
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: const Center(
                        child: Icon(
                          Icons.shopping_bag,
                          size: 32,
                          color: Colors.grey,
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Professional Racket',
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const Spacer(),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          '\$120',
                          style: TextStyle(
                            fontWeight: FontWeight.w600,
                            color: Color(0xFF099c37),
                          ),
                        ),
                        Row(
                          children: const [
                            Icon(Icons.star, size: 12, color: Colors.orange),
                            SizedBox(width: 2),
                            Text('4.8', style: TextStyle(fontSize: 10)),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildStatsCard(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Expanded(
              child: _buildStatItem('12', 'home.matches'.tr()),
            ),
            Expanded(
              child: _buildStatItem('85%', 'home.winRate'.tr()),
            ),
            Expanded(
              child: _buildStatItem('#247', 'home.ranking'.tr()),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatItem(String value, String label) {
    return Column(
      children: [
        Text(
          value,
          style: const TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.w700,
            color: Color(0xFF099c37),
          ),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: TextStyle(
            fontSize: 12,
            color: Colors.grey[600],
          ),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }
}
