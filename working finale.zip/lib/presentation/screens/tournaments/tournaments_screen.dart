import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:easy_localization/easy_localization.dart';

import '../../../core/models/tournament_model.dart';
import '../../../core/models/user_model.dart';
import '../../../core/providers/tournament_provider.dart';
import '../../../core/providers/auth_provider.dart';
import '../../../core/utils/constants.dart';
import '../../../core/utils/extensions.dart';
import '../../widgets/tournaments/tournament_card.dart';
import '../../widgets/tournaments/ranking_card.dart';
import '../../widgets/tournaments/leaderboard_item.dart';
import '../../widgets/common/loading_widget.dart';
import '../../widgets/common/error_widget.dart';

class TournamentsScreen extends ConsumerStatefulWidget {
  const TournamentsScreen({super.key});

  @override
  ConsumerState<TournamentsScreen> createState() => _TournamentsScreenState();
}

class _TournamentsScreenState extends ConsumerState<TournamentsScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  TournamentFilters _filters = const TournamentFilters();
  LeaderboardFilters _leaderboardFilters = const LeaderboardFilters();

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final user = ref.watch(currentUserProvider);
    
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(context),
            _buildUserRanking(context, user),
            _buildTabBar(),
            Expanded(
              child: TabBarView(
                controller: _tabController,
                children: [
                  _buildTournamentsTab(),
                  _buildLeaderboardTab(),
                  _buildMyTournamentsTab(user?.id),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border(
          bottom: BorderSide(color: Colors.grey[200]!),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'tournaments.title'.tr(),
                style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                  fontWeight: FontWeight.w700,
                ),
              ),
              Text(
                'Compete and climb the rankings',
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: Colors.grey[600],
                ),
              ),
            ],
          ),
          ElevatedButton(
            onPressed: _showCreateTournamentDialog,
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF099c37),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.add, color: Colors.white),
                const SizedBox(width: 4),
                Text(
                  'tournaments.createTournament'.tr(),
                  style: const TextStyle(color: Colors.white),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildUserRanking(BuildContext context, User? user) {
    if (user == null) return const SizedBox.shrink();

    return Container(
      margin: const EdgeInsets.all(16),
      child: ref.watch(playerRankingProvider(user.id)).when(
        data: (ranking) => RankingCard(ranking: ranking),
        loading: () => const LoadingWidget(),
        error: (error, stack) => ErrorWidgetCustom(
          error: error.toString(),
          onRetry: () => ref.invalidate(playerRankingProvider(user.id)),
        ),
      ),
    );
  }

  Widget _buildTabBar() {
    return Container(
      color: Colors.white,
      child: TabBar(
        controller: _tabController,
        indicatorColor: const Color(0xFF099c37),
        labelColor: const Color(0xFF099c37),
        unselectedLabelColor: Colors.grey,
        tabs: [
          Tab(text: 'tournaments.title'.tr()),
          Tab(text: 'tournaments.leaderboard'.tr()),
          Tab(text: 'tournaments.myTournaments'.tr()),
        ],
      ),
    );
  }

  Widget _buildTournamentsTab() {
    return Column(
      children: [
        _buildTournamentFilters(),
        Expanded(
          child: ref.watch(tournamentsProvider(_filters)).when(
            data: (tournaments) => _buildTournamentsList(tournaments),
            loading: () => const LoadingWidget(),
            error: (error, stack) => ErrorWidgetCustom(
              error: error.toString(),
              onRetry: () => ref.invalidate(tournamentsProvider(_filters)),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildTournamentFilters() {
    return Container(
      padding: const EdgeInsets.all(16),
      color: Colors.grey[50],
      child: Row(
        children: [
          Expanded(
            child: DropdownButtonFormField<TournamentStatus?>(
              value: _filters.status,
              decoration: const InputDecoration(
                labelText: 'Status',
                border: OutlineInputBorder(),
                contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              ),
              items: [
                const DropdownMenuItem(value: null, child: Text('All Status')),
                ...TournamentStatus.values.map((status) => DropdownMenuItem(
                  value: status,
                  child: Text(status.name.capitalize()),
                )),
              ],
              onChanged: (value) {
                setState(() {
                  _filters = _filters.copyWith(status: value);
                });
                ref.invalidate(tournamentsProvider(_filters));
              },
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: DropdownButtonFormField<TournamentType?>(
              value: _filters.type,
              decoration: const InputDecoration(
                labelText: 'Type',
                border: OutlineInputBorder(),
                contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              ),
              items: [
                const DropdownMenuItem(value: null, child: Text('All Types')),
                ...TournamentType.values.map((type) => DropdownMenuItem(
                  value: type,
                  child: Text(type.name.capitalize()),
                )),
              ],
              onChanged: (value) {
                setState(() {
                  _filters = _filters.copyWith(type: value);
                });
                ref.invalidate(tournamentsProvider(_filters));
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTournamentsList(List<Tournament> tournaments) {
    if (tournaments.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.emoji_events_outlined,
              size: 64,
              color: Colors.grey[400],
            ),
            const SizedBox(height: 16),
            Text(
              'No tournaments found',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                color: Colors.grey[600],
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Be the first to create a tournament!',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Colors.grey[500],
              ),
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: tournaments.length,
      itemBuilder: (context, index) {
        final tournament = tournaments[index];
        return TournamentCard(
          tournament: tournament,
          onJoin: () => _joinTournament(tournament),
          onLeave: () => _leaveTournament(tournament),
        );
      },
    );
  }

  Widget _buildLeaderboardTab() {
    return Column(
      children: [
        _buildLeaderboardFilters(),
        Expanded(
          child: ref.watch(leaderboardProvider(_leaderboardFilters)).when(
            data: (leaderboard) => _buildLeaderboardList(leaderboard),
            loading: () => const LoadingWidget(),
            error: (error, stack) => ErrorWidgetCustom(
              error: error.toString(),
              onRetry: () => ref.invalidate(leaderboardProvider(_leaderboardFilters)),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildLeaderboardFilters() {
    return Container(
      padding: const EdgeInsets.all(16),
      color: Colors.grey[50],
      child: Row(
        children: [
          Expanded(
            child: DropdownButtonFormField<Gender?>(
              value: _leaderboardFilters.gender,
              decoration: const InputDecoration(
                labelText: 'Gender',
                border: OutlineInputBorder(),
                contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              ),
              items: [
                const DropdownMenuItem(value: null, child: Text('All Genders')),
                ...Gender.values.map((gender) => DropdownMenuItem(
                  value: gender,
                  child: Text(gender.name.capitalize()),
                )),
              ],
              onChanged: (value) {
                setState(() {
                  _leaderboardFilters = _leaderboardFilters.copyWith(gender: value);
                });
                ref.invalidate(leaderboardProvider(_leaderboardFilters));
              },
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: DropdownButtonFormField<String?>(
              value: _leaderboardFilters.region,
              decoration: const InputDecoration(
                labelText: 'Region',
                border: OutlineInputBorder(),
                contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              ),
              items: const [
                DropdownMenuItem(value: null, child: Text('All Regions')),
                DropdownMenuItem(value: 'cairo', child: Text('Cairo')),
                DropdownMenuItem(value: 'alexandria', child: Text('Alexandria')),
                DropdownMenuItem(value: 'giza', child: Text('Giza')),
              ],
              onChanged: (value) {
                setState(() {
                  _leaderboardFilters = _leaderboardFilters.copyWith(region: value);
                });
                ref.invalidate(leaderboardProvider(_leaderboardFilters));
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLeaderboardList(List<LeaderboardEntry> leaderboard) {
    if (leaderboard.isEmpty) {
      return const Center(
        child: Text('No players found'),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: leaderboard.length,
      itemBuilder: (context, index) {
        final entry = leaderboard[index];
        return LeaderboardItem(
          entry: entry,
          onTap: () => _showPlayerProfile(entry),
        );
      },
    );
  }

  Widget _buildMyTournamentsTab(String? userId) {
    if (userId == null) {
      return const Center(
        child: Text('Please log in to view your tournaments'),
      );
    }

    return ref.watch(userTournamentsProvider(userId)).when(
      data: (tournaments) {
        if (tournaments.isEmpty) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  Icons.emoji_events_outlined,
                  size: 64,
                  color: Colors.grey[400],
                ),
                const SizedBox(height: 16),
                Text(
                  'tournaments.myTournaments'.tr(),
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    color: Colors.grey[600],
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'Join your first tournament to start building your ranking!',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: Colors.grey[500],
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 16),
                ElevatedButton(
                  onPressed: () => _tabController.animateTo(0),
                  child: const Text('Browse Tournaments'),
                ),
              ],
            ),
          );
        }

        return ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: tournaments.length,
          itemBuilder: (context, index) {
            final tournament = tournaments[index];
            return TournamentCard(
              tournament: tournament,
              onJoin: () => _joinTournament(tournament),
              onLeave: () => _leaveTournament(tournament),
            );
          },
        );
      },
      loading: () => const LoadingWidget(),
      error: (error, stack) => ErrorWidgetCustom(
        error: error.toString(),
        onRetry: () => ref.invalidate(userTournamentsProvider(userId)),
      ),
    );
  }

  void _showCreateTournamentDialog() {
    // TODO: Implement create tournament dialog
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Create tournament feature coming soon!')),
    );
  }

  Future<void> _joinTournament(Tournament tournament) async {
    try {
      await ref.read(tournamentsProvider(_filters).notifier).joinTournament(tournament.id);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Joined ${tournament.name} successfully!')),
        );
      }
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to join tournament: $error')),
        );
      }
    }
  }

  Future<void> _leaveTournament(Tournament tournament) async {
    try {
      await ref.read(tournamentsProvider(_filters).notifier).leaveTournament(tournament.id);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Left ${tournament.name} successfully!')),
        );
      }
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to leave tournament: $error')),
        );
      }
    }
  }

  void _showPlayerProfile(LeaderboardEntry entry) {
    // TODO: Navigate to player profile
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('View ${entry.playerName} profile')),
    );
  }
}
