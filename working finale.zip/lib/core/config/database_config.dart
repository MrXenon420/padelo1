import 'package:flutter/foundation.dart';

/// Database configuration for Neon PostgreSQL
class DatabaseConfig {
  // Production Neon database configuration
  static const String projectId = 'fancy-surf-14449352';
  static const String branchId = 'br-plain-brook-afll1lkz';
  static const String database = 'neondb';
  static const String role = 'neondb_owner';
  
  // Connection details (use environment variables in production)
  static const String host = 'ep-frosty-fog-afz793vd-pooler.c-2.us-west-2.aws.neon.tech';
  static const String password = 'npg_Vg0l8IbQXJaF'; // Move to environment variable
  static const int port = 5432;
  
  /// Get the full connection string
  static String get connectionString {
    return 'postgresql://$role:$password@$host/$database?sslmode=require';
  }
  
  /// Get connection parameters as Map
  static Map<String, dynamic> get connectionParams => {
    'host': host,
    'port': port,
    'database': database,
    'username': role,
    'password': password,
    'sslMode': 'require',
  };
  
  /// Database configuration for different environments
  static Map<String, dynamic> getConfig(String environment) {
    switch (environment) {
      case 'production':
        return {
          'host': host,
          'port': port,
          'database': database,
          'username': role,
          'password': password,
          'sslMode': 'require',
          'poolSize': 10,
          'timeout': 30,
        };
      case 'development':
        return {
          'host': host,
          'port': port,
          'database': database,
          'username': role,
          'password': password,
          'sslMode': 'require',
          'poolSize': 5,
          'timeout': 15,
        };
      default:
        return connectionParams;
    }
  }
  
  /// Health check query
  static const String healthCheckQuery = 'SELECT 1 as health_check';
  
  /// Database version query
  static const String versionQuery = 'SELECT version()';
}

/// Environment configuration
class EnvironmentConfig {
  static String get environment {
    if (kDebugMode) {
      return 'development';
    } else {
      return 'production';
    }
  }
  
  static bool get isProduction => environment == 'production';
  static bool get isDevelopment => environment == 'development';
}
