// App Information
class AppConstants {
  static const String appName = 'Padelo';
  static const String appVersion = '1.0.0';
  static const String appBuildNumber = '1';
  
  // Colors
  static const padeloGreen = 0xFF099c37;
  static const black = 0xFF000000;
  static const white = 0xFFFFFFFF;
  
  // API Configuration
  static const String baseUrl = 'https://api.padelo.app';
  static const String apiVersion = 'v1';
  static const Duration apiTimeout = Duration(seconds: 30);
  
  // Storage Keys
  static const String tokenKey = 'auth_token';
  static const String refreshTokenKey = 'refresh_token';
  static const String userKey = 'user_data';
  static const String languageKey = 'selected_language';
  static const String themeKey = 'selected_theme';
  static const String onboardingKey = 'onboarding_completed';
  
  // Hive Box Names
  static const String userBox = 'user_box';
  static const String tournamentsBox = 'tournaments_box';
  static const String courtsBox = 'courts_box';
  static const String bookingsBox = 'bookings_box';
  static const String cacheBox = 'cache_box';
  
  // Routes
  static const String splashRoute = '/splash';
  static const String languageRoute = '/language';
  static const String onboardingRoute = '/onboarding';
  static const String authRoute = '/auth';
  static const String homeRoute = '/home';
  static const String tournamentsRoute = '/tournaments';
  static const String courtsRoute = '/courts';
  static const String trainingRoute = '/training';
  static const String marketplaceRoute = '/marketplace';
  static const String matchesRoute = '/matches';
  static const String profileRoute = '/profile';
  static const String settingsRoute = '/settings';
  
  // Pagination
  static const int defaultPageSize = 20;
  static const int maxPageSize = 100;
  
  // Validation
  static const int minPasswordLength = 8;
  static const int maxPasswordLength = 128;
  static const int minUsernameLength = 3;
  static const int maxUsernameLength = 20;
  
  // Tournament Settings
  static const List<int> allowedBracketSizes = [8, 16, 32];
  static const int maxTournamentParticipants = 32;
  static const int minTournamentParticipants = 8;
  
  // Court Booking Settings
  static const int maxAdvanceBookingDays = 7;
  static const int maxActiveReservations = 4;
  static const int cancellationWindowHours = 24;
  static const int arrivalWindowMinutes = 10;
  
  // LP System
  static const Map<String, int> tierLPRequirements = {
    'rookie': 0,
    'beginner': 400,
    'intermediate': 1600,
    'advanced': 3600,
    'elite': 6400,
    'master': 10400,
    'pro_players': 16400,
  };
  
  // File Upload
  static const int maxImageSizeMB = 10;
  static const int maxVideoSizeMB = 50;
  static const List<String> allowedImageTypes = ['jpg', 'jpeg', 'png', 'webp'];
  static const List<String> allowedVideoTypes = ['mp4', 'mov', 'avi'];
  
  // Notification Types
  static const String tournamentNotification = 'tournament';
  static const String bookingNotification = 'booking';
  static const String matchNotification = 'match';
  static const String marketplaceNotification = 'marketplace';
  static const String generalNotification = 'general';
  
  // Social Media
  static const String facebookUrl = 'https://facebook.com/padelo';
  static const String instagramUrl = 'https://instagram.com/padelo';
  static const String twitterUrl = 'https://twitter.com/padelo';
  static const String websiteUrl = 'https://padelo.app';
  
  // Support
  static const String supportEmail = 'support@padelo.app';
  static const String supportPhone = '+966123456789';
  
  // Deep Links
  static const String deepLinkScheme = 'padelo';
  static const String webUrlScheme = 'https';
  static const String webHost = 'padelo.app';
  
  // Location
  static const double defaultLatitude = 24.7136;  // Riyadh
  static const double defaultLongitude = 46.6753; // Riyadh
  static const double defaultZoom = 11.0;
  static const double searchRadiusKm = 50.0;
  
  // Animation Durations
  static const Duration shortAnimation = Duration(milliseconds: 200);
  static const Duration mediumAnimation = Duration(milliseconds: 300);
  static const Duration longAnimation = Duration(milliseconds: 500);
  
  // Error Messages
  static const String genericError = 'Something went wrong. Please try again.';
  static const String networkError = 'Network connection error. Please check your internet.';
  static const String timeoutError = 'Request timeout. Please try again.';
  static const String unauthorizedError = 'Session expired. Please login again.';
  
  // Success Messages
  static const String loginSuccess = 'Login successful';
  static const String registerSuccess = 'Account created successfully';
  static const String bookingSuccess = 'Court booked successfully';
  static const String tournamentJoinSuccess = 'Joined tournament successfully';
  
  // Regular Expressions
  static const String phoneRegex = r'^\+?[1-9]\d{1,14}$';
  static const String emailRegex = r'^[^\s@]+@[^\s@]+\.[^\s@]+$';
  static const String usernameRegex = r'^[a-zA-Z0-9_]+$';
  static const String passwordRegex = r'^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]';
}

// User Roles
enum UserRole {
  owner,
  courtOwner,
  tournamentOrganizer,
  coach,
  player,
}

// User Tiers
enum UserTier {
  rookie,
  beginner,
  intermediate,
  advanced,
  elite,
  master,
  proPlayers,
}

// Tournament Status
enum TournamentStatus {
  upcoming,
  ongoing,
  completed,
  cancelled,
}

// Tournament Type
enum TournamentType {
  official,
  unofficial,
}

// Booking Status
enum BookingStatus {
  pending,
  confirmed,
  completed,
  cancelledByPlayer,
  cancelledByOwner,
  noShow,
}

// Match Status
enum MatchStatus {
  scheduled,
  inProgress,
  completed,
  cancelled,
}

// Gender Options
enum Gender {
  male,
  female,
  other,
}

// Preferred Hand
enum PreferredHand {
  left,
  right,
}

// Court Position
enum CourtPosition {
  left,
  right,
  both,
}

// Subscription Type
enum SubscriptionType {
  percentage,
  fixed,
}
