import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../providers/auth_provider.dart';
import '../../presentation/screens/splash/splash_screen.dart';
import '../../presentation/screens/language_selection/language_selection_screen.dart';
import '../../presentation/screens/auth/login_screen.dart';
import '../../presentation/screens/auth/register_screen.dart';
import '../../presentation/screens/main/main_shell.dart';
import '../../presentation/screens/home/home_screen.dart';
import '../../presentation/screens/tournaments/tournaments_screen.dart';
import '../../presentation/screens/courts/courts_screen.dart';
import '../../presentation/screens/training/training_screen.dart';
import '../../presentation/screens/marketplace/marketplace_screen.dart';
import '../../presentation/screens/matches/matches_screen.dart';
import '../../presentation/screens/profile/profile_screen.dart';
import '../../presentation/screens/legal/privacy_policy_screen.dart';
import '../../presentation/screens/legal/terms_of_service_screen.dart';
import 'app_routes.dart';

class AppRouter {
  static final _rootNavigatorKey = GlobalKey<NavigatorState>();
  static final _shellNavigatorKey = GlobalKey<NavigatorState>();

  static final GoRouter router = GoRouter(
    navigatorKey: _rootNavigatorKey,
    initialLocation: AppRoutes.splash,
    debugLogDiagnostics: true,
    redirect: (context, state) {
      final container = ProviderScope.containerOf(context);
      final authState = container.read(authProvider);
      
      // Show splash while loading
      if (authState.isLoading) {
        return AppRoutes.splash;
      }
      
      final isAuthenticated = authState.value != null;
      final location = state.uri.path;
      
      // If not authenticated and trying to access protected routes
      if (!isAuthenticated && _isProtectedRoute(location)) {
        return AppRoutes.login;
      }
      
      // If authenticated and trying to access auth routes
      if (isAuthenticated && _isAuthRoute(location)) {
        return AppRoutes.home;
      }
      
      return null; // No redirect needed
    },
    routes: [
      // Splash Route
      GoRoute(
        path: AppRoutes.splash,
        name: 'splash',
        builder: (context, state) => const SplashScreen(),
      ),
      
      // Language Selection Route
      GoRoute(
        path: AppRoutes.language,
        name: 'language',
        builder: (context, state) => const LanguageSelectionScreen(),
      ),
      
      // Auth Routes
      GoRoute(
        path: AppRoutes.login,
        name: 'login',
        builder: (context, state) => const LoginScreen(),
      ),
      GoRoute(
        path: AppRoutes.register,
        name: 'register',
        builder: (context, state) => const RegisterScreen(),
      ),

      // Legal Routes
      GoRoute(
        path: AppRoutes.privacyPolicy,
        name: 'privacy-policy',
        builder: (context, state) => const PrivacyPolicyScreen(),
      ),
      GoRoute(
        path: AppRoutes.termsOfService,
        name: 'terms-of-service',
        builder: (context, state) => const TermsOfServiceScreen(),
      ),
      
      // Main App Shell with Bottom Navigation
      ShellRoute(
        navigatorKey: _shellNavigatorKey,
        builder: (context, state, child) => MainShell(child: child),
        routes: [
          GoRoute(
            path: AppRoutes.home,
            name: 'home',
            builder: (context, state) => const HomeScreen(),
          ),
          GoRoute(
            path: AppRoutes.tournaments,
            name: 'tournaments',
            builder: (context, state) => const TournamentsScreen(),
          ),
          GoRoute(
            path: AppRoutes.courts,
            name: 'courts',
            builder: (context, state) => const CourtsScreen(),
          ),
          GoRoute(
            path: AppRoutes.training,
            name: 'training',
            builder: (context, state) => const TrainingScreen(),
          ),
          GoRoute(
            path: AppRoutes.marketplace,
            name: 'marketplace',
            builder: (context, state) => const MarketplaceScreen(),
          ),
          GoRoute(
            path: AppRoutes.matches,
            name: 'matches',
            builder: (context, state) => const MatchesScreen(),
          ),
          GoRoute(
            path: AppRoutes.profile,
            name: 'profile',
            builder: (context, state) => const ProfileScreen(),
          ),
        ],
      ),
    ],
    errorBuilder: (context, state) => Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(
              Icons.error_outline,
              size: 64,
              color: Colors.red,
            ),
            const SizedBox(height: 16),
            Text(
              'Page Not Found',
              style: Theme.of(context).textTheme.headlineSmall,
            ),
            const SizedBox(height: 8),
            Text(
              'The page you are looking for does not exist.',
              style: Theme.of(context).textTheme.bodyMedium,
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: () => context.go(AppRoutes.home),
              child: const Text('Go Home'),
            ),
          ],
        ),
      ),
    ),
  );

  static bool _isProtectedRoute(String location) {
    const protectedRoutes = [
      AppRoutes.home,
      AppRoutes.tournaments,
      AppRoutes.courts,
      AppRoutes.training,
      AppRoutes.marketplace,
      AppRoutes.matches,
      AppRoutes.profile,
    ];
    
    return protectedRoutes.any((route) => location.startsWith(route));
  }

  static bool _isAuthRoute(String location) {
    const authRoutes = [
      AppRoutes.login,
      AppRoutes.register,
      AppRoutes.language,
    ];
    
    return authRoutes.contains(location);
  }
}
