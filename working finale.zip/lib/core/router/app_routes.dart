class AppRoutes {
  // Root routes
  static const String splash = '/splash';
  static const String language = '/language';
  
  // Auth routes
  static const String login = '/login';
  static const String register = '/register';
  static const String forgotPassword = '/forgot-password';
  static const String resetPassword = '/reset-password';
  
  // Main app routes
  static const String home = '/home';
  static const String tournaments = '/tournaments';
  static const String courts = '/courts';
  static const String training = '/training';
  static const String marketplace = '/marketplace';
  static const String matches = '/matches';
  static const String profile = '/profile';
  
  // Nested routes
  static const String tournamentDetails = '/tournaments/:id';
  static const String courtDetails = '/courts/:id';
  static const String bookCourt = '/courts/:id/book';
  static const String matchDetails = '/matches/:id';
  static const String userProfile = '/profile/:id';
  static const String editProfile = '/profile/edit';
  static const String settings = '/settings';
  static const String notifications = '/notifications';
  
  // Admin routes
  static const String admin = '/admin';
  static const String adminUsers = '/admin/users';
  static const String adminCourts = '/admin/courts';
  static const String adminTournaments = '/admin/tournaments';
  
  // Support routes
  static const String support = '/support';
  static const String chat = '/chat';
  static const String community = '/community';
  
  // Legal routes
  static const String privacyPolicy = '/privacy-policy';
  static const String termsOfService = '/terms-of-service';

  // Other routes
  static const String onboarding = '/onboarding';
  static const String about = '/about';
}
