import 'dart:convert';
import 'package:http/http.dart' as http;
import '../config/database_config.dart';
import '../models/user_model.dart';
import '../utils/constants.dart';

/// Service for handling database operations with Neon PostgreSQL
class DatabaseService {
  static DatabaseService? _instance;
  static DatabaseService get instance => _instance ??= DatabaseService._();
  
  DatabaseService._();
  
  final String _baseUrl = 'https://api.neon.tech/v2';
  late final Map<String, String> _headers;
  
  /// Initialize the database service
  Future<void> initialize() async {
    _headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    };
    
    // Test connection
    await _testConnection();
  }
  
  /// Test database connection
  Future<bool> _testConnection() async {
    try {
      final result = await executeQuery(DatabaseConfig.healthCheckQuery);
      return result.isNotEmpty;
    } catch (e) {
      print('Database connection test failed: $e');
      return false;
    }
  }
  
  /// Execute a SQL query
  Future<List<Map<String, dynamic>>> executeQuery(String query, [List<dynamic>? params]) async {
    try {
      // For now, we'll use HTTP API calls to Neon
      // In production, you might want to use a proper PostgreSQL client
      
      final response = await http.post(
        Uri.parse('$_baseUrl/projects/${DatabaseConfig.projectId}/query'),
        headers: _headers,
        body: jsonEncode({
          'query': query,
          'params': params ?? [],
        }),
      );
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return List<Map<String, dynamic>>.from(data['rows'] ?? []);
      } else {
        throw Exception('Database query failed: ${response.body}');
      }
    } catch (e) {
      print('Query execution error: $e');
      rethrow;
    }
  }
  
  /// Insert a new record
  Future<Map<String, dynamic>?> insert(String table, Map<String, dynamic> data) async {
    final columns = data.keys.join(', ');
    final placeholders = List.generate(data.length, (i) => '\$${i + 1}').join(', ');
    final values = data.values.toList();
    
    final query = '''
      INSERT INTO $table ($columns) 
      VALUES ($placeholders) 
      RETURNING *
    ''';
    
    final result = await executeQuery(query, values);
    return result.isNotEmpty ? result.first : null;
  }
  
  /// Update a record
  Future<Map<String, dynamic>?> update(String table, String id, Map<String, dynamic> data) async {
    final setParts = data.keys.map((key) => '$key = \$${data.keys.toList().indexOf(key) + 2}').join(', ');
    final values = [id, ...data.values];
    
    final query = '''
      UPDATE $table 
      SET $setParts, updated_at = NOW() 
      WHERE id = \$1 
      RETURNING *
    ''';
    
    final result = await executeQuery(query, values);
    return result.isNotEmpty ? result.first : null;
  }
  
  /// Delete a record
  Future<bool> delete(String table, String id) async {
    final query = 'DELETE FROM $table WHERE id = \$1';
    await executeQuery(query, [id]);
    return true;
  }
  
  /// Find record by ID
  Future<Map<String, dynamic>?> findById(String table, String id) async {
    final query = 'SELECT * FROM $table WHERE id = \$1';
    final result = await executeQuery(query, [id]);
    return result.isNotEmpty ? result.first : null;
  }
  
  /// Find records with conditions
  Future<List<Map<String, dynamic>>> findWhere(
    String table, 
    Map<String, dynamic> conditions, {
    String? orderBy,
    int? limit,
    int? offset,
  }) async {
    final whereParts = conditions.keys.map((key) => '$key = \$${conditions.keys.toList().indexOf(key) + 1}').join(' AND ');
    final values = conditions.values.toList();
    
    String query = 'SELECT * FROM $table WHERE $whereParts';
    
    if (orderBy != null) {
      query += ' ORDER BY $orderBy';
    }
    
    if (limit != null) {
      query += ' LIMIT $limit';
    }
    
    if (offset != null) {
      query += ' OFFSET $offset';
    }
    
    return await executeQuery(query, values);
  }
  
  /// Get all records from a table
  Future<List<Map<String, dynamic>>> findAll(
    String table, {
    String? orderBy,
    int? limit,
    int? offset,
  }) async {
    String query = 'SELECT * FROM $table';
    
    if (orderBy != null) {
      query += ' ORDER BY $orderBy';
    }
    
    if (limit != null) {
      query += ' LIMIT $limit';
    }
    
    if (offset != null) {
      query += ' OFFSET $offset';
    }
    
    return await executeQuery(query);
  }
  
  /// Count records
  Future<int> count(String table, [Map<String, dynamic>? conditions]) async {
    String query = 'SELECT COUNT(*) as count FROM $table';
    List<dynamic> values = [];
    
    if (conditions != null && conditions.isNotEmpty) {
      final whereParts = conditions.keys.map((key) => '$key = \$${conditions.keys.toList().indexOf(key) + 1}').join(' AND ');
      values = conditions.values.toList();
      query += ' WHERE $whereParts';
    }
    
    final result = await executeQuery(query, values);
    return result.isNotEmpty ? (result.first['count'] as int) : 0;
  }
  
  /// Execute a transaction
  Future<T> transaction<T>(Future<T> Function() operation) async {
    // Begin transaction
    await executeQuery('BEGIN');
    
    try {
      final result = await operation();
      await executeQuery('COMMIT');
      return result;
    } catch (e) {
      await executeQuery('ROLLBACK');
      rethrow;
    }
  }
  
  /// Search users by name or email
  Future<List<Map<String, dynamic>>> searchUsers(String searchTerm) async {
    final query = '''
      SELECT u.*, up.first_name, up.last_name, up.city, up.profile_image_url 
      FROM users u 
      LEFT JOIN user_profiles up ON u.id = up.user_id 
      WHERE u.email ILIKE \$1 
         OR up.first_name ILIKE \$1 
         OR up.last_name ILIKE \$1 
         OR CONCAT(up.first_name, ' ', up.last_name) ILIKE \$1
      ORDER BY up.first_name, up.last_name
      LIMIT 20
    ''';
    
    return await executeQuery(query, ['%$searchTerm%']);
  }
  
  /// Get user rankings by region
  Future<List<Map<String, dynamic>>> getUserRankings({
    String? city,
    String? region,
    UserTier? tier,
    int limit = 50,
  }) async {
    String query = '''
      SELECT pr.*, up.first_name, up.last_name, up.city, up.profile_image_url 
      FROM player_rankings pr 
      LEFT JOIN user_profiles up ON pr.user_id = up.user_id 
      WHERE 1=1
    ''';
    
    List<dynamic> params = [];
    int paramIndex = 1;
    
    if (city != null) {
      query += ' AND up.city = \$${paramIndex++}';
      params.add(city);
    }
    
    if (region != null) {
      query += ' AND up.region = \$${paramIndex++}';
      params.add(region);
    }
    
    if (tier != null) {
      query += ' AND pr.tier = \$${paramIndex++}';
      params.add(tier.name);
    }
    
    query += ' ORDER BY pr.lp DESC, pr.win_rate DESC LIMIT \$${paramIndex}';
    params.add(limit);
    
    return await executeQuery(query, params);
  }
  
  /// Get available courts by city and date
  Future<List<Map<String, dynamic>>> getAvailableCourts({
    required String city,
    required DateTime date,
    TimeOfDay? startTime,
    TimeOfDay? endTime,
  }) async {
    String query = '''
      SELECT c.*, COUNT(cb.id) as booking_count
      FROM courts c
      LEFT JOIN court_bookings cb ON c.id = cb.court_id 
        AND cb.booking_date = \$2 
        AND cb.status != 'cancelled_by_player'
        AND cb.status != 'cancelled_by_owner'
      WHERE c.city = \$1 
        AND c.is_active = true
    ''';
    
    List<dynamic> params = [city, date.toIso8601String().split('T')[0]];
    
    if (startTime != null && endTime != null) {
      query += '''
        AND c.id NOT IN (
          SELECT DISTINCT court_id FROM court_bookings 
          WHERE booking_date = \$2 
            AND status NOT IN ('cancelled_by_player', 'cancelled_by_owner')
            AND (
              (start_time <= \$3 AND end_time > \$3) OR
              (start_time < \$4 AND end_time >= \$4) OR
              (start_time >= \$3 AND end_time <= \$4)
            )
        )
      ''';
      params.addAll([
        '${startTime.hour.toString().padLeft(2, '0')}:${startTime.minute.toString().padLeft(2, '0')}:00',
        '${endTime.hour.toString().padLeft(2, '0')}:${endTime.minute.toString().padLeft(2, '0')}:00',
      ]);
    }
    
    query += '''
      GROUP BY c.id, c.name, c.description, c.address, c.city, c.region, 
               c.latitude, c.longitude, c.is_indoor, c.has_lighting, 
               c.has_air_conditioning, c.hourly_rate, c.currency, c.rating, 
               c.total_reviews, c.is_active, c.images, c.amenities, 
               c.created_at, c.updated_at, c.owner_id
      ORDER BY c.rating DESC, booking_count ASC
    ''';
    
    return await executeQuery(query, params);
  }
}

/// Time of day helper for database queries
class TimeOfDay {
  final int hour;
  final int minute;
  
  const TimeOfDay({required this.hour, required this.minute});
  
  @override
  String toString() => '${hour.toString().padLeft(2, '0')}:${minute.toString().padLeft(2, '0')}';
}
