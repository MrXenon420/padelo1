import '../utils/constants.dart';
import 'database_service.dart';
import 'real_auth_service.dart';

/// Real court booking service with database integration
class RealCourtService {
  static RealCourtService? _instance;
  static RealCourtService get instance => _instance ??= RealCourtService._();
  
  RealCourtService._();
  
  final DatabaseService _db = DatabaseService.instance;
  final RealAuthService _auth = RealAuthService.instance;
  
  /// Get available courts by city
  Future<List<Map<String, dynamic>>> getAvailableCourts({
    required String city,
    DateTime? date,
    String? startTime,
    String? endTime,
  }) async {
    try {
      final searchDate = date ?? DateTime.now();
      
      String query = '''
        SELECT c.*, COUNT(cb.id) as booking_count,
               COALESCE(AVG(r.rating), 0) as avg_rating,
               COUNT(r.id) as review_count
        FROM courts c
        LEFT JOIN court_bookings cb ON c.id = cb.court_id 
          AND cb.booking_date = \$2 
          AND cb.status NOT IN ('cancelled_by_player', 'cancelled_by_owner')
        LEFT JOIN reviews r ON c.id = r.court_id
        WHERE c.city ILIKE \$1 
          AND c.is_active = true
      ''';
      
      List<dynamic> params = [city, searchDate.toIso8601String().split('T')[0]];
      
      if (startTime != null && endTime != null) {
        query += '''
          AND c.id NOT IN (
            SELECT DISTINCT court_id FROM court_bookings 
            WHERE booking_date = \$2 
              AND status NOT IN ('cancelled_by_player', 'cancelled_by_owner')
              AND (
                (start_time <= \$3 AND end_time > \$3) OR
                (start_time < \$4 AND end_time >= \$4) OR
                (start_time >= \$3 AND end_time <= \$4)
              )
          )
        ''';
        params.addAll([startTime, endTime]);
      }
      
      query += '''
        GROUP BY c.id, c.owner_id, c.name, c.description, c.address, c.city, c.region, 
                 c.latitude, c.longitude, c.is_indoor, c.has_lighting, 
                 c.has_air_conditioning, c.hourly_rate, c.currency, c.rating, 
                 c.total_reviews, c.is_active, c.images, c.amenities, 
                 c.created_at, c.updated_at
        ORDER BY avg_rating DESC, booking_count ASC
      ''';
      
      return await _db.executeQuery(query, params);
      
    } catch (e) {
      print('Failed to get available courts: $e');
      return [];
    }
  }
  
  /// Book a court
  Future<BookingResult> bookCourt({
    required String courtId,
    required DateTime bookingDate,
    required String startTime,
    required String endTime,
    required double totalCost,
    String? notes,
  }) async {
    if (_auth.currentUser == null) {
      return BookingResult(success: false, message: 'Not authenticated');
    }
    
    try {
      return await _db.transaction(() async {
        // Check if the court is available at the requested time
        final conflictingBookings = await _db.executeQuery('''
          SELECT COUNT(*) as count FROM court_bookings 
          WHERE court_id = \$1 
            AND booking_date = \$2 
            AND status NOT IN ('cancelled_by_player', 'cancelled_by_owner')
            AND (
              (start_time <= \$3 AND end_time > \$3) OR
              (start_time < \$4 AND end_time >= \$4) OR
              (start_time >= \$3 AND end_time <= \$4)
            )
        ''', [
          courtId,
          bookingDate.toIso8601String().split('T')[0],
          startTime,
          endTime,
        ]);
        
        if (conflictingBookings.isNotEmpty && conflictingBookings.first['count'] > 0) {
          throw Exception('Court is not available at the requested time');
        }
        
        // Calculate duration
        final start = _parseTime(startTime);
        final end = _parseTime(endTime);
        final duration = end.difference(start).inMinutes / 60.0;
        
        // Create booking
        final bookingData = await _db.insert('court_bookings', {
          'court_id': courtId,
          'user_id': _auth.currentUser!.id,
          'booking_date': bookingDate.toIso8601String().split('T')[0],
          'start_time': startTime,
          'end_time': endTime,
          'duration_hours': duration,
          'total_cost': totalCost,
          'currency': 'EGP',
          'status': BookingStatus.pending.name,
          'payment_status': 'pending',
          'notes': notes,
        });
        
        if (bookingData == null) {
          throw Exception('Failed to create booking');
        }
        
        return BookingResult(
          success: true,
          message: 'Court booked successfully! Booking ID: ${bookingData['id']}',
          bookingId: bookingData['id'],
        );
      });
      
    } catch (e) {
      return BookingResult(success: false, message: e.toString());
    }
  }
  
  /// Get user bookings
  Future<List<Map<String, dynamic>>> getUserBookings({
    BookingStatus? status,
    bool includePast = false,
  }) async {
    if (_auth.currentUser == null) return [];
    
    try {
      String query = '''
        SELECT cb.*, c.name as court_name, c.address as court_address,
               c.is_indoor, c.has_lighting, c.has_air_conditioning
        FROM court_bookings cb
        JOIN courts c ON cb.court_id = c.id
        WHERE cb.user_id = \$1
      ''';
      
      List<dynamic> params = [_auth.currentUser!.id];
      int paramIndex = 2;
      
      if (!includePast) {
        query += ' AND cb.booking_date >= CURRENT_DATE';
      }
      
      if (status != null) {
        query += ' AND cb.status = \$${paramIndex++}';
        params.add(status.name);
      }
      
      query += ' ORDER BY cb.booking_date DESC, cb.start_time DESC';
      
      return await _db.executeQuery(query, params);
      
    } catch (e) {
      print('Failed to get user bookings: $e');
      return [];
    }
  }
  
  /// Cancel booking
  Future<BookingResult> cancelBooking(String bookingId) async {
    if (_auth.currentUser == null) {
      return BookingResult(success: false, message: 'Not authenticated');
    }
    
    try {
      // Check if booking exists and belongs to user
      final bookings = await _db.findWhere('court_bookings', {
        'id': bookingId,
        'user_id': _auth.currentUser!.id,
      });
      
      if (bookings.isEmpty) {
        return BookingResult(success: false, message: 'Booking not found');
      }
      
      final booking = bookings.first;
      
      // Check if booking can be cancelled (not in the past)
      final bookingDate = DateTime.parse(booking['booking_date']);
      if (bookingDate.isBefore(DateTime.now())) {
        return BookingResult(success: false, message: 'Cannot cancel past bookings');
      }
      
      // Update booking status
      await _db.update('court_bookings', bookingId, {
        'status': BookingStatus.cancelledByPlayer.name,
      });
      
      return BookingResult(
        success: true,
        message: 'Booking cancelled successfully',
      );
      
    } catch (e) {
      return BookingResult(success: false, message: 'Cancellation failed: $e');
    }
  }
  
  /// Get court details by ID
  Future<Map<String, dynamic>?> getCourtById(String courtId) async {
    try {
      final query = '''
        SELECT c.*, up.first_name as owner_first_name, up.last_name as owner_last_name,
               COALESCE(AVG(r.rating), 0) as avg_rating,
               COUNT(r.id) as review_count
        FROM courts c
        LEFT JOIN user_profiles up ON c.owner_id = up.user_id
        LEFT JOIN reviews r ON c.id = r.court_id
        WHERE c.id = \$1
        GROUP BY c.id, c.owner_id, c.name, c.description, c.address, c.city, c.region,
                 c.latitude, c.longitude, c.is_indoor, c.has_lighting,
                 c.has_air_conditioning, c.hourly_rate, c.currency, c.rating,
                 c.total_reviews, c.is_active, c.images, c.amenities,
                 c.created_at, c.updated_at, up.first_name, up.last_name
      ''';
      
      final results = await _db.executeQuery(query, [courtId]);
      
      return results.isNotEmpty ? results.first : null;
      
    } catch (e) {
      print('Failed to get court details: $e');
      return null;
    }
  }
  
  /// Search courts
  Future<List<Map<String, dynamic>>> searchCourts(String searchTerm) async {
    try {
      final query = '''
        SELECT c.*, COALESCE(AVG(r.rating), 0) as avg_rating,
               COUNT(r.id) as review_count
        FROM courts c
        LEFT JOIN reviews r ON c.id = r.court_id
        WHERE c.is_active = true
          AND (c.name ILIKE \$1 
               OR c.description ILIKE \$1
               OR c.address ILIKE \$1
               OR c.city ILIKE \$1)
        GROUP BY c.id, c.owner_id, c.name, c.description, c.address, c.city, c.region,
                 c.latitude, c.longitude, c.is_indoor, c.has_lighting,
                 c.has_air_conditioning, c.hourly_rate, c.currency, c.rating,
                 c.total_reviews, c.is_active, c.images, c.amenities,
                 c.created_at, c.updated_at
        ORDER BY avg_rating DESC
        LIMIT 20
      ''';
      
      return await _db.executeQuery(query, ['%$searchTerm%']);
      
    } catch (e) {
      print('Failed to search courts: $e');
      return [];
    }
  }
  
  /// Helper method to parse time string to DateTime
  DateTime _parseTime(String timeString) {
    final parts = timeString.split(':');
    final hour = int.parse(parts[0]);
    final minute = int.parse(parts[1]);
    
    return DateTime(2000, 1, 1, hour, minute); // Use arbitrary date for time calculation
  }
}

/// Court booking result
class BookingResult {
  final bool success;
  final String message;
  final String? bookingId;
  
  BookingResult({
    required this.success,
    required this.message,
    this.bookingId,
  });
}

/// Booking status enum
enum BookingStatus {
  pending,
  confirmed,
  completed,
  cancelledByPlayer,
  cancelledByOwner,
  noShow,
}
