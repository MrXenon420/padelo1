import 'dart:math';

import '../models/tournament_model.dart';
import '../models/user_model.dart';
import '../utils/constants.dart';
import '../utils/dio_client.dart';

class TournamentService {
  final DioClient _dioClient = DioClient();

  // Tournament CRUD operations
  Future<List<Tournament>> getTournaments({
    TournamentStatus? status,
    TournamentType? type,
    String? region,
    int page = 1,
    int limit = 20,
  }) async {
    final response = await _dioClient.get(
      '/tournaments',
      queryParameters: {
        if (status != null) 'status': status.name,
        if (type != null) 'type': type.name,
        if (region != null) 'region': region,
        'page': page,
        'limit': limit,
      },
    );

    final tournaments = (response.data['tournaments'] as List)
        .map((json) => Tournament.fromJson(json))
        .toList();

    return tournaments;
  }

  Future<Tournament> getTournament(String id) async {
    final response = await _dioClient.get('/tournaments/$id');
    return Tournament.fromJson(response.data);
  }

  Future<Tournament> createTournament(Map<String, dynamic> tournamentData) async {
    final response = await _dioClient.post(
      '/tournaments',
      data: tournamentData,
    );
    return Tournament.fromJson(response.data);
  }

  Future<void> joinTournament(String tournamentId) async {
    await _dioClient.post('/tournaments/$tournamentId/join');
  }

  Future<void> leaveTournament(String tournamentId) async {
    await _dioClient.delete('/tournaments/$tournamentId/leave');
  }

  // Leaderboard operations
  Future<List<LeaderboardEntry>> getLeaderboard({
    String? region,
    Gender? gender,
    String? ageGroup,
    int page = 1,
    int limit = 50,
  }) async {
    final response = await _dioClient.get(
      '/leaderboard',
      queryParameters: {
        if (region != null) 'region': region,
        if (gender != null) 'gender': gender.name,
        if (ageGroup != null) 'ageGroup': ageGroup,
        'page': page,
        'limit': limit,
      },
    );

    final leaderboard = (response.data['leaderboard'] as List)
        .map((json) => LeaderboardEntry.fromJson(json))
        .toList();

    return leaderboard;
  }

  Future<PlayerRanking> getPlayerRanking(String playerId) async {
    final response = await _dioClient.get('/players/$playerId/ranking');
    return PlayerRanking.fromJson(response.data);
  }

  Future<List<LPTransaction>> getPlayerLPTransactions(
    String playerId, {
    int page = 1,
    int limit = 20,
  }) async {
    final response = await _dioClient.get(
      '/players/$playerId/lp-transactions',
      queryParameters: {
        'page': page,
        'limit': limit,
      },
    );

    final transactions = (response.data['transactions'] as List)
        .map((json) => LPTransaction.fromJson(json))
        .toList();

    return transactions;
  }

  // Match operations
  Future<void> recordMatchResult({
    required String matchId,
    required MatchTeam winner,
    required MatchScore score,
    required String refereeCode,
  }) async {
    await _dioClient.post(
      '/matches/$matchId/result',
      data: {
        'winner': winner.toJson(),
        'score': score.toJson(),
        'refereeCode': refereeCode,
      },
    );
  }

  Future<List<TournamentMatch>> getTournamentMatches(String tournamentId) async {
    final response = await _dioClient.get('/tournaments/$tournamentId/matches');
    
    final matches = (response.data['matches'] as List)
        .map((json) => TournamentMatch.fromJson(json))
        .toList();

    return matches;
  }

  // LP Calculation Logic (Client-side for prediction)
  LPChangeResult calculateLPChange({
    required int winnerTeamLP,
    required int loserTeamLP,
    required bool isOfficial,
  }) {
    const baseLPGain = 25;
    final lpDifference = winnerTeamLP - loserTeamLP;
    
    // Adjust based on relative strength
    int lpAdjustment = 0;
    if (lpDifference > 200) {
      // Stronger team wins - less LP
      lpAdjustment = -10;
    } else if (lpDifference < -200) {
      // Weaker team wins - more LP
      lpAdjustment = 15;
    }
    
    final actualGain = max(5, baseLPGain + lpAdjustment);
    final actualLoss = max(5, (actualGain * 0.7).floor());
    
    // Apply official tournament multiplier
    final multiplier = isOfficial ? 1.0 : 0.1;
    
    return LPChangeResult(
      winnerLP: (actualGain * multiplier).floor(),
      loserLP: -(actualLoss * multiplier).floor(),
    );
  }

  int calculateAdvancementPoints({
    required int bracketSize,
    required TournamentRound round,
    required bool isWinner,
    bool isChampion = false,
  }) {
    final pointsConfig = LPConstants.advancementPoints
        .firstWhere((config) => config.bracketSize == bracketSize);
    
    int points = 0;
    
    // Base match win
    if (isWinner) {
      points += pointsConfig.points.matchWin;
      
      // Round-specific bonuses
      switch (round) {
        case TournamentRound.roundOf16:
          points += pointsConfig.points.roundOf16 ?? 0;
          break;
        case TournamentRound.quarterfinal:
          points += pointsConfig.points.quarterfinal;
          break;
        case TournamentRound.semifinal:
          points += pointsConfig.points.semifinal;
          break;
        case TournamentRound.finalMatch:
          points += pointsConfig.points.finalMatch;
          if (isChampion) {
            points += pointsConfig.points.champion;
          }
          break;
        case TournamentRound.roundOf32:
          // No additional points for first round
          break;
      }
    }
    
    return points;
  }

  int calculateBonusPoints({
    required String scenario,
    MatchScore? matchScore,
    PlayerRanking? playerRanking,
    PlayerRanking? opponentRanking,
  }) {
    int bonusPoints = 0;
    
    switch (scenario) {
      case 'winning_without_dropping_set':
        if (matchScore != null) {
          // Check if winner didn't drop a set
          final winnerSets = max(matchScore.team1Sets, matchScore.team2Sets);
          final loserSets = min(matchScore.team1Sets, matchScore.team2Sets);
          
          if (loserSets == 0) {
            bonusPoints += LPConstants.bonusPoints
                .firstWhere((bp) => bp.scenario == scenario)
                .points;
          }
        }
        break;
        
      case 'beating_higher_ranked_team':
        if (playerRanking != null && opponentRanking != null) {
          if (opponentRanking.lp > playerRanking.lp) {
            bonusPoints += LPConstants.bonusPoints
                .firstWhere((bp) => bp.scenario == scenario)
                .points;
          }
        }
        break;
        
      // Other bonus scenarios would be calculated here
    }
    
    return bonusPoints;
  }

  TierInfo calculateTierAndDivision(int currentLP) {
    for (int i = LPConstants.tierRequirements.length - 1; i >= 0; i--) {
      final tierReq = LPConstants.tierRequirements[i];
      
      for (int j = tierReq.divisions.length - 1; j >= 0; j--) {
        final divisionReq = tierReq.divisions[j];
        
        if (currentLP >= divisionReq.lpRequired) {
          // Calculate LP required for next promotion
          int lpRequiredForPromotion = 0;
          
          final nextDivisionIndex = j + 1;
          final nextTierIndex = nextDivisionIndex >= tierReq.divisions.length ? i + 1 : i;
          
          if (nextTierIndex < LPConstants.tierRequirements.length) {
            final nextTier = LPConstants.tierRequirements[nextTierIndex];
            final nextDivision = nextDivisionIndex >= tierReq.divisions.length
                ? nextTier.divisions[0]
                : tierReq.divisions[nextDivisionIndex];
            
            lpRequiredForPromotion = nextDivision.lpRequired - currentLP;
          }
          
          return TierInfo(
            tier: tierReq.tier,
            division: divisionReq.division,
            lpRequiredForPromotion: lpRequiredForPromotion,
          );
        }
      }
    }
    
    // Default to lowest tier
    return const TierInfo(
      tier: UserTier.rookie,
      division: 4,
      lpRequiredForPromotion: 100,
    );
  }

  bool checkLPFarming({
    required String playerId1,
    required String playerId2,
    required List<TournamentMatch> recentMatches,
  }) {
    final oneMonthAgo = DateTime.now().subtract(const Duration(days: 30));
    
    final matchesBetweenPlayers = recentMatches.where((match) {
      final matchDate = match.startTime;
      return matchDate.isAfter(oneMonthAgo) &&
          ((match.team1.player1 == playerId1 && match.team2.player1 == playerId2) ||
           (match.team1.player1 == playerId2 && match.team2.player1 == playerId1));
    }).toList();
    
    if (matchesBetweenPlayers.length >= 6) {
      final player1Wins = matchesBetweenPlayers.where((match) =>
          (match.team1.player1 == playerId1 && match.winner == match.team1) ||
          (match.team2.player1 == playerId1 && match.winner == match.team2)
      ).length;
      
      final winRate = player1Wins / matchesBetweenPlayers.length;
      
      // If either player wins more than 84% of matches, flag as potential farming
      return winRate > 0.84 || (1 - winRate) > 0.84;
    }
    
    return false;
  }

  Future<List<Tournament>> getUserTournaments(String userId) async {
    final response = await _dioClient.get('/users/$userId/tournaments');
    
    final tournaments = (response.data['tournaments'] as List)
        .map((json) => Tournament.fromJson(json))
        .toList();

    return tournaments;
  }
}

class LPChangeResult {
  final int winnerLP;
  final int loserLP;

  const LPChangeResult({
    required this.winnerLP,
    required this.loserLP,
  });
}

class TierInfo {
  final UserTier tier;
  final int division;
  final int lpRequiredForPromotion;

  const TierInfo({
    required this.tier,
    required this.division,
    required this.lpRequiredForPromotion,
  });
}
