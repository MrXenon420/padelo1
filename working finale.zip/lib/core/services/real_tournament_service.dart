import '../models/tournament_model.dart';
import '../models/user_model.dart';
import '../utils/constants.dart';
import 'database_service.dart';
import 'real_auth_service.dart';

/// Real tournament service with database integration
class RealTournamentService {
  static RealTournamentService? _instance;
  static RealTournamentService get instance => _instance ??= RealTournamentService._();
  
  RealTournamentService._();
  
  final DatabaseService _db = DatabaseService.instance;
  final RealAuthService _auth = RealAuthService.instance;
  
  /// Get all tournaments
  Future<List<Tournament>> getAllTournaments({
    TournamentStatus? status,
    TournamentType? type,
    UserTier? minTier,
    UserTier? maxTier,
    String? city,
    int limit = 50,
  }) async {
    try {
      String query = '''
        SELECT t.*, up.first_name as organizer_first_name, up.last_name as organizer_last_name,
               c.name as venue_name
        FROM tournaments t
        LEFT JOIN user_profiles up ON t.organizer_id = up.user_id
        LEFT JOIN courts c ON t.venue_id = c.id
        WHERE 1=1
      ''';
      
      List<dynamic> params = [];
      int paramIndex = 1;
      
      if (status != null) {
        query += ' AND t.status = \$${paramIndex++}';
        params.add(status.name);
      }
      
      if (type != null) {
        query += ' AND t.tournament_type = \$${paramIndex++}';
        params.add(type.name);
      }
      
      if (minTier != null) {
        query += ' AND t.min_tier = \$${paramIndex++}';
        params.add(minTier.name);
      }
      
      if (maxTier != null) {
        query += ' AND t.max_tier = \$${paramIndex++}';
        params.add(maxTier.name);
      }
      
      if (city != null) {
        query += ' AND (c.city = \$${paramIndex++} OR t.venue_address ILIKE \$${paramIndex++})';
        params.add(city);
        params.add('%$city%');
        paramIndex--; // Adjust for the double parameter
      }
      
      query += ' ORDER BY t.start_date ASC LIMIT \$${paramIndex}';
      params.add(limit);
      
      final results = await _db.executeQuery(query, params);
      
      return results.map((data) => Tournament.fromJson(data)).toList();
      
    } catch (e) {
      print('Failed to get tournaments: $e');
      return [];
    }
  }
  
  /// Get tournament by ID
  Future<Tournament?> getTournamentById(String tournamentId) async {
    try {
      final query = '''
        SELECT t.*, up.first_name as organizer_first_name, up.last_name as organizer_last_name,
               c.name as venue_name
        FROM tournaments t
        LEFT JOIN user_profiles up ON t.organizer_id = up.user_id
        LEFT JOIN courts c ON t.venue_id = c.id
        WHERE t.id = \$1
      ''';
      
      final results = await _db.executeQuery(query, [tournamentId]);
      
      if (results.isNotEmpty) {
        return Tournament.fromJson(results.first);
      }
      return null;
      
    } catch (e) {
      print('Failed to get tournament: $e');
      return null;
    }
  }
  
  /// Create new tournament
  Future<TournamentResult> createTournament({
    required String name,
    required String description,
    required TournamentType type,
    required double entryFee,
    required int maxParticipants,
    required UserTier minTier,
    required UserTier maxTier,
    required DateTime startDate,
    required DateTime endDate,
    required DateTime registrationDeadline,
    String? venueId,
    String? venueAddress,
    String? rules,
    double prizePool = 0.0,
    double firstPrize = 0.0,
    double secondPrize = 0.0,
    double thirdPrize = 0.0,
  }) async {
    if (_auth.currentUser == null) {
      return TournamentResult(success: false, message: 'Not authenticated');
    }
    
    // Check if user has permission to create tournaments
    if (_auth.currentUser!.role != UserRole.owner && 
        _auth.currentUser!.role != UserRole.tournamentOrganizer) {
      return TournamentResult(success: false, message: 'No permission to create tournaments');
    }
    
    try {
      final tournamentData = await _db.insert('tournaments', {
        'organizer_id': _auth.currentUser!.id,
        'name': name,
        'description': description,
        'tournament_type': type.name,
        'status': TournamentStatus.upcoming.name,
        'entry_fee': entryFee,
        'currency': 'EGP',
        'max_participants': maxParticipants,
        'current_participants': 0,
        'min_tier': minTier.name,
        'max_tier': maxTier.name,
        'prize_pool': prizePool,
        'first_prize': firstPrize,
        'second_prize': secondPrize,
        'third_prize': thirdPrize,
        'start_date': startDate.toIso8601String(),
        'end_date': endDate.toIso8601String(),
        'registration_deadline': registrationDeadline.toIso8601String(),
        'venue_id': venueId,
        'venue_address': venueAddress,
        'rules': rules,
      });
      
      if (tournamentData != null) {
        final tournament = await getTournamentById(tournamentData['id']);
        return TournamentResult(
          success: true, 
          message: 'Tournament created successfully',
          tournament: tournament,
        );
      }
      
      return TournamentResult(success: false, message: 'Failed to create tournament');
      
    } catch (e) {
      return TournamentResult(success: false, message: 'Tournament creation failed: $e');
    }
  }
  
  /// Register for tournament
  Future<TournamentResult> registerForTournament({
    required String tournamentId,
    String? partnerId, // For doubles tournaments
  }) async {
    if (_auth.currentUser == null) {
      return TournamentResult(success: false, message: 'Not authenticated');
    }
    
    try {
      return await _db.transaction(() async {
        // Get tournament details
        final tournament = await getTournamentById(tournamentId);
        if (tournament == null) {
          throw Exception('Tournament not found');
        }
        
        // Check if registration is still open
        if (DateTime.now().isAfter(tournament.registrationDeadline)) {
          throw Exception('Registration deadline has passed');
        }
        
        // Check if tournament is full
        if (tournament.currentParticipants >= tournament.maxParticipants) {
          throw Exception('Tournament is full');
        }
        
        // Check if user is already registered
        final existingParticipation = await _db.findWhere('tournament_participants', {
          'tournament_id': tournamentId,
          'user_id': _auth.currentUser!.id,
        });
        
        if (existingParticipation.isNotEmpty) {
          throw Exception('Already registered for this tournament');
        }
        
        // Check user tier eligibility
        final userRanking = await _auth.getUserRanking(_auth.currentUser!.id);
        if (userRanking != null) {
          final userTierIndex = UserTier.values.indexOf(userRanking.tier);
          final minTierIndex = UserTier.values.indexOf(tournament.minTier);
          final maxTierIndex = UserTier.values.indexOf(tournament.maxTier);
          
          if (userTierIndex < minTierIndex || userTierIndex > maxTierIndex) {
            throw Exception('Your tier is not eligible for this tournament');
          }
        }
        
        // Register participant
        await _db.insert('tournament_participants', {
          'tournament_id': tournamentId,
          'user_id': _auth.currentUser!.id,
          'partner_id': partnerId,
          'payment_status': 'pending',
          'is_active': true,
        });
        
        // Update participant count
        await _db.update('tournaments', tournamentId, {
          'current_participants': tournament.currentParticipants + 1,
        });
        
        return TournamentResult(
          success: true,
          message: 'Successfully registered for tournament',
        );
      });
      
    } catch (e) {
      return TournamentResult(success: false, message: e.toString());
    }
  }
  
  /// Unregister from tournament
  Future<TournamentResult> unregisterFromTournament(String tournamentId) async {
    if (_auth.currentUser == null) {
      return TournamentResult(success: false, message: 'Not authenticated');
    }
    
    try {
      return await _db.transaction(() async {
        // Find participant record
        final participations = await _db.findWhere('tournament_participants', {
          'tournament_id': tournamentId,
          'user_id': _auth.currentUser!.id,
        });
        
        if (participations.isEmpty) {
          throw Exception('Not registered for this tournament');
        }
        
        // Check if tournament has started
        final tournament = await getTournamentById(tournamentId);
        if (tournament != null && DateTime.now().isAfter(tournament.startDate)) {
          throw Exception('Cannot unregister from started tournament');
        }
        
        // Remove participant
        await _db.delete('tournament_participants', participations.first['id']);
        
        // Update participant count
        if (tournament != null) {
          await _db.update('tournaments', tournamentId, {
            'current_participants': tournament.currentParticipants - 1,
          });
        }
        
        return TournamentResult(
          success: true,
          message: 'Successfully unregistered from tournament',
        );
      });
      
    } catch (e) {
      return TournamentResult(success: false, message: e.toString());
    }
  }
  
  /// Get user's tournaments
  Future<List<Tournament>> getUserTournaments({
    TournamentStatus? status,
    bool includeOrganized = false,
  }) async {
    if (_auth.currentUser == null) return [];
    
    try {
      String query = '''
        SELECT DISTINCT t.*, up.first_name as organizer_first_name, up.last_name as organizer_last_name,
               c.name as venue_name
        FROM tournaments t
        LEFT JOIN user_profiles up ON t.organizer_id = up.user_id
        LEFT JOIN courts c ON t.venue_id = c.id
        LEFT JOIN tournament_participants tp ON t.id = tp.tournament_id
        WHERE (tp.user_id = \$1 AND tp.is_active = true)
      ''';
      
      List<dynamic> params = [_auth.currentUser!.id];
      int paramIndex = 2;
      
      if (includeOrganized) {
        query += ' OR t.organizer_id = \$1';
      }
      
      if (status != null) {
        query += ' AND t.status = \$${paramIndex++}';
        params.add(status.name);
      }
      
      query += ' ORDER BY t.start_date ASC';
      
      final results = await _db.executeQuery(query, params);
      
      return results.map((data) => Tournament.fromJson(data)).toList();
      
    } catch (e) {
      print('Failed to get user tournaments: $e');
      return [];
    }
  }
  
  /// Get tournament participants
  Future<List<User>> getTournamentParticipants(String tournamentId) async {
    try {
      final query = '''
        SELECT u.*, up.first_name, up.last_name, up.city, up.profile_image_url,
               pr.tier, pr.lp, pr.win_rate
        FROM tournament_participants tp
        JOIN users u ON tp.user_id = u.id
        LEFT JOIN user_profiles up ON u.id = up.user_id
        LEFT JOIN player_rankings pr ON u.id = pr.user_id
        WHERE tp.tournament_id = \$1 AND tp.is_active = true
        ORDER BY tp.registration_date ASC
      ''';
      
      final results = await _db.executeQuery(query, [tournamentId]);
      
      return results.map((data) {
        final profile = UserProfile.fromJson(data);
        return User(
          id: data['id'],
          username: data['username'] ?? data['email']?.split('@').first ?? '',
          email: data['email'],
          phoneNumber: data['phone_number'] ?? '',
          role: UserRole.values.firstWhere((r) => r.name == data['role']),
          profile: profile,
          isActive: data['is_active'] ?? false,
          isBanned: data['is_banned'] ?? false,
          emailVerified: data['email_verified'] ?? false,
          phoneVerified: data['phone_verified'] ?? false,
          isVerified: data['is_verified'] ?? false,
          loginAttempts: data['login_attempts'] ?? 0,
          createdAt: DateTime.parse(data['created_at']),
          updatedAt: DateTime.parse(data['updated_at'] ?? data['created_at']),
        );
      }).toList();
      
    } catch (e) {
      print('Failed to get tournament participants: $e');
      return [];
    }
  }
  
  /// Check if user is registered for tournament
  Future<bool> isUserRegistered(String tournamentId) async {
    if (_auth.currentUser == null) return false;
    
    try {
      final participations = await _db.findWhere('tournament_participants', {
        'tournament_id': tournamentId,
        'user_id': _auth.currentUser!.id,
      });
      
      return participations.isNotEmpty;
      
    } catch (e) {
      print('Failed to check registration: $e');
      return false;
    }
  }
  
  /// Search tournaments
  Future<List<Tournament>> searchTournaments(String searchTerm) async {
    try {
      final query = '''
        SELECT t.*, up.first_name as organizer_first_name, up.last_name as organizer_last_name,
               c.name as venue_name
        FROM tournaments t
        LEFT JOIN user_profiles up ON t.organizer_id = up.user_id
        LEFT JOIN courts c ON t.venue_id = c.id
        WHERE t.name ILIKE \$1 
           OR t.description ILIKE \$1
           OR c.name ILIKE \$1
           OR c.city ILIKE \$1
        ORDER BY t.start_date ASC
        LIMIT 20
      ''';
      
      final results = await _db.executeQuery(query, ['%$searchTerm%']);
      
      return results.map((data) => Tournament.fromJson(data)).toList();
      
    } catch (e) {
      print('Failed to search tournaments: $e');
      return [];
    }
  }
}

/// Tournament operation result
class TournamentResult {
  final bool success;
  final String message;
  final Tournament? tournament;
  
  TournamentResult({
    required this.success,
    required this.message,
    this.tournament,
  });
}
