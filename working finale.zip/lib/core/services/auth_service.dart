import 'package:dio/dio.dart';

import '../models/user_model.dart';
import '../utils/constants.dart';
import '../utils/dio_client.dart';
import 'storage_service.dart';

class AuthService {
  final DioClient _dioClient = DioClient();

  Future<AuthResponse> login({
    required String phoneOrEmail,
    required String password,
  }) async {
    try {
      final response = await _dioClient.post(
        '/auth/login',
        data: {
          'phoneOrEmail': phoneOrEmail,
          'password': password,
        },
      );

      return AuthResponse.fromJson(response.data);
    } on DioException catch (e) {
      throw _handleDioError(e);
    }
  }

  Future<AuthResponse> register({
    required String phoneNumber,
    String? email,
    required String password,
    required String confirmPassword,
    required String username,
    required String firstName,
    required String lastName,
    required PreferredHand preferredHand,
    required CourtPosition preferredCourtPosition,
    required Gender gender,
    required String city,
    required String country,
    required String language,
    required bool agreeTerms,
    required bool agreePrivacy,
  }) async {
    try {
      final response = await _dioClient.post(
        '/auth/register',
        data: {
          'phoneNumber': phoneNumber,
          'email': email,
          'password': password,
          'confirmPassword': confirmPassword,
          'username': username,
          'agreeTerms': agreeTerms,
          'agreePrivacy': agreePrivacy,
          'profile': {
            'firstName': firstName,
            'lastName': lastName,
            'preferredHand': preferredHand.name,
            'preferredCourtPosition': preferredCourtPosition.name,
            'gender': gender.name,
            'city': city,
            'country': country,
            'language': language,
          },
        },
      );

      return AuthResponse.fromJson(response.data);
    } on DioException catch (e) {
      throw _handleDioError(e);
    }
  }

  Future<bool> validateToken(String token) async {
    try {
      await _dioClient.get(
        '/auth/validate',
        options: Options(
          headers: {'Authorization': 'Bearer $token'},
        ),
      );
      return true;
    } on DioException catch (e) {
      if (e.response?.statusCode == 401) {
        return false;
      }
      throw _handleDioError(e);
    }
  }

  Future<void> logout() async {
    try {
      final token = StorageService.getString(AppConstants.tokenKey);
      if (token != null) {
        await _dioClient.post(
          '/auth/logout',
          options: Options(
            headers: {'Authorization': 'Bearer $token'},
          ),
        );
      }
    } on DioException catch (e) {
      // Continue with logout even if API call fails
      print('Logout API error: ${e.message}');
    }
  }

  Future<User> updateProfile(Map<String, dynamic> profileData) async {
    try {
      final response = await _dioClient.put(
        '/auth/profile',
        data: profileData,
      );

      return User.fromJson(response.data);
    } on DioException catch (e) {
      throw _handleDioError(e);
    }
  }

  Future<void> changePassword({
    required String currentPassword,
    required String newPassword,
    required String confirmPassword,
  }) async {
    try {
      await _dioClient.put(
        '/auth/change-password',
        data: {
          'currentPassword': currentPassword,
          'newPassword': newPassword,
          'confirmPassword': confirmPassword,
        },
      );
    } on DioException catch (e) {
      throw _handleDioError(e);
    }
  }

  Future<void> requestPasswordReset(String phoneOrEmail) async {
    try {
      await _dioClient.post(
        '/auth/forgot-password',
        data: {
          'phoneOrEmail': phoneOrEmail,
        },
      );
    } on DioException catch (e) {
      throw _handleDioError(e);
    }
  }

  Future<void> resetPassword({
    required String token,
    required String newPassword,
    required String confirmPassword,
  }) async {
    try {
      await _dioClient.post(
        '/auth/reset-password',
        data: {
          'token': token,
          'newPassword': newPassword,
          'confirmPassword': confirmPassword,
        },
      );
    } on DioException catch (e) {
      throw _handleDioError(e);
    }
  }

  Future<String> refreshToken() async {
    try {
      final refreshToken = StorageService.getString(AppConstants.refreshTokenKey);
      if (refreshToken == null) {
        throw Exception('No refresh token available');
      }

      final response = await _dioClient.post(
        '/auth/refresh',
        data: {
          'refreshToken': refreshToken,
        },
      );

      final newToken = response.data['token'] as String;
      await StorageService.setString(AppConstants.tokenKey, newToken);
      
      return newToken;
    } on DioException catch (e) {
      throw _handleDioError(e);
    }
  }

  Future<void> verifyPhone(String code) async {
    try {
      await _dioClient.post(
        '/auth/verify-phone',
        data: {
          'code': code,
        },
      );
    } on DioException catch (e) {
      throw _handleDioError(e);
    }
  }

  Future<void> resendVerificationCode() async {
    try {
      await _dioClient.post('/auth/resend-verification');
    } on DioException catch (e) {
      throw _handleDioError(e);
    }
  }

  Exception _handleDioError(DioException e) {
    String message;
    
    switch (e.type) {
      case DioExceptionType.connectionTimeout:
      case DioExceptionType.sendTimeout:
      case DioExceptionType.receiveTimeout:
        message = 'Connection timeout. Please check your internet connection.';
        break;
      case DioExceptionType.badResponse:
        final statusCode = e.response?.statusCode;
        final data = e.response?.data;
        
        if (statusCode != null) {
          switch (statusCode) {
            case 400:
              message = data?['message'] ?? 'Invalid request.';
              break;
            case 401:
              message = 'Invalid credentials or session expired.';
              break;
            case 403:
              message = 'Access denied.';
              break;
            case 404:
              message = 'Service not found.';
              break;
            case 409:
              message = data?['message'] ?? 'Conflict occurred.';
              break;
            case 422:
              message = data?['message'] ?? 'Validation failed.';
              break;
            case 429:
              message = 'Too many requests. Please try again later.';
              break;
            case 500:
              message = 'Server error. Please try again later.';
              break;
            default:
              message = data?['message'] ?? 'An error occurred.';
          }
        } else {
          message = 'Network error occurred.';
        }
        break;
      case DioExceptionType.cancel:
        message = 'Request was cancelled.';
        break;
      case DioExceptionType.connectionError:
        message = 'Connection error. Please check your internet connection.';
        break;
      case DioExceptionType.badCertificate:
        message = 'Certificate error.';
        break;
      case DioExceptionType.unknown:
      default:
        message = e.message ?? 'An unexpected error occurred.';
        break;
    }
    
    return Exception(message);
  }
}
