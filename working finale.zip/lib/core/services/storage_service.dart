import 'package:hive_flutter/hive_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../utils/constants.dart';

class StorageService {
  static late Box _userBox;
  static late Box _tournamentsBox;
  static late Box _courtsBox;
  static late Box _bookingsBox;
  static late Box _cacheBox;
  static late SharedPreferences _prefs;

  static Future<void> init() async {
    // Initialize Hive
    await Hive.initFlutter();
    
    // Open boxes
    _userBox = await Hive.openBox(AppConstants.userBox);
    _tournamentsBox = await Hive.openBox(AppConstants.tournamentsBox);
    _courtsBox = await Hive.openBox(AppConstants.courtsBox);
    _bookingsBox = await Hive.openBox(AppConstants.bookingsBox);
    _cacheBox = await Hive.openBox(AppConstants.cacheBox);
    
    // Initialize SharedPreferences
    _prefs = await SharedPreferences.getInstance();
  }

  // SharedPreferences methods
  static Future<bool> setString(String key, String value) async {
    return await _prefs.setString(key, value);
  }

  static String? getString(String key) {
    return _prefs.getString(key);
  }

  static Future<bool> setBool(String key, bool value) async {
    return await _prefs.setBool(key, value);
  }

  static bool? getBool(String key) {
    return _prefs.getBool(key);
  }

  static Future<bool> setInt(String key, int value) async {
    return await _prefs.setInt(key, value);
  }

  static int? getInt(String key) {
    return _prefs.getInt(key);
  }

  static Future<bool> setDouble(String key, double value) async {
    return await _prefs.setDouble(key, value);
  }

  static double? getDouble(String key) {
    return _prefs.getDouble(key);
  }

  static Future<bool> setStringList(String key, List<String> value) async {
    return await _prefs.setStringList(key, value);
  }

  static List<String>? getStringList(String key) {
    return _prefs.getStringList(key);
  }

  static Future<bool> remove(String key) async {
    return await _prefs.remove(key);
  }

  static Future<bool> clear() async {
    return await _prefs.clear();
  }

  static bool containsKey(String key) {
    return _prefs.containsKey(key);
  }

  // Hive methods for complex objects
  
  // User data
  static Future<void> saveUserData(String key, Map<String, dynamic> userData) async {
    await _userBox.put(key, userData);
  }

  static Map<String, dynamic>? getUserData(String key) {
    final data = _userBox.get(key);
    return data?.cast<String, dynamic>();
  }

  static Future<void> removeUserData(String key) async {
    await _userBox.delete(key);
  }

  static Future<void> clearUserData() async {
    await _userBox.clear();
  }

  // Tournament data
  static Future<void> saveTournament(String id, Map<String, dynamic> tournament) async {
    await _tournamentsBox.put(id, tournament);
  }

  static Map<String, dynamic>? getTournament(String id) {
    final data = _tournamentsBox.get(id);
    return data?.cast<String, dynamic>();
  }

  static List<Map<String, dynamic>> getAllTournaments() {
    return _tournamentsBox.values
        .map((e) => e as Map<String, dynamic>)
        .toList();
  }

  static Future<void> removeTournament(String id) async {
    await _tournamentsBox.delete(id);
  }

  static Future<void> clearTournaments() async {
    await _tournamentsBox.clear();
  }

  // Court data
  static Future<void> saveCourt(String id, Map<String, dynamic> court) async {
    await _courtsBox.put(id, court);
  }

  static Map<String, dynamic>? getCourt(String id) {
    final data = _courtsBox.get(id);
    return data?.cast<String, dynamic>();
  }

  static List<Map<String, dynamic>> getAllCourts() {
    return _courtsBox.values
        .map((e) => e as Map<String, dynamic>)
        .toList();
  }

  static Future<void> removeCourt(String id) async {
    await _courtsBox.delete(id);
  }

  static Future<void> clearCourts() async {
    await _courtsBox.clear();
  }

  // Booking data
  static Future<void> saveBooking(String id, Map<String, dynamic> booking) async {
    await _bookingsBox.put(id, booking);
  }

  static Map<String, dynamic>? getBooking(String id) {
    final data = _bookingsBox.get(id);
    return data?.cast<String, dynamic>();
  }

  static List<Map<String, dynamic>> getAllBookings() {
    return _bookingsBox.values
        .map((e) => e as Map<String, dynamic>)
        .toList();
  }

  static Future<void> removeBooking(String id) async {
    await _bookingsBox.delete(id);
  }

  static Future<void> clearBookings() async {
    await _bookingsBox.clear();
  }

  // Cache data
  static Future<void> saveToCache(String key, dynamic data, {Duration? expiry}) async {
    final cacheData = {
      'data': data,
      'timestamp': DateTime.now().millisecondsSinceEpoch,
      'expiry': expiry?.inMilliseconds,
    };
    await _cacheBox.put(key, cacheData);
  }

  static dynamic getFromCache(String key) {
    final cacheData = _cacheBox.get(key);
    if (cacheData == null) return null;

    final timestamp = cacheData['timestamp'] as int;
    final expiry = cacheData['expiry'] as int?;

    if (expiry != null) {
      final now = DateTime.now().millisecondsSinceEpoch;
      if (now - timestamp > expiry) {
        _cacheBox.delete(key);
        return null;
      }
    }

    return cacheData['data'];
  }

  static Future<void> removeFromCache(String key) async {
    await _cacheBox.delete(key);
  }

  static Future<void> clearCache() async {
    await _cacheBox.clear();
  }

  // Clear all data
  static Future<void> clearAllData() async {
    await Future.wait([
      clearUserData(),
      clearTournaments(),
      clearCourts(),
      clearBookings(),
      clearCache(),
      clear(),
    ]);
  }
}
