import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/user_model.dart';
import '../models/tournament_model.dart';
import '../utils/constants.dart';
import 'database_service.dart';

/// Real authentication service with database integration
class RealAuthService {
  static RealAuthService? _instance;
  static RealAuthService get instance => _instance ??= RealAuthService._();
  
  RealAuthService._();
  
  final DatabaseService _db = DatabaseService.instance;
  User? _currentUser;

  /// Get current authenticated user
  User? get currentUser => _currentUser;
  
  /// Check if user is authenticated
  bool get isAuthenticated => _currentUser != null;
  
  /// Initialize auth service and check for existing session
  Future<void> initialize() async {
    final prefs = await SharedPreferences.getInstance();
    final userId = prefs.getString('current_user_id');
    
    if (userId != null) {
      try {
        await _loadUserFromDatabase(userId);
      } catch (e) {
        print('Failed to load user session: $e');
        await signOut();
      }
    }
  }
  
  /// Sign up new user
  Future<AuthResult> signUp({
    required String email,
    required String password,
    required String firstName,
    required String lastName,
    required String phoneNumber,
    required String city,
    required String region,
    UserRole role = UserRole.player,
  }) async {
    try {
      // Check if email already exists
      final existingUsers = await _db.findWhere('users', {'email': email});
      if (existingUsers.isNotEmpty) {
        return AuthResult(success: false, message: 'Email already registered');
      }
      
      // Check if phone number already exists
      final existingPhone = await _db.findWhere('users', {'phone_number': phoneNumber});
      if (existingPhone.isNotEmpty) {
        return AuthResult(success: false, message: 'Phone number already registered');
      }
      
      // Hash password
      final passwordHash = _hashPassword(password);
      
      // Create user in transaction
      final result = await _db.transaction(() async {
        // Insert user
        final userData = await _db.insert('users', {
          'email': email,
          'phone_number': phoneNumber,
          'password_hash': passwordHash,
          'role': role.name,
          'is_active': true,
          'email_verified': false,
          'phone_verified': false,
        });
        
        if (userData == null) {
          throw Exception('Failed to create user');
        }
        
        final userId = userData['id'];
        
        // Insert user profile
        await _db.insert('user_profiles', {
          'user_id': userId,
          'first_name': firstName,
          'last_name': lastName,
          'city': city,
          'region': region,
          'preferred_language': 'en',
        });
        
        // Initialize player ranking
        await _db.insert('player_rankings', {
          'user_id': userId,
          'lp': 0,
          'tier': UserTier.rookie.name,
          'win_rate': 0.0,
          'total_matches': 0,
          'total_wins': 0,
          'total_losses': 0,
        });
        
        return userId;
      });
      
      // Load the complete user data
      await _loadUserFromDatabase(result);
      
      // Save session
      await _saveSession(result);
      
      return AuthResult(success: true, message: 'Account created successfully', user: _currentUser);
      
    } catch (e) {
      return AuthResult(success: false, message: 'Registration failed: $e');
    }
  }
  
  /// Sign in existing user
  Future<AuthResult> signIn({
    required String email,
    required String password,
  }) async {
    try {
      // Find user by email
      final users = await _db.findWhere('users', {'email': email});
      
      if (users.isEmpty) {
        return AuthResult(success: false, message: 'Email not found');
      }
      
      final userData = users.first;
      
      // Verify password
      if (!_verifyPassword(password, userData['password_hash'])) {
        return AuthResult(success: false, message: 'Invalid password');
      }
      
      // Check if account is active
      if (userData['is_active'] != true) {
        return AuthResult(success: false, message: 'Account is deactivated');
      }
      
      // Load complete user data
      await _loadUserFromDatabase(userData['id']);
      
      // Save session
      await _saveSession(userData['id']);
      
      return AuthResult(success: true, message: 'Welcome back!', user: _currentUser);
      
    } catch (e) {
      return AuthResult(success: false, message: 'Sign in failed: $e');
    }
  }
  
  /// Sign out current user
  Future<void> signOut() async {
    _currentUser = null;
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('current_user_id');
  }
  
  /// Update user profile
  Future<AuthResult> updateProfile({
    String? firstName,
    String? lastName,
    String? phoneNumber,
    String? city,
    String? region,
    String? bio,
    String? profileImageUrl,
  }) async {
    if (_currentUser == null) {
      return AuthResult(success: false, message: 'Not authenticated');
    }
    
    try {
      await _db.transaction(() async {
        // Update user table if needed
        if (phoneNumber != null) {
          await _db.update('users', _currentUser!.id, {'phone_number': phoneNumber});
        }
        
        // Update user profile
        final profileUpdates = <String, dynamic>{};
        if (firstName != null) profileUpdates['first_name'] = firstName;
        if (lastName != null) profileUpdates['last_name'] = lastName;
        if (city != null) profileUpdates['city'] = city;
        if (region != null) profileUpdates['region'] = region;
        if (bio != null) profileUpdates['bio'] = bio;
        if (profileImageUrl != null) profileUpdates['profile_image_url'] = profileImageUrl;
        
        if (profileUpdates.isNotEmpty) {
          // Find the profile ID first
          final profiles = await _db.findWhere('user_profiles', {'user_id': _currentUser!.id});
          if (profiles.isNotEmpty) {
            await _db.update('user_profiles', profiles.first['id'], profileUpdates);
          }
        }
      });
      
      // Reload user data
      await _loadUserFromDatabase(_currentUser!.id);
      
      return AuthResult(success: true, message: 'Profile updated successfully', user: _currentUser);
      
    } catch (e) {
      return AuthResult(success: false, message: 'Profile update failed: $e');
    }
  }
  
  /// Change password
  Future<AuthResult> changePassword({
    required String currentPassword,
    required String newPassword,
  }) async {
    if (_currentUser == null) {
      return AuthResult(success: false, message: 'Not authenticated');
    }
    
    try {
      // Get current user data
      final userData = await _db.findById('users', _currentUser!.id);
      if (userData == null) {
        return AuthResult(success: false, message: 'User not found');
      }
      
      // Verify current password
      if (!_verifyPassword(currentPassword, userData['password_hash'])) {
        return AuthResult(success: false, message: 'Current password is incorrect');
      }
      
      // Hash new password
      final newPasswordHash = _hashPassword(newPassword);
      
      // Update password
      await _db.update('users', _currentUser!.id, {'password_hash': newPasswordHash});
      
      return AuthResult(success: true, message: 'Password changed successfully');
      
    } catch (e) {
      return AuthResult(success: false, message: 'Password change failed: $e');
    }
  }
  
  /// Get user ranking
  Future<PlayerRanking?> getUserRanking(String userId) async {
    try {
      final rankings = await _db.findWhere('player_rankings', {'user_id': userId});
      if (rankings.isNotEmpty) {
        return PlayerRanking.fromJson(rankings.first);
      }
      return null;
    } catch (e) {
      print('Failed to get user ranking: $e');
      return null;
    }
  }
  
  /// Update user ranking after match
  Future<void> updateUserRanking({
    required String userId,
    required bool won,
    required int lpChange,
    bool isOfficial = false,
  }) async {
    try {
      final ranking = await _db.findWhere('player_rankings', {'user_id': userId});
      if (ranking.isEmpty) return;
      
      final current = ranking.first;
      final newLp = (current['lp'] as int) + lpChange;
      final newTotalMatches = (current['total_matches'] as int) + 1;
      final newTotalWins = won ? (current['total_wins'] as int) + 1 : current['total_wins'];
      final newTotalLosses = !won ? (current['total_losses'] as int) + 1 : current['total_losses'];
      final newWinRate = (newTotalWins / newTotalMatches) * 100;
      
      // Determine new tier based on LP
      UserTier newTier = _calculateTierFromLP(newLp);
      
      final updates = {
        'lp': newLp,
        'tier': newTier.name,
        'total_matches': newTotalMatches,
        'total_wins': newTotalWins,
        'total_losses': newTotalLosses,
        'win_rate': newWinRate,
      };
      
      if (isOfficial && won) {
        updates['official_tournament_wins'] = (current['official_tournament_wins'] as int) + 1;
      }
      
      await _db.update('player_rankings', current['id'], updates);
      
    } catch (e) {
      print('Failed to update user ranking: $e');
    }
  }
  
  /// Load user from database
  Future<void> _loadUserFromDatabase(String userId) async {
    final userData = await _db.findById('users', userId);
    if (userData == null) throw Exception('User not found');

    final profileData = await _db.findWhere('user_profiles', {'user_id': userId});
    if (profileData.isEmpty) throw Exception('User profile not found');

    // Create a basic UserProfile with available data
    final profile = UserProfile(
      id: profileData.first['id'],
      firstName: profileData.first['first_name'] ?? '',
      lastName: profileData.first['last_name'] ?? '',
      city: profileData.first['city'],
      bio: profileData.first['bio'],
      profilePicture: profileData.first['profile_image_url'],
      dateOfBirth: profileData.first['date_of_birth'] != null
        ? DateTime.parse(profileData.first['date_of_birth'])
        : null,
      gender: Gender.values.firstWhere(
        (g) => g.name == (profileData.first['gender'] ?? 'male'),
        orElse: () => Gender.male,
      ),
      preferredHand: PreferredHand.values.firstWhere(
        (h) => h.name == (profileData.first['preferred_hand'] ?? 'right'),
        orElse: () => PreferredHand.right,
      ),
      preferredCourtPosition: CourtPosition.values.firstWhere(
        (p) => p.name == (profileData.first['preferred_position'] ?? 'right'),
        orElse: () => CourtPosition.right,
      ),
      location: UserLocation(
        state: profileData.first['region'] ?? 'Egypt',
        city: profileData.first['city'] ?? '',
        country: profileData.first['region'] ?? 'Egypt',
        coordinates: const Coordinates(latitude: 30.0444, longitude: 31.2357, lat: 30.0444, lng: 31.2357), // Default Cairo
      ),
      preferences: const UserPreferences(
        language: 'en',
        notifications: NotificationSettings(
          pushNotifications: true,
          emailNotifications: true,
          smsNotifications: false,
          matchInvitations: true,
          tournamentUpdates: true,
          marketplaceOffers: false,
          email: true,
          push: true,
          sms: false,
        ),
        privacy: PrivacySettings(
          profileVisibility: true,
          showStats: true,
          allowDirectMessages: true,
          showEmail: true,
          showPhone: false,
          showLocation: true,
        ),
      ),
    );

    _currentUser = User(
      id: userData['id'],
      username: userData['email']?.split('@').first ?? '',
      email: userData['email'],
      phoneNumber: userData['phone_number'] ?? '',
      role: UserRole.values.firstWhere((r) => r.name == userData['role']),
      profile: profile,
      isActive: userData['is_active'] ?? false,
      isBanned: false,
      createdAt: DateTime.parse(userData['created_at']),
      updatedAt: DateTime.parse(userData['updated_at'] ?? userData['created_at']),
      loginAttempts: 0,
      isVerified: userData['email_verified'] ?? false,
      emailVerified: userData['email_verified'] ?? false,
      phoneVerified: userData['phone_verified'] ?? false,
    );
  }
  
  /// Save user session
  Future<void> _saveSession(String userId) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('current_user_id', userId);
  }
  
  /// Hash password using SHA-256
  String _hashPassword(String password) {
    final bytes = utf8.encode(password + 'padelo_salt_2024'); // Add salt
    final digest = sha256.convert(bytes);
    return digest.toString();
  }
  
  /// Verify password
  bool _verifyPassword(String password, String hash) {
    return _hashPassword(password) == hash;
  }
  
  /// Calculate tier from LP
  UserTier _calculateTierFromLP(int lp) {
    if (lp < 100) return UserTier.rookie;
    if (lp < 300) return UserTier.beginner;
    if (lp < 600) return UserTier.intermediate;
    if (lp < 1000) return UserTier.advanced;
    if (lp < 1500) return UserTier.elite;
    if (lp < 2000) return UserTier.master;
    return UserTier.proPlayers;
  }
}

/// Authentication result class
class AuthResult {
  final bool success;
  final String message;
  final User? user;
  
  AuthResult({
    required this.success,
    required this.message,
    this.user,
  });
}
