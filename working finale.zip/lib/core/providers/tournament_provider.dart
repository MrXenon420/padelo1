import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../models/tournament_model.dart';
import '../models/user_model.dart';
import '../services/tournament_service.dart';
import '../utils/constants.dart';

// Tournament Service Provider
final tournamentServiceProvider = Provider<TournamentService>((ref) {
  return TournamentService();
});

// Tournament List Provider
final tournamentsProvider = StateNotifierProvider.family<TournamentsNotifier, AsyncValue<List<Tournament>>, TournamentFilters>(
  (ref, filters) {
    final service = ref.watch(tournamentServiceProvider);
    return TournamentsNotifier(service, filters);
  },
);

// Tournament Detail Provider
final tournamentProvider = FutureProvider.family<Tournament, String>((ref, tournamentId) async {
  final service = ref.watch(tournamentServiceProvider);
  return service.getTournament(tournamentId);
});

// Leaderboard Provider
final leaderboardProvider = StateNotifierProvider.family<LeaderboardNotifier, AsyncValue<List<LeaderboardEntry>>, LeaderboardFilters>(
  (ref, filters) {
    final service = ref.watch(tournamentServiceProvider);
    return LeaderboardNotifier(service, filters);
  },
);

// Player Ranking Provider
final playerRankingProvider = FutureProvider.family<PlayerRanking, String>((ref, playerId) async {
  final service = ref.watch(tournamentServiceProvider);
  return service.getPlayerRanking(playerId);
});

// LP Transactions Provider
final lpTransactionsProvider = StateNotifierProvider.family<LPTransactionsNotifier, AsyncValue<List<LPTransaction>>, String>(
  (ref, playerId) {
    final service = ref.watch(tournamentServiceProvider);
    return LPTransactionsNotifier(service, playerId);
  },
);

// User Tournaments Provider
final userTournamentsProvider = FutureProvider.family<List<Tournament>, String>((ref, userId) async {
  final service = ref.watch(tournamentServiceProvider);
  return service.getUserTournaments(userId);
});

// Tournament Matches Provider
final tournamentMatchesProvider = FutureProvider.family<List<TournamentMatch>, String>((ref, tournamentId) async {
  final service = ref.watch(tournamentServiceProvider);
  return service.getTournamentMatches(tournamentId);
});

// State Notifiers
class TournamentsNotifier extends StateNotifier<AsyncValue<List<Tournament>>> {
  final TournamentService _service;
  final TournamentFilters _filters;
  int _currentPage = 1;
  bool _hasMoreData = true;

  TournamentsNotifier(this._service, this._filters) : super(const AsyncValue.loading()) {
    loadTournaments();
  }

  Future<void> loadTournaments({bool refresh = false}) async {
    if (refresh) {
      _currentPage = 1;
      _hasMoreData = true;
      state = const AsyncValue.loading();
    }

    if (!_hasMoreData && !refresh) return;

    try {
      final tournaments = await _service.getTournaments(
        status: _filters.status,
        type: _filters.type,
        region: _filters.region,
        page: _currentPage,
        limit: 20,
      );

      if (refresh) {
        state = AsyncValue.data(tournaments);
      } else {
        final currentTournaments = state.value ?? [];
        state = AsyncValue.data([...currentTournaments, ...tournaments]);
      }

      _hasMoreData = tournaments.length == 20;
      _currentPage++;
    } catch (error, stackTrace) {
      state = AsyncValue.error(error, stackTrace);
    }
  }

  Future<void> joinTournament(String tournamentId) async {
    try {
      await _service.joinTournament(tournamentId);
      // Refresh the tournaments list
      await loadTournaments(refresh: true);
    } catch (error) {
      rethrow;
    }
  }

  Future<void> leaveTournament(String tournamentId) async {
    try {
      await _service.leaveTournament(tournamentId);
      // Refresh the tournaments list
      await loadTournaments(refresh: true);
    } catch (error) {
      rethrow;
    }
  }

  Future<Tournament> createTournament(Map<String, dynamic> tournamentData) async {
    try {
      final tournament = await _service.createTournament(tournamentData);
      // Refresh the tournaments list
      await loadTournaments(refresh: true);
      return tournament;
    } catch (error) {
      rethrow;
    }
  }
}

class LeaderboardNotifier extends StateNotifier<AsyncValue<List<LeaderboardEntry>>> {
  final TournamentService _service;
  final LeaderboardFilters _filters;
  int _currentPage = 1;
  bool _hasMoreData = true;

  LeaderboardNotifier(this._service, this._filters) : super(const AsyncValue.loading()) {
    loadLeaderboard();
  }

  Future<void> loadLeaderboard({bool refresh = false}) async {
    if (refresh) {
      _currentPage = 1;
      _hasMoreData = true;
      state = const AsyncValue.loading();
    }

    if (!_hasMoreData && !refresh) return;

    try {
      final leaderboard = await _service.getLeaderboard(
        region: _filters.region,
        gender: _filters.gender,
        ageGroup: _filters.ageGroup,
        page: _currentPage,
        limit: 50,
      );

      if (refresh) {
        state = AsyncValue.data(leaderboard);
      } else {
        final currentLeaderboard = state.value ?? [];
        state = AsyncValue.data([...currentLeaderboard, ...leaderboard]);
      }

      _hasMoreData = leaderboard.length == 50;
      _currentPage++;
    } catch (error, stackTrace) {
      state = AsyncValue.error(error, stackTrace);
    }
  }
}

class LPTransactionsNotifier extends StateNotifier<AsyncValue<List<LPTransaction>>> {
  final TournamentService _service;
  final String _playerId;
  int _currentPage = 1;
  bool _hasMoreData = true;

  LPTransactionsNotifier(this._service, this._playerId) : super(const AsyncValue.loading()) {
    loadTransactions();
  }

  Future<void> loadTransactions({bool refresh = false}) async {
    if (refresh) {
      _currentPage = 1;
      _hasMoreData = true;
      state = const AsyncValue.loading();
    }

    if (!_hasMoreData && !refresh) return;

    try {
      final transactions = await _service.getPlayerLPTransactions(
        _playerId,
        page: _currentPage,
        limit: 20,
      );

      if (refresh) {
        state = AsyncValue.data(transactions);
      } else {
        final currentTransactions = state.value ?? [];
        state = AsyncValue.data([...currentTransactions, ...transactions]);
      }

      _hasMoreData = transactions.length == 20;
      _currentPage++;
    } catch (error, stackTrace) {
      state = AsyncValue.error(error, stackTrace);
    }
  }
}

// Filter Classes
class TournamentFilters {
  final TournamentStatus? status;
  final TournamentType? type;
  final String? region;

  const TournamentFilters({
    this.status,
    this.type,
    this.region,
  });

  TournamentFilters copyWith({
    TournamentStatus? status,
    TournamentType? type,
    String? region,
  }) {
    return TournamentFilters(
      status: status ?? this.status,
      type: type ?? this.type,
      region: region ?? this.region,
    );
  }
}

class LeaderboardFilters {
  final String? region;
  final Gender? gender;
  final String? ageGroup;

  const LeaderboardFilters({
    this.region,
    this.gender,
    this.ageGroup,
  });

  LeaderboardFilters copyWith({
    String? region,
    Gender? gender,
    String? ageGroup,
  }) {
    return LeaderboardFilters(
      region: region ?? this.region,
      gender: gender ?? this.gender,
      ageGroup: ageGroup ?? this.ageGroup,
    );
  }
}

// Convenience Providers
final upcomingTournamentsProvider = Provider<AsyncValue<List<Tournament>>>((ref) {
  const filters = TournamentFilters(status: TournamentStatus.upcoming);
  return ref.watch(tournamentsProvider(filters));
});

final ongoingTournamentsProvider = Provider<AsyncValue<List<Tournament>>>((ref) {
  const filters = TournamentFilters(status: TournamentStatus.ongoing);
  return ref.watch(tournamentsProvider(filters));
});

final officialTournamentsProvider = Provider<AsyncValue<List<Tournament>>>((ref) {
  const filters = TournamentFilters(type: TournamentType.official);
  return ref.watch(tournamentsProvider(filters));
});

final globalLeaderboardProvider = Provider<AsyncValue<List<LeaderboardEntry>>>((ref) {
  const filters = LeaderboardFilters();
  return ref.watch(leaderboardProvider(filters));
});
