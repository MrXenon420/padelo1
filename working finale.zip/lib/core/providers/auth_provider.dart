import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:dio/dio.dart';

import '../models/user_model.dart';
import '../services/auth_service.dart';
import '../services/storage_service.dart';
import '../utils/constants.dart';

class AuthNotifier extends StateNotifier<AsyncValue<User?>> {
  final AuthService _authService;

  AuthNotifier(this._authService) : super(const AsyncValue.loading()) {
    _initAuth();
  }

  Future<void> _initAuth() async {
    try {
      // Check if user is already logged in
      final token = StorageService.getString(AppConstants.tokenKey);
      final userData = StorageService.getUserData(AppConstants.userKey);

      if (token != null && userData != null) {
        // Validate token with server
        final isValid = await _authService.validateToken(token);
        if (isValid) {
          final user = User.fromJson(userData);
          state = AsyncValue.data(user);
        } else {
          // Invalid token, clear storage
          await _clearAuthData();
          state = const AsyncValue.data(null);
        }
      } else {
        state = const AsyncValue.data(null);
      }
    } catch (error, stackTrace) {
      state = AsyncValue.error(error, stackTrace);
    }
  }

  Future<void> login({
    required String phoneOrEmail,
    required String password,
  }) async {
    state = const AsyncValue.loading();
    
    try {
      final response = await _authService.login(
        phoneOrEmail: phoneOrEmail,
        password: password,
      );

      // Store auth data
      await StorageService.setString(AppConstants.tokenKey, response.token);
      await StorageService.setString(AppConstants.refreshTokenKey, response.refreshToken);
      await StorageService.saveUserData(AppConstants.userKey, response.user.toJson());

      state = AsyncValue.data(response.user);
    } catch (error, stackTrace) {
      state = AsyncValue.error(error, stackTrace);
    }
  }

  Future<void> signUp({
    required String email,
    required String password,
    required String name,
    required bool agreeTerms,
  }) async {
    final nameParts = name.split(' ');
    final firstName = nameParts.first;
    final lastName = nameParts.length > 1 ? nameParts.sublist(1).join(' ') : '';

    await register(
      phoneNumber: '',
      email: email,
      password: password,
      confirmPassword: password,
      username: email.split('@').first,
      firstName: firstName,
      lastName: lastName,
      preferredHand: PreferredHand.right,
      preferredCourtPosition: CourtPosition.left,
      gender: Gender.other,
      city: '',
      country: '',
      language: 'en',
      agreeTerms: agreeTerms,
      agreePrivacy: agreeTerms,
    );
  }

  Future<void> register({
    required String phoneNumber,
    String? email,
    required String password,
    required String confirmPassword,
    required String username,
    required String firstName,
    required String lastName,
    required PreferredHand preferredHand,
    required CourtPosition preferredCourtPosition,
    required Gender gender,
    required String city,
    required String country,
    required String language,
    required bool agreeTerms,
    required bool agreePrivacy,
  }) async {
    state = const AsyncValue.loading();
    
    try {
      final response = await _authService.register(
        phoneNumber: phoneNumber,
        email: email,
        password: password,
        confirmPassword: confirmPassword,
        username: username,
        firstName: firstName,
        lastName: lastName,
        preferredHand: preferredHand,
        preferredCourtPosition: preferredCourtPosition,
        gender: gender,
        city: city,
        country: country,
        language: language,
        agreeTerms: agreeTerms,
        agreePrivacy: agreePrivacy,
      );

      // Store auth data
      await StorageService.setString(AppConstants.tokenKey, response.token);
      await StorageService.setString(AppConstants.refreshTokenKey, response.refreshToken);
      await StorageService.saveUserData(AppConstants.userKey, response.user.toJson());

      state = AsyncValue.data(response.user);
    } catch (error, stackTrace) {
      state = AsyncValue.error(error, stackTrace);
    }
  }

  Future<void> logout() async {
    try {
      // Call logout endpoint
      await _authService.logout();
    } catch (e) {
      // Continue with logout even if API call fails
    } finally {
      // Clear local data
      await _clearAuthData();
      state = const AsyncValue.data(null);
    }
  }

  Future<void> updateProfile(Map<String, dynamic> profileData) async {
    final currentUser = state.value;
    if (currentUser == null) return;

    try {
      final updatedUser = await _authService.updateProfile(profileData);
      await StorageService.saveUserData(AppConstants.userKey, updatedUser.toJson());
      state = AsyncValue.data(updatedUser);
    } catch (error, stackTrace) {
      state = AsyncValue.error(error, stackTrace);
    }
  }

  Future<void> changePassword({
    required String currentPassword,
    required String newPassword,
    required String confirmPassword,
  }) async {
    try {
      await _authService.changePassword(
        currentPassword: currentPassword,
        newPassword: newPassword,
        confirmPassword: confirmPassword,
      );
    } catch (error) {
      rethrow;
    }
  }

  Future<void> requestPasswordReset(String phoneOrEmail) async {
    try {
      await _authService.requestPasswordReset(phoneOrEmail);
    } catch (error) {
      rethrow;
    }
  }

  Future<void> resetPassword({
    required String token,
    required String newPassword,
    required String confirmPassword,
  }) async {
    try {
      await _authService.resetPassword(
        token: token,
        newPassword: newPassword,
        confirmPassword: confirmPassword,
      );
    } catch (error) {
      rethrow;
    }
  }

  Future<void> _clearAuthData() async {
    await Future.wait([
      StorageService.remove(AppConstants.tokenKey),
      StorageService.remove(AppConstants.refreshTokenKey),
      StorageService.removeUserData(AppConstants.userKey),
    ]);
  }

  User? get currentUser => state.value;
  bool get isAuthenticated => state.value != null;
  bool get isLoading => state.isLoading;
  
  UserRole? get userRole => currentUser?.role;
  
  bool hasPermission(String permission) {
    final user = currentUser;
    if (user == null) return false;
    
    // Check permissions based on user role
    switch (user.role) {
      case UserRole.owner:
        return true; // Owner has all permissions
      case UserRole.courtOwner:
        return [
          'canCreateTournaments',
          'canManageCourts',
          'canPostTraining',
          'canSellMarketplace',
        ].contains(permission);
      case UserRole.tournamentOrganizer:
        return [
          'canCreateTournaments',
          'canPostTraining',
          'canSellMarketplace',
        ].contains(permission);
      case UserRole.coach:
        return [
          'canPostTraining',
          'canSellMarketplace',
        ].contains(permission);
      case UserRole.player:
        return [
          'canSellMarketplace',
        ].contains(permission);
    }
  }
}

final authServiceProvider = Provider<AuthService>((ref) {
  return AuthService();
});

final authProvider = StateNotifierProvider<AuthNotifier, AsyncValue<User?>>((ref) {
  final authService = ref.watch(authServiceProvider);
  return AuthNotifier(authService);
});

// Convenience providers
final currentUserProvider = Provider<User?>((ref) {
  return ref.watch(authProvider).value;
});

final isAuthenticatedProvider = Provider<bool>((ref) {
  return ref.watch(authProvider).value != null;
});

final userRoleProvider = Provider<UserRole?>((ref) {
  return ref.watch(authProvider).value?.role;
});
