import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../services/real_auth_service.dart';
import '../services/real_tournament_service.dart';
import '../services/database_service.dart';
import '../models/user_model.dart';
import '../models/tournament_model.dart';
import '../utils/constants.dart';

/// Database service provider
final databaseServiceProvider = Provider<DatabaseService>((ref) {
  return DatabaseService.instance;
});

/// Auth service provider
final authServiceProvider = Provider<RealAuthService>((ref) {
  return RealAuthService.instance;
});

/// Tournament service provider
final tournamentServiceProvider = Provider<RealTournamentService>((ref) {
  return RealTournamentService.instance;
});

/// Current user provider
final currentUserProvider = StateProvider<User?>((ref) {
  final authService = ref.watch(authServiceProvider);
  return authService.currentUser;
});

/// Authentication state provider
final authStateProvider = StateProvider<bool>((ref) {
  final authService = ref.watch(authServiceProvider);
  return authService.isAuthenticated;
});

/// User ranking provider
final userRankingProvider = FutureProvider<PlayerRanking?>((ref) async {
  final authService = ref.watch(authServiceProvider);
  final currentUser = authService.currentUser;

  if (currentUser == null) return null;

  return await authService.getUserRanking(currentUser.id);
});

/// Available courts provider
final availableCourtsProvider = FutureProvider.family<List<Map<String, dynamic>>, String>((ref, city) async {
  final db = ref.watch(databaseServiceProvider);
  return await db.getAvailableCourts(
    city: city,
    date: DateTime.now(),
  );
});

/// Loading state provider for various operations
final loadingStateProvider = StateProvider<Map<String, bool>>((ref) {
  return {};
});

/// Set loading state for a specific operation
void setLoading(WidgetRef ref, String operation, bool isLoading) {
  final currentState = ref.read(loadingStateProvider);
  ref.read(loadingStateProvider.notifier).state = {
    ...currentState,
    operation: isLoading,
  };
}

/// Check if operation is loading
bool isLoading(WidgetRef ref, String operation) {
  final loadingState = ref.watch(loadingStateProvider);
  return loadingState[operation] ?? false;
}

/// Show success message
final successMessageProvider = StateProvider<String?>((ref) => null);

/// Show error message
final errorMessageProvider = StateProvider<String?>((ref) => null);

/// Show message (success or error)
void showMessage(WidgetRef ref, String message, {bool isError = false}) {
  if (isError) {
    ref.read(errorMessageProvider.notifier).state = message;
    ref.read(successMessageProvider.notifier).state = null;
  } else {
    ref.read(successMessageProvider.notifier).state = message;
    ref.read(errorMessageProvider.notifier).state = null;
  }
  
  // Clear message after 3 seconds
  Future.delayed(const Duration(seconds: 3), () {
    ref.read(successMessageProvider.notifier).state = null;
    ref.read(errorMessageProvider.notifier).state = null;
  });
}

/// User tournaments provider
final userTournamentsProvider = FutureProvider<List<Tournament>>((ref) async {
  final tournamentService = ref.watch(tournamentServiceProvider);
  final authService = ref.watch(authServiceProvider);
  final currentUser = authService.currentUser;

  if (currentUser == null) return [];

  return await tournamentService.getUserTournaments();
});

/// All tournaments provider
final allTournamentsProvider = FutureProvider<List<Tournament>>((ref) async {
  final tournamentService = ref.watch(tournamentServiceProvider);
  return await tournamentService.getAllTournaments();
});

/// Search users provider
final searchUsersProvider = FutureProvider.family<List<Map<String, dynamic>>, String>((ref, searchTerm) async {
  final db = ref.watch(databaseServiceProvider);
  if (searchTerm.isEmpty) return [];
  return await db.searchUsers(searchTerm);
});

/// User rankings leaderboard provider
final userRankingsProvider = FutureProvider.family<List<Map<String, dynamic>>, Map<String, String?>>((ref, filters) async {
  final db = ref.watch(databaseServiceProvider);
  return await db.getUserRankings(
    city: filters['city'],
    region: filters['region'],
    tier: filters['tier'] != null ? UserTier.values.firstWhere((t) => t.name == filters['tier']) : null,
  );
});

/// Update user data after changes
void refreshUserData(WidgetRef ref) {
  ref.invalidate(currentUserProvider);
  ref.invalidate(userRankingProvider);
  ref.invalidate(userTournamentsProvider);
}

/// Update tournament data after changes
void refreshTournamentData(WidgetRef ref) {
  // Tournament refresh functionality will be added later
}

/// Court booking provider
final courtBookingProvider = StateProvider<Map<String, dynamic>?>((ref) => null);

/// Reset all providers (for logout)
void resetAllProviders(WidgetRef ref) {
  ref.invalidate(currentUserProvider);
  ref.invalidate(authStateProvider);
  ref.invalidate(userRankingProvider);
  ref.invalidate(userTournamentsProvider);
  ref.invalidate(allTournamentsProvider);
  ref.invalidate(courtBookingProvider);
  ref.read(loadingStateProvider.notifier).state = {};
  ref.read(successMessageProvider.notifier).state = null;
  ref.read(errorMessageProvider.notifier).state = null;
}
