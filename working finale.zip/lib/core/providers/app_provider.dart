import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../services/storage_service.dart';
import '../services/notification_service.dart';
import '../utils/constants.dart';

class AppNotifier extends StateNotifier<AsyncValue<bool>> {
  AppNotifier() : super(const AsyncValue.loading()) {
    _initialize();
  }

  Future<void> _initialize() async {
    try {
      // Initialize core services
      await _initializeServices();
      
      // Check if app is properly initialized
      final isInitialized = await _checkInitialization();
      
      state = AsyncValue.data(isInitialized);
    } catch (error, stackTrace) {
      state = AsyncValue.error(error, stackTrace);
    }
  }

  Future<void> _initializeServices() async {
    // Initialize storage service
    await StorageService.init();
    
    // Initialize notification service
    await NotificationService.initialize();
    
    // Any other service initialization
  }

  Future<bool> _checkInitialization() async {
    try {
      final prefs = await SharedPreferences.getInstance();

      // For now, always return true to skip the initialization check
      // This will allow the app to load properly
      await prefs.setBool('app_initialized', true);
      return true;
    } catch (e) {
      // If SharedPreferences fails, still allow the app to continue
      return true;
    }
  }

  Future<void> completeInitialization() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('initialization_completed', true);
    state = const AsyncValue.data(true);
  }
}

final appProvider = StateNotifierProvider<AppNotifier, AsyncValue<bool>>(
  (ref) => AppNotifier(),
);
