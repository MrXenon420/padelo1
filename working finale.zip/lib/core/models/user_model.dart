import 'package:json_annotation/json_annotation.dart';

import '../utils/constants.dart';

part 'user_model.g.dart';

@JsonSerializable()
class User {
  final String id;
  final String username;
  final String? email;
  final String phoneNumber;
  final UserRole role;
  final UserProfile profile;
  final bool isActive;
  final bool isBanned;
  final String? banReason;
  final DateTime? banExpiryDate;
  final DateTime createdAt;
  final DateTime updatedAt;
  final DateTime? lastLoginAt;
  final int loginAttempts;
  final bool isVerified;
  final bool emailVerified;
  final bool phoneVerified;
  final DateTime? termsAcceptedAt;
  final DateTime? privacyAcceptedAt;
  final String? termsVersion;
  final String? privacyVersion;

  const User({
    required this.id,
    required this.username,
    this.email,
    required this.phoneNumber,
    required this.role,
    required this.profile,
    required this.isActive,
    required this.isBanned,
    this.banReason,
    this.banExpiryDate,
    required this.createdAt,
    required this.updatedAt,
    this.lastLoginAt,
    required this.loginAttempts,
    required this.isVerified,
    required this.emailVerified,
    required this.phoneVerified,
    this.termsAcceptedAt,
    this.privacyAcceptedAt,
    this.termsVersion,
    this.privacyVersion,
  });

  factory User.fromJson(Map<String, dynamic> json) => _$UserFromJson(json);
  Map<String, dynamic> toJson() => _$UserToJson(this);

  User copyWith({
    String? id,
    String? username,
    String? email,
    String? phoneNumber,
    UserRole? role,
    UserProfile? profile,
    bool? isActive,
    bool? isBanned,
    String? banReason,
    DateTime? banExpiryDate,
    DateTime? createdAt,
    DateTime? updatedAt,
    DateTime? lastLoginAt,
    int? loginAttempts,
    bool? isVerified,
    bool? emailVerified,
    bool? phoneVerified,
    DateTime? termsAcceptedAt,
    DateTime? privacyAcceptedAt,
    String? termsVersion,
    String? privacyVersion,
  }) {
    return User(
      id: id ?? this.id,
      username: username ?? this.username,
      email: email ?? this.email,
      phoneNumber: phoneNumber ?? this.phoneNumber,
      role: role ?? this.role,
      profile: profile ?? this.profile,
      isActive: isActive ?? this.isActive,
      isBanned: isBanned ?? this.isBanned,
      banReason: banReason ?? this.banReason,
      banExpiryDate: banExpiryDate ?? this.banExpiryDate,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      lastLoginAt: lastLoginAt ?? this.lastLoginAt,
      loginAttempts: loginAttempts ?? this.loginAttempts,
      isVerified: isVerified ?? this.isVerified,
      emailVerified: emailVerified ?? this.emailVerified,
      phoneVerified: phoneVerified ?? this.phoneVerified,
      termsAcceptedAt: termsAcceptedAt ?? this.termsAcceptedAt,
      privacyAcceptedAt: privacyAcceptedAt ?? this.privacyAcceptedAt,
      termsVersion: termsVersion ?? this.termsVersion,
      privacyVersion: privacyVersion ?? this.privacyVersion,
    );
  }

  String get displayName => '${profile.firstName} ${profile.lastName}';
  String get initials => '${profile.firstName[0]}${profile.lastName[0]}';
}

@JsonSerializable()
class UserProfile {
  final String? id;
  final String firstName;
  final String lastName;
  final DateTime? dateOfBirth;
  final Gender gender;
  final PreferredHand preferredHand;
  final CourtPosition preferredCourtPosition;
  final String? profilePicture;
  final String? bio;
  final String? city;
  final UserLocation location;
  final SocialMedia? socialMedia;
  final UserPreferences preferences;

  const UserProfile({
    this.id,
    required this.firstName,
    required this.lastName,
    this.dateOfBirth,
    required this.gender,
    required this.preferredHand,
    required this.preferredCourtPosition,
    this.profilePicture,
    this.bio,
    this.city,
    required this.location,
    this.socialMedia,
    required this.preferences,
  });

  String get fullName => '$firstName $lastName';

  factory UserProfile.fromJson(Map<String, dynamic> json) => _$UserProfileFromJson(json);
  Map<String, dynamic> toJson() => _$UserProfileToJson(this);

  UserProfile copyWith({
    String? firstName,
    String? lastName,
    DateTime? dateOfBirth,
    Gender? gender,
    PreferredHand? preferredHand,
    CourtPosition? preferredCourtPosition,
    String? profilePicture,
    String? bio,
    UserLocation? location,
    SocialMedia? socialMedia,
    UserPreferences? preferences,
  }) {
    return UserProfile(
      firstName: firstName ?? this.firstName,
      lastName: lastName ?? this.lastName,
      dateOfBirth: dateOfBirth ?? this.dateOfBirth,
      gender: gender ?? this.gender,
      preferredHand: preferredHand ?? this.preferredHand,
      preferredCourtPosition: preferredCourtPosition ?? this.preferredCourtPosition,
      profilePicture: profilePicture ?? this.profilePicture,
      bio: bio ?? this.bio,
      location: location ?? this.location,
      socialMedia: socialMedia ?? this.socialMedia,
      preferences: preferences ?? this.preferences,
    );
  }
}

@JsonSerializable()
class UserLocation {
  final String state;
  final String city;
  final String country;
  final Coordinates? coordinates;

  const UserLocation({
    required this.state,
    required this.city,
    required this.country,
    this.coordinates,
  });

  factory UserLocation.fromJson(Map<String, dynamic> json) => _$UserLocationFromJson(json);
  Map<String, dynamic> toJson() => _$UserLocationToJson(this);
}

@JsonSerializable()
class Coordinates {
  final double latitude;
  final double longitude;
  final double lat;
  final double lng;

  const Coordinates({
    required this.latitude,
    required this.longitude,
    required this.lat,
    required this.lng,
  });

  factory Coordinates.fromJson(Map<String, dynamic> json) => _$CoordinatesFromJson(json);
  Map<String, dynamic> toJson() => _$CoordinatesToJson(this);
}

@JsonSerializable()
class SocialMedia {
  final String? instagramUsername;
  final String? facebookUsername;
  final String? twitterUsername;
  final String? instagram;
  final String? facebook;
  final String? twitter;

  const SocialMedia({
    this.instagramUsername,
    this.facebookUsername,
    this.twitterUsername,
    this.instagram,
    this.facebook,
    this.twitter,
  });

  factory SocialMedia.fromJson(Map<String, dynamic> json) => _$SocialMediaFromJson(json);
  Map<String, dynamic> toJson() => _$SocialMediaToJson(this);
}

@JsonSerializable()
class UserPreferences {
  final String language;
  final NotificationSettings notifications;
  final PrivacySettings privacy;

  const UserPreferences({
    required this.language,
    required this.notifications,
    required this.privacy,
  });

  factory UserPreferences.fromJson(Map<String, dynamic> json) => _$UserPreferencesFromJson(json);
  Map<String, dynamic> toJson() => _$UserPreferencesToJson(this);
}

@JsonSerializable()
class NotificationSettings {
  final bool pushNotifications;
  final bool emailNotifications;
  final bool smsNotifications;
  final bool matchInvitations;
  final bool tournamentUpdates;
  final bool marketplaceOffers;
  final bool email;
  final bool push;
  final bool sms;

  const NotificationSettings({
    required this.pushNotifications,
    required this.emailNotifications,
    required this.smsNotifications,
    required this.matchInvitations,
    required this.tournamentUpdates,
    required this.marketplaceOffers,
    required this.email,
    required this.push,
    required this.sms,
  });

  factory NotificationSettings.fromJson(Map<String, dynamic> json) => _$NotificationSettingsFromJson(json);
  Map<String, dynamic> toJson() => _$NotificationSettingsToJson(this);
}

@JsonSerializable()
class PrivacySettings {
  final bool profileVisibility;
  final bool showStats;
  final bool allowDirectMessages;
  final bool showEmail;
  final bool showPhone;
  final bool showLocation;

  const PrivacySettings({
    required this.profileVisibility,
    required this.showStats,
    required this.allowDirectMessages,
    required this.showEmail,
    required this.showPhone,
    required this.showLocation,
  });

  factory PrivacySettings.fromJson(Map<String, dynamic> json) => _$PrivacySettingsFromJson(json);
  Map<String, dynamic> toJson() => _$PrivacySettingsToJson(this);
}

@JsonSerializable()
class AuthResponse {
  final bool success;
  final String message;
  final User user;
  final String token;
  final String refreshToken;

  const AuthResponse({
    required this.success,
    required this.message,
    required this.user,
    required this.token,
    required this.refreshToken,
  });

  factory AuthResponse.fromJson(Map<String, dynamic> json) => _$AuthResponseFromJson(json);
  Map<String, dynamic> toJson() => _$AuthResponseToJson(this);
}

@JsonSerializable()
class UserStats {
  final int totalMatches;
  final int totalWins;
  final int totalLosses;
  final double winPercentage;
  final double averageRating;
  final double currentRating;
  final double bestRating;
  final int currentStreak;
  final int bestStreak;
  final int totalTournaments;
  final DateTime? lastMatchDate;
  final int totalFollowers;
  final int totalFollowing;
  final int matchesPlayed;
  final int tournamentsJoined;
  final int tournamentsWon;
  final double winRate;
  final int currentRank;
  final int currentLP;
  final UserTier currentTier;
  final int currentDivision;
  final List<String> achievements;
  final DateTime joinDate;

  const UserStats({
    required this.totalMatches,
    required this.totalWins,
    required this.totalLosses,
    required this.winPercentage,
    required this.averageRating,
    required this.currentRating,
    required this.bestRating,
    required this.currentStreak,
    required this.bestStreak,
    required this.totalTournaments,
    this.lastMatchDate,
    required this.totalFollowers,
    required this.totalFollowing,
    required this.matchesPlayed,
    required this.tournamentsJoined,
    required this.tournamentsWon,
    required this.winRate,
    required this.currentRank,
    required this.currentLP,
    required this.currentTier,
    required this.currentDivision,
    required this.achievements,
    required this.joinDate,
  });

  factory UserStats.fromJson(Map<String, dynamic> json) => _$UserStatsFromJson(json);
  Map<String, dynamic> toJson() => _$UserStatsToJson(this);
}
