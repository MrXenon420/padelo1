// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'tournament_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Tournament _$TournamentFromJson(Map<String, dynamic> json) => Tournament(
      id: json['id'] as String,
      name: json['name'] as String,
      description: json['description'] as String,
      location: json['location'] as String,
      startDate: DateTime.parse(json['start_date'] as String),
      endDate: DateTime.parse(json['end_date'] as String),
      entryFee: (json['entry_fee'] as num).toDouble(),
      maxParticipants: json['max_participants'] as int,
      currentParticipants: json['current_participants'] as int,
      type: TournamentType.values.byName(json['type'] as String),
      bracketSize: json['bracket_size'] as int,
      status: TournamentStatus.values.byName(json['status'] as String),
      organizerId: json['organizer_id'] as String,
      organizerRole: UserRole.values.byName(json['organizer_role'] as String),
      prizes: TournamentPrizes.fromJson(json['prizes'] as Map<String, dynamic>),
      image: json['image'] as String?,
      rules: json['rules'] as String,
      createdAt: DateTime.parse(json['created_at'] as String),
      updatedAt: DateTime.parse(json['updated_at'] as String),
      isApproved: json['is_approved'] as bool,
      minTier: UserTier.values.byName(json['min_tier'] as String),
      maxTier: UserTier.values.byName(json['max_tier'] as String),
      registrationDeadline: DateTime.parse(json['registration_deadline'] as String),
      isFeatured: json['is_featured'] as bool,
      allowSpectators: json['allow_spectators'] as bool,
      isPublic: json['is_public'] as bool,
    );

Map<String, dynamic> _$TournamentToJson(Tournament instance) => <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
      'description': instance.description,
      'location': instance.location,
      'start_date': instance.startDate.toIso8601String(),
      'end_date': instance.endDate.toIso8601String(),
      'entry_fee': instance.entryFee,
      'max_participants': instance.maxParticipants,
      'current_participants': instance.currentParticipants,
      'type': instance.type.name,
      'bracket_size': instance.bracketSize,
      'status': instance.status.name,
      'organizer_id': instance.organizerId,
      'organizer_role': instance.organizerRole.name,
      'prizes': instance.prizes.toJson(),
      'image': instance.image,
      'rules': instance.rules,
      'created_at': instance.createdAt.toIso8601String(),
      'updated_at': instance.updatedAt.toIso8601String(),
      'is_approved': instance.isApproved,
      'min_tier': instance.minTier.name,
      'max_tier': instance.maxTier.name,
      'registration_deadline': instance.registrationDeadline.toIso8601String(),
      'is_featured': instance.isFeatured,
      'allow_spectators': instance.allowSpectators,
      'is_public': instance.isPublic,
    };

TournamentPrizes _$TournamentPrizesFromJson(Map<String, dynamic> json) => TournamentPrizes(
      totalPrizePool: (json['total_prize_pool'] as num).toDouble(),
      firstPlace: (json['first_place'] as num).toDouble(),
      secondPlace: (json['second_place'] as num).toDouble(),
      thirdPlace: (json['third_place'] as num).toDouble(),
      currency: json['currency'] as String,
    );

Map<String, dynamic> _$TournamentPrizesToJson(TournamentPrizes instance) => <String, dynamic>{
      'total_prize_pool': instance.totalPrizePool,
      'first_place': instance.firstPlace,
      'second_place': instance.secondPlace,
      'third_place': instance.thirdPlace,
      'currency': instance.currency,
    };

TournamentMatch _$TournamentMatchFromJson(Map<String, dynamic> json) => TournamentMatch(
      id: json['id'] as String,
      tournamentId: json['tournament_id'] as String,
      matchNumber: json['match_number'] as int,
      round: TournamentRound.values.byName(json['round'] as String),
      team1: MatchTeam.fromJson(json['team1'] as Map<String, dynamic>),
      team2: MatchTeam.fromJson(json['team2'] as Map<String, dynamic>),
      winner: json['winner'] == null
          ? null
          : MatchTeam.fromJson(json['winner'] as Map<String, dynamic>),
      score: json['score'] == null
          ? null
          : MatchScore.fromJson(json['score'] as Map<String, dynamic>),
      lpAwarded: json['lp_awarded'] as int?,
      qrCode: json['qr_code'] as String,
      refereeCode: json['referee_code'] as String?,
      startTime: DateTime.parse(json['start_time'] as String),
      scheduledTime: json['scheduled_time'] == null
          ? null
          : DateTime.parse(json['scheduled_time'] as String),
      actualStartTime: json['actual_start_time'] == null
          ? null
          : DateTime.parse(json['actual_start_time'] as String),
      actualEndTime: json['actual_end_time'] == null
          ? null
          : DateTime.parse(json['actual_end_time'] as String),
      endTime: json['end_time'] == null
          ? null
          : DateTime.parse(json['end_time'] as String),
      courtId: json['court_id'] as String,
      status: MatchStatus.values.byName(json['status'] as String),
    );

Map<String, dynamic> _$TournamentMatchToJson(TournamentMatch instance) => <String, dynamic>{
      'id': instance.id,
      'tournament_id': instance.tournamentId,
      'match_number': instance.matchNumber,
      'round': instance.round.name,
      'team1': instance.team1.toJson(),
      'team2': instance.team2.toJson(),
      'winner': instance.winner?.toJson(),
      'score': instance.score?.toJson(),
      'lp_awarded': instance.lpAwarded,
      'qr_code': instance.qrCode,
      'referee_code': instance.refereeCode,
      'start_time': instance.startTime.toIso8601String(),
      'scheduled_time': instance.scheduledTime?.toIso8601String(),
      'actual_start_time': instance.actualStartTime?.toIso8601String(),
      'actual_end_time': instance.actualEndTime?.toIso8601String(),
      'end_time': instance.endTime?.toIso8601String(),
      'court_id': instance.courtId,
      'status': instance.status.name,
    };

MatchTeam _$MatchTeamFromJson(Map<String, dynamic> json) => MatchTeam(
      player1Id: json['player1_id'] as String,
      player2Id: json['player2_id'] as String,
      player1: json['player1'] as String,
      player2: json['player2'] as String,
    );

Map<String, dynamic> _$MatchTeamToJson(MatchTeam instance) => <String, dynamic>{
      'player1_id': instance.player1Id,
      'player2_id': instance.player2Id,
      'player1': instance.player1,
      'player2': instance.player2,
    };

MatchScore _$MatchScoreFromJson(Map<String, dynamic> json) => MatchScore(
      winnerId: json['winner_id'] as String?,
      totalGamesTeam1: json['total_games_team1'] as int,
      totalGamesTeam2: json['total_games_team2'] as int,
      team1Sets: json['team1_sets'] as int,
      team2Sets: json['team2_sets'] as int,
      sets: (json['sets'] as List<dynamic>)
          .map((e) => SetScore.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$MatchScoreToJson(MatchScore instance) => <String, dynamic>{
      'winner_id': instance.winnerId,
      'total_games_team1': instance.totalGamesTeam1,
      'total_games_team2': instance.totalGamesTeam2,
      'team1_sets': instance.team1Sets,
      'team2_sets': instance.team2Sets,
      'sets': instance.sets.map((e) => e.toJson()).toList(),
    };

SetScore _$SetScoreFromJson(Map<String, dynamic> json) => SetScore(
      setNumber: json['set_number'] as int,
      team1Games: json['team1_games'] as int,
      team2Games: json['team2_games'] as int,
    );

Map<String, dynamic> _$SetScoreToJson(SetScore instance) => <String, dynamic>{
      'set_number': instance.setNumber,
      'team1_games': instance.team1Games,
      'team2_games': instance.team2Games,
    };

PlayerRanking _$PlayerRankingFromJson(Map<String, dynamic> json) => PlayerRanking(
      playerId: json['player_id'] as String,
      tier: UserTier.values.byName(json['tier'] as String),
      division: json['division'] as int,
      lp: json['lp'] as int,
      lpRequiredForPromotion: json['lp_required_for_promotion'] as int,
      officialTournamentWins: json['official_tournament_wins'] as int,
      matchesPlayed: json['matches_played'] as int,
      winRate: (json['win_rate'] as num).toDouble(),
      currentStreak: json['current_streak'] as int,
      longestWinStreak: json['longest_win_streak'] as int,
      totalTournamentsPlayed: json['total_tournaments_played'] as int,
      sportsmanshipRating: (json['sportsmanship_rating'] as num).toDouble(),
      isUnderReview: json['is_under_review'] as bool,
      lastMatchDate: DateTime.parse(json['last_match_date'] as String),
      inactivityPenaltyDate: json['inactivity_penalty_date'] == null
          ? null
          : DateTime.parse(json['inactivity_penalty_date'] as String),
      bonusPoints: json['bonus_points'] as int,
      achievements: (json['achievements'] as List<dynamic>).map((e) => e as String).toList(),
      region: json['region'] as String,
      ageGroup: json['age_group'] as String,
      gender: Gender.values.byName(json['gender'] as String),
      globalRank: json['global_rank'] as int?,
      regionalRank: json['regional_rank'] as int?,
      cityRank: json['city_rank'] as int?,
      totalMatches: json['total_matches'] as int,
      totalWins: json['total_wins'] as int,
      totalLosses: json['total_losses'] as int,
      bestStreak: json['best_streak'] as int,
      unofficialTournamentWins: json['unofficial_tournament_wins'] as int,
      totalTournamentParticipations: json['total_tournament_participations'] as int,
      lastUpdated: DateTime.parse(json['last_updated'] as String),
    );

Map<String, dynamic> _$PlayerRankingToJson(PlayerRanking instance) => <String, dynamic>{
      'player_id': instance.playerId,
      'tier': instance.tier.name,
      'division': instance.division,
      'lp': instance.lp,
      'lp_required_for_promotion': instance.lpRequiredForPromotion,
      'official_tournament_wins': instance.officialTournamentWins,
      'matches_played': instance.matchesPlayed,
      'win_rate': instance.winRate,
      'current_streak': instance.currentStreak,
      'longest_win_streak': instance.longestWinStreak,
      'total_tournaments_played': instance.totalTournamentsPlayed,
      'sportsmanship_rating': instance.sportsmanshipRating,
      'is_under_review': instance.isUnderReview,
      'last_match_date': instance.lastMatchDate.toIso8601String(),
      'inactivity_penalty_date': instance.inactivityPenaltyDate?.toIso8601String(),
      'bonus_points': instance.bonusPoints,
      'achievements': instance.achievements,
      'region': instance.region,
      'age_group': instance.ageGroup,
      'gender': instance.gender.name,
      'global_rank': instance.globalRank,
      'regional_rank': instance.regionalRank,
      'city_rank': instance.cityRank,
      'total_matches': instance.totalMatches,
      'total_wins': instance.totalWins,
      'total_losses': instance.totalLosses,
      'best_streak': instance.bestStreak,
      'unofficial_tournament_wins': instance.unofficialTournamentWins,
      'total_tournament_participations': instance.totalTournamentParticipations,
      'last_updated': instance.lastUpdated.toIso8601String(),
    };

LPTransaction _$LPTransactionFromJson(Map<String, dynamic> json) => LPTransaction(
      id: json['id'] as String,
      playerId: json['player_id'] as String,
      tournamentId: json['tournament_id'] as String?,
      matchId: json['match_id'] as String?,
      type: LPTransactionType.values.byName(json['type'] as String),
      amount: json['amount'] as int,
      lpChange: json['lp_change'] as int,
      previousLP: json['previous_lp'] as int,
      newLP: json['new_lp'] as int,
      reason: json['reason'] as String,
      createdAt: DateTime.parse(json['created_at'] as String),
      isOfficial: json['is_official'] as bool,
    );

Map<String, dynamic> _$LPTransactionToJson(LPTransaction instance) => <String, dynamic>{
      'id': instance.id,
      'player_id': instance.playerId,
      'tournament_id': instance.tournamentId,
      'match_id': instance.matchId,
      'type': instance.type.name,
      'amount': instance.amount,
      'lp_change': instance.lpChange,
      'previous_lp': instance.previousLP,
      'new_lp': instance.newLP,
      'reason': instance.reason,
      'created_at': instance.createdAt.toIso8601String(),
      'is_official': instance.isOfficial,
    };

TierRequirement _$TierRequirementFromJson(Map<String, dynamic> json) => TierRequirement(
      tier: UserTier.values.byName(json['tier'] as String),
      minLP: json['min_lp'] as int,
      maxLP: json['max_lp'] as int,
      promotionRequirement: json['promotion_requirement'] as int,
      divisions: (json['divisions'] as List<dynamic>)
          .map((e) => DivisionRequirement.fromJson(e as Map<String, dynamic>))
          .toList(),
      lpGainMultiplier: (json['lp_gain_multiplier'] as num).toDouble(),
      lpLossMultiplier: (json['lp_loss_multiplier'] as num).toDouble(),
    );

Map<String, dynamic> _$TierRequirementToJson(TierRequirement instance) => <String, dynamic>{
      'tier': instance.tier.name,
      'min_lp': instance.minLP,
      'max_lp': instance.maxLP,
      'promotion_requirement': instance.promotionRequirement,
      'divisions': instance.divisions.map((e) => e.toJson()).toList(),
      'lp_gain_multiplier': instance.lpGainMultiplier,
      'lp_loss_multiplier': instance.lpLossMultiplier,
    };

DivisionRequirement _$DivisionRequirementFromJson(Map<String, dynamic> json) => DivisionRequirement(
      tier: UserTier.values.byName(json['tier'] as String),
      division: json['division'] as int,
      minLP: json['min_lp'] as int,
      maxLP: json['max_lp'] as int,
      lpRequired: json['lp_required'] as int,
    );

Map<String, dynamic> _$DivisionRequirementToJson(DivisionRequirement instance) => <String, dynamic>{
      'tier': instance.tier.name,
      'division': instance.division,
      'min_lp': instance.minLP,
      'max_lp': instance.maxLP,
      'lp_required': instance.lpRequired,
    };

TournamentAdvancementPoints _$TournamentAdvancementPointsFromJson(Map<String, dynamic> json) => TournamentAdvancementPoints(
      tournamentType: TournamentType.values.byName(json['tournament_type'] as String),
      participantCount: json['participant_count'] as int,
      tier: UserTier.values.byName(json['tier'] as String),
      bracketSize: json['bracket_size'] as int,
      points: AdvancementPoints.fromJson(json['points'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$TournamentAdvancementPointsToJson(TournamentAdvancementPoints instance) => <String, dynamic>{
      'tournament_type': instance.tournamentType.name,
      'participant_count': instance.participantCount,
      'tier': instance.tier.name,
      'bracket_size': instance.bracketSize,
      'points': instance.points.toJson(),
    };

AdvancementPoints _$AdvancementPointsFromJson(Map<String, dynamic> json) => AdvancementPoints(
      winner: json['winner'] as int,
      runnerUp: json['runner_up'] as int,
      semifinalist: json['semifinalist'] as int,
      quarterfinalist: json['quarterfinalist'] as int,
      participation: json['participation'] as int,
      matchWin: json['match_win'] as int,
      roundOf16: json['round_of_16'] as int?,
      quarterfinal: json['quarterfinal'] as int,
      semifinal: json['semifinal'] as int,
      finalMatch: json['final'] as int,
      champion: json['champion'] as int,
    );

Map<String, dynamic> _$AdvancementPointsToJson(AdvancementPoints instance) => <String, dynamic>{
      'winner': instance.winner,
      'runner_up': instance.runnerUp,
      'semifinalist': instance.semifinalist,
      'quarterfinalist': instance.quarterfinalist,
      'participation': instance.participation,
      'match_win': instance.matchWin,
      'round_of_16': instance.roundOf16,
      'quarterfinal': instance.quarterfinal,
      'semifinal': instance.semifinal,
      'final': instance.finalMatch,
      'champion': instance.champion,
    };

BonusPoints _$BonusPointsFromJson(Map<String, dynamic> json) => BonusPoints(
      firstTournamentWin: json['first_tournament_win'] as int,
      perfectGame: json['perfect_game'] as int,
      comebackVictory: json['comeback_victory'] as int,
      beatingHigherRankedTeam: json['beating_higher_ranked_team'] as int,
      weeklyStreakBonus: json['weekly_streak_bonus'] as int,
      scenario: json['scenario'] as String,
      points: json['points'] as int,
    );

Map<String, dynamic> _$BonusPointsToJson(BonusPoints instance) => <String, dynamic>{
      'first_tournament_win': instance.firstTournamentWin,
      'perfect_game': instance.perfectGame,
      'comeback_victory': instance.comebackVictory,
      'beating_higher_ranked_team': instance.beatingHigherRankedTeam,
      'weekly_streak_bonus': instance.weeklyStreakBonus,
      'scenario': instance.scenario,
      'points': instance.points,
    };

LeaderboardEntry _$LeaderboardEntryFromJson(Map<String, dynamic> json) => LeaderboardEntry(
      user: User.fromJson(json['user'] as Map<String, dynamic>),
      ranking: PlayerRanking.fromJson(json['ranking'] as Map<String, dynamic>),
      globalRank: json['global_rank'] as int,
      playerName: json['player_name'] as String,
      profilePicture: json['profile_picture'] as String?,
    );

Map<String, dynamic> _$LeaderboardEntryToJson(LeaderboardEntry instance) => <String, dynamic>{
      'user': instance.user.toJson(),
      'ranking': instance.ranking.toJson(),
      'global_rank': instance.globalRank,
      'player_name': instance.playerName,
      'profile_picture': instance.profilePicture,
    };
