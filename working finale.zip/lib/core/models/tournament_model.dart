import 'package:json_annotation/json_annotation.dart';

import '../utils/constants.dart';
import 'user_model.dart';

part 'tournament_model.g.dart';

@JsonSerializable()
class Tournament {
  final String id;
  final String name;
  final String description;
  final String location;
  final DateTime startDate;
  final DateTime endDate;
  final double entryFee;
  final int maxParticipants;
  final int currentParticipants;
  final TournamentType type;
  final int bracketSize; // 8, 16, or 32
  final TournamentStatus status;
  final String organizerId;
  final UserRole organizerRole;
  final TournamentPrizes prizes;
  final String? image;
  final String rules;
  final DateTime createdAt;
  final DateTime updatedAt;
  final bool isApproved;

  // Additional properties for compatibility
  final UserTier minTier;
  final UserTier maxTier;
  final DateTime registrationDeadline;
  final bool isFeatured;
  final bool allowSpectators;
  final bool isPublic;

  const Tournament({
    required this.id,
    required this.name,
    required this.description,
    required this.location,
    required this.startDate,
    required this.endDate,
    required this.entryFee,
    required this.maxParticipants,
    required this.currentParticipants,
    required this.type,
    required this.bracketSize,
    required this.status,
    required this.organizerId,
    required this.organizerRole,
    required this.prizes,
    this.image,
    required this.rules,
    required this.createdAt,
    required this.updatedAt,
    required this.isApproved,
    required this.minTier,
    required this.maxTier,
    required this.registrationDeadline,
    required this.isFeatured,
    required this.allowSpectators,
    required this.isPublic,
  });

  factory Tournament.fromJson(Map<String, dynamic> json) => _$TournamentFromJson(json);
  Map<String, dynamic> toJson() => _$TournamentToJson(this);

  bool get isFull => currentParticipants >= maxParticipants;
  bool get isUpcoming => status == TournamentStatus.upcoming;
  bool get isOngoing => status == TournamentStatus.ongoing;
  bool get isCompleted => status == TournamentStatus.completed;
  bool get isOfficial => type == TournamentType.official;
}

@JsonSerializable()
class TournamentPrizes {
  final double totalPrizePool;
  final double firstPlace;
  final double secondPlace;
  final double thirdPlace;
  final String currency;

  const TournamentPrizes({
    required this.totalPrizePool,
    required this.firstPlace,
    required this.secondPlace,
    required this.thirdPlace,
    required this.currency,
  });

  factory TournamentPrizes.fromJson(Map<String, dynamic> json) => _$TournamentPrizesFromJson(json);
  Map<String, dynamic> toJson() => _$TournamentPrizesToJson(this);

  double get total => firstPlace + secondPlace + thirdPlace;

  // Legacy getters for compatibility
  double get first => firstPlace;
  double get second => secondPlace;
  double get third => thirdPlace;
}

@JsonSerializable()
class TournamentMatch {
  final String id;
  final String tournamentId;
  final int matchNumber;
  final TournamentRound round;
  final MatchTeam team1;
  final MatchTeam team2;
  final MatchTeam? winner;
  final MatchScore? score;
  final int? lpAwarded;
  final String qrCode;
  final String? refereeCode;
  final DateTime startTime;
  final DateTime? scheduledTime;
  final DateTime? actualStartTime;
  final DateTime? actualEndTime;
  final DateTime? endTime;
  final String courtId;
  final MatchStatus status;

  const TournamentMatch({
    required this.id,
    required this.tournamentId,
    required this.matchNumber,
    required this.round,
    required this.team1,
    required this.team2,
    this.winner,
    this.score,
    this.lpAwarded,
    required this.qrCode,
    this.refereeCode,
    required this.startTime,
    this.scheduledTime,
    this.actualStartTime,
    this.actualEndTime,
    this.endTime,
    required this.courtId,
    required this.status,
  });

  factory TournamentMatch.fromJson(Map<String, dynamic> json) => _$TournamentMatchFromJson(json);
  Map<String, dynamic> toJson() => _$TournamentMatchToJson(this);
}

@JsonSerializable()
class MatchTeam {
  final String player1Id;
  final String player2Id;
  final String player1;
  final String player2;

  const MatchTeam({
    required this.player1Id,
    required this.player2Id,
    required this.player1,
    required this.player2,
  });

  factory MatchTeam.fromJson(Map<String, dynamic> json) => _$MatchTeamFromJson(json);
  Map<String, dynamic> toJson() => _$MatchTeamToJson(this);
}

@JsonSerializable()
class MatchScore {
  final String? winnerId;
  final int totalGamesTeam1;
  final int totalGamesTeam2;
  final int team1Sets;
  final int team2Sets;
  final List<SetScore> sets;

  const MatchScore({
    this.winnerId,
    required this.totalGamesTeam1,
    required this.totalGamesTeam2,
    required this.team1Sets,
    required this.team2Sets,
    required this.sets,
  });

  factory MatchScore.fromJson(Map<String, dynamic> json) => _$MatchScoreFromJson(json);
  Map<String, dynamic> toJson() => _$MatchScoreToJson(this);
}

@JsonSerializable()
class SetScore {
  final int setNumber;
  final int team1Games;
  final int team2Games;

  const SetScore({
    required this.setNumber,
    required this.team1Games,
    required this.team2Games,
  });

  factory SetScore.fromJson(Map<String, dynamic> json) => _$SetScoreFromJson(json);
  Map<String, dynamic> toJson() => _$SetScoreToJson(this);
}

@JsonSerializable()
class PlayerRanking {
  final String playerId;
  final UserTier tier;
  final int division; // 1-4
  final int lp; // League Points
  final int lpRequiredForPromotion;
  final int officialTournamentWins;
  final int matchesPlayed;
  final double winRate;
  final int currentStreak;
  final int longestWinStreak;
  final int totalTournamentsPlayed;
  final double sportsmanshipRating; // 1-5 scale
  final bool isUnderReview;
  final DateTime lastMatchDate;
  final DateTime? inactivityPenaltyDate;
  final int bonusPoints;
  final List<String> achievements;
  final String region;
  final String ageGroup;
  final Gender gender;

  // Additional properties for compatibility
  final int? globalRank;
  final int? regionalRank;
  final int? cityRank;
  final int totalMatches;
  final int totalWins;
  final int totalLosses;
  final int bestStreak;
  final int unofficialTournamentWins;
  final int totalTournamentParticipations;
  final DateTime lastUpdated;

  const PlayerRanking({
    required this.playerId,
    required this.tier,
    required this.division,
    required this.lp,
    required this.lpRequiredForPromotion,
    required this.officialTournamentWins,
    required this.matchesPlayed,
    required this.winRate,
    required this.currentStreak,
    required this.longestWinStreak,
    required this.totalTournamentsPlayed,
    required this.sportsmanshipRating,
    required this.isUnderReview,
    required this.lastMatchDate,
    this.inactivityPenaltyDate,
    required this.bonusPoints,
    required this.achievements,
    required this.region,
    required this.ageGroup,
    required this.gender,
    this.globalRank,
    this.regionalRank,
    this.cityRank,
    required this.totalMatches,
    required this.totalWins,
    required this.totalLosses,
    required this.bestStreak,
    required this.unofficialTournamentWins,
    required this.totalTournamentParticipations,
    required this.lastUpdated,
  });

  factory PlayerRanking.fromJson(Map<String, dynamic> json) => _$PlayerRankingFromJson(json);
  Map<String, dynamic> toJson() => _$PlayerRankingToJson(this);

  String get tierDisplayName {
    switch (tier) {
      case UserTier.rookie:
        return 'Rookie';
      case UserTier.beginner:
        return 'Beginner';
      case UserTier.intermediate:
        return 'Intermediate';
      case UserTier.advanced:
        return 'Advanced';
      case UserTier.elite:
        return 'Elite';
      case UserTier.master:
        return 'Master';
      case UserTier.proPlayers:
        return 'Pro Players';
    }
  }

  String get divisionRoman {
    switch (division) {
      case 1:
        return 'I';
      case 2:
        return 'II';
      case 3:
        return 'III';
      case 4:
        return 'IV';
      default:
        return 'I';
    }
  }

  String get fullRankDisplay => '$tierDisplayName $divisionRoman';
}

@JsonSerializable()
class LPTransaction {
  final String id;
  final String playerId;
  final String? tournamentId;
  final String? matchId;
  final LPTransactionType type;
  final int amount;
  final int lpChange;
  final int previousLP;
  final int newLP;
  final String reason;
  final DateTime createdAt;
  final bool isOfficial;

  const LPTransaction({
    required this.id,
    required this.playerId,
    this.tournamentId,
    this.matchId,
    required this.type,
    required this.amount,
    required this.lpChange,
    required this.previousLP,
    required this.newLP,
    required this.reason,
    required this.createdAt,
    required this.isOfficial,
  });

  factory LPTransaction.fromJson(Map<String, dynamic> json) => _$LPTransactionFromJson(json);
  Map<String, dynamic> toJson() => _$LPTransactionToJson(this);
}

@JsonSerializable()
class TierRequirement {
  final UserTier tier;
  final int minLP;
  final int maxLP;
  final int promotionRequirement;
  final List<DivisionRequirement> divisions;
  final double lpGainMultiplier;
  final double lpLossMultiplier;

  const TierRequirement({
    required this.tier,
    required this.minLP,
    required this.maxLP,
    required this.promotionRequirement,
    required this.divisions,
    required this.lpGainMultiplier,
    required this.lpLossMultiplier,
  });

  factory TierRequirement.fromJson(Map<String, dynamic> json) => _$TierRequirementFromJson(json);
  Map<String, dynamic> toJson() => _$TierRequirementToJson(this);
}

@JsonSerializable()
class DivisionRequirement {
  final UserTier tier;
  final int division;
  final int minLP;
  final int maxLP;
  final int lpRequired;

  const DivisionRequirement({
    required this.tier,
    required this.division,
    required this.minLP,
    required this.maxLP,
    required this.lpRequired,
  });

  factory DivisionRequirement.fromJson(Map<String, dynamic> json) => _$DivisionRequirementFromJson(json);
  Map<String, dynamic> toJson() => _$DivisionRequirementToJson(this);
}

@JsonSerializable()
class TournamentAdvancementPoints {
  final TournamentType tournamentType;
  final int participantCount;
  final UserTier tier;
  final int bracketSize;
  final AdvancementPoints points;

  const TournamentAdvancementPoints({
    required this.tournamentType,
    required this.participantCount,
    required this.tier,
    required this.bracketSize,
    required this.points,
  });

  factory TournamentAdvancementPoints.fromJson(Map<String, dynamic> json) => _$TournamentAdvancementPointsFromJson(json);
  Map<String, dynamic> toJson() => _$TournamentAdvancementPointsToJson(this);
}

@JsonSerializable()
class AdvancementPoints {
  final int winner;
  final int runnerUp;
  final int semifinalist;
  final int quarterfinalist;
  final int participation;
  final int matchWin;
  final int? roundOf16;
  final int quarterfinal;
  final int semifinal;
  @JsonKey(name: 'final')
  final int finalMatch;
  final int champion;

  const AdvancementPoints({
    required this.winner,
    required this.runnerUp,
    required this.semifinalist,
    required this.quarterfinalist,
    required this.participation,
    required this.matchWin,
    this.roundOf16,
    required this.quarterfinal,
    required this.semifinal,
    required this.finalMatch,
    required this.champion,
  });

  factory AdvancementPoints.fromJson(Map<String, dynamic> json) => _$AdvancementPointsFromJson(json);
  Map<String, dynamic> toJson() => _$AdvancementPointsToJson(this);
}

@JsonSerializable()
class BonusPoints {
  final int firstTournamentWin;
  final int perfectGame;
  final int comebackVictory;
  final int beatingHigherRankedTeam;
  final int weeklyStreakBonus;
  final String scenario;
  final int points;

  const BonusPoints({
    required this.firstTournamentWin,
    required this.perfectGame,
    required this.comebackVictory,
    required this.beatingHigherRankedTeam,
    required this.weeklyStreakBonus,
    required this.scenario,
    required this.points,
  });

  factory BonusPoints.fromJson(Map<String, dynamic> json) => _$BonusPointsFromJson(json);
  Map<String, dynamic> toJson() => _$BonusPointsToJson(this);
}

@JsonSerializable()
class LeaderboardEntry {
  final User user;
  final PlayerRanking ranking;
  final int globalRank;
  final String playerName;
  final String? profilePicture;

  const LeaderboardEntry({
    required this.user,
    required this.ranking,
    required this.globalRank,
    required this.playerName,
    this.profilePicture,
  });

  factory LeaderboardEntry.fromJson(Map<String, dynamic> json) => _$LeaderboardEntryFromJson(json);
  Map<String, dynamic> toJson() => _$LeaderboardEntryToJson(this);
}

// Enums
enum TournamentRound {
  roundOf32,
  roundOf16,
  quarterfinal,
  semifinal,
  finalMatch,
}

enum LPTransactionType {
  matchWin,
  matchLoss,
  tournamentWin,
  advancement,
  bonus,
  penalty,
  inactivity,
}

// Constants for LP System
class LPConstants {
  static const List<TierRequirement> tierRequirements = [
    TierRequirement(
      tier: UserTier.rookie,
      minLP: 0,
      maxLP: 399,
      promotionRequirement: 300,
      divisions: [
        DivisionRequirement(tier: UserTier.rookie, division: 4, minLP: 0, maxLP: 99, lpRequired: 0),
        DivisionRequirement(tier: UserTier.rookie, division: 3, minLP: 100, maxLP: 199, lpRequired: 100),
        DivisionRequirement(tier: UserTier.rookie, division: 2, minLP: 200, maxLP: 299, lpRequired: 200),
        DivisionRequirement(tier: UserTier.rookie, division: 1, minLP: 300, maxLP: 399, lpRequired: 300),
      ],
      lpGainMultiplier: 1.0,
      lpLossMultiplier: 1.0,
    ),
    TierRequirement(
      tier: UserTier.beginner,
      minLP: 400,
      maxLP: 1599,
      promotionRequirement: 1300,
      divisions: [
        DivisionRequirement(tier: UserTier.beginner, division: 4, minLP: 400, maxLP: 699, lpRequired: 400),
        DivisionRequirement(tier: UserTier.beginner, division: 3, minLP: 700, maxLP: 999, lpRequired: 700),
        DivisionRequirement(tier: UserTier.beginner, division: 2, minLP: 1000, maxLP: 1299, lpRequired: 1000),
        DivisionRequirement(tier: UserTier.beginner, division: 1, minLP: 1300, maxLP: 1599, lpRequired: 1300),
      ],
      lpGainMultiplier: 1.1,
      lpLossMultiplier: 0.9,
    ),
    TierRequirement(
      tier: UserTier.intermediate,
      minLP: 1600,
      maxLP: 3599,
      promotionRequirement: 3100,
      divisions: [
        DivisionRequirement(tier: UserTier.intermediate, division: 4, minLP: 1600, maxLP: 2099, lpRequired: 1600),
        DivisionRequirement(tier: UserTier.intermediate, division: 3, minLP: 2100, maxLP: 2599, lpRequired: 2100),
        DivisionRequirement(tier: UserTier.intermediate, division: 2, minLP: 2600, maxLP: 3099, lpRequired: 2600),
        DivisionRequirement(tier: UserTier.intermediate, division: 1, minLP: 3100, maxLP: 3599, lpRequired: 3100),
      ],
      lpGainMultiplier: 1.2,
      lpLossMultiplier: 0.8,
    ),
    TierRequirement(
      tier: UserTier.advanced,
      minLP: 3600,
      maxLP: 6399,
      promotionRequirement: 5700,
      divisions: [
        DivisionRequirement(tier: UserTier.advanced, division: 4, minLP: 3600, maxLP: 4299, lpRequired: 3600),
        DivisionRequirement(tier: UserTier.advanced, division: 3, minLP: 4300, maxLP: 4999, lpRequired: 4300),
        DivisionRequirement(tier: UserTier.advanced, division: 2, minLP: 5000, maxLP: 5699, lpRequired: 5000),
        DivisionRequirement(tier: UserTier.advanced, division: 1, minLP: 5700, maxLP: 6399, lpRequired: 5700),
      ],
      lpGainMultiplier: 1.3,
      lpLossMultiplier: 0.7,
    ),
    TierRequirement(
      tier: UserTier.elite,
      minLP: 6400,
      maxLP: 10399,
      promotionRequirement: 9400,
      divisions: [
        DivisionRequirement(tier: UserTier.elite, division: 4, minLP: 6400, maxLP: 7399, lpRequired: 6400),
        DivisionRequirement(tier: UserTier.elite, division: 3, minLP: 7400, maxLP: 8399, lpRequired: 7400),
        DivisionRequirement(tier: UserTier.elite, division: 2, minLP: 8400, maxLP: 9399, lpRequired: 8400),
        DivisionRequirement(tier: UserTier.elite, division: 1, minLP: 9400, maxLP: 10399, lpRequired: 9400),
      ],
      lpGainMultiplier: 1.4,
      lpLossMultiplier: 0.6,
    ),
    TierRequirement(
      tier: UserTier.master,
      minLP: 10400,
      maxLP: 16399,
      promotionRequirement: 14900,
      divisions: [
        DivisionRequirement(tier: UserTier.master, division: 4, minLP: 10400, maxLP: 11899, lpRequired: 10400),
        DivisionRequirement(tier: UserTier.master, division: 3, minLP: 11900, maxLP: 13399, lpRequired: 11900),
        DivisionRequirement(tier: UserTier.master, division: 2, minLP: 13400, maxLP: 14899, lpRequired: 13400),
        DivisionRequirement(tier: UserTier.master, division: 1, minLP: 14900, maxLP: 16399, lpRequired: 14900),
      ],
      lpGainMultiplier: 1.5,
      lpLossMultiplier: 0.5,
    ),
    TierRequirement(
      tier: UserTier.proPlayers,
      minLP: 16400,
      maxLP: 99999,
      promotionRequirement: 16400,
      divisions: [
        DivisionRequirement(tier: UserTier.proPlayers, division: 1, minLP: 16400, maxLP: 99999, lpRequired: 16400),
      ],
      lpGainMultiplier: 1.6,
      lpLossMultiplier: 0.4,
    ),
  ];

  static const List<TournamentAdvancementPoints> advancementPoints = [
    TournamentAdvancementPoints(
      tournamentType: TournamentType.official,
      participantCount: 32,
      tier: UserTier.intermediate,
      bracketSize: 32,
      points: AdvancementPoints(
        winner: 50,
        runnerUp: 30,
        semifinalist: 20,
        quarterfinalist: 10,
        participation: 5,
        matchWin: 1,
        roundOf16: 4,
        quarterfinal: 4,
        semifinal: 4,
        finalMatch: 4,
        champion: 10,
      ),
    ),
    TournamentAdvancementPoints(
      tournamentType: TournamentType.official,
      participantCount: 16,
      tier: UserTier.intermediate,
      bracketSize: 16,
      points: AdvancementPoints(
        winner: 40,
        runnerUp: 25,
        semifinalist: 15,
        quarterfinalist: 8,
        participation: 3,
        matchWin: 1,
        quarterfinal: 4,
        semifinal: 4,
        finalMatch: 4,
        champion: 10,
      ),
    ),
    TournamentAdvancementPoints(
      tournamentType: TournamentType.official,
      participantCount: 8,
      tier: UserTier.intermediate,
      bracketSize: 8,
      points: AdvancementPoints(
        winner: 30,
        runnerUp: 20,
        semifinalist: 10,
        quarterfinalist: 5,
        participation: 2,
        matchWin: 1,
        quarterfinal: 4,
        semifinal: 4,
        finalMatch: 4,
        champion: 10,
      ),
    ),
  ];

  static const List<BonusPoints> bonusPoints = [
    BonusPoints(
      firstTournamentWin: 50,
      perfectGame: 20,
      comebackVictory: 15,
      beatingHigherRankedTeam: 15,
      weeklyStreakBonus: 25,
      scenario: 'winning_without_dropping_set',
      points: 20
    ),
    BonusPoints(
      firstTournamentWin: 50,
      perfectGame: 20,
      comebackVictory: 15,
      beatingHigherRankedTeam: 15,
      weeklyStreakBonus: 25,
      scenario: 'beating_higher_ranked_team',
      points: 15
    ),
    BonusPoints(
      firstTournamentWin: 50,
      perfectGame: 20,
      comebackVictory: 15,
      beatingHigherRankedTeam: 15,
      weeklyStreakBonus: 25,
      scenario: 'participating_5_tournaments_season',
      points: 50
    ),
    BonusPoints(
      firstTournamentWin: 50,
      perfectGame: 20,
      comebackVictory: 15,
      beatingHigherRankedTeam: 15,
      weeklyStreakBonus: 25,
      scenario: 'fastest_rise_of_month',
      points: 25
    ),
  ];
}
