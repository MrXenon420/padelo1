// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'user_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

User _$UserFromJson(Map<String, dynamic> json) => User(
      id: json['id'] as String,
      username: json['username'] as String,
      email: json['email'] as String?,
      phoneNumber: json['phone_number'] as String,
      role: UserRole.values.byName(json['role'] as String),
      profile: UserProfile.fromJson(json['profile'] as Map<String, dynamic>),
      isActive: json['is_active'] as bool,
      isBanned: json['is_banned'] as bool,
      banReason: json['ban_reason'] as String?,
      banExpiryDate: json['ban_expiry_date'] == null
          ? null
          : DateTime.parse(json['ban_expiry_date'] as String),
      createdAt: DateTime.parse(json['created_at'] as String),
      updatedAt: DateTime.parse(json['updated_at'] as String),
      lastLoginAt: json['last_login_at'] == null
          ? null
          : DateTime.parse(json['last_login_at'] as String),
      loginAttempts: json['login_attempts'] as int,
      isVerified: json['is_verified'] as bool,
      emailVerified: json['email_verified'] as bool,
      phoneVerified: json['phone_verified'] as bool,
      termsAcceptedAt: json['terms_accepted_at'] == null
          ? null
          : DateTime.parse(json['terms_accepted_at'] as String),
      privacyAcceptedAt: json['privacy_accepted_at'] == null
          ? null
          : DateTime.parse(json['privacy_accepted_at'] as String),
      termsVersion: json['terms_version'] as String?,
      privacyVersion: json['privacy_version'] as String?,
    );

Map<String, dynamic> _$UserToJson(User instance) => <String, dynamic>{
      'id': instance.id,
      'username': instance.username,
      'email': instance.email,
      'phone_number': instance.phoneNumber,
      'role': instance.role.name,
      'profile': instance.profile.toJson(),
      'is_active': instance.isActive,
      'is_banned': instance.isBanned,
      'ban_reason': instance.banReason,
      'ban_expiry_date': instance.banExpiryDate?.toIso8601String(),
      'created_at': instance.createdAt.toIso8601String(),
      'updated_at': instance.updatedAt.toIso8601String(),
      'last_login_at': instance.lastLoginAt?.toIso8601String(),
      'login_attempts': instance.loginAttempts,
      'is_verified': instance.isVerified,
      'email_verified': instance.emailVerified,
      'phone_verified': instance.phoneVerified,
      'terms_accepted_at': instance.termsAcceptedAt?.toIso8601String(),
      'privacy_accepted_at': instance.privacyAcceptedAt?.toIso8601String(),
      'terms_version': instance.termsVersion,
      'privacy_version': instance.privacyVersion,
    };

UserProfile _$UserProfileFromJson(Map<String, dynamic> json) => UserProfile(
      id: json['id'] as String?,
      firstName: json['first_name'] as String,
      lastName: json['last_name'] as String,
      dateOfBirth: json['date_of_birth'] == null
          ? null
          : DateTime.parse(json['date_of_birth'] as String),
      gender: Gender.values.byName(json['gender'] as String),
      preferredHand: PreferredHand.values.byName(json['preferred_hand'] as String),
      preferredCourtPosition: CourtPosition.values.byName(json['preferred_court_position'] as String),
      profilePicture: json['profile_picture'] as String?,
      bio: json['bio'] as String?,
      city: json['city'] as String?,
      location: UserLocation.fromJson(json['location'] as Map<String, dynamic>),
      socialMedia: json['social_media'] == null
          ? null
          : SocialMedia.fromJson(json['social_media'] as Map<String, dynamic>),
      preferences: UserPreferences.fromJson(json['preferences'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$UserProfileToJson(UserProfile instance) => <String, dynamic>{
      'id': instance.id,
      'first_name': instance.firstName,
      'last_name': instance.lastName,
      'date_of_birth': instance.dateOfBirth?.toIso8601String(),
      'gender': instance.gender.name,
      'preferred_hand': instance.preferredHand.name,
      'preferred_court_position': instance.preferredCourtPosition.name,
      'profile_picture': instance.profilePicture,
      'bio': instance.bio,
      'city': instance.city,
      'location': instance.location.toJson(),
      'social_media': instance.socialMedia?.toJson(),
      'preferences': instance.preferences.toJson(),
    };

UserLocation _$UserLocationFromJson(Map<String, dynamic> json) => UserLocation(
      state: json['state'] as String,
      city: json['city'] as String,
      country: json['country'] as String,
      coordinates: json['coordinates'] == null
          ? null
          : Coordinates.fromJson(json['coordinates'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$UserLocationToJson(UserLocation instance) => <String, dynamic>{
      'state': instance.state,
      'city': instance.city,
      'country': instance.country,
      'coordinates': instance.coordinates?.toJson(),
    };

Coordinates _$CoordinatesFromJson(Map<String, dynamic> json) => Coordinates(
      latitude: (json['latitude'] as num).toDouble(),
      longitude: (json['longitude'] as num).toDouble(),
      lat: (json['lat'] as num).toDouble(),
      lng: (json['lng'] as num).toDouble(),
    );

Map<String, dynamic> _$CoordinatesToJson(Coordinates instance) => <String, dynamic>{
      'latitude': instance.latitude,
      'longitude': instance.longitude,
      'lat': instance.lat,
      'lng': instance.lng,
    };

SocialMedia _$SocialMediaFromJson(Map<String, dynamic> json) => SocialMedia(
      instagramUsername: json['instagram_username'] as String?,
      facebookUsername: json['facebook_username'] as String?,
      twitterUsername: json['twitter_username'] as String?,
      instagram: json['instagram'] as String?,
      facebook: json['facebook'] as String?,
      twitter: json['twitter'] as String?,
    );

Map<String, dynamic> _$SocialMediaToJson(SocialMedia instance) => <String, dynamic>{
      'instagram_username': instance.instagramUsername,
      'facebook_username': instance.facebookUsername,
      'twitter_username': instance.twitterUsername,
      'instagram': instance.instagram,
      'facebook': instance.facebook,
      'twitter': instance.twitter,
    };

UserPreferences _$UserPreferencesFromJson(Map<String, dynamic> json) => UserPreferences(
      language: json['language'] as String,
      notifications: NotificationSettings.fromJson(json['notifications'] as Map<String, dynamic>),
      privacy: PrivacySettings.fromJson(json['privacy'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$UserPreferencesToJson(UserPreferences instance) => <String, dynamic>{
      'language': instance.language,
      'notifications': instance.notifications.toJson(),
      'privacy': instance.privacy.toJson(),
    };

NotificationSettings _$NotificationSettingsFromJson(Map<String, dynamic> json) => NotificationSettings(
      pushNotifications: json['push_notifications'] as bool,
      emailNotifications: json['email_notifications'] as bool,
      smsNotifications: json['sms_notifications'] as bool,
      matchInvitations: json['match_invitations'] as bool,
      tournamentUpdates: json['tournament_updates'] as bool,
      marketplaceOffers: json['marketplace_offers'] as bool,
      email: json['email'] as bool,
      push: json['push'] as bool,
      sms: json['sms'] as bool,
    );

Map<String, dynamic> _$NotificationSettingsToJson(NotificationSettings instance) => <String, dynamic>{
      'push_notifications': instance.pushNotifications,
      'email_notifications': instance.emailNotifications,
      'sms_notifications': instance.smsNotifications,
      'match_invitations': instance.matchInvitations,
      'tournament_updates': instance.tournamentUpdates,
      'marketplace_offers': instance.marketplaceOffers,
      'email': instance.email,
      'push': instance.push,
      'sms': instance.sms,
    };

PrivacySettings _$PrivacySettingsFromJson(Map<String, dynamic> json) => PrivacySettings(
      profileVisibility: json['profile_visibility'] as bool,
      showStats: json['show_stats'] as bool,
      allowDirectMessages: json['allow_direct_messages'] as bool,
      showEmail: json['show_email'] as bool,
      showPhone: json['show_phone'] as bool,
      showLocation: json['show_location'] as bool,
    );

Map<String, dynamic> _$PrivacySettingsToJson(PrivacySettings instance) => <String, dynamic>{
      'profile_visibility': instance.profileVisibility,
      'show_stats': instance.showStats,
      'allow_direct_messages': instance.allowDirectMessages,
      'show_email': instance.showEmail,
      'show_phone': instance.showPhone,
      'show_location': instance.showLocation,
    };

AuthResponse _$AuthResponseFromJson(Map<String, dynamic> json) => AuthResponse(
      success: json['success'] as bool,
      message: json['message'] as String,
      user: User.fromJson(json['user'] as Map<String, dynamic>),
      token: json['token'] as String,
      refreshToken: json['refresh_token'] as String,
    );

Map<String, dynamic> _$AuthResponseToJson(AuthResponse instance) => <String, dynamic>{
      'success': instance.success,
      'message': instance.message,
      'user': instance.user.toJson(),
      'token': instance.token,
      'refresh_token': instance.refreshToken,
    };

UserStats _$UserStatsFromJson(Map<String, dynamic> json) => UserStats(
      totalMatches: json['total_matches'] as int,
      totalWins: json['total_wins'] as int,
      totalLosses: json['total_losses'] as int,
      winPercentage: (json['win_percentage'] as num).toDouble(),
      averageRating: (json['average_rating'] as num).toDouble(),
      currentRating: (json['current_rating'] as num).toDouble(),
      bestRating: (json['best_rating'] as num).toDouble(),
      currentStreak: json['current_streak'] as int,
      bestStreak: json['best_streak'] as int,
      totalTournaments: json['total_tournaments'] as int,
      lastMatchDate: json['last_match_date'] == null
          ? null
          : DateTime.parse(json['last_match_date'] as String),
      totalFollowers: json['total_followers'] as int,
      totalFollowing: json['total_following'] as int,
      matchesPlayed: json['matches_played'] as int,
      tournamentsJoined: json['tournaments_joined'] as int,
      tournamentsWon: json['tournaments_won'] as int,
      winRate: (json['win_rate'] as num).toDouble(),
      currentRank: json['current_rank'] as int,
      currentLP: json['current_lp'] as int,
      currentTier: UserTier.values.byName(json['current_tier'] as String),
      currentDivision: json['current_division'] as int,
      achievements: (json['achievements'] as List<dynamic>).map((e) => e as String).toList(),
      joinDate: DateTime.parse(json['join_date'] as String),
    );

Map<String, dynamic> _$UserStatsToJson(UserStats instance) => <String, dynamic>{
      'total_matches': instance.totalMatches,
      'total_wins': instance.totalWins,
      'total_losses': instance.totalLosses,
      'win_percentage': instance.winPercentage,
      'average_rating': instance.averageRating,
      'current_rating': instance.currentRating,
      'best_rating': instance.bestRating,
      'current_streak': instance.currentStreak,
      'best_streak': instance.bestStreak,
      'total_tournaments': instance.totalTournaments,
      'last_match_date': instance.lastMatchDate?.toIso8601String(),
      'total_followers': instance.totalFollowers,
      'total_following': instance.totalFollowing,
      'matches_played': instance.matchesPlayed,
      'tournaments_joined': instance.tournamentsJoined,
      'tournaments_won': instance.tournamentsWon,
      'win_rate': instance.winRate,
      'current_rank': instance.currentRank,
      'current_lp': instance.currentLP,
      'current_tier': instance.currentTier.name,
      'current_division': instance.currentDivision,
      'achievements': instance.achievements,
      'join_date': instance.joinDate.toIso8601String(),
    };
