import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

void main() {
  runApp(const ProviderScope(child: SimplePadeloApp()));
}

class SimplePadeloApp extends StatelessWidget {
  const SimplePadeloApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Padelo',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.green,
        useMaterial3: true,
      ),
      home: const PadeloHomePage(),
    );
  }
}

class PadeloHomePage extends StatefulWidget {
  const PadeloHomePage({super.key});

  @override
  State<PadeloHomePage> createState() => _PadeloHomePageState();
}

class _PadeloHomePageState extends State<PadeloHomePage> {
  int _selectedIndex = 0;

  final List<Widget> _pages = [
    const HomePage(),
    const TournamentsPage(),
    const CourtsPage(),
    const TrainingPage(),
    const MarketplacePage(),
    const MatchesPage(),
    const ProfilePage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        currentIndex: _selectedIndex,
        selectedItemColor: const Color(0xFF099c37),
        unselectedItemColor: Colors.grey,
        onTap: (index) => setState(() => _selectedIndex = index),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.emoji_events), label: 'Tournaments'),
          BottomNavigationBarItem(icon: Icon(Icons.sports_tennis), label: 'Courts'),
          BottomNavigationBarItem(icon: Icon(Icons.school), label: 'Training'),
          BottomNavigationBarItem(icon: Icon(Icons.shopping_bag), label: 'Marketplace'),
          BottomNavigationBarItem(icon: Icon(Icons.people), label: 'Matches'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Row(
          children: [
            Text('Padel', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
            Text('o', style: TextStyle(color: Color(0xFF099c37), fontWeight: FontWeight.bold)),
          ],
        ),
        backgroundColor: Colors.white,
        elevation: 1,
        actions: [
          IconButton(
            icon: const Icon(Icons.language, color: Colors.grey),
            onPressed: () {},
          ),
          IconButton(
            icon: const Icon(Icons.person, color: Colors.grey),
            onPressed: () {},
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Center(
              child: Column(
                children: [
                  Text('Welcome', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                  Text('Your Ultimate Padel Experience', style: TextStyle(color: Colors.grey)),
                ],
              ),
            ),
            const SizedBox(height: 20),
            _buildQuickActions(),
            const SizedBox(height: 20),
            _buildTournaments(),
            const SizedBox(height: 20),
            _buildCourts(),
            const SizedBox(height: 20),
            _buildStats(),
          ],
        ),
      ),
    );
  }

  Widget _buildQuickActions() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Quick Actions', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () {},
                    icon: const Icon(Icons.calendar_today),
                    label: const Text('Book Court'),
                    style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF099c37)),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () {},
                    icon: const Icon(Icons.people),
                    label: const Text('Find Match'),
                    style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF099c37)),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () {},
                icon: const Icon(Icons.emoji_events),
                label: const Text('Join Tournament'),
                style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF099c37)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTournaments() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Upcoming Tournaments', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                TextButton(onPressed: () {}, child: const Text('View All')),
              ],
            ),
            const ListTile(
              leading: CircleAvatar(
                backgroundColor: Color(0xFF099c37),
                child: Icon(Icons.emoji_events, color: Colors.white),
              ),
              title: Text('Spring Championship'),
              subtitle: Text('Sports Club • Mar 15'),
              trailing: Text('\$50', style: TextStyle(color: Color(0xFF099c37), fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCourts() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Nearby Courts', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                TextButton(onPressed: () {}, child: const Text('View All')),
              ],
            ),
            const ListTile(
              leading: CircleAvatar(
                backgroundColor: Colors.black,
                child: Icon(Icons.location_on, color: Colors.white),
              ),
              title: Text('Elite Padel Club'),
              subtitle: Text('2:00 PM - 4:00 PM • 25% Off'),
              trailing: Text('\$30', style: TextStyle(color: Color(0xFF099c37), fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStats() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Your Stats', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildStatItem('12', 'Matches'),
                _buildStatItem('85%', 'Win Rate'),
                _buildStatItem('#247', 'Ranking'),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatItem(String value, String label) {
    return Column(
      children: [
        Text(value, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Color(0xFF099c37))),
        Text(label, style: const TextStyle(color: Colors.grey, fontSize: 12)),
      ],
    );
  }
}

// Tournaments Page with content
class TournamentsPage extends StatelessWidget {
  const TournamentsPage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Tournaments', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
        backgroundColor: Colors.white,
        elevation: 1,
        actions: [
          IconButton(icon: const Icon(Icons.filter_list, color: Colors.grey), onPressed: () {}),
          IconButton(icon: const Icon(Icons.search, color: Colors.grey), onPressed: () {}),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: ElevatedButton(
                    onPressed: () {},
                    style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF099c37)),
                    child: const Text('Join Tournament'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: OutlinedButton(
                    onPressed: () {},
                    child: const Text('Create Tournament'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            const Text('Upcoming Tournaments', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            _buildTournamentCard('Spring Championship', 'Sports Club', 'Mar 15', '\$50', Icons.emoji_events),
            _buildTournamentCard('Summer League', 'Elite Club', 'Apr 2', '\$75', Icons.emoji_events),
            _buildTournamentCard('Pro Series', 'Premium Courts', 'Apr 20', '\$100', Icons.emoji_events),
            const SizedBox(height: 20),
            const Text('Your Tournaments', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            _buildTournamentCard('Winter Cup', 'Local Club', 'Completed', 'Winner!', Icons.emoji_events, isCompleted: true),
          ],
        ),
      ),
    );
  }

  Widget _buildTournamentCard(String title, String location, String date, String price, IconData icon, {bool isCompleted = false}) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            CircleAvatar(
              backgroundColor: isCompleted ? Colors.orange : const Color(0xFF099c37),
              child: Icon(icon, color: Colors.white),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
                  Text('$location • $date', style: const TextStyle(color: Colors.grey)),
                ],
              ),
            ),
            Text(price, style: TextStyle(
              color: isCompleted ? Colors.orange : const Color(0xFF099c37),
              fontWeight: FontWeight.bold
            )),
          ],
        ),
      ),
    );
  }
}

// Courts Page with content
class CourtsPage extends StatelessWidget {
  const CourtsPage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Courts', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
        backgroundColor: Colors.white,
        elevation: 1,
        actions: [
          IconButton(icon: const Icon(Icons.location_on, color: Colors.grey), onPressed: () {}),
          IconButton(icon: const Icon(Icons.filter_list, color: Colors.grey), onPressed: () {}),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xFF099c37).withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: [
                  const Icon(Icons.location_on, color: Color(0xFF099c37)),
                  const SizedBox(width: 8),
                  const Expanded(child: Text('Showing courts near you')),
                  TextButton(onPressed: () {}, child: const Text('Change')),
                ],
              ),
            ),
            const SizedBox(height: 20),
            const Text('Available Now', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            _buildCourtCard('Elite Padel Club', '2:00 PM - 4:00 PM', '\$30', '\$40', true),
            _buildCourtCard('Sports Complex', '4:00 PM - 6:00 PM', '\$25', null, false),
            _buildCourtCard('Premium Courts', '6:00 PM - 8:00 PM', '\$45', null, false),
            const SizedBox(height: 20),
            const Text('Your Reservations', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            _buildReservationCard('Today', 'Elite Padel Club', '2:00 PM - 4:00 PM', 'Confirmed'),
            _buildReservationCard('Tomorrow', 'Sports Complex', '10:00 AM - 12:00 PM', 'Pending'),
          ],
        ),
      ),
    );
  }

  Widget _buildCourtCard(String name, String time, String price, String? originalPrice, bool hasDiscount) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            const CircleAvatar(
              backgroundColor: Colors.black,
              child: Icon(Icons.sports_tennis, color: Colors.white),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(name, style: const TextStyle(fontWeight: FontWeight.bold)),
                  Row(
                    children: [
                      const Icon(Icons.access_time, size: 16, color: Colors.grey),
                      const SizedBox(width: 4),
                      Text(time, style: const TextStyle(color: Colors.grey)),
                      if (hasDiscount) ...[
                        const SizedBox(width: 8),
                        const Icon(Icons.local_offer, size: 16, color: Color(0xFF099c37)),
                        const Text(' 25% Off', style: TextStyle(color: Color(0xFF099c37))),
                      ],
                    ],
                  ),
                ],
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                if (originalPrice != null)
                  Text(originalPrice, style: const TextStyle(decoration: TextDecoration.lineThrough, color: Colors.grey)),
                Text(price, style: const TextStyle(color: Color(0xFF099c37), fontWeight: FontWeight.bold)),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildReservationCard(String date, String court, String time, String status) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            CircleAvatar(
              backgroundColor: status == 'Confirmed' ? const Color(0xFF099c37) : Colors.orange,
              child: Icon(status == 'Confirmed' ? Icons.check : Icons.schedule, color: Colors.white),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('$date - $court', style: const TextStyle(fontWeight: FontWeight.bold)),
                  Text(time, style: const TextStyle(color: Colors.grey)),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: status == 'Confirmed' ? const Color(0xFF099c37) : Colors.orange,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(status, style: const TextStyle(color: Colors.white, fontSize: 12)),
            ),
          ],
        ),
      ),
    );
  }
}

// Training Page with content
class TrainingPage extends StatelessWidget {
  const TrainingPage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Training', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
        backgroundColor: Colors.white,
        elevation: 1,
        actions: [
          IconButton(icon: const Icon(Icons.bookmark_border, color: Colors.grey), onPressed: () {}),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Find a Coach', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            _buildCoachCard('Carlos Rodriguez', 'Pro Coach', '4.9', '\$50/hour'),
            _buildCoachCard('Maria Santos', 'Advanced Coach', '4.8', '\$40/hour'),
            const SizedBox(height: 20),
            const Text('Training Programs', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            _buildProgramCard('Beginner Basics', '4 weeks', '\$200'),
            _buildProgramCard('Advanced Techniques', '6 weeks', '\$350'),
            _buildProgramCard('Tournament Prep', '8 weeks', '\$500'),
            const SizedBox(height: 20),
            const Text('Your Sessions', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            _buildSessionCard('Tomorrow', 'Carlos Rodriguez', '10:00 AM - 11:00 AM'),
          ],
        ),
      ),
    );
  }

  Widget _buildCoachCard(String name, String level, String rating, String price) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            const CircleAvatar(
              backgroundColor: Color(0xFF099c37),
              child: Icon(Icons.person, color: Colors.white),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(name, style: const TextStyle(fontWeight: FontWeight.bold)),
                  Text(level, style: const TextStyle(color: Colors.grey)),
                  Row(
                    children: [
                      const Icon(Icons.star, size: 16, color: Colors.amber),
                      Text(' $rating', style: const TextStyle(color: Colors.grey)),
                    ],
                  ),
                ],
              ),
            ),
            Text(price, style: const TextStyle(color: Color(0xFF099c37), fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }

  Widget _buildProgramCard(String name, String duration, String price) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            const CircleAvatar(
              backgroundColor: Colors.orange,
              child: Icon(Icons.school, color: Colors.white),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(name, style: const TextStyle(fontWeight: FontWeight.bold)),
                  Text(duration, style: const TextStyle(color: Colors.grey)),
                ],
              ),
            ),
            Text(price, style: const TextStyle(color: Color(0xFF099c37), fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }

  Widget _buildSessionCard(String date, String coach, String time) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            const CircleAvatar(
              backgroundColor: Color(0xFF099c37),
              child: Icon(Icons.schedule, color: Colors.white),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('$date with $coach', style: const TextStyle(fontWeight: FontWeight.bold)),
                  Text(time, style: const TextStyle(color: Colors.grey)),
                ],
              ),
            ),
            const Icon(Icons.arrow_forward_ios, color: Colors.grey),
          ],
        ),
      ),
    );
  }
}

// Marketplace Page with content
class MarketplacePage extends StatelessWidget {
  const MarketplacePage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Marketplace', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
        backgroundColor: Colors.white,
        elevation: 1,
        actions: [
          IconButton(icon: const Icon(Icons.shopping_cart, color: Colors.grey), onPressed: () {}),
          IconButton(icon: const Icon(Icons.search, color: Colors.grey), onPressed: () {}),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Featured Deals', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(child: _buildProductCard('Professional Racket', '\$120', '4.8')),
                const SizedBox(width: 12),
                Expanded(child: _buildProductCard('Premium Balls', '\$25', '4.6')),
              ],
            ),
            const SizedBox(height: 20),
            const Text('Equipment', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            _buildListProductCard('Carbon Fiber Racket', '\$180', '4.9', 'Professional'),
            _buildListProductCard('Training Balls Set', '\$35', '4.7', '12 balls'),
            _buildListProductCard('Court Shoes', '\$95', '4.8', 'Size 9-12'),
            const SizedBox(height: 20),
            const Text('Apparel', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            _buildListProductCard('Pro Jersey', '\$45', '4.5', 'Multiple colors'),
            _buildListProductCard('Sports Shorts', '\$30', '4.6', 'Quick-dry'),
          ],
        ),
      ),
    );
  }

  Widget _buildProductCard(String name, String price, String rating) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              height: 80,
              width: double.infinity,
              decoration: BoxDecoration(
                color: Colors.grey[200],
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Icon(Icons.sports_tennis, size: 32, color: Colors.grey),
            ),
            const SizedBox(height: 8),
            Text(name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(price, style: const TextStyle(color: Color(0xFF099c37), fontWeight: FontWeight.bold)),
                Row(
                  children: [
                    const Icon(Icons.star, size: 14, color: Colors.amber),
                    Text(rating, style: const TextStyle(fontSize: 12, color: Colors.grey)),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildListProductCard(String name, String price, String rating, String description) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Container(
              width: 50,
              height: 50,
              decoration: BoxDecoration(
                color: Colors.grey[200],
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Icon(Icons.sports_tennis, color: Colors.grey),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(name, style: const TextStyle(fontWeight: FontWeight.bold)),
                  Text(description, style: const TextStyle(color: Colors.grey)),
                  Row(
                    children: [
                      const Icon(Icons.star, size: 14, color: Colors.amber),
                      Text(' $rating', style: const TextStyle(color: Colors.grey)),
                    ],
                  ),
                ],
              ),
            ),
            Text(price, style: const TextStyle(color: Color(0xFF099c37), fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }
}

// Matches Page with content
class MatchesPage extends StatelessWidget {
  const MatchesPage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Matches', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
        backgroundColor: Colors.white,
        elevation: 1,
        actions: [
          IconButton(icon: const Icon(Icons.add, color: Colors.grey), onPressed: () {}),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ElevatedButton.icon(
              onPressed: () {},
              icon: const Icon(Icons.people),
              label: const Text('Find Players'),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF099c37),
                minimumSize: const Size(double.infinity, 48),
              ),
            ),
            const SizedBox(height: 20),
            const Text('Upcoming Matches', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            _buildMatchCard('Today, 2:00 PM', 'You vs John & Mike', 'Elite Padel Club', 'Confirmed'),
            _buildMatchCard('Tomorrow, 10:00 AM', 'You vs Sarah & Ana', 'Sports Complex', 'Pending'),
            const SizedBox(height: 20),
            const Text('Find Opponents', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            _buildPlayerCard('Alex & Carlos', 'Intermediate', 'Available now'),
            _buildPlayerCard('Maria & Sofia', 'Advanced', 'Available evening'),
            _buildPlayerCard('David & Luis', 'Beginner', 'Weekends only'),
            const SizedBox(height: 20),
            const Text('Recent Matches', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            _buildRecentMatchCard('Yesterday', 'Won 6-4, 6-2', 'vs John & Mike'),
            _buildRecentMatchCard('Last Week', 'Lost 4-6, 6-3, 4-6', 'vs Pro Team'),
          ],
        ),
      ),
    );
  }

  Widget _buildMatchCard(String time, String players, String location, String status) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  backgroundColor: status == 'Confirmed' ? const Color(0xFF099c37) : Colors.orange,
                  child: Icon(status == 'Confirmed' ? Icons.check : Icons.schedule, color: Colors.white),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(time, style: const TextStyle(fontWeight: FontWeight.bold)),
                      Text(players, style: const TextStyle(color: Colors.grey)),
                      Text(location, style: const TextStyle(color: Colors.grey)),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: status == 'Confirmed' ? const Color(0xFF099c37) : Colors.orange,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(status, style: const TextStyle(color: Colors.white, fontSize: 12)),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPlayerCard(String names, String level, String availability) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            const CircleAvatar(
              backgroundColor: Color(0xFF099c37),
              child: Icon(Icons.people, color: Colors.white),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(names, style: const TextStyle(fontWeight: FontWeight.bold)),
                  Text('Level: $level', style: const TextStyle(color: Colors.grey)),
                  Text(availability, style: const TextStyle(color: Colors.grey)),
                ],
              ),
            ),
            ElevatedButton(
              onPressed: () {},
              style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF099c37)),
              child: const Text('Challenge'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRecentMatchCard(String date, String result, String opponent) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            CircleAvatar(
              backgroundColor: result.contains('Won') ? const Color(0xFF099c37) : Colors.red,
              child: Icon(result.contains('Won') ? Icons.emoji_events : Icons.close, color: Colors.white),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('$date $opponent', style: const TextStyle(fontWeight: FontWeight.bold)),
                  Text(result, style: const TextStyle(color: Colors.grey)),
                ],
              ),
            ),
            const Icon(Icons.arrow_forward_ios, color: Colors.grey),
          ],
        ),
      ),
    );
  }
}

// Profile Page with content
class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
        backgroundColor: Colors.white,
        elevation: 1,
        actions: [
          IconButton(icon: const Icon(Icons.settings, color: Colors.grey), onPressed: () {}),
          IconButton(icon: const Icon(Icons.edit, color: Colors.grey), onPressed: () {}),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            const CircleAvatar(
              radius: 50,
              backgroundColor: Color(0xFF099c37),
              child: Icon(Icons.person, size: 50, color: Colors.white),
            ),
            const SizedBox(height: 16),
            const Text('Ibrahim Abada', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            const Text('Advanced Player', style: TextStyle(color: Colors.grey)),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildStatColumn('24', 'Matches'),
                _buildStatColumn('18', 'Wins'),
                _buildStatColumn('75%', 'Win Rate'),
                _buildStatColumn('#156', 'Ranking'),
              ],
            ),
            const SizedBox(height: 30),
            _buildProfileSection('Account', [
              _buildProfileItem(Icons.person, 'Personal Info'),
              _buildProfileItem(Icons.security, 'Privacy & Security'),
              _buildProfileItem(Icons.payment, 'Payment Methods'),
              _buildProfileItem(Icons.notifications, 'Notifications'),
            ]),
            const SizedBox(height: 20),
            _buildProfileSection('Game', [
              _buildProfileItem(Icons.emoji_events, 'Achievements'),
              _buildProfileItem(Icons.history, 'Match History'),
              _buildProfileItem(Icons.star, 'Favorite Courts'),
              _buildProfileItem(Icons.people, 'Friends'),
            ]),
            const SizedBox(height: 20),
            _buildProfileSection('Support', [
              _buildProfileItem(Icons.help, 'Help Center'),
              _buildProfileItem(Icons.feedback, 'Feedback'),
              _buildProfileItem(Icons.info, 'About'),
              _buildProfileItem(Icons.logout, 'Sign Out', isRed: true),
            ]),
          ],
        ),
      ),
    );
  }

  Widget _buildStatColumn(String value, String label) {
    return Column(
      children: [
        Text(value, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Color(0xFF099c37))),
        Text(label, style: const TextStyle(color: Colors.grey)),
      ],
    );
  }

  Widget _buildProfileSection(String title, List<Widget> items) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            ...items,
          ],
        ),
      ),
    );
  }

  Widget _buildProfileItem(IconData icon, String title, {bool isRed = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Icon(icon, color: isRed ? Colors.red : Colors.grey),
          const SizedBox(width: 12),
          Expanded(child: Text(title, style: TextStyle(color: isRed ? Colors.red : Colors.black))),
          const Icon(Icons.arrow_forward_ios, color: Colors.grey, size: 16),
        ],
      ),
    );
  }
}
