import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';

// Import translation files
import enTranslations from './locales/en.json';
import arTranslations from './locales/ar.json';

// Initialize i18n with better error handling
const initI18n = async () => {
  try {
    await i18n
      .use(LanguageDetector)
      .use(initReactI18next)
      .init({
        resources: {
          en: {
            translation: enTranslations
          },
          ar: {
            translation: arTranslations
          }
        },
        lng: 'en', // default language
        fallbackLng: 'en',
        interpolation: {
          escapeValue: false, // React already escapes values
        },
        detection: {
          order: ['localStorage', 'navigator', 'htmlTag'],
          caches: ['localStorage'],
        },
        react: {
          useSuspense: false, // Disable suspense to prevent context issues
        },
      });
  } catch (error) {
    console.error('Failed to initialize i18n:', error);
  }
};

// Initialize immediately
initI18n();

export default i18n;
