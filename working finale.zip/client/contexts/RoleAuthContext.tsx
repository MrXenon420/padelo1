import React, { createContext, useContext, useState, useEffect } from 'react';

// Define user roles and their permissions
export type UserRole = 'player' | 'coach' | 'court_owner' | 'tournament_organizer' | 'owner' | 'super_admin';

export interface Permission {
  resource: string;
  actions: string[];
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  permissions: Permission[];
  avatar?: string;
  isVerified: boolean;
  courtIds?: string[]; // For court owners
  organizationId?: string; // For tournament organizers
  termsAcceptedAt?: string; // ISO date string
  privacyAcceptedAt?: string; // ISO date string
  termsVersion?: string;
  privacyVersion?: string;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  hasPermission: (resource: string, action: string) => boolean;
  hasRole: (role: UserRole | UserRole[]) => boolean;
  canAccessRoute: (route: string) => boolean;
}

interface AuthContextType extends AuthState {
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => void;
  register: (userData: RegisterData) => Promise<boolean>;
  updateUser: (userData: Partial<User>) => Promise<boolean>;
  switchRole: (role: UserRole) => Promise<boolean>; // For owners only
  assignRoleToUser: (userId: string, newRole: UserRole) => Promise<boolean>; // For owners to assign roles to others
}

interface RegisterData {
  name: string;
  email: string;
  password: string;
  // role removed - all users default to 'player'
  agreeTerms?: boolean;
  agreePrivacy?: boolean;
}

// Role-based permissions configuration
const ROLE_PERMISSIONS: Record<UserRole, Permission[]> = {
  player: [
    { resource: 'tournaments', actions: ['read', 'join'] },
    { resource: 'courts', actions: ['read', 'book'] },
    { resource: 'marketplace', actions: ['read', 'buy', 'sell'] },
    { resource: 'training', actions: ['read', 'book'] },
    { resource: 'matches', actions: ['read', 'create', 'join'] },
    { resource: 'profile', actions: ['read', 'update'] },
    { resource: 'support', actions: ['read', 'create'] }
  ],
  coach: [
    { resource: 'tournaments', actions: ['read', 'join', 'organize'] },
    { resource: 'courts', actions: ['read', 'book'] },
    { resource: 'marketplace', actions: ['read', 'buy', 'sell'] },
    { resource: 'training', actions: ['read', 'create', 'manage'] },
    { resource: 'matches', actions: ['read', 'create', 'join'] },
    { resource: 'profile', actions: ['read', 'update'] },
    { resource: 'support', actions: ['read', 'create'] },
    { resource: 'students', actions: ['read', 'manage'] }
  ],
  court_owner: [
    { resource: 'tournaments', actions: ['read', 'join', 'organize', 'host'] },
    { resource: 'courts', actions: ['read', 'create', 'manage', 'analytics'] },
    { resource: 'marketplace', actions: ['read', 'buy', 'sell'] },
    { resource: 'training', actions: ['read', 'book'] },
    { resource: 'matches', actions: ['read', 'create', 'join'] },
    { resource: 'profile', actions: ['read', 'update'] },
    { resource: 'support', actions: ['read', 'create'] },
    { resource: 'bookings', actions: ['read', 'manage'] },
    { resource: 'revenue', actions: ['read', 'analytics'] }
  ],
  tournament_organizer: [
    { resource: 'tournaments', actions: ['read', 'create', 'manage', 'analytics'] },
    { resource: 'courts', actions: ['read', 'book'] },
    { resource: 'marketplace', actions: ['read', 'buy', 'sell'] },
    { resource: 'training', actions: ['read', 'book'] },
    { resource: 'matches', actions: ['read', 'create', 'join'] },
    { resource: 'profile', actions: ['read', 'update'] },
    { resource: 'support', actions: ['read', 'create'] },
    { resource: 'participants', actions: ['read', 'manage'] }
  ],
  owner: [
    { resource: '*', actions: ['*'] } // Full access to everything
  ],
  super_admin: [
    { resource: '*', actions: ['*'] }, // Full access to everything including system settings
    { resource: 'admin', actions: ['read', 'manage'] },
    { resource: 'system', actions: ['read', 'manage'] }
  ]
};

// Route access configuration
const ROUTE_ACCESS: Record<string, UserRole[]> = {
  '/': ['player', 'coach', 'court_owner', 'tournament_organizer', 'owner', 'super_admin'],
  '/tournaments': ['player', 'coach', 'court_owner', 'tournament_organizer', 'owner', 'super_admin'],
  '/courts': ['player', 'coach', 'court_owner', 'tournament_organizer', 'owner', 'super_admin'],
  '/training': ['player', 'coach', 'court_owner', 'tournament_organizer', 'owner', 'super_admin'],
  '/marketplace': ['player', 'coach', 'court_owner', 'tournament_organizer', 'owner', 'super_admin'],
  '/matches': ['player', 'coach', 'court_owner', 'tournament_organizer', 'owner', 'super_admin'],
  '/profile': ['player', 'coach', 'court_owner', 'tournament_organizer', 'owner', 'super_admin'],
  '/support': ['player', 'coach', 'court_owner', 'tournament_organizer', 'owner', 'super_admin'],
  '/admin': ['owner', 'super_admin'],
  '/admin/users': ['owner', 'super_admin'],
  '/admin/courts': ['court_owner', 'owner', 'super_admin'],
  '/admin/tournaments': ['tournament_organizer', 'owner', 'super_admin'],
  '/admin/analytics': ['court_owner', 'tournament_organizer', 'owner', 'super_admin'],
  '/admin/settings': ['owner', 'super_admin']
};

const RoleAuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(RoleAuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within a RoleAuthProvider');
  }
  return context;
};

export const RoleAuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Mock authentication - in real app this would be API calls
  const mockUsers: Record<string, User> = {
    'player@example.com': {
      id: 'user1',
      name: 'Ahmed Hassan',
      email: 'player@example.com',
      role: 'player',
      permissions: ROLE_PERMISSIONS.player,
      avatar: '/user1.jpg',
      isVerified: true,
      termsAcceptedAt: '2024-01-01T00:00:00Z',
      privacyAcceptedAt: '2024-01-01T00:00:00Z',
      termsVersion: '1.0',
      privacyVersion: '1.0'
    },
    'coach@example.com': {
      id: 'user2',
      name: 'Sara Mohamed',
      email: 'coach@example.com',
      role: 'coach',
      permissions: ROLE_PERMISSIONS.coach,
      avatar: '/user2.jpg',
      isVerified: true,
      termsAcceptedAt: '2024-01-01T00:00:00Z',
      privacyAcceptedAt: '2024-01-01T00:00:00Z',
      termsVersion: '1.0',
      privacyVersion: '1.0'
    },
    'owner@example.com': {
      id: 'user3',
      name: 'Omar Ali',
      email: 'owner@example.com',
      role: 'court_owner',
      permissions: ROLE_PERMISSIONS.court_owner,
      avatar: '/user3.jpg',
      isVerified: true,
      courtIds: ['court1', 'court2'],
      termsAcceptedAt: '2024-01-01T00:00:00Z',
      privacyAcceptedAt: '2024-01-01T00:00:00Z',
      termsVersion: '1.0',
      privacyVersion: '1.0'
    },
    'organizer@example.com': {
      id: 'user4',
      name: 'Layla Ahmed',
      email: 'organizer@example.com',
      role: 'tournament_organizer',
      permissions: ROLE_PERMISSIONS.tournament_organizer,
      avatar: '/user4.jpg',
      isVerified: true,
      organizationId: 'org1',
      termsAcceptedAt: '2024-01-01T00:00:00Z',
      privacyAcceptedAt: '2024-01-01T00:00:00Z',
      termsVersion: '1.0',
      privacyVersion: '1.0'
    },
    'admin@example.com': {
      id: 'admin1',
      name: 'Ibrahim Abada',
      email: 'admin@example.com',
      role: 'owner',
      permissions: ROLE_PERMISSIONS.owner,
      avatar: '/admin.jpg',
      isVerified: true,
      termsAcceptedAt: '2024-01-01T00:00:00Z',
      privacyAcceptedAt: '2024-01-01T00:00:00Z',
      termsVersion: '1.0',
      privacyVersion: '1.0'
    }
  };

  useEffect(() => {
    // Check for existing session
    const storedUser = localStorage.getItem('padelo-user');
    if (storedUser) {
      try {
        const userData = JSON.parse(storedUser);
        setUser(userData);
      } catch (error) {
        console.error('Failed to parse stored user data:', error);
        localStorage.removeItem('padelo-user');
      }
    }
    setIsLoading(false);
  }, []);

  const login = async (email: string, password: string): Promise<boolean> => {
    setIsLoading(true);
    
    // Mock API call delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const userData = mockUsers[email];
    if (userData && password === 'password123') {
      setUser(userData);
      localStorage.setItem('padelo-user', JSON.stringify(userData));
      setIsLoading(false);
      return true;
    }
    
    setIsLoading(false);
    return false;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('padelo-user');
  };

  const register = async (userData: RegisterData): Promise<boolean> => {
    setIsLoading(true);

    // Mock API call delay
    await new Promise(resolve => setTimeout(resolve, 1500));

    // Check if user already exists
    if (mockUsers[userData.email]) {
      setIsLoading(false);
      return false;
    }

    // Create new user - ALWAYS default to 'player' role
    const currentDate = new Date().toISOString();
    const newUser: User = {
      id: `user_${Date.now()}`,
      name: userData.name,
      email: userData.email,
      role: 'player', // Always default to player role
      permissions: ROLE_PERMISSIONS['player'],
      isVerified: false,
      termsAcceptedAt: userData.agreeTerms ? currentDate : undefined,
      privacyAcceptedAt: userData.agreePrivacy ? currentDate : undefined,
      termsVersion: '1.0',
      privacyVersion: '1.0'
    };

    // In real app, this would be sent to backend
    setUser(newUser);
    localStorage.setItem('padelo-user', JSON.stringify(newUser));
    setIsLoading(false);
    return true;
  };

  const updateUser = async (userData: Partial<User>): Promise<boolean> => {
    if (!user) return false;
    
    setIsLoading(true);
    
    // Mock API call delay
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const updatedUser = { ...user, ...userData };
    setUser(updatedUser);
    localStorage.setItem('padelo-user', JSON.stringify(updatedUser));
    setIsLoading(false);
    return true;
  };

  const switchRole = async (role: UserRole): Promise<boolean> => {
    if (!user) return false;

    // Only owners can switch/assign roles
    if (user.role !== 'owner' && user.role !== 'super_admin') {
      return false;
    }

    const updatedUser = {
      ...user,
      role,
      permissions: ROLE_PERMISSIONS[role]
    };

    setUser(updatedUser);
    localStorage.setItem('padelo-user', JSON.stringify(updatedUser));
    return true;
  };

  // New function for owners to assign roles to other users
  const assignRoleToUser = async (userId: string, newRole: UserRole): Promise<boolean> => {
    if (!user || (user.role !== 'owner' && user.role !== 'super_admin')) {
      return false; // Only owners can assign roles
    }

    // In real app, this would be an API call to update another user's role
    // For now, we'll just return true to indicate the action is allowed
    return true;
  };

  const hasPermission = (resource: string, action: string): boolean => {
    if (!user) return false;
    
    // Super admin and owner have access to everything
    if (user.role === 'super_admin' || user.role === 'owner') {
      return true;
    }
    
    return user.permissions.some(permission => {
      // Check for wildcard permissions
      if (permission.resource === '*' && permission.actions.includes('*')) {
        return true;
      }
      
      // Check specific resource and action
      return permission.resource === resource && 
             (permission.actions.includes(action) || permission.actions.includes('*'));
    });
  };

  const hasRole = (roles: UserRole | UserRole[]): boolean => {
    if (!user) return false;
    
    const roleArray = Array.isArray(roles) ? roles : [roles];
    return roleArray.includes(user.role);
  };

  const canAccessRoute = (route: string): boolean => {
    if (!user) return false;
    
    // Check exact route match first
    if (ROUTE_ACCESS[route]) {
      return ROUTE_ACCESS[route].includes(user.role);
    }
    
    // Check for parent route access (e.g., /admin/* routes)
    const parentRoute = route.split('/').slice(0, 2).join('/');
    if (ROUTE_ACCESS[parentRoute]) {
      return ROUTE_ACCESS[parentRoute].includes(user.role);
    }
    
    // Default to allowing access if route not specifically restricted
    return true;
  };

  const value: AuthContextType = {
    user,
    isAuthenticated: !!user,
    isLoading,
    hasPermission,
    hasRole,
    canAccessRoute,
    login,
    logout,
    register,
    updateUser,
    switchRole,
    assignRoleToUser
  };

  return (
    <RoleAuthContext.Provider value={value}>
      {children}
    </RoleAuthContext.Provider>
  );
};

// Higher-order component for protecting routes
export const withRoleAuth = <P extends object>(
  WrappedComponent: React.ComponentType<P>,
  requiredRoles?: UserRole[],
  requiredPermissions?: { resource: string; action: string }[]
) => {
  return (props: P) => {
    const { user, hasRole, hasPermission } = useAuth();
    
    // Check if user is authenticated
    if (!user) {
      return (
        <div className="min-h-screen bg-gray-50 flex items-center justify-center">
          <div className="text-center">
            <h2 className="text-2xl font-bold text-black mb-4">Authentication Required</h2>
            <p className="text-gray-600 mb-6">You need to be logged in to access this page.</p>
            <button className="bg-green-500 hover:bg-green-600 text-white px-6 py-2 rounded-lg">
              Login
            </button>
          </div>
        </div>
      );
    }
    
    // Check role requirements
    if (requiredRoles && !hasRole(requiredRoles)) {
      return (
        <div className="min-h-screen bg-gray-50 flex items-center justify-center">
          <div className="text-center">
            <h2 className="text-2xl font-bold text-black mb-4">Access Denied</h2>
            <p className="text-gray-600 mb-6">
              You don't have the required role to access this page.
            </p>
            <p className="text-sm text-gray-500">
              Required roles: {requiredRoles.join(', ')}
            </p>
          </div>
        </div>
      );
    }
    
    // Check permission requirements
    if (requiredPermissions) {
      const hasAllPermissions = requiredPermissions.every(perm => 
        hasPermission(perm.resource, perm.action)
      );
      
      if (!hasAllPermissions) {
        return (
          <div className="min-h-screen bg-gray-50 flex items-center justify-center">
            <div className="text-center">
              <h2 className="text-2xl font-bold text-black mb-4">Insufficient Permissions</h2>
              <p className="text-gray-600 mb-6">
                You don't have the required permissions to access this page.
              </p>
            </div>
          </div>
        );
      }
    }
    
    return <WrappedComponent {...props} />;
  };
};

// Hook for role-based UI rendering
export const useRoleBasedUI = () => {
  const { user, hasRole, hasPermission } = useAuth();
  
  const showForRoles = (roles: UserRole | UserRole[]) => {
    return hasRole(roles);
  };
  
  const showForPermissions = (resource: string, action: string) => {
    return hasPermission(resource, action);
  };
  
  const getRoleBasedContent = (content: Partial<Record<UserRole, React.ReactNode>>) => {
    if (!user) return null;
    return content[user.role] || content['player'] || null;
  };
  
  return {
    user,
    showForRoles,
    showForPermissions,
    getRoleBasedContent
  };
};

export default RoleAuthProvider;
