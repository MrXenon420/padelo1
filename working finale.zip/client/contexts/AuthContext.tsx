import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { 
  User, 
  UserPermissions, 
  AuthContextType, 
  LoginCredentials, 
  RegisterData,
  ChangePassword,
  PasswordResetRequest,
  PasswordReset,
  UserProfile,
  ROLE_PERMISSIONS
} from '@shared/auth';

const AuthContext = createContext<AuthContextType | undefined>(undefined);

interface AuthProviderProps {
  children: ReactNode;
}

export function AuthProvider({ children }: AuthProviderProps) {
  const [user, setUser] = useState<Omit<User, 'password'> | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [permissions, setPermissions] = useState<UserPermissions | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const isAuthenticated = !!user && !!token;

  // Initialize auth state from localStorage
  useEffect(() => {
    const initAuth = async () => {
      try {
        const storedToken = localStorage.getItem('padelo-token');
        const storedUser = localStorage.getItem('padelo-user');

        if (storedToken && storedUser) {
          const parsedUser = JSON.parse(storedUser);
          
          // Validate token with server
          const response = await fetch('/api/auth/validate', {
            headers: {
              'Authorization': `Bearer ${storedToken}`
            }
          });

          if (response.ok) {
            setToken(storedToken);
            setUser(parsedUser);
            setPermissions(ROLE_PERMISSIONS[parsedUser.role]);
          } else {
            // Invalid token, clear stored data
            localStorage.removeItem('padelo-token');
            localStorage.removeItem('padelo-user');
          }
        }
      } catch (error) {
        console.error('Failed to initialize auth:', error);
        localStorage.removeItem('padelo-token');
        localStorage.removeItem('padelo-user');
      } finally {
        setIsLoading(false);
      }
    };

    initAuth();
  }, []);

  const login = async (credentials: LoginCredentials) => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(credentials),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Login failed');
      }

      const { user: authUser, token: authToken, permissions: userPermissions } = await response.json();

      setUser(authUser);
      setToken(authToken);
      setPermissions(userPermissions);

      // Store in localStorage
      localStorage.setItem('padelo-token', authToken);
      localStorage.setItem('padelo-user', JSON.stringify(authUser));

    } catch (error) {
      console.error('Login error:', error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (data: RegisterData) => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/auth/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Registration failed');
      }

      const { user: authUser, token: authToken, permissions: userPermissions } = await response.json();

      setUser(authUser);
      setToken(authToken);
      setPermissions(userPermissions);

      // Store in localStorage
      localStorage.setItem('padelo-token', authToken);
      localStorage.setItem('padelo-user', JSON.stringify(authUser));

    } catch (error) {
      console.error('Registration error:', error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    setUser(null);
    setToken(null);
    setPermissions(null);
    localStorage.removeItem('padelo-token');
    localStorage.removeItem('padelo-user');
    
    // Optional: Call logout endpoint to invalidate token on server
    if (token) {
      fetch('/api/auth/logout', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      }).catch(console.error);
    }
  };

  const updateProfile = async (profileData: Partial<UserProfile>) => {
    if (!token || !user) {
      throw new Error('Not authenticated');
    }

    try {
      const response = await fetch('/api/auth/profile', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(profileData),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Profile update failed');
      }

      const updatedUser = await response.json();
      setUser(updatedUser);
      localStorage.setItem('padelo-user', JSON.stringify(updatedUser));

    } catch (error) {
      console.error('Profile update error:', error);
      throw error;
    }
  };

  const changePassword = async (data: ChangePassword) => {
    if (!token) {
      throw new Error('Not authenticated');
    }

    try {
      const response = await fetch('/api/auth/change-password', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Password change failed');
      }

    } catch (error) {
      console.error('Password change error:', error);
      throw error;
    }
  };

  const requestPasswordReset = async (data: PasswordResetRequest) => {
    try {
      const response = await fetch('/api/auth/forgot-password', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Password reset request failed');
      }

    } catch (error) {
      console.error('Password reset request error:', error);
      throw error;
    }
  };

  const resetPassword = async (data: PasswordReset) => {
    try {
      const response = await fetch('/api/auth/reset-password', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Password reset failed');
      }

    } catch (error) {
      console.error('Password reset error:', error);
      throw error;
    }
  };

  const value: AuthContextType = {
    user,
    token,
    permissions,
    isLoading,
    isAuthenticated,
    login,
    register,
    logout,
    updateProfile,
    changePassword,
    requestPasswordReset,
    resetPassword,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}

// Hook for checking specific permissions
export function usePermission(permission: keyof UserPermissions) {
  const { permissions } = useAuth();
  return permissions?.[permission] ?? false;
}

// HOC for role-based access control
export function withAuth<P extends object>(
  Component: React.ComponentType<P>,
  requiredPermission?: keyof UserPermissions
) {
  return function AuthenticatedComponent(props: P) {
    const { isAuthenticated, isLoading, permissions } = useAuth();

    if (isLoading) {
      return (
        <div className="flex items-center justify-center min-h-screen">
          <div className="text-center">
            <div className="w-8 h-8 border-2 border-green-500 border-t-transparent rounded-full animate-spin mx-auto mb-2"></div>
            <p className="text-gray-600">Loading...</p>
          </div>
        </div>
      );
    }

    if (!isAuthenticated) {
      return (
        <div className="flex items-center justify-center min-h-screen p-4">
          <div className="text-center">
            <h2 className="text-xl font-semibold text-black mb-2">Authentication Required</h2>
            <p className="text-gray-600 mb-4">Please log in to access this feature</p>
            {/* This would redirect to login page in a real app */}
          </div>
        </div>
      );
    }

    if (requiredPermission && !permissions?.[requiredPermission]) {
      return (
        <div className="flex items-center justify-center min-h-screen p-4">
          <div className="text-center">
            <h2 className="text-xl font-semibold text-black mb-2">Access Denied</h2>
            <p className="text-gray-600">You don't have permission to access this feature</p>
          </div>
        </div>
      );
    }

    return <Component {...props} />;
  };
}
