import React from 'react';
import { Monitor, Moon, Sun } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { useTheme } from '../contexts/ThemeContext';

type ThemeOption = 'light' | 'dark' | 'system';

export const ThemeSettings: React.FC = () => {
  const { theme, setTheme } = useTheme();
  
  const themeOptions: Array<{
    value: ThemeOption;
    label: string;
    description: string;
    icon: React.ComponentType<{ className?: string }>;
  }> = [
    {
      value: 'light',
      label: 'Light Mode',
      description: 'Clean and bright interface',
      icon: Sun,
    },
    {
      value: 'dark',
      label: 'Dark Mode',
      description: 'Easy on the eyes in low light',
      icon: Moon,
    },
    {
      value: 'system',
      label: 'System Default',
      description: 'Follows your device settings',
      icon: Monitor,
    },
  ];

  const handleThemeChange = (newTheme: ThemeOption) => {
    if (newTheme === 'system') {
      // For system theme, check the current system preference
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      setTheme(prefersDark ? 'dark' : 'light');
      localStorage.setItem('padelo-theme-preference', 'system');
    } else {
      setTheme(newTheme);
      localStorage.setItem('padelo-theme-preference', newTheme);
    }
  };

  const getCurrentThemePreference = (): ThemeOption => {
    const saved = localStorage.getItem('padelo-theme-preference') as ThemeOption;
    return saved || 'system';
  };

  const currentPreference = getCurrentThemePreference();

  return (
    <Card className="p-6">
      <div className="space-y-4">
        <div>
          <h3 className="text-lg font-semibold text-black dark:text-white mb-2">Theme Preference</h3>
          <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
            Choose how Padelo looks to you. Select a single theme, or sync with your system and automatically switch between day and night themes.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {themeOptions.map((option) => {
            const Icon = option.icon;
            const isSelected = currentPreference === option.value;

            return (
              <button
                key={option.value}
                onClick={() => handleThemeChange(option.value)}
                className={`
                  relative p-4 rounded-lg border-2 transition-all duration-200 text-left
                  ${
                    isSelected
                      ? 'border-green-500 bg-green-50 dark:bg-green-900/30'
                      : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600 bg-white dark:bg-gray-800'
                  }
                `}
              >
                <div className="flex items-start space-x-3">
                  <div
                    className={`
                      p-2 rounded-full
                      ${
                        isSelected
                          ? 'bg-green-100 dark:bg-green-800'
                          : 'bg-gray-100 dark:bg-gray-700'
                      }
                    `}
                  >
                    <Icon
                      className={`
                        w-5 h-5
                        ${
                          isSelected
                            ? 'text-green-600 dark:text-green-400'
                            : 'text-gray-600 dark:text-gray-400'
                        }
                      `}
                    />
                  </div>
                  <div className="flex-1">
                    <h4
                      className={`
                        font-medium
                        ${
                          isSelected
                            ? 'text-green-700 dark:text-green-300'
                            : 'text-gray-900 dark:text-gray-100'
                        }
                      `}
                    >
                      {option.label}
                    </h4>
                    <p
                      className={`
                        text-sm mt-1
                        ${
                          isSelected
                            ? 'text-green-600 dark:text-green-400'
                            : 'text-gray-500 dark:text-gray-400'
                        }
                      `}
                    >
                      {option.description}
                    </p>
                  </div>
                </div>

                {isSelected && (
                  <div className="absolute top-2 right-2">
                    <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                  </div>
                )}
              </button>
            );
          })}
        </div>

        <div className="pt-4 border-t border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-600 dark:text-gray-400">
              Current theme: {theme === 'dark' ? 'Dark Mode' : 'Light Mode'}
            </span>
            <span className="text-gray-500 dark:text-gray-500">
              Preference: {currentPreference === 'system' ? 'System Default' : currentPreference === 'dark' ? 'Dark Mode' : 'Light Mode'}
            </span>
          </div>
        </div>
      </div>
    </Card>
  );
};
