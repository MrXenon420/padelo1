import { Link, useLocation } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import {
  Home,
  Trophy,
  MapPin,
  GraduationCap,
  ShoppingBag,
  Users,
  User
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { ThemeToggle } from './ThemeToggle';

const navigationItems = [
  {
    key: 'home',
    icon: Home,
    path: '/',
  },
  {
    key: 'tournaments',
    icon: Trophy,
    path: '/tournaments',
  },
  {
    key: 'courts',
    icon: MapPin,
    path: '/courts',
  },
  {
    key: 'training',
    icon: GraduationCap,
    path: '/training',
  },
  {
    key: 'marketplace',
    icon: ShoppingBag,
    path: '/marketplace',
  },
  {
    key: 'matches',
    icon: Users,
    path: '/matches',
  },
  {
    key: 'profile',
    icon: User,
    path: '/profile',
  }
];

export function BottomNavigation() {
  const location = useLocation();
  const { t } = useTranslation();

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 safe-area-pb">
      <div className="flex items-center justify-around px-2 py-2">
        {navigationItems.map((item) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.path;

          return (
            <Link
              key={item.key}
              to={item.path}
              className={cn(
                "flex flex-col items-center justify-center px-2 py-1 rounded-lg transition-colors min-w-0 flex-1",
                isActive
                  ? "text-green-500 bg-green-50 dark:bg-green-900/30"
                  : "text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300"
              )}
            >
              <Icon
                size={20}
                className={cn(
                  "mb-1",
                  isActive ? "text-green-500" : "text-gray-500 dark:text-gray-400"
                )}
              />
              <span className={cn(
                "text-xs font-medium truncate",
                isActive ? "text-green-500" : "text-gray-500 dark:text-gray-400"
              )}>
                {t(`navigation.${item.key}`)}
              </span>
            </Link>
          );
        })}

        {/* Theme Toggle */}
        <div className="flex items-center justify-center px-2 py-1">
          <ThemeToggle variant="ghost" size="icon" />
        </div>
      </div>
    </nav>
  );
}
