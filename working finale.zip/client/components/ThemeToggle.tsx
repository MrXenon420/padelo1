import React from 'react';
import { Moon, Sun } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useTheme } from '../contexts/ThemeContext';

interface ThemeToggleProps {
  variant?: 'default' | 'outline' | 'ghost';
  size?: 'default' | 'sm' | 'lg' | 'icon';
  showLabel?: boolean;
}

export const ThemeToggle: React.FC<ThemeToggleProps> = ({ 
  variant = 'outline', 
  size = 'icon',
  showLabel = false 
}) => {
  const { theme, toggleTheme } = useTheme();

  return (
    <Button
      variant={variant}
      size={size}
      onClick={toggleTheme}
      className="transition-colors duration-200"
      title={`Switch to ${theme === 'light' ? 'dark' : 'light'} mode`}
    >
      {theme === 'light' ? (
        <>
          <Moon className="h-4 w-4" />
          {showLabel && <span className="ml-2">Dark Mode</span>}
        </>
      ) : (
        <>
          <Sun className="h-4 w-4" />
          {showLabel && <span className="ml-2">Light Mode</span>}
        </>
      )}
    </Button>
  );
};

export const ThemeToggleWithLabel: React.FC = () => {
  const { theme, toggleTheme } = useTheme();

  return (
    <div className="flex items-center justify-between p-4 border border-gray-200 dark:border-gray-700 rounded-lg bg-white dark:bg-gray-800">
      <div className="flex items-center space-x-3">
        <div className="p-2 bg-gray-100 dark:bg-gray-700 rounded-full">
          {theme === 'light' ? (
            <Sun className="w-5 h-5 text-yellow-600 dark:text-yellow-400" />
          ) : (
            <Moon className="w-5 h-5 text-blue-600 dark:text-blue-400" />
          )}
        </div>
        <div>
          <h3 className="font-medium text-black dark:text-white">Theme Preference</h3>
          <p className="text-sm text-gray-600 dark:text-gray-400">
            Choose between light and dark mode
          </p>
        </div>
      </div>
      <div className="flex items-center space-x-2">
        <span className="text-sm text-gray-600 dark:text-gray-400">
          {theme === 'light' ? 'Light' : 'Dark'}
        </span>
        <Button
          variant="outline"
          size="sm"
          onClick={toggleTheme}
          className="bg-white dark:bg-gray-800 border-gray-300 dark:border-gray-600"
        >
          {theme === 'light' ? (
            <>
              <Moon className="w-4 h-4 mr-2" />
              Switch to Dark
            </>
          ) : (
            <>
              <Sun className="w-4 h-4 mr-2" />
              Switch to Light
            </>
          )}
        </Button>
      </div>
    </div>
  );
};
