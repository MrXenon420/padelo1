import { cn } from "@/lib/utils";

interface LogoProps {
  className?: string;
  size?: "sm" | "md" | "lg";
  textOnly?: boolean;
}

export function Logo({ className, size = "md", textOnly = false }: LogoProps) {
  const sizeClasses = {
    sm: "text-lg",
    md: "text-2xl",
    lg: "text-4xl"
  };

  const ballSizes = {
    sm: "w-5 h-5",
    md: "w-8 h-8", 
    lg: "w-12 h-12"
  };

  if (textOnly) {
    return (
      <div className={cn("font-bold text-black", sizeClasses[size], className)}>
        Padel
        <span className="relative inline-block mx-1">
          <span className="text-green-500">O</span>
        </span>
      </div>
    );
  }

  return (
    <div className={cn("flex items-center space-x-2", className)}>
      {/* Padel Ball Icon */}
      <div className={cn("relative flex items-center justify-center", ballSizes[size])}>
        <svg
          viewBox="0 0 24 24"
          fill="none"
          className="w-full h-full"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Main ball circle */}
          <circle
            cx="12"
            cy="12"
            r="10"
            fill="#099c37"
            stroke="#087830"
            strokeWidth="1"
          />
          {/* Padel ball pattern - curved lines */}
          <path
            d="M7 7 C9 9, 15 9, 17 7"
            stroke="white"
            strokeWidth="1.5"
            fill="none"
            strokeLinecap="round"
          />
          <path
            d="M7 17 C9 15, 15 15, 17 17"
            stroke="white"
            strokeWidth="1.5"
            fill="none"
            strokeLinecap="round"
          />
          <path
            d="M12 4 C12 8, 12 16, 12 20"
            stroke="white"
            strokeWidth="1.5"
            fill="none"
            strokeLinecap="round"
          />
        </svg>
      </div>
      
      {/* Text */}
      <div className={cn("font-bold text-black", sizeClasses[size])}>
        Padel
        <span className="text-green-500">o</span>
      </div>
    </div>
  );
}
