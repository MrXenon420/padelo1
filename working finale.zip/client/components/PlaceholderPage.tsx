import { useTranslation } from 'react-i18next';
import { Construction } from "lucide-react";
import { Button } from "./ui/button";

interface PlaceholderPageProps {
  title: string;
  description?: string;
}

export function PlaceholderPage({ title, description }: PlaceholderPageProps) {
  const { t } = useTranslation();

  return (
    <div className="min-h-[60vh] flex items-center justify-center p-4">
      <div className="text-center space-y-6 max-w-md mx-auto">
        <div className="mx-auto w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center">
          <Construction className="w-8 h-8 text-green-500" />
        </div>

        <div className="space-y-2">
          <h1 className="text-2xl font-bold text-black">{title}</h1>
          <p className="text-gray-600">
            {description || "This page is coming soon! We're working hard to bring you this feature."}
          </p>
        </div>

        <div className="space-y-3">
          <p className="text-sm text-gray-500">
            Continue prompting to help build out this page's content.
          </p>
          <Button
            variant="outline"
            onClick={() => window.history.back()}
            className="border-green-500 text-green-600 hover:bg-green-50"
          >
            {t('common.back')}
          </Button>
        </div>
      </div>
    </div>
  );
}
