import "./global.css";
import "./i18n/config";

import { useState, useEffect } from "react";
import { Toaster } from "@/components/ui/toaster";
import { createRoot } from "react-dom/client";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { BottomNavigation } from "./components/BottomNavigation";
import { LanguageSelection } from "./pages/LanguageSelection";
import { PlaceholderPage } from "./components/PlaceholderPage";
import { RoleAuthProvider, useAuth } from "./contexts/RoleAuthContext";
import { ThemeProvider } from "./contexts/ThemeContext";
import Index from "./pages/Index";
import Tournaments from "./pages/Tournaments";
import Courts from "./pages/Courts";
import Training from "./pages/Training";
import Marketplace from "./pages/Marketplace";
import Matches from "./pages/Matches";
import Profile from "./pages/Profile";
import Support from "./pages/Support";
import Admin from "./pages/Admin";
import Login from "./pages/Login";
import Register from "./pages/Register";
import NotFound from "./pages/NotFound";
import PrivacyPolicy from "./pages/PrivacyPolicy";
import TermsOfService from "./pages/TermsOfService";
import AppUsagePolicy from "./pages/AppUsagePolicy";

const queryClient = new QueryClient();

// Protected Routes Component
const ProtectedRoutes = () => {
  const { isAuthenticated, isLoading, canAccessRoute } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-500 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  return (
    <>
      <div className="pb-16">
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/tournaments" element={<Tournaments />} />
          <Route path="/courts" element={<Courts />} />
          <Route path="/training" element={<Training />} />
          <Route path="/marketplace" element={<Marketplace />} />
          <Route path="/matches" element={<Matches />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/support" element={<Support />} />
          <Route path="/admin" element={
            canAccessRoute('/admin') ? <Admin /> : <Navigate to="/" replace />
          } />
          <Route path="/community" element={<PlaceholderPage title="Community" description="Connect with other players." />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </div>
      <BottomNavigation />
    </>
  );
};

const App = () => {
  const [languageSelected, setLanguageSelected] = useState(false);

  useEffect(() => {
    const hasSelectedLanguage = localStorage.getItem('padelo-language-selected');
    if (hasSelectedLanguage) {
      setLanguageSelected(true);
    }
  }, []);

  if (!languageSelected) {
    return <LanguageSelection onLanguageSelected={() => setLanguageSelected(true)} />;
  }

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <ThemeProvider>
          <RoleAuthProvider>
            <BrowserRouter>
              <Routes>
                <Route path="/login" element={<Login />} />
                <Route path="/register" element={<Register />} />
                <Route path="/privacy-policy" element={<PrivacyPolicy />} />
                <Route path="/terms-of-service" element={<TermsOfService />} />
                <Route path="/app-usage-policy" element={<AppUsagePolicy />} />
                <Route path="/*" element={<ProtectedRoutes />} />
              </Routes>
            </BrowserRouter>
          </RoleAuthProvider>
        </ThemeProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
};

createRoot(document.getElementById("root")!).render(<App />);
