import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { 
  MapPin, 
  Clock, 
  Star, 
  DollarSign,
  Calendar,
  Filter,
  Plus,
  Zap,
  CheckCircle,
  AlertCircle,
  Search,
  Heart,
  Share
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

export default function Courts() {
  const { t } = useTranslation();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [selectedLocation, setSelectedLocation] = useState('all');

  // Mock data - in real app this would come from API
  const courts = [
    {
      id: '1',
      name: 'Elite Padel Club',
      location: {
        address: 'New Cairo, Cairo',
        city: 'Cairo',
        coordinates: { lat: 30.0444, lng: 31.2357 }
      },
      hourlyRate: 80,
      rating: 4.8,
      reviewCount: 156,
      images: ['/court1.jpg'],
      amenities: ['Parking', 'Changing Rooms', 'Refreshments', 'Equipment Rental'],
      isActive: true,
      cancellationRate: 2,
      badges: ['Reliable Court'],
      distance: 2.3,
      availableSlots: [
        { startTime: '14:00', endTime: '16:00', price: 80, isOnSale: false },
        { startTime: '16:00', endTime: '18:00', price: 100, isOnSale: false },
        { startTime: '18:00', endTime: '20:00', price: 70, isOnSale: true, salePrice: 55, salePercentage: 20 }
      ]
    },
    {
      id: '2',
      name: 'Sports Complex Arena',
      location: {
        address: 'Zamalek, Cairo',
        city: 'Cairo',
        coordinates: { lat: 30.0626, lng: 31.2497 }
      },
      hourlyRate: 60,
      rating: 4.5,
      reviewCount: 89,
      images: ['/court2.jpg'],
      amenities: ['Parking', 'Changing Rooms', 'Cafe'],
      isActive: true,
      cancellationRate: 0,
      badges: ['Reliable Court', 'Best Value'],
      distance: 5.1,
      availableSlots: [
        { startTime: '10:00', endTime: '12:00', price: 60, isOnSale: false },
        { startTime: '12:00', endTime: '14:00', price: 60, isOnSale: false },
        { startTime: '20:00', endTime: '22:00', price: 50, isOnSale: true, salePrice: 35, salePercentage: 30 }
      ]
    }
  ];

  const nearExpiringSlots = [
    {
      courtId: '1',
      courtName: 'Elite Padel Club',
      date: selectedDate,
      startTime: '18:00',
      endTime: '20:00',
      originalPrice: 100,
      salePrice: 70,
      discountPercentage: 30,
      hoursUntilExpiry: 6,
      location: 'New Cairo'
    },
    {
      courtId: '2',
      courtName: 'Sports Complex Arena',
      date: selectedDate,
      startTime: '20:00',
      endTime: '22:00',
      originalPrice: 80,
      salePrice: 50,
      discountPercentage: 37,
      hoursUntilExpiry: 8,
      location: 'Zamalek'
    }
  ];

  const userBookings = [
    {
      id: '1',
      courtName: 'Elite Padel Club',
      date: '2024-03-20',
      startTime: '16:00',
      endTime: '18:00',
      totalAmount: 160,
      status: 'confirmed'
    },
    {
      id: '2',
      courtName: 'Sports Complex Arena',
      date: '2024-03-18',
      startTime: '14:00',
      endTime: '16:00',
      totalAmount: 120,
      status: 'completed'
    }
  ];

  const formatTime = (time: string) => {
    return new Date(`2024-01-01T${time}`).toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  };

  const getBadgeColor = (badge: string) => {
    const colors = {
      'Reliable Court': 'bg-green-500 text-white',
      'Best Value': 'bg-blue-500 text-white',
      'Premium': 'bg-purple-500 text-white',
      'New': 'bg-orange-500 text-white'
    };
    return colors[badge as keyof typeof colors] || 'bg-gray-500 text-white';
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 p-4">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-2xl font-bold text-black">{t('courts.title')}</h1>
            <p className="text-gray-600">Find and book the perfect court</p>
          </div>
          <Button className="bg-green-500 hover:bg-green-600 text-white">
            <Plus className="w-4 h-4 mr-2" />
            {t('courts.addCourt')}
          </Button>
        </div>

        {/* Search and Filters */}
        <div className="flex flex-col lg:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Search courts by name or location..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          
          <Input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="w-full lg:w-auto"
          />
          
          <Select value={selectedLocation} onValueChange={setSelectedLocation}>
            <SelectTrigger className="w-full lg:w-[160px]">
              <SelectValue placeholder="Location" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Locations</SelectItem>
              <SelectItem value="cairo">Cairo</SelectItem>
              <SelectItem value="giza">Giza</SelectItem>
              <SelectItem value="alexandria">Alexandria</SelectItem>
            </SelectContent>
          </Select>

          <Button variant="outline">
            <Filter className="w-4 h-4 mr-2" />
            Filters
          </Button>
        </div>
      </div>

      <div className="p-4">
        <Tabs defaultValue="browse" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="browse">Browse Courts</TabsTrigger>
            <TabsTrigger value="deals">Deals</TabsTrigger>
            <TabsTrigger value="my-bookings">My Bookings</TabsTrigger>
          </TabsList>

          <TabsContent value="browse" className="space-y-6 mt-6">
            {/* Court List */}
            <div className="space-y-4">
              {courts.map((court) => (
                <Card key={court.id} className="p-4">
                  <div className="flex flex-col lg:flex-row gap-4">
                    {/* Court Image */}
                    <div className="w-full lg:w-48 h-32 bg-gray-200 rounded-lg flex items-center justify-center">
                      <MapPin className="w-8 h-8 text-gray-400" />
                    </div>

                    {/* Court Details */}
                    <div className="flex-1">
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <div className="flex items-center space-x-2 mb-1">
                            <h3 className="text-lg font-semibold text-black">{court.name}</h3>
                            {court.badges.map((badge) => (
                              <Badge key={badge} className={`text-xs ${getBadgeColor(badge)}`}>
                                {badge === 'Reliable Court' && <CheckCircle className="w-3 h-3 mr-1" />}
                                {badge}
                              </Badge>
                            ))}
                          </div>
                          
                          <div className="flex items-center space-x-4 text-sm text-gray-600 mb-2">
                            <div className="flex items-center">
                              <MapPin className="w-4 h-4 mr-1" />
                              {court.location.address} • {court.distance}km away
                            </div>
                            <div className="flex items-center">
                              <Star className="w-4 h-4 mr-1 fill-current text-yellow-400" />
                              {court.rating} ({court.reviewCount} reviews)
                            </div>
                          </div>

                          <div className="flex items-center space-x-2 mb-3">
                            <DollarSign className="w-4 h-4 text-gray-600" />
                            <span className="text-lg font-semibold text-black">${court.hourlyRate}/hour</span>
                            {court.cancellationRate === 0 && (
                              <span className="text-xs text-green-600">• Zero cancellations</span>
                            )}
                          </div>

                          {/* Amenities */}
                          <div className="flex flex-wrap gap-2 mb-3">
                            {court.amenities.slice(0, 4).map((amenity) => (
                              <Badge key={amenity} variant="outline" className="text-xs">
                                {amenity}
                              </Badge>
                            ))}
                            {court.amenities.length > 4 && (
                              <Badge variant="outline" className="text-xs">
                                +{court.amenities.length - 4} more
                              </Badge>
                            )}
                          </div>
                        </div>

                        <div className="flex space-x-2">
                          <Button variant="outline" size="sm">
                            <Heart className="w-4 h-4" />
                          </Button>
                          <Button variant="outline" size="sm">
                            <Share className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>

                      {/* Available Slots */}
                      <div>
                        <h4 className="text-sm font-medium text-black mb-2">
                          Available today ({new Date(selectedDate).toLocaleDateString()})
                        </h4>
                        <div className="flex flex-wrap gap-2">
                          {court.availableSlots.map((slot, index) => (
                            <Button
                              key={index}
                              variant="outline"
                              size="sm"
                              className={`relative ${slot.isOnSale ? 'border-green-500 bg-green-50' : ''}`}
                            >
                              {slot.isOnSale && (
                                <Zap className="w-3 h-3 absolute -top-1 -right-1 text-green-500" />
                              )}
                              <div className="text-center">
                                <div className="text-xs font-medium">
                                  {formatTime(slot.startTime)} - {formatTime(slot.endTime)}
                                </div>
                                <div className="text-xs">
                                  {slot.isOnSale ? (
                                    <span className="text-green-600">
                                      <span className="line-through text-gray-400">${slot.price}</span> ${slot.salePrice}
                                    </span>
                                  ) : (
                                    <span>${slot.price}</span>
                                  )}
                                </div>
                              </div>
                            </Button>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="deals" className="space-y-6 mt-6">
            {/* Near Expiring Slots */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-black">Limited Time Deals</h2>
                <Badge className="bg-green-500 text-white">
                  <Zap className="w-3 h-3 mr-1" />
                  Flash Sales
                </Badge>
              </div>
              
              <div className="grid gap-4">
                {nearExpiringSlots.map((slot, index) => (
                  <Card key={index} className="p-4 border-green-200 bg-green-50">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-2">
                          <h3 className="font-semibold text-black">{slot.courtName}</h3>
                          <Badge className="bg-green-500 text-white text-xs">
                            {slot.discountPercentage}% OFF
                          </Badge>
                          <Badge variant="outline" className="text-xs border-orange-500 text-orange-600">
                            <Clock className="w-3 h-3 mr-1" />
                            {slot.hoursUntilExpiry}h left
                          </Badge>
                        </div>
                        
                        <div className="flex items-center space-x-4 text-sm text-gray-600 mb-2">
                          <div className="flex items-center">
                            <MapPin className="w-4 h-4 mr-1" />
                            {slot.location}
                          </div>
                          <div className="flex items-center">
                            <Calendar className="w-4 h-4 mr-1" />
                            {new Date(slot.date).toLocaleDateString()}
                          </div>
                          <div className="flex items-center">
                            <Clock className="w-4 h-4 mr-1" />
                            {formatTime(slot.startTime)} - {formatTime(slot.endTime)}
                          </div>
                        </div>

                        <div className="flex items-center space-x-2">
                          <span className="text-lg font-bold text-green-600">${slot.salePrice}</span>
                          <span className="text-sm text-gray-500 line-through">${slot.originalPrice}</span>
                          <span className="text-sm text-green-600">Save ${slot.originalPrice - slot.salePrice}</span>
                        </div>
                      </div>

                      <Button className="bg-green-500 hover:bg-green-600 text-white">
                        Book Now
                      </Button>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="my-bookings" className="space-y-6 mt-6">
            {/* User Bookings */}
            <div>
              <h2 className="text-lg font-semibold text-black mb-4">Your Bookings</h2>
              
              <div className="space-y-4">
                {userBookings.map((booking) => (
                  <Card key={booking.id} className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-2">
                          <h3 className="font-semibold text-black">{booking.courtName}</h3>
                          <Badge 
                            className={
                              booking.status === 'confirmed' ? 'bg-green-500 text-white' :
                              booking.status === 'completed' ? 'bg-gray-500 text-white' :
                              'bg-orange-500 text-white'
                            }
                          >
                            {booking.status === 'confirmed' && <CheckCircle className="w-3 h-3 mr-1" />}
                            {booking.status}
                          </Badge>
                        </div>
                        
                        <div className="flex items-center space-x-4 text-sm text-gray-600 mb-2">
                          <div className="flex items-center">
                            <Calendar className="w-4 h-4 mr-1" />
                            {new Date(booking.date).toLocaleDateString()}
                          </div>
                          <div className="flex items-center">
                            <Clock className="w-4 h-4 mr-1" />
                            {formatTime(booking.startTime)} - {formatTime(booking.endTime)}
                          </div>
                          <div className="flex items-center">
                            <DollarSign className="w-4 h-4 mr-1" />
                            ${booking.totalAmount}
                          </div>
                        </div>

                        {booking.status === 'confirmed' && (
                          <div className="flex items-center text-xs text-green-600">
                            <AlertCircle className="w-3 h-3 mr-1" />
                            Cancellation allowed until 24h before match time
                          </div>
                        )}
                      </div>

                      <div className="flex space-x-2">
                        {booking.status === 'confirmed' && (
                          <>
                            <Button variant="outline" size="sm">
                              Cancel
                            </Button>
                            <Button size="sm" className="bg-green-500 hover:bg-green-600 text-white">
                              View QR
                            </Button>
                          </>
                        )}
                        {booking.status === 'completed' && (
                          <Button variant="outline" size="sm">
                            Rate Court
                          </Button>
                        )}
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
