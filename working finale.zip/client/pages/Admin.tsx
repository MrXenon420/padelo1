import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { 
  Users,
  Building,
  Trophy,
  DollarSign,
  BarChart3,
  Settings,
  Shield,
  AlertTriangle,
  CheckCircle,
  Clock,
  TrendingUp,
  TrendingDown,
  User,
  Calendar,
  MapPin,
  Phone,
  Mail,
  Edit,
  Trash2,
  Plus,
  Download,
  Upload,
  Filter,
  Search,
  Eye,
  Ban,
  Unlock,
  Star,
  Flag,
  MessageCircle,
  FileText,
  Activity,
  Database,
  Zap,
  Target,
  Award,
  Crown,
  Briefcase
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Progress } from '@/components/ui/progress';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';

export default function Admin() {
  const { t } = useTranslation();
  const [selectedTimeRange, setSelectedTimeRange] = useState('30d');
  const [searchQuery, setSearchQuery] = useState('');

  // Mock current admin user
  const currentAdmin = {
    id: 'admin1',
    name: 'Ibrahim Abada',
    role: 'owner', // owner, court_owner, tournament_organizer, coach, super_admin
    permissions: ['all'],
    avatar: '/admin.jpg'
  };

  // Mock analytics data
  const analytics = {
    overview: {
      totalUsers: 12847,
      totalCourts: 156,
      totalTournaments: 89,
      totalRevenue: 284650,
      growthMetrics: {
        users: { value: 15.3, trend: 'up' },
        revenue: { value: 8.7, trend: 'up' },
        bookings: { value: -2.1, trend: 'down' },
        tournaments: { value: 12.4, trend: 'up' }
      }
    },
    recentActivity: [
      {
        id: '1',
        type: 'user_registration',
        description: 'New user registered: Ahmed Hassan',
        timestamp: '2024-03-20T14:30:00Z',
        severity: 'info'
      },
      {
        id: '2',
        type: 'tournament_created',
        description: 'Tournament "Spring Championship" created by Elite Padel Club',
        timestamp: '2024-03-20T14:15:00Z',
        severity: 'success'
      },
      {
        id: '3',
        type: 'payment_issue',
        description: 'Payment failed for court booking #12834',
        timestamp: '2024-03-20T13:45:00Z',
        severity: 'warning'
      },
      {
        id: '4',
        type: 'court_approval',
        description: 'New court "Sports Arena" pending approval',
        timestamp: '2024-03-20T13:20:00Z',
        severity: 'info'
      }
    ]
  };

  // Mock users data
  const users = [
    {
      id: 'user1',
      name: 'Ahmed Hassan',
      email: 'ahmed.hassan@email.com',
      role: 'player',
      status: 'active',
      joinDate: '2024-01-15',
      lastActive: '2024-03-20T14:30:00Z',
      tier: 'Elite',
      tournamentsWon: 8,
      totalSpent: 1250,
      avatar: '/user1.jpg'
    },
    {
      id: 'user2',
      name: 'Sara Mohamed',
      email: 'sara.mohamed@email.com',
      role: 'coach',
      status: 'active',
      joinDate: '2023-11-22',
      lastActive: '2024-03-20T12:15:00Z',
      tier: 'Advanced',
      tournamentsWon: 3,
      totalSpent: 890,
      avatar: '/user2.jpg'
    },
    {
      id: 'user3',
      name: 'Omar Ali',
      email: 'omar.ali@email.com',
      role: 'court_owner',
      status: 'suspended',
      joinDate: '2023-08-10',
      lastActive: '2024-03-19T18:45:00Z',
      tier: 'Intermediate',
      tournamentsWon: 1,
      totalSpent: 450,
      avatar: '/user3.jpg'
    }
  ];

  // Mock courts data
  const courts = [
    {
      id: 'court1',
      name: 'Elite Padel Club',
      owner: 'Mohamed Farid',
      location: 'New Cairo',
      status: 'active',
      rating: 4.8,
      totalBookings: 1247,
      revenue: 89650,
      lastInspection: '2024-02-15',
      capacity: 4,
      amenities: ['Parking', 'Changing Rooms', 'Cafe']
    },
    {
      id: 'court2',
      name: 'Sports Complex Arena',
      owner: 'Sarah Ahmed',
      location: 'Zamalek',
      status: 'pending',
      rating: 4.5,
      totalBookings: 892,
      revenue: 62340,
      lastInspection: null,
      capacity: 6,
      amenities: ['Parking', 'Changing Rooms']
    }
  ];

  // Mock tournaments data
  const tournaments = [
    {
      id: 'tournament1',
      name: 'Spring Championship',
      organizer: 'Elite Padel Club',
      status: 'upcoming',
      participants: 24,
      maxParticipants: 32,
      entryFee: 50,
      prizePool: 1000,
      startDate: '2024-03-25',
      location: 'New Cairo',
      type: 'official'
    },
    {
      id: 'tournament2',
      name: 'Friday Night Cup',
      organizer: 'Sports Complex',
      status: 'ongoing',
      participants: 16,
      maxParticipants: 16,
      entryFee: 25,
      prizePool: 400,
      startDate: '2024-03-22',
      location: 'Zamalek',
      type: 'unofficial'
    }
  ];

  const getStatusColor = (status: string) => {
    const colors = {
      'active': 'bg-green-500 text-white',
      'inactive': 'bg-gray-500 text-white',
      'suspended': 'bg-red-500 text-white',
      'pending': 'bg-yellow-500 text-white',
      'upcoming': 'bg-blue-500 text-white',
      'ongoing': 'bg-green-500 text-white',
      'completed': 'bg-gray-500 text-white'
    };
    return colors[status as keyof typeof colors] || 'bg-gray-500 text-white';
  };

  const getRoleIcon = (role: string) => {
    const icons = {
      'player': User,
      'coach': Award,
      'court_owner': Building,
      'tournament_organizer': Trophy,
      'owner': Crown,
      'super_admin': Shield
    };
    return icons[role as keyof typeof icons] || User;
  };

  const getSeverityColor = (severity: string) => {
    const colors = {
      'info': 'text-blue-600',
      'success': 'text-green-600',
      'warning': 'text-yellow-600',
      'error': 'text-red-600'
    };
    return colors[severity as keyof typeof colors] || 'text-gray-600';
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  const formatTimeAgo = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)}h ago`;
    return date.toLocaleDateString();
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Admin Header */}
      <div className="bg-white border-b border-gray-200 p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="p-2 bg-green-100 rounded-lg">
              <Shield className="w-6 h-6 text-green-600" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-black">Admin Panel</h1>
              <p className="text-gray-600">Welcome back, {currentAdmin.name}</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-3">
            <Badge className="bg-green-500 text-white">
              <Crown className="w-3 h-3 mr-1" />
              {currentAdmin.role.replace('_', ' ').toUpperCase()}
            </Badge>
            <Select value={selectedTimeRange} onValueChange={setSelectedTimeRange}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7d">Last 7 days</SelectItem>
                <SelectItem value="30d">Last 30 days</SelectItem>
                <SelectItem value="90d">Last 90 days</SelectItem>
                <SelectItem value="1y">Last year</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      <div className="p-4">
        <Tabs defaultValue="dashboard" className="w-full">
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
            <TabsTrigger value="users">Users</TabsTrigger>
            <TabsTrigger value="courts">Courts</TabsTrigger>
            <TabsTrigger value="tournaments">Tournaments</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard" className="space-y-6 mt-6">
            {/* Key Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="p-3 bg-blue-100 rounded-lg">
                    <Users className="w-6 h-6 text-blue-600" />
                  </div>
                  <div className={`flex items-center text-sm ${
                    analytics.overview.growthMetrics.users.trend === 'up' ? 'text-green-600' : 'text-red-600'
                  }`}>
                    {analytics.overview.growthMetrics.users.trend === 'up' ? (
                      <TrendingUp className="w-4 h-4 mr-1" />
                    ) : (
                      <TrendingDown className="w-4 h-4 mr-1" />
                    )}
                    {analytics.overview.growthMetrics.users.value}%
                  </div>
                </div>
                <h3 className="text-2xl font-bold text-black">{analytics.overview.totalUsers.toLocaleString()}</h3>
                <p className="text-gray-600">Total Users</p>
              </Card>

              <Card className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="p-3 bg-green-100 rounded-lg">
                    <DollarSign className="w-6 h-6 text-green-600" />
                  </div>
                  <div className={`flex items-center text-sm ${
                    analytics.overview.growthMetrics.revenue.trend === 'up' ? 'text-green-600' : 'text-red-600'
                  }`}>
                    {analytics.overview.growthMetrics.revenue.trend === 'up' ? (
                      <TrendingUp className="w-4 h-4 mr-1" />
                    ) : (
                      <TrendingDown className="w-4 h-4 mr-1" />
                    )}
                    {analytics.overview.growthMetrics.revenue.value}%
                  </div>
                </div>
                <h3 className="text-2xl font-bold text-black">{formatCurrency(analytics.overview.totalRevenue)}</h3>
                <p className="text-gray-600">Total Revenue</p>
              </Card>

              <Card className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="p-3 bg-purple-100 rounded-lg">
                    <Building className="w-6 h-6 text-purple-600" />
                  </div>
                  <div className="flex items-center text-sm text-green-600">
                    <TrendingUp className="w-4 h-4 mr-1" />
                    12.3%
                  </div>
                </div>
                <h3 className="text-2xl font-bold text-black">{analytics.overview.totalCourts}</h3>
                <p className="text-gray-600">Active Courts</p>
              </Card>

              <Card className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="p-3 bg-yellow-100 rounded-lg">
                    <Trophy className="w-6 h-6 text-yellow-600" />
                  </div>
                  <div className={`flex items-center text-sm ${
                    analytics.overview.growthMetrics.tournaments.trend === 'up' ? 'text-green-600' : 'text-red-600'
                  }`}>
                    {analytics.overview.growthMetrics.tournaments.trend === 'up' ? (
                      <TrendingUp className="w-4 h-4 mr-1" />
                    ) : (
                      <TrendingDown className="w-4 h-4 mr-1" />
                    )}
                    {analytics.overview.growthMetrics.tournaments.value}%
                  </div>
                </div>
                <h3 className="text-2xl font-bold text-black">{analytics.overview.totalTournaments}</h3>
                <p className="text-gray-600">Tournaments</p>
              </Card>
            </div>

            {/* Recent Activity */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-semibold text-black">Recent Activity</h2>
                  <Button variant="outline" size="sm">
                    <Eye className="w-4 h-4 mr-2" />
                    View All
                  </Button>
                </div>
                
                <div className="space-y-4">
                  {analytics.recentActivity.map((activity) => (
                    <div key={activity.id} className="flex items-start space-x-3 p-3 bg-gray-50 rounded-lg">
                      <div className={`p-2 rounded-full ${
                        activity.severity === 'success' ? 'bg-green-100' :
                        activity.severity === 'warning' ? 'bg-yellow-100' :
                        activity.severity === 'error' ? 'bg-red-100' : 'bg-blue-100'
                      }`}>
                        <Activity className={`w-4 h-4 ${getSeverityColor(activity.severity)}`} />
                      </div>
                      <div className="flex-1">
                        <p className="text-sm text-black">{activity.description}</p>
                        <p className="text-xs text-gray-500">{formatTimeAgo(activity.timestamp)}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>

              {/* Quick Actions */}
              <Card className="p-6">
                <h2 className="text-xl font-semibold text-black mb-6">Quick Actions</h2>
                
                <div className="grid grid-cols-2 gap-3">
                  <Button variant="outline" className="h-16 flex-col">
                    <Plus className="w-5 h-5 mb-1" />
                    <span className="text-xs">Add User</span>
                  </Button>
                  <Button variant="outline" className="h-16 flex-col">
                    <Building className="w-5 h-5 mb-1" />
                    <span className="text-xs">Add Court</span>
                  </Button>
                  <Button variant="outline" className="h-16 flex-col">
                    <Trophy className="w-5 h-5 mb-1" />
                    <span className="text-xs">Create Tournament</span>
                  </Button>
                  <Button variant="outline" className="h-16 flex-col">
                    <Download className="w-5 h-5 mb-1" />
                    <span className="text-xs">Export Data</span>
                  </Button>
                  <Button variant="outline" className="h-16 flex-col">
                    <MessageCircle className="w-5 h-5 mb-1" />
                    <span className="text-xs">Send Notice</span>
                  </Button>
                  <Button variant="outline" className="h-16 flex-col">
                    <BarChart3 className="w-5 h-5 mb-1" />
                    <span className="text-xs">View Reports</span>
                  </Button>
                </div>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="users" className="space-y-6 mt-6">
            {/* User Management */}
            <Card className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold text-black">User Management</h2>
                <div className="flex space-x-3">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      placeholder="Search users..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10 w-64"
                    />
                  </div>
                  <Button className="bg-green-500 hover:bg-green-600 text-white">
                    <Plus className="w-4 h-4 mr-2" />
                    Add User
                  </Button>
                </div>
              </div>

              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>User</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Tier</TableHead>
                    <TableHead>Joined</TableHead>
                    <TableHead>Last Active</TableHead>
                    <TableHead>Total Spent</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {users.map((user) => {
                    const RoleIcon = getRoleIcon(user.role);
                    return (
                      <TableRow key={user.id}>
                        <TableCell>
                          <div className="flex items-center space-x-3">
                            <Avatar className="w-10 h-10">
                              <AvatarImage src={user.avatar} />
                              <AvatarFallback>{user.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                            </Avatar>
                            <div>
                              <div className="font-medium text-black">{user.name}</div>
                              <div className="text-sm text-gray-600">{user.email}</div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            <RoleIcon className="w-4 h-4 text-gray-600" />
                            <span className="capitalize">{user.role.replace('_', ' ')}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge className={getStatusColor(user.status)}>
                            {user.status}
                          </Badge>
                        </TableCell>
                        <TableCell>{user.tier}</TableCell>
                        <TableCell>{new Date(user.joinDate).toLocaleDateString()}</TableCell>
                        <TableCell>{formatTimeAgo(user.lastActive)}</TableCell>
                        <TableCell>{formatCurrency(user.totalSpent)}</TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            <Button variant="outline" size="sm">
                              <Eye className="w-4 h-4" />
                            </Button>
                            <Button variant="outline" size="sm">
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button variant="outline" size="sm">
                              {user.status === 'suspended' ? (
                                <Unlock className="w-4 h-4" />
                              ) : (
                                <Ban className="w-4 h-4" />
                              )}
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </Card>
          </TabsContent>

          <TabsContent value="courts" className="space-y-6 mt-6">
            {/* Court Management */}
            <Card className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold text-black">Court Management</h2>
                <Button className="bg-green-500 hover:bg-green-600 text-white">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Court
                </Button>
              </div>

              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Court</TableHead>
                    <TableHead>Owner</TableHead>
                    <TableHead>Location</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Rating</TableHead>
                    <TableHead>Bookings</TableHead>
                    <TableHead>Revenue</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {courts.map((court) => (
                    <TableRow key={court.id}>
                      <TableCell>
                        <div>
                          <div className="font-medium text-black">{court.name}</div>
                          <div className="text-sm text-gray-600">
                            Capacity: {court.capacity} courts
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>{court.owner}</TableCell>
                      <TableCell>
                        <div className="flex items-center">
                          <MapPin className="w-4 h-4 mr-1 text-gray-400" />
                          {court.location}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge className={getStatusColor(court.status)}>
                          {court.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center">
                          <Star className="w-4 h-4 mr-1 text-yellow-400 fill-current" />
                          {court.rating}
                        </div>
                      </TableCell>
                      <TableCell>{court.totalBookings}</TableCell>
                      <TableCell>{formatCurrency(court.revenue)}</TableCell>
                      <TableCell>
                        <div className="flex space-x-2">
                          <Button variant="outline" size="sm">
                            <Eye className="w-4 h-4" />
                          </Button>
                          <Button variant="outline" size="sm">
                            <Edit className="w-4 h-4" />
                          </Button>
                          {court.status === 'pending' && (
                            <Button size="sm" className="bg-green-500 hover:bg-green-600 text-white">
                              <CheckCircle className="w-4 h-4" />
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </Card>
          </TabsContent>

          <TabsContent value="tournaments" className="space-y-6 mt-6">
            {/* Tournament Management */}
            <Card className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold text-black">Tournament Management</h2>
                <Button className="bg-green-500 hover:bg-green-600 text-white">
                  <Plus className="w-4 h-4 mr-2" />
                  Create Tournament
                </Button>
              </div>

              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Tournament</TableHead>
                    <TableHead>Organizer</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Participants</TableHead>
                    <TableHead>Prize Pool</TableHead>
                    <TableHead>Start Date</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {tournaments.map((tournament) => (
                    <TableRow key={tournament.id}>
                      <TableCell>
                        <div>
                          <div className="font-medium text-black">{tournament.name}</div>
                          <div className="text-sm text-gray-600 flex items-center">
                            <MapPin className="w-3 h-3 mr-1" />
                            {tournament.location}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>{tournament.organizer}</TableCell>
                      <TableCell>
                        <Badge variant={tournament.type === 'official' ? 'default' : 'secondary'}>
                          {tournament.type === 'official' && <Zap className="w-3 h-3 mr-1" />}
                          {tournament.type}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge className={getStatusColor(tournament.status)}>
                          {tournament.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center">
                          <Users className="w-4 h-4 mr-1 text-gray-400" />
                          {tournament.participants}/{tournament.maxParticipants}
                        </div>
                      </TableCell>
                      <TableCell>{formatCurrency(tournament.prizePool)}</TableCell>
                      <TableCell>{new Date(tournament.startDate).toLocaleDateString()}</TableCell>
                      <TableCell>
                        <div className="flex space-x-2">
                          <Button variant="outline" size="sm">
                            <Eye className="w-4 h-4" />
                          </Button>
                          <Button variant="outline" size="sm">
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button variant="outline" size="sm">
                            <FileText className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </Card>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6 mt-6">
            {/* Analytics Dashboard */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="p-6">
                <h3 className="text-lg font-semibold text-black mb-4">Revenue Analytics</h3>
                <div className="h-64 bg-gray-50 rounded-lg flex items-center justify-center">
                  <div className="text-center">
                    <BarChart3 className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                    <p className="text-gray-600">Revenue chart visualization</p>
                  </div>
                </div>
              </Card>

              <Card className="p-6">
                <h3 className="text-lg font-semibold text-black mb-4">User Growth</h3>
                <div className="h-64 bg-gray-50 rounded-lg flex items-center justify-center">
                  <div className="text-center">
                    <TrendingUp className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                    <p className="text-gray-600">User growth chart visualization</p>
                  </div>
                </div>
              </Card>

              <Card className="p-6">
                <h3 className="text-lg font-semibold text-black mb-4">Court Utilization</h3>
                <div className="h-64 bg-gray-50 rounded-lg flex items-center justify-center">
                  <div className="text-center">
                    <Target className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                    <p className="text-gray-600">Court utilization chart</p>
                  </div>
                </div>
              </Card>

              <Card className="p-6">
                <h3 className="text-lg font-semibold text-black mb-4">Geographic Distribution</h3>
                <div className="h-64 bg-gray-50 rounded-lg flex items-center justify-center">
                  <div className="text-center">
                    <MapPin className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                    <p className="text-gray-600">Geographic map visualization</p>
                  </div>
                </div>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="settings" className="space-y-6 mt-6">
            {/* System Settings */}
            <Card className="p-6">
              <h2 className="text-xl font-semibold text-black mb-6">System Settings</h2>
              
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-semibold text-black mb-4">Platform Configuration</h3>
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-black mb-2">Platform Name</label>
                      <Input value="Padelo" readOnly />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-black mb-2">Support Email</label>
                      <Input value="support@padelo.com" readOnly />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-black mb-2">Default Currency</label>
                      <Select defaultValue="USD">
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="USD">USD ($)</SelectItem>
                          <SelectItem value="EUR">EUR (€)</SelectItem>
                          <SelectItem value="EGP">EGP (£)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-black mb-2">Timezone</label>
                      <Select defaultValue="UTC+2">
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="UTC+2">Cairo (UTC+2)</SelectItem>
                          <SelectItem value="UTC+0">London (UTC+0)</SelectItem>
                          <SelectItem value="UTC-5">New York (UTC-5)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold text-black mb-4">Features</h3>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium text-black">Tournament System</div>
                        <div className="text-sm text-gray-600">Enable tournament creation and management</div>
                      </div>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input type="checkbox" defaultChecked className="sr-only peer" />
                        <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-green-600"></div>
                      </label>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium text-black">Marketplace</div>
                        <div className="text-sm text-gray-600">Allow users to buy and sell equipment</div>
                      </div>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input type="checkbox" defaultChecked className="sr-only peer" />
                        <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-green-600"></div>
                      </label>
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium text-black">Training System</div>
                        <div className="text-sm text-gray-600">Enable coach booking and training programs</div>
                      </div>
                      <label className="relative inline-flex items-center cursor-pointer">
                        <input type="checkbox" defaultChecked className="sr-only peer" />
                        <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-green-600"></div>
                      </label>
                    </div>
                  </div>
                </div>

                <div className="flex space-x-4 pt-4 border-t border-gray-200">
                  <Button className="bg-green-500 hover:bg-green-600 text-white">
                    Save Settings
                  </Button>
                  <Button variant="outline">
                    Reset to Default
                  </Button>
                </div>
              </div>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
