import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { 
  Users,
  Plus,
  MapPin,
  Calendar,
  Clock,
  Star,
  Target,
  Filter,
  Search,
  User,
  Trophy,
  Zap,
  AlertCircle,
  CheckCircle,
  MessageCircle,
  Phone,
  Share,
  Heart,
  Flag,
  Settings,
  Edit,
  Trash2,
  Copy,
  Eye,
  UserPlus,
  UserMinus,
  Award,
  Shield,
  Crown,
  Medal
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Textarea } from '@/components/ui/textarea';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

export default function Matches() {
  const { t } = useTranslation();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSkillLevel, setSelectedSkillLevel] = useState('all');
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedLocation, setSelectedLocation] = useState('all');

  // Mock current user
  const currentUser = {
    id: 'user123',
    name: 'Ahmed Hassan',
    tier: 'Elite',
    division: 2,
    skillLevel: 'Advanced',
    preferredPosition: 'Right Side',
    avatar: '/user1.jpg'
  };

  // Mock available matches
  const availableMatches = [
    {
      id: 'match1',
      title: 'Elite Division Match',
      description: 'Looking for 2 players for competitive doubles match',
      organizer: {
        id: 'org1',
        name: 'Sara Mohamed',
        avatar: '/user2.jpg',
        tier: 'Elite',
        rating: 4.8,
        verified: true
      },
      skillLevel: 'Advanced',
      requiredTier: 'Elite',
      date: '2024-03-22',
      time: '18:00',
      duration: '1.5 hours',
      location: {
        name: 'Elite Padel Club',
        address: 'New Cairo',
        distance: 2.3
      },
      spotsAvailable: 2,
      totalSpots: 4,
      entryFee: 25,
      gameType: 'doubles',
      isCompetitive: true,
      preferredPositions: ['Left Side', 'Right Side'],
      requirements: ['Intermediate+ level', 'Own equipment required'],
      tags: ['Competitive', 'Elite Level', 'Evening'],
      createdAt: '2024-03-20T10:00:00Z'
    },
    {
      id: 'match2',
      title: 'Casual Friday Game',
      description: 'Friendly doubles match for intermediate players',
      organizer: {
        id: 'org2',
        name: 'Omar Ali',
        avatar: '/user3.jpg',
        tier: 'Advanced',
        rating: 4.5,
        verified: false
      },
      skillLevel: 'Intermediate',
      requiredTier: 'Intermediate',
      date: '2024-03-22',
      time: '15:00',
      duration: '1 hour',
      location: {
        name: 'Sports Complex Arena',
        address: 'Zamalek',
        distance: 5.1
      },
      spotsAvailable: 1,
      totalSpots: 4,
      entryFee: 15,
      gameType: 'doubles',
      isCompetitive: false,
      preferredPositions: ['Any'],
      requirements: ['Beginner+ level'],
      tags: ['Casual', 'Friendly', 'Afternoon'],
      createdAt: '2024-03-19T14:30:00Z'
    },
    {
      id: 'match3',
      title: 'Morning Training Match',
      description: 'Practice match with focus on technique improvement',
      organizer: {
        id: 'org3',
        name: 'Mohamed Farid',
        avatar: '/user4.jpg',
        tier: 'Master',
        rating: 4.9,
        verified: true,
        isCoach: true
      },
      skillLevel: 'Mixed',
      requiredTier: 'Any',
      date: '2024-03-23',
      time: '09:00',
      duration: '2 hours',
      location: {
        name: 'Training Center',
        address: 'Maadi',
        distance: 8.2
      },
      spotsAvailable: 3,
      totalSpots: 6,
      entryFee: 20,
      gameType: 'training',
      isCompetitive: false,
      preferredPositions: ['Any'],
      requirements: ['All levels welcome', 'Coaching included'],
      tags: ['Training', 'Coaching', 'Morning', 'All Levels'],
      createdAt: '2024-03-20T08:15:00Z'
    }
  ];

  // Mock user's matches
  const userMatches = [
    {
      id: 'umatch1',
      title: 'Elite Championship Practice',
      status: 'upcoming',
      date: '2024-03-21',
      time: '16:00',
      location: 'Elite Padel Club',
      players: [
        { name: 'Ahmed Hassan', avatar: '/user1.jpg', isOrganizer: true },
        { name: 'Sara Mohamed', avatar: '/user2.jpg', isOrganizer: false },
        { name: 'Omar Ali', avatar: '/user3.jpg', isOrganizer: false },
        { name: 'Layla Ahmed', avatar: '/user5.jpg', isOrganizer: false }
      ],
      courtBooked: true
    },
    {
      id: 'umatch2',
      title: 'Weekend Casual Game',
      status: 'completed',
      date: '2024-03-16',
      time: '10:00',
      location: 'Sports Complex',
      players: [
        { name: 'Ahmed Hassan', avatar: '/user1.jpg', isOrganizer: false },
        { name: 'Mohamed Farid', avatar: '/user4.jpg', isOrganizer: true },
        { name: 'Sara Ahmed', avatar: '/user6.jpg', isOrganizer: false },
        { name: 'Tarek Ali', avatar: '/user7.jpg', isOrganizer: false }
      ],
      courtBooked: true,
      score: '6-3, 6-4',
      result: 'won'
    }
  ];

  // Mock match requests
  const matchRequests = [
    {
      id: 'req1',
      from: {
        id: 'user456',
        name: 'Layla Ahmed',
        avatar: '/user5.jpg',
        tier: 'Advanced',
        rating: 4.6
      },
      matchId: 'match1',
      matchTitle: 'Elite Division Match',
      message: 'Hi! I\'d love to join your match. I\'m an experienced player with similar skill level.',
      timestamp: '2024-03-20T12:30:00Z',
      status: 'pending'
    },
    {
      id: 'req2',
      from: {
        id: 'user789',
        name: 'Tarek Ali',
        avatar: '/user7.jpg',
        tier: 'Intermediate',
        rating: 4.2
      },
      matchId: 'match2',
      matchTitle: 'Casual Friday Game',
      message: 'Count me in for Friday! Looking forward to a good game.',
      timestamp: '2024-03-20T09:15:00Z',
      status: 'pending'
    }
  ];

  const getTierColor = (tier: string) => {
    const colors = {
      'Rookie': 'bg-gray-500',
      'Beginner': 'bg-green-500',
      'Intermediate': 'bg-blue-500',
      'Advanced': 'bg-purple-500',
      'Elite': 'bg-yellow-500',
      'Master': 'bg-red-500',
      'Pro Players': 'bg-black'
    };
    return colors[tier as keyof typeof colors] || 'bg-gray-500';
  };

  const getTierIcon = (tier: string) => {
    if (tier === 'Pro Players' || tier === 'Master') return Crown;
    if (tier === 'Elite' || tier === 'Advanced') return Award;
    return Medal;
  };

  const getStatusColor = (status: string) => {
    const colors = {
      'upcoming': 'bg-blue-500 text-white',
      'ongoing': 'bg-green-500 text-white',
      'completed': 'bg-gray-500 text-white',
      'cancelled': 'bg-red-500 text-white'
    };
    return colors[status as keyof typeof colors] || 'bg-gray-500 text-white';
  };

  const formatTimeAgo = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)}h ago`;
    return date.toLocaleDateString();
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 p-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-black">Matches</h1>
            <p className="text-gray-600">Create and join padel matches</p>
          </div>
          <Button className="bg-green-500 hover:bg-green-600 text-white">
            <Plus className="w-4 h-4 mr-2" />
            Create Match
          </Button>
        </div>
      </div>

      <div className="p-4">
        <Tabs defaultValue="browse" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="browse">Browse Matches</TabsTrigger>
            <TabsTrigger value="my-matches">My Matches</TabsTrigger>
            <TabsTrigger value="requests">Requests</TabsTrigger>
            <TabsTrigger value="create">Create Match</TabsTrigger>
          </TabsList>

          <TabsContent value="browse" className="space-y-6 mt-6">
            {/* Search and Filters */}
            <Card className="p-4">
              <div className="flex flex-col lg:flex-row gap-3">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    placeholder="Search matches by title or location..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
                
                <Select value={selectedSkillLevel} onValueChange={setSelectedSkillLevel}>
                  <SelectTrigger className="w-full lg:w-[140px]">
                    <SelectValue placeholder="Skill Level" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Levels</SelectItem>
                    <SelectItem value="beginner">Beginner</SelectItem>
                    <SelectItem value="intermediate">Intermediate</SelectItem>
                    <SelectItem value="advanced">Advanced</SelectItem>
                    <SelectItem value="mixed">Mixed</SelectItem>
                  </SelectContent>
                </Select>
                
                <Input
                  type="date"
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  className="w-full lg:w-auto"
                />
                
                <Select value={selectedLocation} onValueChange={setSelectedLocation}>
                  <SelectTrigger className="w-full lg:w-[140px]">
                    <SelectValue placeholder="Location" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Locations</SelectItem>
                    <SelectItem value="cairo">Cairo</SelectItem>
                    <SelectItem value="giza">Giza</SelectItem>
                    <SelectItem value="alexandria">Alexandria</SelectItem>
                  </SelectContent>
                </Select>

                <Button variant="outline">
                  <Filter className="w-4 h-4 mr-2" />
                  More Filters
                </Button>
              </div>
            </Card>

            {/* Available Matches */}
            <div className="space-y-4">
              {availableMatches.map((match) => {
                const TierIcon = getTierIcon(match.organizer.tier);
                return (
                  <Card key={match.id} className="p-6">
                    <div className="flex flex-col lg:flex-row gap-6">
                      {/* Match Details */}
                      <div className="flex-1">
                        <div className="flex items-start justify-between mb-4">
                          <div>
                            <div className="flex items-center space-x-2 mb-2">
                              <h3 className="text-xl font-semibold text-black">{match.title}</h3>
                              {match.isCompetitive && (
                                <Badge className="bg-red-500 text-white">
                                  <Trophy className="w-3 h-3 mr-1" />
                                  Competitive
                                </Badge>
                              )}
                              <Badge variant="outline">
                                {match.gameType}
                              </Badge>
                            </div>
                            
                            <p className="text-gray-700 mb-3">{match.description}</p>
                            
                            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 text-sm text-gray-600 mb-3">
                              <div className="flex items-center">
                                <Calendar className="w-4 h-4 mr-1" />
                                {new Date(match.date).toLocaleDateString()}
                              </div>
                              <div className="flex items-center">
                                <Clock className="w-4 h-4 mr-1" />
                                {match.time} ({match.duration})
                              </div>
                              <div className="flex items-center">
                                <MapPin className="w-4 h-4 mr-1" />
                                {match.location.name}
                              </div>
                              <div className="flex items-center">
                                <Users className="w-4 h-4 mr-1" />
                                {match.spotsAvailable}/{match.totalSpots} spots
                              </div>
                            </div>

                            {/* Requirements */}
                            <div className="mb-3">
                              <h4 className="text-sm font-medium text-black mb-2">Requirements:</h4>
                              <div className="flex flex-wrap gap-2">
                                {match.requirements.map((req, index) => (
                                  <Badge key={index} variant="outline" className="text-xs">
                                    {req}
                                  </Badge>
                                ))}
                              </div>
                            </div>

                            {/* Tags */}
                            <div className="flex flex-wrap gap-2">
                              {match.tags.map((tag) => (
                                <Badge key={tag} variant="secondary" className="text-xs">
                                  {tag}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        </div>

                        {/* Organizer Info */}
                        <div className="flex items-center justify-between border-t border-gray-200 pt-4">
                          <div className="flex items-center space-x-3">
                            <Avatar className="w-12 h-12">
                              <AvatarImage src={match.organizer.avatar} />
                              <AvatarFallback>{match.organizer.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                            </Avatar>
                            <div>
                              <div className="flex items-center space-x-2">
                                <span className="font-medium text-black">{match.organizer.name}</span>
                                {match.organizer.verified && (
                                  <CheckCircle className="w-4 h-4 text-green-500" />
                                )}
                                {match.organizer.isCoach && (
                                  <Badge className="bg-blue-500 text-white text-xs">
                                    <Award className="w-3 h-3 mr-1" />
                                    Coach
                                  </Badge>
                                )}
                              </div>
                              <div className="flex items-center space-x-3 text-sm text-gray-600">
                                <Badge className={`${getTierColor(match.organizer.tier)} text-white text-xs`}>
                                  <TierIcon className="w-3 h-3 mr-1" />
                                  {match.organizer.tier}
                                </Badge>
                                <div className="flex items-center">
                                  <Star className="w-3 h-3 mr-1 fill-current text-yellow-400" />
                                  {match.organizer.rating}
                                </div>
                                <span>Posted {formatTimeAgo(match.createdAt)}</span>
                              </div>
                            </div>
                          </div>

                          <div className="text-right">
                            <div className="text-lg font-bold text-black">${match.entryFee}</div>
                            <div className="text-sm text-gray-600">per player</div>
                          </div>
                        </div>
                      </div>

                      {/* Action Section */}
                      <div className="lg:w-64 space-y-4">
                        {/* Availability */}
                        <div className="p-3 bg-green-50 rounded-lg text-center">
                          <div className="text-2xl font-bold text-green-600">
                            {match.spotsAvailable}
                          </div>
                          <div className="text-sm text-green-700">spots available</div>
                        </div>

                        {/* Distance */}
                        <div className="text-center text-sm text-gray-600">
                          <MapPin className="w-4 h-4 mx-auto mb-1" />
                          {match.location.distance}km away
                        </div>

                        {/* Action Buttons */}
                        <div className="space-y-2">
                          <Button 
                            className="w-full bg-green-500 hover:bg-green-600 text-white"
                            disabled={match.spotsAvailable === 0}
                          >
                            <UserPlus className="w-4 h-4 mr-2" />
                            {match.spotsAvailable === 0 ? 'Match Full' : 'Join Match'}
                          </Button>
                          <div className="grid grid-cols-3 gap-2">
                            <Button variant="outline" size="sm">
                              <MessageCircle className="w-4 h-4" />
                            </Button>
                            <Button variant="outline" size="sm">
                              <Heart className="w-4 h-4" />
                            </Button>
                            <Button variant="outline" size="sm">
                              <Share className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          <TabsContent value="my-matches" className="space-y-6 mt-6">
            {/* User's Matches */}
            <div className="space-y-4">
              {userMatches.map((match) => (
                <Card key={match.id} className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <div className="flex items-center space-x-2 mb-2">
                        <h3 className="text-lg font-semibold text-black">{match.title}</h3>
                        <Badge className={getStatusColor(match.status)}>
                          {match.status}
                        </Badge>
                        {match.courtBooked && (
                          <Badge className="bg-green-500 text-white text-xs">
                            <CheckCircle className="w-3 h-3 mr-1" />
                            Court Booked
                          </Badge>
                        )}
                      </div>
                      
                      <div className="flex items-center space-x-4 text-sm text-gray-600 mb-3">
                        <div className="flex items-center">
                          <Calendar className="w-4 h-4 mr-1" />
                          {new Date(match.date).toLocaleDateString()}
                        </div>
                        <div className="flex items-center">
                          <Clock className="w-4 h-4 mr-1" />
                          {match.time}
                        </div>
                        <div className="flex items-center">
                          <MapPin className="w-4 h-4 mr-1" />
                          {match.location}
                        </div>
                      </div>

                      {match.status === 'completed' && match.score && (
                        <div className="flex items-center space-x-2 mb-3">
                          <Badge className={match.result === 'won' ? 'bg-green-500 text-white' : 'bg-red-500 text-white'}>
                            {match.result === 'won' ? 'Victory' : 'Defeat'}
                          </Badge>
                          <span className="text-sm text-gray-600">Score: {match.score}</span>
                        </div>
                      )}

                      {/* Players */}
                      <div className="flex items-center space-x-2">
                        <span className="text-sm font-medium text-black">Players:</span>
                        <div className="flex -space-x-2">
                          {match.players.map((player, index) => (
                            <Avatar key={index} className="w-8 h-8 border-2 border-white">
                              <AvatarImage src={player.avatar} />
                              <AvatarFallback className="text-xs">
                                {player.name.split(' ').map(n => n[0]).join('')}
                              </AvatarFallback>
                            </Avatar>
                          ))}
                        </div>
                      </div>
                    </div>

                    <div className="flex space-x-2">
                      {match.status === 'upcoming' && (
                        <>
                          <Button variant="outline" size="sm">
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button variant="outline" size="sm">
                            <MessageCircle className="w-4 h-4" />
                          </Button>
                        </>
                      )}
                      <Button variant="outline" size="sm">
                        <Eye className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="requests" className="space-y-6 mt-6">
            {/* Match Requests */}
            <Card className="p-6">
              <h2 className="text-xl font-semibold text-black mb-6">Match Requests</h2>
              
              <div className="space-y-4">
                {matchRequests.map((request) => (
                  <div key={request.id} className="p-4 border border-gray-200 rounded-lg">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start space-x-3 flex-1">
                        <Avatar className="w-12 h-12">
                          <AvatarImage src={request.from.avatar} />
                          <AvatarFallback>{request.from.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                        </Avatar>
                        
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-1">
                            <span className="font-medium text-black">{request.from.name}</span>
                            <Badge className={`${getTierColor(request.from.tier)} text-white text-xs`}>
                              {request.from.tier}
                            </Badge>
                            <div className="flex items-center text-sm text-gray-600">
                              <Star className="w-3 h-3 mr-1 fill-current text-yellow-400" />
                              {request.from.rating}
                            </div>
                          </div>
                          
                          <p className="text-sm text-gray-600 mb-2">
                            Wants to join: <span className="font-medium text-black">{request.matchTitle}</span>
                          </p>
                          
                          <p className="text-sm text-gray-700 mb-2">{request.message}</p>
                          
                          <p className="text-xs text-gray-500">{formatTimeAgo(request.timestamp)}</p>
                        </div>
                      </div>
                      
                      <div className="flex space-x-2">
                        <Button size="sm" className="bg-green-500 hover:bg-green-600 text-white">
                          <CheckCircle className="w-4 h-4 mr-2" />
                          Accept
                        </Button>
                        <Button variant="outline" size="sm">
                          Decline
                        </Button>
                        <Button variant="outline" size="sm">
                          <MessageCircle className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="create" className="space-y-6 mt-6">
            {/* Create Match Form */}
            <Card className="p-6">
              <h2 className="text-xl font-semibold text-black mb-6">Create New Match</h2>
              
              <div className="space-y-6">
                {/* Basic Information */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-black mb-2">Match Title *</label>
                    <Input placeholder="e.g., Elite Division Match" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-black mb-2">Game Type *</label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select game type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="doubles">Doubles</SelectItem>
                        <SelectItem value="singles">Singles</SelectItem>
                        <SelectItem value="training">Training Session</SelectItem>
                        <SelectItem value="tournament">Tournament Practice</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Description */}
                <div>
                  <label className="block text-sm font-medium text-black mb-2">Description *</label>
                  <Textarea 
                    placeholder="Describe your match, what you're looking for in players, and any special requirements..."
                    rows={3}
                  />
                </div>

                {/* Date and Time */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-black mb-2">Date *</label>
                    <Input type="date" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-black mb-2">Start Time *</label>
                    <Input type="time" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-black mb-2">Duration *</label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Duration" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1 hour</SelectItem>
                        <SelectItem value="1.5">1.5 hours</SelectItem>
                        <SelectItem value="2">2 hours</SelectItem>
                        <SelectItem value="2.5">2.5 hours</SelectItem>
                        <SelectItem value="3">3 hours</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Location and Players */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-black mb-2">Location *</label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select court" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="elite-club">Elite Padel Club</SelectItem>
                        <SelectItem value="sports-complex">Sports Complex Arena</SelectItem>
                        <SelectItem value="training-center">Training Center</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-black mb-2">Players Needed *</label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="How many players?" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1 player</SelectItem>
                        <SelectItem value="2">2 players</SelectItem>
                        <SelectItem value="3">3 players</SelectItem>
                        <SelectItem value="4">4 players</SelectItem>
                        <SelectItem value="5">5 players</SelectItem>
                        <SelectItem value="6">6 players</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Requirements */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-black mb-2">Skill Level Required</label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select skill level" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="any">Any Level</SelectItem>
                        <SelectItem value="beginner">Beginner</SelectItem>
                        <SelectItem value="intermediate">Intermediate</SelectItem>
                        <SelectItem value="advanced">Advanced</SelectItem>
                        <SelectItem value="expert">Expert Only</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-black mb-2">Entry Fee ($)</label>
                    <Input type="number" placeholder="0" />
                  </div>
                </div>

                {/* Match Settings */}
                <div>
                  <label className="block text-sm font-medium text-black mb-3">Match Settings</label>
                  <div className="space-y-3">
                    <div className="flex items-center">
                      <input type="checkbox" id="competitive" className="mr-3" />
                      <label htmlFor="competitive" className="text-sm text-black">
                        Competitive match (affects LP and rankings)
                      </label>
                    </div>
                    <div className="flex items-center">
                      <input type="checkbox" id="equipment" className="mr-3" />
                      <label htmlFor="equipment" className="text-sm text-black">
                        Players must bring own equipment
                      </label>
                    </div>
                    <div className="flex items-center">
                      <input type="checkbox" id="autobook" className="mr-3" />
                      <label htmlFor="autobook" className="text-sm text-black">
                        Automatically book court when match is full
                      </label>
                    </div>
                  </div>
                </div>

                {/* Submit */}
                <div className="flex space-x-4">
                  <Button className="bg-green-500 hover:bg-green-600 text-white">
                    <Plus className="w-4 h-4 mr-2" />
                    Create Match
                  </Button>
                  <Button variant="outline">
                    Save as Draft
                  </Button>
                </div>
              </div>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
