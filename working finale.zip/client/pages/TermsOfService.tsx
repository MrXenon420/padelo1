import React from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowLeft, FileText, Gavel, Users, Shield, AlertTriangle, CreditCard } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function TermsOfService() {
  const navigate = useNavigate();

  const handleBackClick = () => {
    if (window.history.length > 1) {
      navigate(-1);
    } else {
      navigate('/');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 dark:from-gray-900 dark:to-gray-800 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-6">
          <Button 
            variant="outline" 
            onClick={handleBackClick}
            className="mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          
          <Card className="p-6">
            <div className="flex items-center mb-4">
              <div className="p-3 bg-green-100 rounded-full mr-4">
                <FileText className="w-8 h-8 text-green-600" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-black">Terms of Service</h1>
                <p className="text-gray-600">Last updated: {new Date().toLocaleDateString()}</p>
              </div>
            </div>
            <p className="text-lg text-gray-700">
              Welcome to Padelo! These terms govern your use of our platform and services. 
              Please read them carefully before using our application.
            </p>
          </Card>
        </div>

        {/* Table of Contents */}
        <Card className="p-6 mb-6">
          <h2 className="text-xl font-semibold text-black mb-4">Table of Contents</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
            <a href="#acceptance" className="text-green-600 hover:text-green-500 py-1">1. Acceptance of Terms</a>
            <a href="#description" className="text-green-600 hover:text-green-500 py-1">2. Service Description</a>
            <a href="#user-accounts" className="text-green-600 hover:text-green-500 py-1">3. User Accounts</a>
            <a href="#user-conduct" className="text-green-600 hover:text-green-500 py-1">4. User Conduct</a>
            <a href="#bookings-payments" className="text-green-600 hover:text-green-500 py-1">5. Bookings and Payments</a>
            <a href="#intellectual-property" className="text-green-600 hover:text-green-500 py-1">6. Intellectual Property</a>
            <a href="#disclaimers" className="text-green-600 hover:text-green-500 py-1">7. Disclaimers</a>
            <a href="#limitation-liability" className="text-green-600 hover:text-green-500 py-1">8. Limitation of Liability</a>
            <a href="#termination" className="text-green-600 hover:text-green-500 py-1">9. Termination</a>
            <a href="#governing-law" className="text-green-600 hover:text-green-500 py-1">10. Governing Law</a>
          </div>
        </Card>

        {/* Terms Content */}
        <div className="space-y-6">
          
          {/* Section 1: Acceptance of Terms */}
          <Card className="p-6" id="acceptance">
            <div className="flex items-center mb-4">
              <Gavel className="w-6 h-6 text-green-600 mr-3" />
              <h2 className="text-2xl font-semibold text-black">1. Acceptance of Terms</h2>
            </div>
            
            <div className="space-y-4 text-gray-700">
              <p>
                By accessing or using the Padelo application ("Service"), you agree to be bound by these Terms of Service ("Terms"). 
                If you disagree with any part of these terms, then you may not access the Service.
              </p>
              
              <div>
                <h3 className="text-lg font-medium text-black mb-2">Agreement Components</h3>
                <ul className="list-disc list-inside space-y-1 ml-4">
                  <li>These Terms of Service</li>
                  <li>Our Privacy Policy</li>
                  <li>Community Guidelines</li>
                  <li>Any additional terms for specific features</li>
                </ul>
              </div>
              
              <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                <p className="text-blue-800">
                  <strong>Age Requirement:</strong> You must be at least 13 years old to use this service. 
                  Users under 18 should have parental consent.
                </p>
              </div>
            </div>
          </Card>

          {/* Section 2: Service Description */}
          <Card className="p-6" id="description">
            <div className="flex items-center mb-4">
              <FileText className="w-6 h-6 text-green-600 mr-3" />
              <h2 className="text-2xl font-semibold text-black">2. Service Description</h2>
            </div>
            
            <div className="space-y-4 text-gray-700">
              <p>
                Padelo is a comprehensive platform for padel enthusiasts that connects players, coaches, court owners, 
                and tournament organizers in one unified ecosystem.
              </p>
              
              <div>
                <h3 className="text-lg font-medium text-black mb-2">Core Services</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <h4 className="font-medium text-black mb-1">For Players</h4>
                    <ul className="list-disc list-inside space-y-1 ml-4 text-sm">
                      <li>Court booking and scheduling</li>
                      <li>Tournament participation</li>
                      <li>Training session booking</li>
                      <li>Equipment marketplace</li>
                      <li>Community networking</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-medium text-black mb-1">For Businesses</h4>
                    <ul className="list-disc list-inside space-y-1 ml-4 text-sm">
                      <li>Court management and bookings</li>
                      <li>Tournament organization</li>
                      <li>Coaching service management</li>
                      <li>Revenue analytics</li>
                      <li>Customer relationship tools</li>
                    </ul>
                  </div>
                </div>
              </div>
              
              <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-200">
                <p className="text-yellow-800">
                  <strong>Service Availability:</strong> We strive to maintain 99.9% uptime but cannot guarantee 
                  uninterrupted service due to maintenance, updates, or external factors beyond our control.
                </p>
              </div>
            </div>
          </Card>

          {/* Section 3: User Accounts */}
          <Card className="p-6" id="user-accounts">
            <div className="flex items-center mb-4">
              <Users className="w-6 h-6 text-green-600 mr-3" />
              <h2 className="text-2xl font-semibold text-black">3. User Accounts</h2>
            </div>
            
            <div className="space-y-4 text-gray-700">
              <div>
                <h3 className="text-lg font-medium text-black mb-2">Account Creation</h3>
                <ul className="list-disc list-inside space-y-1 ml-4">
                  <li>You must provide accurate and complete information during registration</li>
                  <li>All new users are assigned the "Player" role by default</li>
                  <li>Additional roles can only be assigned by platform owners</li>
                  <li>You are responsible for maintaining the confidentiality of your account</li>
                </ul>
              </div>
              
              <div>
                <h3 className="text-lg font-medium text-black mb-2">Account Security</h3>
                <ul className="list-disc list-inside space-y-1 ml-4">
                  <li>Use a strong, unique password for your account</li>
                  <li>Enable two-factor authentication when available</li>
                  <li>Notify us immediately of any unauthorized access</li>
                  <li>You are liable for all activities under your account</li>
                </ul>
              </div>
              
              <div>
                <h3 className="text-lg font-medium text-black mb-2">Account Types and Roles</h3>
                <div className="space-y-2">
                  <div className="flex items-start space-x-3">
                    <div className="w-3 h-3 bg-blue-500 rounded-full mt-2"></div>
                    <div><strong>Player:</strong> Standard user with access to booking, tournaments, and marketplace features.</div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-3 h-3 bg-green-500 rounded-full mt-2"></div>
                    <div><strong>Coach:</strong> Certified instructors who can offer training services and manage students.</div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-3 h-3 bg-purple-500 rounded-full mt-2"></div>
                    <div><strong>Court Owner:</strong> Venue operators who can manage facilities and bookings.</div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-3 h-3 bg-orange-500 rounded-full mt-2"></div>
                    <div><strong>Tournament Organizer:</strong> Event coordinators who can create and manage tournaments.</div>
                  </div>
                </div>
              </div>
            </div>
          </Card>

          {/* Section 4: User Conduct */}
          <Card className="p-6" id="user-conduct">
            <div className="flex items-center mb-4">
              <Shield className="w-6 h-6 text-green-600 mr-3" />
              <h2 className="text-2xl font-semibold text-black">4. User Conduct</h2>
            </div>
            
            <div className="space-y-4 text-gray-700">
              <div>
                <h3 className="text-lg font-medium text-black mb-2">Acceptable Use</h3>
                <ul className="list-disc list-inside space-y-1 ml-4">
                  <li>Use the service for its intended purpose only</li>
                  <li>Respect other users and maintain professional conduct</li>
                  <li>Provide accurate information in bookings and profiles</li>
                  <li>Honor your commitments and booking agreements</li>
                  <li>Report any issues or violations promptly</li>
                </ul>
              </div>
              
              <div>
                <h3 className="text-lg font-medium text-black mb-2">Prohibited Activities</h3>
                <div className="bg-red-50 p-4 rounded-lg border border-red-200">
                  <ul className="list-disc list-inside space-y-1 ml-4 text-red-800">
                    <li>Fraudulent or deceptive practices</li>
                    <li>Harassment, discrimination, or hate speech</li>
                    <li>Sharing false or misleading information</li>
                    <li>Attempting to hack or compromise the platform</li>
                    <li>Creating multiple accounts to circumvent restrictions</li>
                    <li>Commercial spam or unauthorized advertising</li>
                    <li>Violating any applicable laws or regulations</li>
                  </ul>
                </div>
              </div>
              
              <div>
                <h3 className="text-lg font-medium text-black mb-2">Content Guidelines</h3>
                <ul className="list-disc list-inside space-y-1 ml-4">
                  <li>Keep all content appropriate and family-friendly</li>
                  <li>Respect intellectual property rights</li>
                  <li>Do not share personal contact information publicly</li>
                  <li>Use accurate photos in your profile and listings</li>
                </ul>
              </div>
            </div>
          </Card>

          {/* Section 5: Bookings and Payments */}
          <Card className="p-6" id="bookings-payments">
            <div className="flex items-center mb-4">
              <CreditCard className="w-6 h-6 text-green-600 mr-3" />
              <h2 className="text-2xl font-semibold text-black">5. Bookings and Payments</h2>
            </div>
            
            <div className="space-y-4 text-gray-700">
              <div>
                <h3 className="text-lg font-medium text-black mb-2">Booking Terms</h3>
                <ul className="list-disc list-inside space-y-1 ml-4">
                  <li>All bookings are subject to availability and confirmation</li>
                  <li>Court owners set their own pricing and availability</li>
                  <li>You agree to arrive on time for your reserved sessions</li>
                  <li>No-shows may result in charges and account restrictions</li>
                </ul>
              </div>
              
              <div>
                <h3 className="text-lg font-medium text-black mb-2">Payment Processing</h3>
                <ul className="list-disc list-inside space-y-1 ml-4">
                  <li>All payments are processed through secure third-party providers</li>
                  <li>We do not store credit card information on our servers</li>
                  <li>Payment is required at the time of booking confirmation</li>
                  <li>Additional fees may apply for premium services</li>
                </ul>
              </div>
              
              <div>
                <h3 className="text-lg font-medium text-black mb-2">Cancellations and Refunds</h3>
                <div className="space-y-2">
                  <div className="flex items-start space-x-3">
                    <div className="w-3 h-3 bg-green-500 rounded-full mt-2"></div>
                    <div><strong>24+ hours:</strong> Full refund available</div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-3 h-3 bg-yellow-500 rounded-full mt-2"></div>
                    <div><strong>2-24 hours:</strong> 50% refund (subject to court owner policy)</div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-3 h-3 bg-red-500 rounded-full mt-2"></div>
                    <div><strong>Less than 2 hours:</strong> No refund available</div>
                  </div>
                </div>
                <p className="text-sm mt-2">Individual court owners may have different cancellation policies, which will be clearly displayed at booking time.</p>
              </div>
            </div>
          </Card>

          {/* Section 6: Intellectual Property */}
          <Card className="p-6" id="intellectual-property">
            <div className="flex items-center mb-4">
              <FileText className="w-6 h-6 text-green-600 mr-3" />
              <h2 className="text-2xl font-semibold text-black">6. Intellectual Property</h2>
            </div>
            
            <div className="space-y-4 text-gray-700">
              <div>
                <h3 className="text-lg font-medium text-black mb-2">Our Rights</h3>
                <ul className="list-disc list-inside space-y-1 ml-4">
                  <li>The Padelo platform, logo, and branding are our property</li>
                  <li>All software, designs, and functionality are protected by copyright</li>
                  <li>Users may not copy, modify, or distribute our intellectual property</li>
                  <li>We reserve all rights not expressly granted to users</li>
                </ul>
              </div>
              
              <div>
                <h3 className="text-lg font-medium text-black mb-2">User Content</h3>
                <ul className="list-disc list-inside space-y-1 ml-4">
                  <li>You retain ownership of content you create and upload</li>
                  <li>By uploading content, you grant us a license to use it for service operation</li>
                  <li>You represent that you have the right to share any content you upload</li>
                  <li>We may remove content that violates these terms or applicable laws</li>
                </ul>
              </div>
              
              <div>
                <h3 className="text-lg font-medium text-black mb-2">Third-Party Content</h3>
                <ul className="list-disc list-inside space-y-1 ml-4">
                  <li>Respect copyrights and trademarks of third parties</li>
                  <li>Only use images and content you have permission to use</li>
                  <li>Report any copyright violations to our support team</li>
                  <li>We will respond to valid DMCA takedown requests</li>
                </ul>
              </div>
            </div>
          </Card>

          {/* Section 7: Disclaimers */}
          <Card className="p-6" id="disclaimers">
            <div className="flex items-center mb-4">
              <AlertTriangle className="w-6 h-6 text-green-600 mr-3" />
              <h2 className="text-2xl font-semibold text-black">7. Disclaimers</h2>
            </div>
            
            <div className="space-y-4 text-gray-700">
              <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-200">
                <p className="text-yellow-800 mb-2">
                  <strong>IMPORTANT:</strong> The following disclaimers limit our liability and your remedies:
                </p>
              </div>
              
              <div>
                <h3 className="text-lg font-medium text-black mb-2">Service Disclaimers</h3>
                <ul className="list-disc list-inside space-y-1 ml-4">
                  <li>The service is provided "as is" without warranties of any kind</li>
                  <li>We do not guarantee continuous, uninterrupted, or error-free operation</li>
                  <li>We are not responsible for third-party content or services</li>
                  <li>Court availability and quality are determined by individual owners</li>
                </ul>
              </div>
              
              <div>
                <h3 className="text-lg font-medium text-black mb-2">Safety and Health</h3>
                <ul className="list-disc list-inside space-y-1 ml-4">
                  <li>Padel is a physical sport with inherent injury risks</li>
                  <li>Players participate at their own risk and responsibility</li>
                  <li>We recommend appropriate insurance coverage for sports activities</li>
                  <li>Courts and equipment safety are the responsibility of venue owners</li>
                </ul>
              </div>
              
              <div>
                <h3 className="text-lg font-medium text-black mb-2">User Interactions</h3>
                <ul className="list-disc list-inside space-y-1 ml-4">
                  <li>We do not screen users or verify their identities</li>
                  <li>Use caution when meeting or interacting with other users</li>
                  <li>We are not responsible for disputes between users</li>
                  <li>Report any concerning behavior to our support team</li>
                </ul>
              </div>
            </div>
          </Card>

          {/* Section 8: Limitation of Liability */}
          <Card className="p-6" id="limitation-liability">
            <div className="flex items-center mb-4">
              <Shield className="w-6 h-6 text-green-600 mr-3" />
              <h2 className="text-2xl font-semibold text-black">8. Limitation of Liability</h2>
            </div>
            
            <div className="space-y-4 text-gray-700">
              <div className="bg-red-50 p-4 rounded-lg border border-red-200">
                <p className="text-red-800 font-medium mb-2">
                  LIMITATION OF LIABILITY NOTICE
                </p>
                <p className="text-red-800 text-sm">
                  To the maximum extent permitted by law, Padelo shall not be liable for any indirect, 
                  incidental, special, consequential, or punitive damages, including without limitation, 
                  loss of profits, data, use, goodwill, or other intangible losses.
                </p>
              </div>
              
              <div>
                <h3 className="text-lg font-medium text-black mb-2">Liability Limits</h3>
                <ul className="list-disc list-inside space-y-1 ml-4">
                  <li>Our total liability is limited to the amount you paid for services in the past 12 months</li>
                  <li>We are not liable for actions or omissions of third-party service providers</li>
                  <li>Force majeure events are excluded from our liability</li>
                  <li>Some jurisdictions do not allow liability limitations, so these may not apply to you</li>
                </ul>
              </div>
              
              <div>
                <h3 className="text-lg font-medium text-black mb-2">Indemnification</h3>
                <p>
                  You agree to indemnify and hold harmless Padelo from any claims, damages, or expenses 
                  arising from your use of the service, violation of these terms, or infringement of any rights.
                </p>
              </div>
            </div>
          </Card>

          {/* Section 9: Termination */}
          <Card className="p-6" id="termination">
            <div className="flex items-center mb-4">
              <AlertTriangle className="w-6 h-6 text-green-600 mr-3" />
              <h2 className="text-2xl font-semibold text-black">9. Termination</h2>
            </div>
            
            <div className="space-y-4 text-gray-700">
              <div>
                <h3 className="text-lg font-medium text-black mb-2">Termination by You</h3>
                <ul className="list-disc list-inside space-y-1 ml-4">
                  <li>You may delete your account at any time through app settings</li>
                  <li>Account deletion is permanent and cannot be undone</li>
                  <li>You remain liable for any outstanding obligations</li>
                  <li>Some information may be retained as required by law</li>
                </ul>
              </div>
              
              <div>
                <h3 className="text-lg font-medium text-black mb-2">Termination by Us</h3>
                <ul className="list-disc list-inside space-y-1 ml-4">
                  <li>We may suspend or terminate accounts for terms violations</li>
                  <li>Serious violations may result in immediate termination</li>
                  <li>We will provide notice when possible, but immediate action may be necessary</li>
                  <li>We may discontinue the service with 30 days' notice</li>
                </ul>
              </div>
              
              <div>
                <h3 className="text-lg font-medium text-black mb-2">Effect of Termination</h3>
                <ul className="list-disc list-inside space-y-1 ml-4">
                  <li>Your right to use the service immediately ceases</li>
                  <li>Pending bookings may be canceled with appropriate refunds</li>
                  <li>Survival clauses continue to apply after termination</li>
                  <li>We may retain some data as required by law or policy</li>
                </ul>
              </div>
            </div>
          </Card>

          {/* Section 10: Governing Law */}
          <Card className="p-6" id="governing-law">
            <div className="flex items-center mb-4">
              <Gavel className="w-6 h-6 text-green-600 mr-3" />
              <h2 className="text-2xl font-semibold text-black">10. Governing Law</h2>
            </div>
            
            <div className="space-y-4 text-gray-700">
              <div>
                <h3 className="text-lg font-medium text-black mb-2">Applicable Law</h3>
                <p>
                  These terms are governed by and construed in accordance with the laws of the jurisdiction 
                  where Padelo is incorporated, without regard to conflict of law principles.
                </p>
              </div>
              
              <div>
                <h3 className="text-lg font-medium text-black mb-2">Dispute Resolution</h3>
                <ul className="list-disc list-inside space-y-1 ml-4">
                  <li>We encourage resolving disputes through direct communication first</li>
                  <li>Formal disputes will be resolved through binding arbitration</li>
                  <li>Class action lawsuits are waived where legally permissible</li>
                  <li>Small claims court remains available for qualifying disputes</li>
                </ul>
              </div>
              
              <div>
                <h3 className="text-lg font-medium text-black mb-2">Changes to Terms</h3>
                <ul className="list-disc list-inside space-y-1 ml-4">
                  <li>We may modify these terms at any time with notice</li>
                  <li>Significant changes will be announced prominently</li>
                  <li>Continued use constitutes acceptance of modified terms</li>
                  <li>You should review terms periodically for updates</li>
                </ul>
              </div>
            </div>
          </Card>

        </div>

        {/* Footer */}
        <div className="mt-8 mb-6">
          <Card className="p-6 text-center">
            <p className="text-gray-600 mb-4">
              Thank you for taking the time to read our Terms of Service. These terms help ensure a safe, 
              fair, and enjoyable experience for all members of the Padelo community.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <Button 
                onClick={handleBackClick}
                variant="outline"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to App
              </Button>
              <Button 
                onClick={() => navigate('/privacy-policy')}
                className="bg-green-500 hover:bg-green-600 text-white"
              >
                View Privacy Policy
              </Button>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
