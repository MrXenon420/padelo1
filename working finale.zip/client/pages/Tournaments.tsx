import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { 
  Trophy, 
  Plus, 
  Calendar, 
  MapPin, 
  Users, 
  DollarSign,
  Medal,
  Star,
  Filter,
  TrendingUp,
  Crown,
  Award,
  Zap
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

export default function Tournaments() {
  const { t } = useTranslation();
  const [selectedFilter, setSelectedFilter] = useState('all');
  const [selectedRegion, setSelectedRegion] = useState('all');

  // Mock data - in real app this would come from API
  const userRanking = {
    tier: 'intermediate',
    division: 2,
    lp: 2100,
    lpRequiredForPromotion: 500,
    rank: 247,
    region: 'Cairo',
    winRate: 85,
    matchesPlayed: 12,
    tournamentsWon: 2
  };

  const tournaments = [
    {
      id: '1',
      name: 'Spring Championship',
      location: 'Elite Padel Club',
      startDate: '2024-03-15',
      entryFee: 50,
      maxParticipants: 32,
      currentParticipants: 24,
      tournamentType: 'official',
      status: 'upcoming',
      prizes: { first: 500, second: 300, third: 150 },
      organizerRole: 'court_owner'
    },
    {
      id: '2',
      name: 'Friday Night Cup',
      location: 'Sports Complex',
      startDate: '2024-03-08',
      entryFee: 25,
      maxParticipants: 16,
      currentParticipants: 12,
      tournamentType: 'unofficial',
      status: 'ongoing',
      prizes: { first: 200, second: 100, third: 50 },
      organizerRole: 'tournament_organizer'
    }
  ];

  const leaderboard = [
    {
      rank: 1,
      name: 'Ahmed Hassan',
      tier: 'elite',
      division: 1,
      lp: 8900,
      winRate: 92,
      region: 'Cairo',
      gender: 'male',
      tournamentsWon: 8
    },
    {
      rank: 2,
      name: 'Sara Mohamed',
      tier: 'elite',
      division: 2,
      lp: 8200,
      winRate: 88,
      region: 'Alexandria',
      gender: 'female',
      tournamentsWon: 6
    },
    {
      rank: 3,
      name: 'Omar Ali',
      tier: 'advanced',
      division: 1,
      lp: 5600,
      winRate: 85,
      region: 'Giza',
      gender: 'male',
      tournamentsWon: 4
    }
  ];

  const getTierColor = (tier: string) => {
    const colors = {
      rookie: 'bg-gray-500',
      beginner: 'bg-green-500',
      intermediate: 'bg-blue-500',
      advanced: 'bg-purple-500',
      elite: 'bg-yellow-500',
      master: 'bg-red-500',
      pro_players: 'bg-black'
    };
    return colors[tier as keyof typeof colors] || 'bg-gray-500';
  };

  const getTierIcon = (tier: string) => {
    if (tier === 'pro_players') return <Crown className="w-4 h-4" />;
    if (tier === 'master' || tier === 'elite') return <Award className="w-4 h-4" />;
    return <Medal className="w-4 h-4" />;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 p-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-black">{t('tournaments.title')}</h1>
            <p className="text-gray-600">Compete and climb the rankings</p>
          </div>
          <Button className="bg-green-500 hover:bg-green-600 text-white">
            <Plus className="w-4 h-4 mr-2" />
            {t('tournaments.createTournament')}
          </Button>
        </div>
      </div>

      <div className="p-4 space-y-6">
        {/* User Ranking Card */}
        <Card className="p-4 bg-gradient-to-r from-green-50 to-white border-green-200">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-black">Your Ranking</h2>
            <Badge className={`${getTierColor(userRanking.tier)} text-white`}>
              {getTierIcon(userRanking.tier)}
              <span className="ml-1 capitalize">{userRanking.tier} {userRanking.division}</span>
            </Badge>
          </div>
          
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-black">#{userRanking.rank}</div>
              <div className="text-sm text-gray-600">Global Rank</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">{userRanking.lp}</div>
              <div className="text-sm text-gray-600">League Points</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-black">{userRanking.winRate}%</div>
              <div className="text-sm text-gray-600">Win Rate</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">{userRanking.tournamentsWon}</div>
              <div className="text-sm text-gray-600">Tournaments Won</div>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="mt-4">
            <div className="flex justify-between text-sm text-gray-600 mb-2">
              <span>Progress to next division</span>
              <span>{userRanking.lpRequiredForPromotion} LP needed</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div 
                className="bg-green-500 h-2 rounded-full" 
                style={{ width: `${(userRanking.lp % 500) / 5}%` }}
              ></div>
            </div>
          </div>
        </Card>

        {/* Tabs */}
        <Tabs defaultValue="tournaments" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="tournaments">Tournaments</TabsTrigger>
            <TabsTrigger value="leaderboard">Leaderboard</TabsTrigger>
            <TabsTrigger value="my-tournaments">My Tournaments</TabsTrigger>
          </TabsList>

          <TabsContent value="tournaments" className="space-y-4">
            {/* Filters */}
            <div className="flex flex-wrap gap-3">
              <Select value={selectedFilter} onValueChange={setSelectedFilter}>
                <SelectTrigger className="w-[140px]">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="upcoming">Upcoming</SelectItem>
                  <SelectItem value="ongoing">Ongoing</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                </SelectContent>
              </Select>
              
              <Select value={selectedRegion} onValueChange={setSelectedRegion}>
                <SelectTrigger className="w-[140px]">
                  <SelectValue placeholder="Region" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Regions</SelectItem>
                  <SelectItem value="cairo">Cairo</SelectItem>
                  <SelectItem value="alexandria">Alexandria</SelectItem>
                  <SelectItem value="giza">Giza</SelectItem>
                </SelectContent>
              </Select>

              <Button variant="outline" size="sm">
                <Filter className="w-4 h-4 mr-2" />
                More Filters
              </Button>
            </div>

            {/* Tournament List */}
            <div className="space-y-4">
              {tournaments.map((tournament) => (
                <Card key={tournament.id} className="p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-2">
                        <h3 className="text-lg font-semibold text-black">{tournament.name}</h3>
                        <Badge 
                          variant={tournament.tournamentType === 'official' ? 'default' : 'secondary'}
                          className={tournament.tournamentType === 'official' ? 'bg-green-500' : ''}
                        >
                          {tournament.tournamentType === 'official' && <Zap className="w-3 h-3 mr-1" />}
                          {tournament.tournamentType === 'official' ? 'Official' : 'Unofficial'}
                        </Badge>
                        <Badge 
                          variant={tournament.status === 'upcoming' ? 'outline' : 
                                  tournament.status === 'ongoing' ? 'default' : 'secondary'}
                          className={tournament.status === 'ongoing' ? 'bg-green-500' : ''}
                        >
                          {tournament.status}
                        </Badge>
                      </div>
                      
                      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 text-sm text-gray-600">
                        <div className="flex items-center">
                          <MapPin className="w-4 h-4 mr-1" />
                          {tournament.location}
                        </div>
                        <div className="flex items-center">
                          <Calendar className="w-4 h-4 mr-1" />
                          {new Date(tournament.startDate).toLocaleDateString()}
                        </div>
                        <div className="flex items-center">
                          <Users className="w-4 h-4 mr-1" />
                          {tournament.currentParticipants}/{tournament.maxParticipants}
                        </div>
                        <div className="flex items-center">
                          <DollarSign className="w-4 h-4 mr-1" />
                          ${tournament.entryFee} Entry
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Prize Pool */}
                  <div className="bg-gray-50 rounded-lg p-3 mb-3">
                    <div className="text-sm font-medium text-gray-700 mb-2">Prize Pool</div>
                    <div className="flex justify-between text-sm">
                      <span>🥇 ${tournament.prizes.first}</span>
                      <span>🥈 ${tournament.prizes.second}</span>
                      <span>🥉 ${tournament.prizes.third}</span>
                    </div>
                  </div>

                  {/* LP Information */}
                  <div className="bg-green-50 rounded-lg p-3 mb-3">
                    <div className="text-sm font-medium text-green-700 mb-1">League Points</div>
                    <div className="text-xs text-green-600">
                      {tournament.tournamentType === 'official' 
                        ? '100% LP value - Full ranking points awarded'
                        : '10% LP value - Limited ranking points'
                      }
                    </div>
                  </div>

                  <div className="flex space-x-3">
                    <Button 
                      className="flex-1 bg-green-500 hover:bg-green-600 text-white"
                      disabled={tournament.currentParticipants >= tournament.maxParticipants}
                    >
                      <Trophy className="w-4 h-4 mr-2" />
                      {tournament.currentParticipants >= tournament.maxParticipants ? 'Full' : 'Join Tournament'}
                    </Button>
                    <Button variant="outline" size="sm">
                      View Details
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="leaderboard" className="space-y-4">
            {/* Leaderboard Filters */}
            <div className="flex flex-wrap gap-3">
              <Select defaultValue="all-gender">
                <SelectTrigger className="w-[140px]">
                  <SelectValue placeholder="Gender" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all-gender">All Genders</SelectItem>
                  <SelectItem value="male">Male</SelectItem>
                  <SelectItem value="female">Female</SelectItem>
                </SelectContent>
              </Select>
              
              <Select defaultValue="all-age">
                <SelectTrigger className="w-[140px]">
                  <SelectValue placeholder="Age Group" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all-age">All Ages</SelectItem>
                  <SelectItem value="18-25">18-25</SelectItem>
                  <SelectItem value="26-35">26-35</SelectItem>
                  <SelectItem value="36-45">36-45</SelectItem>
                  <SelectItem value="45+">45+</SelectItem>
                </SelectContent>
              </Select>

              <Select defaultValue="all-region">
                <SelectTrigger className="w-[140px]">
                  <SelectValue placeholder="Region" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all-region">All Regions</SelectItem>
                  <SelectItem value="cairo">Cairo</SelectItem>
                  <SelectItem value="alexandria">Alexandria</SelectItem>
                  <SelectItem value="giza">Giza</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Leaderboard */}
            <div className="space-y-2">
              {leaderboard.map((player, index) => (
                <Card key={player.rank} className="p-4">
                  <div className="flex items-center space-x-4">
                    <div className="text-center min-w-[50px]">
                      <div className={`text-2xl font-bold ${
                        index === 0 ? 'text-yellow-500' :
                        index === 1 ? 'text-gray-400' :
                        index === 2 ? 'text-amber-600' : 'text-black'
                      }`}>
                        #{player.rank}
                      </div>
                    </div>
                    
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-1">
                        <h3 className="font-semibold text-black">{player.name}</h3>
                        <Badge className={`${getTierColor(player.tier)} text-white text-xs`}>
                          {getTierIcon(player.tier)}
                          <span className="ml-1 capitalize">{player.tier} {player.division}</span>
                        </Badge>
                        {index < 3 && (
                          <Badge variant="outline" className="text-xs">
                            {index === 0 ? '🥇' : index === 1 ? '🥈' : '🥉'} Top 3
                          </Badge>
                        )}
                      </div>
                      
                      <div className="grid grid-cols-3 lg:grid-cols-5 gap-4 text-sm text-gray-600">
                        <div>
                          <div className="font-medium text-green-600">{player.lp}</div>
                          <div className="text-xs">LP</div>
                        </div>
                        <div>
                          <div className="font-medium text-black">{player.winRate}%</div>
                          <div className="text-xs">Win Rate</div>
                        </div>
                        <div>
                          <div className="font-medium text-black">{player.tournamentsWon}</div>
                          <div className="text-xs">Tournaments</div>
                        </div>
                        <div className="hidden lg:block">
                          <div className="font-medium text-black">{player.region}</div>
                          <div className="text-xs">Region</div>
                        </div>
                        <div className="hidden lg:block">
                          <div className="font-medium text-black capitalize">{player.gender}</div>
                          <div className="text-xs">Gender</div>
                        </div>
                      </div>
                    </div>

                    <Button variant="outline" size="sm">
                      View Profile
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="my-tournaments" className="space-y-4">
            <div className="text-center py-8">
              <Trophy className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-black mb-2">No tournaments yet</h3>
              <p className="text-gray-600 mb-4">Join your first tournament to start building your ranking!</p>
              <Button className="bg-green-500 hover:bg-green-600 text-white">
                Browse Tournaments
              </Button>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
