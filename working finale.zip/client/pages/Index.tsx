import { useTranslation } from 'react-i18next';
import { Logo } from '@/components/Logo';
import { LanguageSelector } from '@/components/LanguageSelector';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { 
  Calendar, 
  MapPin, 
  Trophy, 
  ShoppingBag, 
  Users, 
  Clock,
  Star,
  TrendingUp,
  Zap
} from 'lucide-react';

export default function Index() {
  const { t } = useTranslation();

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900">
      {/* Header */}
      <header className="flex items-center justify-between p-4 border-b border-gray-100 dark:border-gray-800">
        <Logo size="md" />
        <div className="flex items-center space-x-3">
          <LanguageSelector />
          <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
            <Users className="w-5 h-5 text-gray-600" />
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="p-4 space-y-6">
        {/* Welcome Section */}
        <div className="text-center space-y-2">
          <h1 className="text-2xl font-bold text-black">{t('common.welcome')}</h1>
          <p className="text-gray-600">{t('home.subtitle')}</p>
        </div>

        {/* Quick Actions */}
        <Card className="p-4">
          <h2 className="text-lg font-semibold text-black mb-4">{t('home.quickActions')}</h2>
          <div className="grid grid-cols-2 gap-3">
            <Button 
              className="bg-green-500 hover:bg-green-600 text-white h-16 flex flex-col space-y-1"
              size="lg"
            >
              <Calendar className="w-5 h-5" />
              <span className="text-sm font-medium">{t('home.bookCourt')}</span>
            </Button>
            <Button 
              variant="outline" 
              className="border-green-500 text-green-600 hover:bg-green-50 h-16 flex flex-col space-y-1"
              size="lg"
            >
              <Users className="w-5 h-5" />
              <span className="text-sm font-medium">{t('home.findMatch')}</span>
            </Button>
          </div>
          <Button 
            variant="outline" 
            className="w-full mt-3 border-black text-black hover:bg-gray-50 h-12"
            size="lg"
          >
            <Trophy className="w-5 h-5 mr-2" />
            {t('home.joinTournament')}
          </Button>
        </Card>

        {/* Upcoming Tournaments */}
        <Card className="p-4">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-black">{t('home.upcomingTournaments')}</h2>
            <Button variant="ghost" size="sm" className="text-green-600">
              View All
            </Button>
          </div>
          <div className="space-y-3">
            {[1, 2].map((i) => (
              <div key={i} className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                <div className="w-12 h-12 bg-green-500 rounded-lg flex items-center justify-center">
                  <Trophy className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="font-medium text-black">Spring Championship</h3>
                  <div className="flex items-center text-sm text-gray-600 space-x-4">
                    <span className="flex items-center">
                      <MapPin className="w-4 h-4 mr-1" />
                      Sports Club
                    </span>
                    <span className="flex items-center">
                      <Calendar className="w-4 h-4 mr-1" />
                      Mar 15
                    </span>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-sm font-medium text-green-600">$50</div>
                  <div className="text-xs text-gray-500">Entry Fee</div>
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* Nearby Reservations on Sale */}
        <Card className="p-4">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-black">{t('home.nearbyReservations')}</h2>
            <Button variant="ghost" size="sm" className="text-green-600">
              View All
            </Button>
          </div>
          <div className="space-y-3">
            {[1, 2].map((i) => (
              <div key={i} className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                <div className="w-12 h-12 bg-black rounded-lg flex items-center justify-center">
                  <MapPin className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="font-medium text-black">Elite Padel Club</h3>
                  <div className="flex items-center text-sm text-gray-600 space-x-4">
                    <span className="flex items-center">
                      <Clock className="w-4 h-4 mr-1" />
                      2:00 PM - 4:00 PM
                    </span>
                    <span className="flex items-center text-green-600">
                      <Zap className="w-4 h-4 mr-1" />
                      25% Off
                    </span>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-sm font-medium text-black line-through">$40</div>
                  <div className="text-lg font-bold text-green-600">$30</div>
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* Marketplace Deals */}
        <Card className="p-4">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-black">{t('home.marketplaceDeals')}</h2>
            <Button variant="ghost" size="sm" className="text-green-600">
              View All
            </Button>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {[1, 2].map((i) => (
              <div key={i} className="bg-gray-50 rounded-lg p-3">
                <div className="w-full h-24 bg-gray-200 rounded-lg mb-2 flex items-center justify-center">
                  <ShoppingBag className="w-8 h-8 text-gray-400" />
                </div>
                <h3 className="font-medium text-black text-sm">Professional Racket</h3>
                <div className="flex items-center justify-between mt-1">
                  <div className="text-green-600 font-bold">$120</div>
                  <div className="flex items-center text-xs text-gray-600">
                    <Star className="w-3 h-3 mr-1 fill-current text-yellow-400" />
                    4.8
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* Stats Overview */}
        <Card className="p-4">
          <h2 className="text-lg font-semibold text-black mb-4">Your Stats</h2>
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-black">12</div>
              <div className="text-xs text-gray-600">Matches</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">85%</div>
              <div className="text-xs text-gray-600">Win Rate</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-black">#247</div>
              <div className="text-xs text-gray-600">Ranking</div>
            </div>
          </div>
        </Card>
      </main>
    </div>
  );
}
