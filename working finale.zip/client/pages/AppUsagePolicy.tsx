import React from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Users, Building, AlertTriangle, Trophy, Target, Star, Crown } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function AppUsagePolicy() {
  const navigate = useNavigate();

  const handleBackClick = () => {
    if (window.history.length > 1) {
      navigate(-1);
    } else {
      navigate('/');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 dark:from-gray-900 dark:to-gray-800 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-6">
          <Button 
            variant="outline" 
            onClick={handleBackClick}
            className="mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          
          <Card className="p-6">
            <div className="flex items-center mb-4">
              <div className="p-3 bg-blue-100 rounded-full mr-4">
                <Users className="w-8 h-8 text-blue-600" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-black">App Usage Policy</h1>
                <p className="text-gray-600">Comprehensive guidelines for all users</p>
              </div>
            </div>
            <p className="text-lg text-gray-700">
              These policies ensure fair play, quality service, and a positive experience for all Padelo community members.
            </p>
          </Card>
        </div>

        {/* Players Policy Section */}
        <Card className="p-6 mb-6">
          <div className="flex items-center mb-6">
            <div className="p-3 bg-green-100 rounded-full mr-4">
              <Users className="w-6 h-6 text-green-600" />
            </div>
            <h2 className="text-2xl font-semibold text-black">APP USAGE POLICY (PLAYERS)</h2>
          </div>
          
          <div className="space-y-6">
            {/* Account Policy */}
            <div className="border-l-4 border-blue-500 pl-4">
              <h3 className="text-lg font-semibold text-black mb-3">Account Management</h3>
              <div className="space-y-2 text-gray-700">
                <div className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-red-500 rounded-full mt-2 flex-shrink-0"></div>
                  <p><strong>Each person may only have ONE account.</strong> If duplicate accounts are detected, ban immediately.</p>
                </div>
                <div className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-red-500 rounded-full mt-2 flex-shrink-0"></div>
                  <p><strong>All user information must be valid.</strong> If fraudulent or false information is detected, ban immediately.</p>
                </div>
              </div>
            </div>

            {/* Reservation Policy */}
            <div className="border-l-4 border-green-500 pl-4">
              <h3 className="text-lg font-semibold text-black mb-3">Court Reservations</h3>
              <div className="space-y-2 text-gray-700">
                <div className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0"></div>
                  <p>Courts can be reserved up to <strong>7 days in advance</strong>.</p>
                </div>
                <div className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0"></div>
                  <p>Maximum number of active reservations per user = <strong>4</strong>.</p>
                </div>
              </div>
            </div>

            {/* Cancellation Policy */}
            <div className="border-l-4 border-orange-500 pl-4">
              <h3 className="text-lg font-semibold text-black mb-3">Player Cancellations</h3>
              <div className="space-y-3 text-gray-700">
                <div className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-orange-500 rounded-full mt-2 flex-shrink-0"></div>
                  <p>Cancellations allowed <strong>ONLY if done exactly 24 hours before</strong> the scheduled start time.</p>
                </div>
                <div className="bg-red-50 p-4 rounded-lg border border-red-200">
                  <p className="font-semibold text-red-800 mb-2">Any late cancellation (&lt;24h) or no-show results in:</p>
                  <div className="ml-4 space-y-1">
                    <p className="text-red-700">• <strong>1 warning = 1-week ban</strong></p>
                    <p className="text-red-700">• <strong>2 warnings in a row OR 3 warnings in one month = permanent ban</strong></p>
                  </div>
                </div>
              </div>
            </div>

            {/* Court Etiquette */}
            <div className="border-l-4 border-purple-500 pl-4">
              <h3 className="text-lg font-semibold text-black mb-3">Court Etiquette</h3>
              <div className="space-y-2 text-gray-700">
                <div className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-purple-500 rounded-full mt-2 flex-shrink-0"></div>
                  <p>Players must arrive <strong>10 minutes before match time</strong>.</p>
                </div>
                <div className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-purple-500 rounded-full mt-2 flex-shrink-0"></div>
                  <p><strong>Immediate evacuation at end of session.</strong></p>
                </div>
                <div className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-purple-500 rounded-full mt-2 flex-shrink-0"></div>
                  <p>Damage to court property: court owner can either settle directly or escalate to app support. App support must log and resolve professionally.</p>
                </div>
                <div className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-purple-500 rounded-full mt-2 flex-shrink-0"></div>
                  <p>On-court disputes must be resolved respectfully or reported to support.</p>
                </div>
              </div>
            </div>
          </div>
        </Card>

        {/* Court Owners Policy Section */}
        <Card className="p-6 mb-6">
          <div className="flex items-center mb-6">
            <div className="p-3 bg-purple-100 rounded-full mr-4">
              <Building className="w-6 h-6 text-purple-600" />
            </div>
            <h2 className="text-2xl font-semibold text-black">COURT USAGE POLICY (COURT OWNERS)</h2>
          </div>
          
          <div className="space-y-6">
            {/* Maintenance Standards */}
            <div className="border-l-4 border-green-500 pl-4">
              <h3 className="text-lg font-semibold text-black mb-3">Court Standards</h3>
              <div className="space-y-2 text-gray-700">
                <div className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0"></div>
                  <p>Courts must maintain playable conditions.</p>
                </div>
                <div className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0"></div>
                  <p>Keep timely availability updates.</p>
                </div>
                <div className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0"></div>
                  <p>Prioritize reservations from the application.</p>
                </div>
              </div>
            </div>

            {/* Cancellation Penalties */}
            <div className="border-l-4 border-red-500 pl-4">
              <h3 className="text-lg font-semibold text-black mb-3">Owner Cancellation Penalties</h3>
              <p className="text-gray-700 mb-4">Court owners must NOT cancel without a valid reason. The following penalties apply for OWNER cancellations:</p>
              
              <div className="space-y-3">
                <div className="bg-green-50 p-3 rounded-lg border border-green-200">
                  <p className="text-green-800"><strong>Cancel ≥48h before match:</strong> No penalty.</p>
                </div>
                <div className="bg-yellow-50 p-3 rounded-lg border border-yellow-200">
                  <p className="text-yellow-800"><strong>Cancel 48–24h before match:</strong> 25% discount voucher for player's next booking (deducted from owner payout).</p>
                </div>
                <div className="bg-orange-50 p-3 rounded-lg border border-orange-200">
                  <p className="text-orange-800"><strong>Cancel 24–4h before match:</strong> 50% discount voucher or equivalent wallet credit to player (deducted from owner payout).</p>
                </div>
                <div className="bg-red-50 p-3 rounded-lg border border-red-200">
                  <p className="text-red-800"><strong>Cancel &lt;4h before match or court no-show:</strong> Full refund + 100% booking value credit to player (deducted from owner payout).</p>
                </div>
              </div>
            </div>

            {/* Strike System */}
            <div className="border-l-4 border-yellow-500 pl-4">
              <h3 className="text-lg font-semibold text-black mb-3">Strike System for Owner Violations</h3>
              <div className="space-y-2 text-gray-700">
                <div className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-yellow-500 rounded-full mt-2 flex-shrink-0"></div>
                  <p><strong>1 strike:</strong> Warning.</p>
                </div>
                <div className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-orange-500 rounded-full mt-2 flex-shrink-0"></div>
                  <p><strong>2 strikes in 60 days:</strong> Lower court ranking in search for 14 days.</p>
                </div>
                <div className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-red-500 rounded-full mt-2 flex-shrink-0"></div>
                  <p><strong>3 strikes in 90 days:</strong> Suspend court from new bookings for 7 days.</p>
                </div>
                <div className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-red-700 rounded-full mt-2 flex-shrink-0"></div>
                  <p><strong>5 strikes in 180 days:</strong> Suspend court until manual review.</p>
                </div>
              </div>
            </div>

            {/* Emergency Exemptions & Incentives */}
            <div className="border-l-4 border-blue-500 pl-4">
              <h3 className="text-lg font-semibold text-black mb-3">Special Provisions</h3>
              <div className="space-y-3">
                <div className="bg-blue-50 p-3 rounded-lg border border-blue-200">
                  <p className="text-blue-800"><strong>Emergency exemptions:</strong> Each court gets 2 emergency cancellations per 6 months without strike (requires valid proof).</p>
                </div>
                <div className="bg-purple-50 p-3 rounded-lg border border-purple-200">
                  <p className="text-purple-800">Court cancellation rate must be tracked and displayed publicly on the court profile.</p>
                </div>
                <div className="bg-green-50 p-3 rounded-lg border border-green-200 flex items-center">
                  <Star className="w-5 h-5 text-green-600 mr-2" />
                  <p className="text-green-800"><strong>Reliable Court Badge:</strong> Courts with 0 cancellations in 90 days receive a "Reliable Court" badge and higher search ranking.</p>
                </div>
              </div>
            </div>
          </div>
        </Card>

        {/* Global Violation Handling */}
        <Card className="p-6 mb-6">
          <div className="flex items-center mb-6">
            <div className="p-3 bg-red-100 rounded-full mr-4">
              <AlertTriangle className="w-6 h-6 text-red-600" />
            </div>
            <h2 className="text-2xl font-semibold text-black">VIOLATION HANDLING (GLOBAL)</h2>
          </div>
          
          <div className="space-y-6">
            {/* Universal Rules */}
            <div className="bg-red-50 p-4 rounded-lg border border-red-200">
              <h3 className="text-lg font-semibold text-red-800 mb-3">For both PLAYERS and COURT OWNERS:</h3>
              <div className="space-y-2 text-red-700">
                <div className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-red-500 rounded-full mt-2 flex-shrink-0"></div>
                  <p><strong>1 violation = 1 warning = 1-week ban.</strong></p>
                </div>
                <div className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-red-500 rounded-full mt-2 flex-shrink-0"></div>
                  <p><strong>2 consecutive warnings OR 3 in one month = permanent ban (PLAYER) or indefinite suspension (COURT OWNER).</strong></p>
                </div>
              </div>
            </div>

            {/* Notification Requirements */}
            <div className="border-l-4 border-blue-500 pl-4">
              <h3 className="text-lg font-semibold text-black mb-3">Notification & Documentation</h3>
              <div className="space-y-2 text-gray-700">
                <div className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0"></div>
                  <p>All bans/suspensions must trigger notification (push + email) with reason and evidence.</p>
                </div>
                <div className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0"></div>
                  <p>All warnings, bans, suspensions, and strikes must be stored in the database with timestamps and reasons.</p>
                </div>
              </div>
            </div>

            {/* Automatic Detection */}
            <div className="border-l-4 border-green-500 pl-4">
              <h3 className="text-lg font-semibold text-black mb-3">Automatic Detection Systems</h3>
              <p className="text-gray-700 mb-3">Implement automatic detection for:</p>
              <div className="space-y-2 text-gray-700">
                <div className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0"></div>
                  <p>Duplicate accounts.</p>
                </div>
                <div className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0"></div>
                  <p>Invalid profile data.</p>
                </div>
                <div className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0"></div>
                  <p>Late cancellations and no-shows.</p>
                </div>
                <div className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0"></div>
                  <p>Court cancellations with timestamp comparison.</p>
                </div>
              </div>
            </div>

            {/* Compensation System */}
            <div className="border-l-4 border-purple-500 pl-4">
              <h3 className="text-lg font-semibold text-black mb-3">Compensation System</h3>
              <div className="bg-purple-50 p-3 rounded-lg border border-purple-200">
                <p className="text-purple-800">All voucher/credit compensations must be automatically issued and deducted from the responsible party's balance or payout reserve.</p>
              </div>
            </div>
          </div>
        </Card>

        {/* Ranking Policy Section */}
        <Card className="p-6 mb-6">
          <div className="flex items-center mb-6">
            <div className="p-3 bg-yellow-100 rounded-full mr-4">
              <Trophy className="w-6 h-6 text-yellow-600" />
            </div>
            <h2 className="text-2xl font-semibold text-black">RANKING POLICY</h2>
          </div>
          
          <div className="space-y-6">
            {/* Ranking Structure */}
            <div className="border-l-4 border-yellow-500 pl-4">
              <h3 className="text-lg font-semibold text-black mb-3">1. Ranking Structure (Tiers & Divisions)</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div className="space-y-3">
                  <div className="bg-gray-100 p-3 rounded-lg">
                    <div className="flex items-center mb-2">
                      <Target className="w-4 h-4 text-gray-600 mr-2" />
                      <h4 className="font-semibold">Rookie</h4>
                    </div>
                    <p className="text-sm text-gray-600">Divisions IV → I • 100 LP per division</p>
                  </div>
                  <div className="bg-green-100 p-3 rounded-lg">
                    <div className="flex items-center mb-2">
                      <Target className="w-4 h-4 text-green-600 mr-2" />
                      <h4 className="font-semibold">Beginner</h4>
                    </div>
                    <p className="text-sm text-green-700">Divisions IV → I • 300 LP per division</p>
                  </div>
                  <div className="bg-blue-100 p-3 rounded-lg">
                    <div className="flex items-center mb-2">
                      <Target className="w-4 h-4 text-blue-600 mr-2" />
                      <h4 className="font-semibold">Intermediate</h4>
                    </div>
                    <p className="text-sm text-blue-700">Divisions IV → I • 400 LP per division</p>
                  </div>
                </div>
                <div className="space-y-3">
                  <div className="bg-purple-100 p-3 rounded-lg">
                    <div className="flex items-center mb-2">
                      <Target className="w-4 h-4 text-purple-600 mr-2" />
                      <h4 className="font-semibold">Advanced</h4>
                    </div>
                    <p className="text-sm text-purple-700">Divisions IV → I • 500 LP per division</p>
                  </div>
                  <div className="bg-orange-100 p-3 rounded-lg">
                    <div className="flex items-center mb-2">
                      <Star className="w-4 h-4 text-orange-600 mr-2" />
                      <h4 className="font-semibold">Elite</h4>
                    </div>
                    <p className="text-sm text-orange-700">Divisions IV → I • 600 LP per division</p>
                  </div>
                  <div className="bg-red-100 p-3 rounded-lg">
                    <div className="flex items-center mb-2">
                      <Star className="w-4 h-4 text-red-600 mr-2" />
                      <h4 className="font-semibold">Master</h4>
                    </div>
                    <p className="text-sm text-red-700">Divisions IV → I • 800 LP per division</p>
                  </div>
                </div>
              </div>
              
              <div className="bg-gradient-to-r from-yellow-100 to-yellow-200 p-4 rounded-lg border border-yellow-300">
                <div className="flex items-center mb-2">
                  <Crown className="w-5 h-5 text-yellow-700 mr-2" />
                  <h4 className="font-semibold text-yellow-800">Pro Players</h4>
                </div>
                <p className="text-sm text-yellow-700">Invite-only, no divisions</p>
              </div>

              <div className="mt-4 space-y-3">
                <div className="bg-green-50 p-3 rounded-lg border border-green-200">
                  <p className="text-green-800"><strong>Promotion:</strong> Player advances to the next division when LP threshold is reached. On tier promotion, LP resets to 0 of the new tier/division.</p>
                </div>
                <div className="bg-red-50 p-3 rounded-lg border border-red-200">
                  <p className="text-red-800"><strong>Demotion:</strong> Occurs when a player drops to 0 LP and loses again. Starts new division at 75% of LP threshold.</p>
                </div>
              </div>
            </div>

            {/* LP Calculation */}
            <div className="border-l-4 border-blue-500 pl-4">
              <h3 className="text-lg font-semibold text-black mb-3">2. LP Gain/Loss Calculation (Official Matches)</h3>
              <p className="text-gray-700 mb-4">LP values are based on opponent strength (stronger/weaker).</p>
              
              <div className="overflow-x-auto">
                <table className="w-full border-collapse border border-gray-300">
                  <thead>
                    <tr className="bg-gray-100">
                      <th className="border border-gray-300 p-2 text-left">Tier</th>
                      <th className="border border-gray-300 p-2 text-center">Win vs Equal</th>
                      <th className="border border-gray-300 p-2 text-center">Loss vs Equal</th>
                      <th className="border border-gray-300 p-2 text-center">Win vs Stronger</th>
                      <th className="border border-gray-300 p-2 text-center">Loss vs Stronger</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td className="border border-gray-300 p-2 font-medium">Rookie</td>
                      <td className="border border-gray-300 p-2 text-center text-green-600">+20</td>
                      <td className="border border-gray-300 p-2 text-center text-red-600">-20</td>
                      <td className="border border-gray-300 p-2 text-center text-green-600">+30</td>
                      <td className="border border-gray-300 p-2 text-center text-red-600">-10</td>
                    </tr>
                    <tr>
                      <td className="border border-gray-300 p-2 font-medium">Beginner</td>
                      <td className="border border-gray-300 p-2 text-center text-green-600">+20</td>
                      <td className="border border-gray-300 p-2 text-center text-red-600">-18</td>
                      <td className="border border-gray-300 p-2 text-center text-green-600">+30</td>
                      <td className="border border-gray-300 p-2 text-center text-red-600">-9</td>
                    </tr>
                    <tr>
                      <td className="border border-gray-300 p-2 font-medium">Intermediate</td>
                      <td className="border border-gray-300 p-2 text-center text-green-600">+20</td>
                      <td className="border border-gray-300 p-2 text-center text-red-600">-16</td>
                      <td className="border border-gray-300 p-2 text-center text-green-600">+30</td>
                      <td className="border border-gray-300 p-2 text-center text-red-600">-8</td>
                    </tr>
                    <tr>
                      <td className="border border-gray-300 p-2 font-medium">Advanced</td>
                      <td className="border border-gray-300 p-2 text-center text-green-600">+20</td>
                      <td className="border border-gray-300 p-2 text-center text-red-600">-14</td>
                      <td className="border border-gray-300 p-2 text-center text-green-600">+30</td>
                      <td className="border border-gray-300 p-2 text-center text-red-600">-7</td>
                    </tr>
                    <tr>
                      <td className="border border-gray-300 p-2 font-medium">Elite</td>
                      <td className="border border-gray-300 p-2 text-center text-green-600">+20</td>
                      <td className="border border-gray-300 p-2 text-center text-red-600">-12</td>
                      <td className="border border-gray-300 p-2 text-center text-green-600">+30</td>
                      <td className="border border-gray-300 p-2 text-center text-red-600">-6</td>
                    </tr>
                    <tr>
                      <td className="border border-gray-300 p-2 font-medium">Master</td>
                      <td className="border border-gray-300 p-2 text-center text-green-600">+20</td>
                      <td className="border border-gray-300 p-2 text-center text-red-600">-10</td>
                      <td className="border border-gray-300 p-2 text-center text-green-600">+30</td>
                      <td className="border border-gray-300 p-2 text-center text-red-600">-5</td>
                    </tr>
                    <tr>
                      <td className="border border-gray-300 p-2 font-medium">Pro Players</td>
                      <td className="border border-gray-300 p-2 text-center text-purple-600">Custom</td>
                      <td className="border border-gray-300 p-2 text-center text-purple-600">Custom</td>
                      <td className="border border-gray-300 p-2 text-center text-purple-600">Custom</td>
                      <td className="border border-gray-300 p-2 text-center text-purple-600">Custom</td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <div className="mt-4 bg-yellow-50 p-3 rounded-lg border border-yellow-200">
                <p className="text-yellow-800"><strong>Unofficial matches:</strong> Rewards = 10% of official match LP values. No advancement bonuses.</p>
              </div>
            </div>

            {/* Tournament Bonuses */}
            <div className="border-l-4 border-green-500 pl-4">
              <h3 className="text-lg font-semibold text-black mb-3">3. Tournament Advancement Bonus (Official Tournaments Only)</h3>
              <p className="text-gray-700 mb-4">Awarded in addition to match LP. Based on tournament size:</p>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                  <h4 className="font-semibold text-green-800 mb-2">32-Team Tournament</h4>
                  <div className="text-sm text-green-700 space-y-1">
                    <p>Win: +1 LP</p>
                    <p>Round of 16: +4 LP</p>
                    <p>Quarterfinals: +4 LP</p>
                    <p>Semifinals: +4 LP</p>
                    <p>Final: +4 LP</p>
                    <p className="font-semibold">Winner: +10 LP</p>
                  </div>
                </div>
                
                <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                  <h4 className="font-semibold text-blue-800 mb-2">16-Team Tournament</h4>
                  <div className="text-sm text-blue-700 space-y-1">
                    <p>Win: +1 LP</p>
                    <p>Quarterfinals: +4 LP</p>
                    <p>Semifinals: +4 LP</p>
                    <p>Final: +4 LP</p>
                    <p className="font-semibold">Winner: +10 LP</p>
                  </div>
                </div>
                
                <div className="bg-purple-50 p-4 rounded-lg border border-purple-200">
                  <h4 className="font-semibold text-purple-800 mb-2">8-Team Tournament</h4>
                  <div className="text-sm text-purple-700 space-y-1">
                    <p>Win: +1 LP</p>
                    <p>Semifinals: +4 LP</p>
                    <p>Final: +4 LP</p>
                    <p className="font-semibold">Winner: +10 LP</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Tournament Schedule */}
            <div className="border-l-4 border-orange-500 pl-4">
              <h3 className="text-lg font-semibold text-black mb-3">4. Official Tournament Scheduling</h3>
              <div className="bg-orange-50 p-3 rounded-lg border border-orange-200">
                <p className="text-orange-800">Official tournaments are scheduled <strong>1st Friday and 3rd Friday of each month</strong>. These events give full LP rewards + advancement bonuses.</p>
              </div>
            </div>

            {/* Leaderboard System */}
            <div className="border-l-4 border-red-500 pl-4">
              <h3 className="text-lg font-semibold text-black mb-3">5. Leaderboard System</h3>
              
              <div className="space-y-4">
                <div>
                  <h4 className="font-semibold text-black mb-2">Global leaderboard ranks players by:</h4>
                  <div className="space-y-2 text-gray-700">
                    <div className="flex items-start space-x-2">
                      <div className="w-2 h-2 bg-red-500 rounded-full mt-2 flex-shrink-0"></div>
                      <p>Total LP</p>
                    </div>
                    <div className="flex items-start space-x-2">
                      <div className="w-2 h-2 bg-red-500 rounded-full mt-2 flex-shrink-0"></div>
                      <p>Tier & Division</p>
                    </div>
                    <div className="flex items-start space-x-2">
                      <div className="w-2 h-2 bg-red-500 rounded-full mt-2 flex-shrink-0"></div>
                      <p>Win rate (optional)</p>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold text-black mb-2">Leaderboard Filters:</h4>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                    <div className="bg-gray-100 p-2 rounded text-center text-sm">Age (U18, 18–30, 30–50, 50+)</div>
                    <div className="bg-gray-100 p-2 rounded text-center text-sm">Gender (Male / Female / Mixed)</div>
                    <div className="bg-gray-100 p-2 rounded text-center text-sm">Region (based on location)</div>
                    <div className="bg-gray-100 p-2 rounded text-center text-sm">Combined filters allowed</div>
                  </div>
                </div>

                <div className="bg-blue-50 p-3 rounded-lg border border-blue-200">
                  <h4 className="font-semibold text-blue-800 mb-2">Display format:</h4>
                  <p className="text-blue-700 text-sm">Player name, Tier & Division, LP, Region, Age group, Gender.</p>
                </div>
              </div>
            </div>

            {/* Implementation Notes */}
            <div className="border-l-4 border-gray-500 pl-4">
              <h3 className="text-lg font-semibold text-black mb-3">6. Extra Implementation Notes</h3>
              <div className="space-y-2 text-gray-700">
                <div className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-gray-500 rounded-full mt-2 flex-shrink-0"></div>
                  <p>Every player must have only one account (email or phone verification required).</p>
                </div>
                <div className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-gray-500 rounded-full mt-2 flex-shrink-0"></div>
                  <p>LP values should be stored in a central database so leaderboards update in real-time.</p>
                </div>
                <div className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-gray-500 rounded-full mt-2 flex-shrink-0"></div>
                  <p>Players should see: Current LP, Current tier/division, Progress bar to next division/tier, Last 5 match results.</p>
                </div>
              </div>
            </div>
          </div>
        </Card>

        {/* Footer */}
        <div className="mt-8 mb-6">
          <Card className="p-6 text-center">
            <p className="text-gray-600 mb-4">
              These policies ensure fair play, quality service, and competitive integrity for all Padelo users. 
              All violations will be automatically tracked and enforced by the system.
            </p>
            <Button 
              onClick={handleBackClick}
              className="bg-blue-500 hover:bg-blue-600 text-white"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to App
            </Button>
          </Card>
        </div>
      </div>
    </div>
  );
}
