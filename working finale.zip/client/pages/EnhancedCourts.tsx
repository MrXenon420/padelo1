import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useAuth } from '../contexts/RoleAuthContext';
import { 
  MapPin, 
  Clock, 
  Star, 
  DollarSign,
  Calendar,
  Filter,
  Plus,
  Zap,
  CheckCircle,
  AlertCircle,
  Search,
  Heart,
  Share,
  CreditCard,
  Crown,
  Gift,
  Users,
  Shield,
  TrendingUp,
  Target,
  Award,
  Percent,
  Package,
  Infinity,
  RefreshCw
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';

export default function EnhancedCourts() {
  const { t } = useTranslation();
  const { user } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [selectedLocation, setSelectedLocation] = useState('all');

  // User subscription status
  const userSubscription = {
    type: user?.subscriptionType || 'free',
    isActive: true,
    courtCredits: 8,
    totalCredits: 10,
    nextBillingDate: '2024-04-20',
    discountPercentage: user?.subscriptionType === 'pro' ? 25 : user?.subscriptionType === 'premium' ? 15 : 0,
    priorityBooking: user?.subscriptionType !== 'free',
    cancellationPolicy: user?.subscriptionType === 'pro' ? 'flexible' : user?.subscriptionType === 'premium' ? 'moderate' : 'strict'
  };

  // Subscription plans
  const subscriptionPlans = [
    {
      id: 'premium',
      name: 'Premium Player',
      price: 29.99,
      originalPrice: 39.99,
      description: 'Perfect for regular players',
      features: [
        '10 court credits per month',
        '15% discount on all bookings',
        'Priority booking (24h early access)',
        'Free cancellation up to 2h before',
        'No booking fees',
        'Tournament entry discounts'
      ],
      popular: false,
      color: 'bg-blue-500',
      savings: 25
    },
    {
      id: 'pro',
      name: 'Pro Player',
      price: 49.99,
      originalPrice: 69.99,
      description: 'For serious players and coaches',
      features: [
        'Unlimited court credits',
        '25% discount on all bookings',
        'Priority booking (48h early access)',
        'Free cancellation up to 30min before',
        'No booking fees',
        'Tournament entry discounts',
        'Training session discounts',
        'Equipment rental discounts',
        'Exclusive tournaments access'
      ],
      popular: true,
      color: 'bg-green-500',
      savings: 40
    },
    {
      id: 'elite',
      name: 'Elite Champion',
      price: 99.99,
      originalPrice: 139.99,
      description: 'Ultimate experience for professionals',
      features: [
        'Unlimited court credits',
        '35% discount on all bookings',
        'Instant booking guarantee',
        'Free cancellation anytime',
        'No booking fees',
        'All tournament entries included',
        'Personal coaching sessions',
        'Equipment rental included',
        'VIP tournament access',
        'Dedicated support line',
        'Analytics and performance tracking'
      ],
      popular: false,
      color: 'bg-purple-500',
      savings: 50
    }
  ];

  // Enhanced courts data with subscription features
  const courts = [
    {
      id: '1',
      name: 'Elite Padel Club',
      location: {
        address: 'New Cairo, Cairo',
        city: 'Cairo',
        coordinates: { lat: 30.0444, lng: 31.2357 }
      },
      hourlyRate: 80,
      subscriptionRate: {
        premium: 68, // 15% off
        pro: 60,     // 25% off
        elite: 52    // 35% off
      },
      rating: 4.8,
      reviewCount: 156,
      images: ['/court1.jpg'],
      amenities: ['Parking', 'Changing Rooms', 'Refreshments', 'Equipment Rental'],
      isActive: true,
      isPremiumPartner: true,
      badges: ['Reliable Court', 'Premium Partner'],
      distance: 2.3,
      availableSlots: [
        { 
          startTime: '14:00', 
          endTime: '16:00', 
          price: 80, 
          subscriptionPrice: { premium: 68, pro: 60, elite: 52 },
          isOnSale: false,
          availableForCredits: true,
          creditCost: 1
        },
        { 
          startTime: '16:00', 
          endTime: '18:00', 
          price: 100, 
          subscriptionPrice: { premium: 85, pro: 75, elite: 65 },
          isOnSale: false,
          availableForCredits: true,
          creditCost: 1
        },
        { 
          startTime: '18:00', 
          endTime: '20:00', 
          price: 120, 
          subscriptionPrice: { premium: 102, pro: 90, elite: 78 },
          isOnSale: true, 
          salePrice: 95, 
          salePercentage: 20,
          availableForCredits: true,
          creditCost: 1,
          priorityAccess: true
        }
      ],
      subscriptionBenefits: [
        'Priority booking window',
        'Flexible cancellation',
        'Equipment rental discounts',
        'Tournament hosting priority'
      ]
    },
    {
      id: '2',
      name: 'Sports Complex Arena',
      location: {
        address: 'Zamalek, Cairo',
        city: 'Cairo',
        coordinates: { lat: 30.0626, lng: 31.2497 }
      },
      hourlyRate: 60,
      subscriptionRate: {
        premium: 51, // 15% off
        pro: 45,     // 25% off
        elite: 39    // 35% off
      },
      rating: 4.5,
      reviewCount: 89,
      images: ['/court2.jpg'],
      amenities: ['Parking', 'Changing Rooms', 'Cafe'],
      isActive: true,
      isPremiumPartner: false,
      badges: ['Reliable Court', 'Best Value'],
      distance: 5.1,
      availableSlots: [
        { 
          startTime: '10:00', 
          endTime: '12:00', 
          price: 60, 
          subscriptionPrice: { premium: 51, pro: 45, elite: 39 },
          isOnSale: false,
          availableForCredits: true,
          creditCost: 1
        },
        { 
          startTime: '12:00', 
          endTime: '14:00', 
          price: 60, 
          subscriptionPrice: { premium: 51, pro: 45, elite: 39 },
          isOnSale: false,
          availableForCredits: true,
          creditCost: 1
        },
        { 
          startTime: '20:00', 
          endTime: '22:00', 
          price: 70, 
          subscriptionPrice: { premium: 60, pro: 53, elite: 46 },
          isOnSale: true, 
          salePrice: 50, 
          salePercentage: 30,
          availableForCredits: true,
          creditCost: 1
        }
      ],
      subscriptionBenefits: [
        'Discounted rates',
        'No booking fees',
        'Extended cancellation window'
      ]
    }
  ];

  // Mock user bookings with subscription features
  const userBookings = [
    {
      id: '1',
      courtName: 'Elite Padel Club',
      date: '2024-03-22',
      startTime: '16:00',
      endTime: '18:00',
      originalPrice: 100,
      paidPrice: 75,
      paymentMethod: 'credits',
      creditsUsed: 1,
      discountApplied: 25,
      status: 'confirmed',
      cancellationDeadline: '2024-03-22T14:00:00Z',
      canCancel: true
    },
    {
      id: '2',
      courtName: 'Sports Complex Arena',
      date: '2024-03-25',
      startTime: '14:00',
      endTime: '16:00',
      originalPrice: 60,
      paidPrice: 45,
      paymentMethod: 'subscription_discount',
      discountApplied: 25,
      status: 'confirmed',
      cancellationDeadline: '2024-03-25T12:00:00Z',
      canCancel: true
    }
  ];

  const formatTime = (time: string) => {
    return new Date(`2024-01-01T${time}`).toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  };

  const getBadgeColor = (badge: string) => {
    const colors = {
      'Reliable Court': 'bg-green-500 text-white',
      'Best Value': 'bg-blue-500 text-white',
      'Premium Partner': 'bg-purple-500 text-white',
      'New': 'bg-orange-500 text-white'
    };
    return colors[badge as keyof typeof colors] || 'bg-gray-500 text-white';
  };

  const getSubscriptionColor = (type: string) => {
    const colors = {
      'free': 'bg-gray-500',
      'premium': 'bg-blue-500',
      'pro': 'bg-green-500',
      'elite': 'bg-purple-500'
    };
    return colors[type as keyof typeof colors] || 'bg-gray-500';
  };

  const getCurrentPrice = (slot: any) => {
    if (userSubscription.type === 'free') {
      return slot.isOnSale ? slot.salePrice : slot.price;
    }
    return slot.subscriptionPrice[userSubscription.type] || slot.price;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 p-4">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-2xl font-bold text-black">Courts</h1>
            <p className="text-gray-600">Find and book the perfect court</p>
          </div>
          <div className="flex space-x-3">
            {user?.hasRole(['court_owner', 'owner']) && (
              <Button variant="outline">
                <Plus className="w-4 h-4 mr-2" />
                Add Court
              </Button>
            )}
            <Button className="bg-green-500 hover:bg-green-600 text-white">
              <Calendar className="w-4 h-4 mr-2" />
              Quick Book
            </Button>
          </div>
        </div>

        {/* User Subscription Status */}
        {userSubscription.type !== 'free' && (
          <Card className="p-4 mb-4 bg-gradient-to-r from-green-50 to-blue-50">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className={`p-2 rounded-full ${getSubscriptionColor(userSubscription.type)} text-white`}>
                  <Crown className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center space-x-2">
                    <h3 className="font-semibold text-black capitalize">{userSubscription.type} Member</h3>
                    <Badge className="bg-green-500 text-white text-xs">
                      {userSubscription.discountPercentage}% OFF
                    </Badge>
                  </div>
                  <p className="text-sm text-gray-600">
                    {userSubscription.courtCredits}/{userSubscription.totalCredits} credits remaining
                  </p>
                </div>
              </div>
              
              <div className="text-right">
                <div className="text-sm text-gray-600">Next billing: {new Date(userSubscription.nextBillingDate).toLocaleDateString()}</div>
                <Button variant="outline" size="sm" className="mt-1">
                  <Settings className="w-4 h-4 mr-1" />
                  Manage
                </Button>
              </div>
            </div>
            
            <div className="mt-3">
              <div className="flex justify-between text-sm text-gray-600 mb-1">
                <span>Credits Used</span>
                <span>{userSubscription.totalCredits - userSubscription.courtCredits}/{userSubscription.totalCredits}</span>
              </div>
              <Progress 
                value={((userSubscription.totalCredits - userSubscription.courtCredits) / userSubscription.totalCredits) * 100} 
                className="h-2"
              />
            </div>
          </Card>
        )}

        {/* Search and Filters */}
        <div className="flex flex-col lg:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Search courts by name or location..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          
          <Input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="w-full lg:w-auto"
          />
          
          <Select value={selectedLocation} onValueChange={setSelectedLocation}>
            <SelectTrigger className="w-full lg:w-[160px]">
              <SelectValue placeholder="Location" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Locations</SelectItem>
              <SelectItem value="cairo">Cairo</SelectItem>
              <SelectItem value="giza">Giza</SelectItem>
              <SelectItem value="alexandria">Alexandria</SelectItem>
            </SelectContent>
          </Select>

          <Button variant="outline">
            <Filter className="w-4 h-4 mr-2" />
            Filters
          </Button>
        </div>
      </div>

      <div className="p-4">
        <Tabs defaultValue="browse" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="browse">Browse Courts</TabsTrigger>
            <TabsTrigger value="subscriptions">Subscriptions</TabsTrigger>
            <TabsTrigger value="my-bookings">My Bookings</TabsTrigger>
            <TabsTrigger value="favorites">Favorites</TabsTrigger>
          </TabsList>

          <TabsContent value="browse" className="space-y-6 mt-6">
            {/* Court List */}
            <div className="space-y-4">
              {courts.map((court) => (
                <Card key={court.id} className="p-4">
                  <div className="flex flex-col lg:flex-row gap-4">
                    {/* Court Image */}
                    <div className="w-full lg:w-48 h-32 bg-gray-200 rounded-lg flex items-center justify-center relative">
                      <MapPin className="w-8 h-8 text-gray-400" />
                      {court.isPremiumPartner && (
                        <Badge className="absolute top-2 left-2 bg-purple-500 text-white text-xs">
                          <Crown className="w-3 h-3 mr-1" />
                          Premium Partner
                        </Badge>
                      )}
                      <div className="absolute top-2 right-2 flex space-x-1">
                        <Button variant="outline" size="sm" className="w-8 h-8 p-0">
                          <Heart className="w-4 h-4" />
                        </Button>
                        <Button variant="outline" size="sm" className="w-8 h-8 p-0">
                          <Share className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>

                    {/* Court Details */}
                    <div className="flex-1">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <div className="flex items-center space-x-2 mb-2">
                            <h3 className="text-lg font-semibold text-black">{court.name}</h3>
                            {court.badges.map((badge) => (
                              <Badge key={badge} className={`text-xs ${getBadgeColor(badge)}`}>
                                {badge === 'Reliable Court' && <CheckCircle className="w-3 h-3 mr-1" />}
                                {badge}
                              </Badge>
                            ))}
                          </div>
                          
                          <div className="flex items-center space-x-4 text-sm text-gray-600 mb-2">
                            <div className="flex items-center">
                              <MapPin className="w-4 h-4 mr-1" />
                              {court.location.address} • {court.distance}km away
                            </div>
                            <div className="flex items-center">
                              <Star className="w-4 h-4 mr-1 fill-current text-yellow-400" />
                              {court.rating} ({court.reviewCount} reviews)
                            </div>
                          </div>

                          <div className="flex items-center space-x-2 mb-3">
                            <DollarSign className="w-4 h-4 text-gray-600" />
                            <span className="text-lg font-semibold text-black">
                              ${userSubscription.type !== 'free' 
                                ? court.subscriptionRate[userSubscription.type] 
                                : court.hourlyRate
                              }/hour
                            </span>
                            {userSubscription.type !== 'free' && (
                              <span className="text-sm text-green-600">
                                (Save ${court.hourlyRate - court.subscriptionRate[userSubscription.type]})
                              </span>
                            )}
                          </div>

                          {/* Amenities */}
                          <div className="flex flex-wrap gap-2 mb-3">
                            {court.amenities.slice(0, 4).map((amenity) => (
                              <Badge key={amenity} variant="outline" className="text-xs">
                                {amenity}
                              </Badge>
                            ))}
                            {court.amenities.length > 4 && (
                              <Badge variant="outline" className="text-xs">
                                +{court.amenities.length - 4} more
                              </Badge>
                            )}
                          </div>

                          {/* Subscription Benefits */}
                          {court.isPremiumPartner && userSubscription.type !== 'free' && (
                            <div className="bg-purple-50 rounded-lg p-2 mb-3">
                              <div className="text-xs font-medium text-purple-700 mb-1">Member Benefits:</div>
                              <div className="flex flex-wrap gap-1">
                                {court.subscriptionBenefits.slice(0, 2).map((benefit, index) => (
                                  <span key={index} className="text-xs text-purple-600">
                                    • {benefit}
                                  </span>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Available Slots */}
                      <div>
                        <h4 className="text-sm font-medium text-black mb-2">
                          Available today ({new Date(selectedDate).toLocaleDateString()})
                        </h4>
                        <div className="flex flex-wrap gap-2">
                          {court.availableSlots.map((slot, index) => {
                            const currentPrice = getCurrentPrice(slot);
                            const canUseCredits = userSubscription.type !== 'free' && 
                                                 slot.availableForCredits && 
                                                 userSubscription.courtCredits >= slot.creditCost;
                            
                            return (
                              <Button
                                key={index}
                                variant="outline"
                                size="sm"
                                className={`relative flex-col h-auto p-2 ${
                                  slot.isOnSale ? 'border-green-500 bg-green-50' : ''
                                } ${slot.priorityAccess && userSubscription.priorityBooking ? 'border-purple-500 bg-purple-50' : ''}`}
                              >
                                {slot.isOnSale && (
                                  <Zap className="w-3 h-3 absolute -top-1 -right-1 text-green-500" />
                                )}
                                {slot.priorityAccess && userSubscription.priorityBooking && (
                                  <Crown className="w-3 h-3 absolute -top-1 -left-1 text-purple-500" />
                                )}
                                
                                <div className="text-center">
                                  <div className="text-xs font-medium">
                                    {formatTime(slot.startTime)} - {formatTime(slot.endTime)}
                                  </div>
                                  <div className="text-xs mt-1">
                                    <div className="flex items-center space-x-1">
                                      <span className="font-semibold">${currentPrice}</span>
                                      {userSubscription.type !== 'free' && slot.price > currentPrice && (
                                        <span className="line-through text-gray-400 text-xs">${slot.price}</span>
                                      )}
                                    </div>
                                    {canUseCredits && (
                                      <div className="text-xs text-blue-600 mt-1">
                                        or {slot.creditCost} credit{slot.creditCost > 1 ? 's' : ''}
                                      </div>
                                    )}
                                  </div>
                                </div>
                              </Button>
                            );
                          })}
                        </div>
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="subscriptions" className="space-y-6 mt-6">
            {/* Current Subscription Status */}
            <Card className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-semibold text-black">Your Subscription</h2>
                <Badge className={`${getSubscriptionColor(userSubscription.type)} text-white`}>
                  <Crown className="w-3 h-3 mr-1" />
                  {userSubscription.type.toUpperCase()}
                </Badge>
              </div>

              {userSubscription.type === 'free' ? (
                <div className="text-center py-8">
                  <Package className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-black mb-2">Upgrade Your Experience</h3>
                  <p className="text-gray-600 mb-6">
                    Get access to exclusive discounts, priority booking, and more benefits
                  </p>
                  <Button className="bg-green-500 hover:bg-green-600 text-white">
                    <Crown className="w-4 h-4 mr-2" />
                    View Plans
                  </Button>
                </div>
              ) : (
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600">{userSubscription.discountPercentage}%</div>
                    <div className="text-sm text-gray-600">Discount on all bookings</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-black">{userSubscription.courtCredits}</div>
                    <div className="text-sm text-gray-600">Credits remaining</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-600">
                      {userSubscription.cancellationPolicy === 'flexible' ? '30min' : 
                       userSubscription.cancellationPolicy === 'moderate' ? '2h' : '24h'}
                    </div>
                    <div className="text-sm text-gray-600">Free cancellation window</div>
                  </div>
                </div>
              )}
            </Card>

            {/* Subscription Plans */}
            <div>
              <h2 className="text-xl font-semibold text-black mb-6">Choose Your Plan</h2>
              
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {subscriptionPlans.map((plan) => (
                  <Card 
                    key={plan.id} 
                    className={`p-6 relative ${plan.popular ? 'border-green-500 shadow-lg' : ''}`}
                  >
                    {plan.popular && (
                      <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-green-500 text-white">
                        Most Popular
                      </Badge>
                    )}
                    
                    <div className="text-center mb-6">
                      <div className={`p-3 rounded-full ${plan.color} text-white w-fit mx-auto mb-4`}>
                        <Crown className="w-6 h-6" />
                      </div>
                      <h3 className="text-xl font-semibold text-black mb-2">{plan.name}</h3>
                      <p className="text-gray-600 text-sm mb-4">{plan.description}</p>
                      
                      <div className="mb-2">
                        <span className="text-3xl font-bold text-black">${plan.price}</span>
                        <span className="text-gray-600">/month</span>
                      </div>
                      <div className="text-sm text-gray-500">
                        <span className="line-through">${plan.originalPrice}</span>
                        <span className="text-green-600 ml-2">Save {plan.savings}%</span>
                      </div>
                    </div>
                    
                    <div className="space-y-3 mb-6">
                      {plan.features.map((feature, index) => (
                        <div key={index} className="flex items-start space-x-2">
                          <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                          <span className="text-sm text-gray-700">{feature}</span>
                        </div>
                      ))}
                    </div>
                    
                    <Button 
                      className={`w-full ${
                        userSubscription.type === plan.id 
                          ? 'bg-gray-500 cursor-not-allowed' 
                          : plan.popular 
                            ? 'bg-green-500 hover:bg-green-600' 
                            : 'bg-blue-500 hover:bg-blue-600'
                      } text-white`}
                      disabled={userSubscription.type === plan.id}
                    >
                      {userSubscription.type === plan.id ? (
                        <>
                          <CheckCircle className="w-4 h-4 mr-2" />
                          Current Plan
                        </>
                      ) : userSubscription.type !== 'free' ? (
                        <>
                          <RefreshCw className="w-4 h-4 mr-2" />
                          Switch Plan
                        </>
                      ) : (
                        <>
                          <Crown className="w-4 h-4 mr-2" />
                          Upgrade Now
                        </>
                      )}
                    </Button>
                  </Card>
                ))}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="my-bookings" className="space-y-6 mt-6">
            {/* User Bookings with Subscription Features */}
            <Card className="p-6">
              <h2 className="text-xl font-semibold text-black mb-6">Your Bookings</h2>
              
              <div className="space-y-4">
                {userBookings.map((booking) => (
                  <div key={booking.id} className="p-4 border border-gray-200 rounded-lg">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-2">
                          <h3 className="font-semibold text-black">{booking.courtName}</h3>
                          <Badge className="bg-green-500 text-white">
                            <CheckCircle className="w-3 h-3 mr-1" />
                            {booking.status}
                          </Badge>
                          {booking.paymentMethod === 'credits' && (
                            <Badge className="bg-blue-500 text-white text-xs">
                              <CreditCard className="w-3 h-3 mr-1" />
                              {booking.creditsUsed} Credit Used
                            </Badge>
                          )}
                        </div>
                        
                        <div className="grid grid-cols-2 lg:grid-cols-5 gap-4 text-sm text-gray-600 mb-2">
                          <div>
                            <span className="font-medium">Date:</span> {new Date(booking.date).toLocaleDateString()}
                          </div>
                          <div>
                            <span className="font-medium">Time:</span> {booking.startTime} - {booking.endTime}
                          </div>
                          <div>
                            <span className="font-medium">Original:</span> ${booking.originalPrice}
                          </div>
                          <div>
                            <span className="font-medium">Paid:</span> 
                            <span className="text-green-600 ml-1">${booking.paidPrice}</span>
                          </div>
                          <div>
                            <span className="font-medium">Saved:</span> 
                            <span className="text-green-600 ml-1">${booking.originalPrice - booking.paidPrice}</span>
                          </div>
                        </div>

                        {booking.canCancel && (
                          <div className="text-xs text-gray-500">
                            <AlertCircle className="w-3 h-3 inline mr-1" />
                            Free cancellation until {new Date(booking.cancellationDeadline).toLocaleString()}
                          </div>
                        )}
                      </div>

                      <div className="flex space-x-2">
                        {booking.canCancel && (
                          <Button variant="outline" size="sm">
                            Cancel
                          </Button>
                        )}
                        <Button size="sm" className="bg-green-500 hover:bg-green-600 text-white">
                          View QR
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="favorites" className="space-y-6 mt-6">
            <Card className="p-6">
              <div className="text-center py-8">
                <Heart className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-black mb-2">No favorite courts yet</h3>
                <p className="text-gray-600 mb-4">Save courts you love to quickly find them later</p>
                <Button className="bg-green-500 hover:bg-green-600 text-white">
                  Browse Courts
                </Button>
              </div>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
