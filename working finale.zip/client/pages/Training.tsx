import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { 
  User, 
  Star, 
  MapPin, 
  Clock, 
  DollarSign,
  Calendar,
  Filter,
  Search,
  Award,
  TrendingUp,
  Play,
  BookOpen,
  Target,
  Heart,
  MessageCircle,
  Phone,
  Video,
  CheckCircle,
  Trophy,
  BarChart3,
  Users,
  Plus
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Progress } from '@/components/ui/progress';

export default function Training() {
  const { t } = useTranslation();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSpecialty, setSelectedSpecialty] = useState('all');
  const [selectedLocation, setSelectedLocation] = useState('all');
  const [selectedPriceRange, setSelectedPriceRange] = useState('all');

  // Mock user progress data
  const userProgress = {
    level: 'Intermediate',
    skillPoints: 2450,
    nextLevelPoints: 3000,
    completedSessions: 18,
    totalHours: 24,
    improvementRate: 15,
    strengths: ['Backhand', 'Court Positioning'],
    improvements: ['Serve Power', 'Net Play']
  };

  // Mock coaches data
  const coaches = [
    {
      id: '1',
      name: 'Ahmed El-Masry',
      avatar: '/coach1.jpg',
      rating: 4.9,
      reviewCount: 127,
      specialties: ['Technique', 'Mental Game', 'Tournament Prep'],
      experience: '8 years',
      languages: ['Arabic', 'English'],
      location: 'New Cairo',
      pricePerHour: 120,
      availability: 'Available today',
      successRate: 92,
      studentsCount: 48,
      bio: 'Former professional player turned coach specializing in technique refinement and mental preparation.',
      achievements: ['National Championship Runner-up 2018', 'Certified PTR Professional'],
      sessionTypes: ['1-on-1', 'Group', 'Online'],
      isVerified: true,
      responseTime: '< 2 hours'
    },
    {
      id: '2',
      name: 'Sarah Hassan',
      avatar: '/coach2.jpg',
      rating: 4.8,
      reviewCount: 89,
      specialties: ['Beginners', 'Fitness', 'Strategy'],
      experience: '5 years',
      languages: ['Arabic', 'English', 'French'],
      location: 'Zamalek',
      pricePerHour: 100,
      availability: 'Available tomorrow',
      successRate: 88,
      studentsCount: 32,
      bio: 'Passionate about introducing new players to padel and building strong fundamentals.',
      achievements: ['Level 2 FIP Coach', 'Sports Science Degree'],
      sessionTypes: ['1-on-1', 'Group'],
      isVerified: true,
      responseTime: '< 4 hours'
    },
    {
      id: '3',
      name: 'Mohamed Farid',
      avatar: '/coach3.jpg',
      rating: 4.7,
      reviewCount: 156,
      specialties: ['Advanced Play', 'Power Development', 'Competition'],
      experience: '12 years',
      languages: ['Arabic', 'English'],
      location: 'Maadi',
      pricePerHour: 150,
      availability: 'Available next week',
      successRate: 95,
      studentsCount: 76,
      bio: 'Elite coach focusing on advanced techniques and competitive performance enhancement.',
      achievements: ['Former National Team Coach', 'International Tournament Winner'],
      sessionTypes: ['1-on-1', 'Advanced Groups'],
      isVerified: true,
      responseTime: '< 1 hour'
    }
  ];

  // Mock training programs
  const trainingPrograms = [
    {
      id: '1',
      title: 'Beginner Fundamentals',
      description: 'Master the basics of padel in 8 comprehensive sessions',
      duration: '4 weeks',
      sessions: 8,
      difficulty: 'Beginner',
      price: 800,
      features: ['Basic Techniques', 'Court Rules', 'Equipment Guide', 'Practice Drills'],
      instructor: 'Sarah Hassan',
      rating: 4.8,
      studentsEnrolled: 24,
      nextStart: '2024-03-25'
    },
    {
      id: '2',
      title: 'Competitive Edge',
      description: 'Advanced tactics and mental preparation for tournaments',
      duration: '6 weeks',
      sessions: 12,
      difficulty: 'Advanced',
      price: 1500,
      features: ['Tournament Strategy', 'Mental Training', 'Advanced Techniques', 'Match Analysis'],
      instructor: 'Ahmed El-Masry',
      rating: 4.9,
      studentsEnrolled: 16,
      nextStart: '2024-04-01'
    },
    {
      id: '3',
      title: 'Power & Precision',
      description: 'Develop explosive shots and precise placement',
      duration: '5 weeks',
      sessions: 10,
      difficulty: 'Intermediate',
      price: 1200,
      features: ['Power Development', 'Shot Precision', 'Fitness Training', 'Video Analysis'],
      instructor: 'Mohamed Farid',
      rating: 4.7,
      studentsEnrolled: 18,
      nextStart: '2024-03-30'
    }
  ];

  // Mock user sessions
  const upcomingSessions = [
    {
      id: '1',
      coachName: 'Ahmed El-Masry',
      type: '1-on-1 Session',
      date: '2024-03-22',
      time: '16:00',
      duration: '1 hour',
      location: 'Elite Padel Club',
      focus: 'Backhand Technique',
      price: 120,
      status: 'confirmed'
    },
    {
      id: '2',
      coachName: 'Sarah Hassan',
      type: 'Group Session',
      date: '2024-03-24',
      time: '10:00',
      duration: '1.5 hours',
      location: 'Sports Complex',
      focus: 'Fundamentals Review',
      price: 60,
      status: 'confirmed'
    }
  ];

  // Mock skill assessments
  const skillAssessment = {
    overall: 72,
    skills: [
      { name: 'Serve', level: 68, improvement: '+5' },
      { name: 'Forehand', level: 78, improvement: '+3' },
      { name: 'Backhand', level: 82, improvement: '+8' },
      { name: 'Volley', level: 65, improvement: '+2' },
      { name: 'Strategy', level: 74, improvement: '+6' },
      { name: 'Fitness', level: 70, improvement: '+4' }
    ]
  };

  const getDifficultyColor = (difficulty: string) => {
    const colors = {
      'Beginner': 'bg-green-500 text-white',
      'Intermediate': 'bg-blue-500 text-white',
      'Advanced': 'bg-purple-500 text-white'
    };
    return colors[difficulty as keyof typeof colors] || 'bg-gray-500 text-white';
  };

  const getSkillColor = (level: number) => {
    if (level >= 80) return 'bg-green-500';
    if (level >= 60) return 'bg-blue-500';
    return 'bg-orange-500';
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 p-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-black">Training</h1>
            <p className="text-gray-600">Find coaches and improve your skills</p>
          </div>
          <Button className="bg-green-500 hover:bg-green-600 text-white">
            <Plus className="w-4 h-4 mr-2" />
            Book Session
          </Button>
        </div>
      </div>

      <div className="p-4">
        <Tabs defaultValue="coaches" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="coaches">Find Coaches</TabsTrigger>
            <TabsTrigger value="programs">Programs</TabsTrigger>
            <TabsTrigger value="progress">My Progress</TabsTrigger>
            <TabsTrigger value="sessions">My Sessions</TabsTrigger>
          </TabsList>

          <TabsContent value="coaches" className="space-y-6 mt-6">
            {/* Search and Filters */}
            <Card className="p-4">
              <div className="flex flex-col lg:flex-row gap-3">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    placeholder="Search coaches by name or specialty..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
                
                <Select value={selectedSpecialty} onValueChange={setSelectedSpecialty}>
                  <SelectTrigger className="w-full lg:w-[160px]">
                    <SelectValue placeholder="Specialty" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Specialties</SelectItem>
                    <SelectItem value="technique">Technique</SelectItem>
                    <SelectItem value="strategy">Strategy</SelectItem>
                    <SelectItem value="fitness">Fitness</SelectItem>
                    <SelectItem value="mental">Mental Game</SelectItem>
                    <SelectItem value="beginners">Beginners</SelectItem>
                  </SelectContent>
                </Select>
                
                <Select value={selectedLocation} onValueChange={setSelectedLocation}>
                  <SelectTrigger className="w-full lg:w-[140px]">
                    <SelectValue placeholder="Location" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Areas</SelectItem>
                    <SelectItem value="cairo">New Cairo</SelectItem>
                    <SelectItem value="zamalek">Zamalek</SelectItem>
                    <SelectItem value="maadi">Maadi</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={selectedPriceRange} onValueChange={setSelectedPriceRange}>
                  <SelectTrigger className="w-full lg:w-[140px]">
                    <SelectValue placeholder="Price Range" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Prices</SelectItem>
                    <SelectItem value="0-100">$0 - $100</SelectItem>
                    <SelectItem value="100-150">$100 - $150</SelectItem>
                    <SelectItem value="150+">$150+</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </Card>

            {/* Coaches List */}
            <div className="space-y-4">
              {coaches.map((coach) => (
                <Card key={coach.id} className="p-6">
                  <div className="flex flex-col lg:flex-row gap-6">
                    {/* Coach Profile */}
                    <div className="flex items-start space-x-4">
                      <Avatar className="w-20 h-20">
                        <AvatarImage src={coach.avatar} />
                        <AvatarFallback>{coach.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                      </Avatar>
                      
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-2">
                          <h3 className="text-xl font-semibold text-black">{coach.name}</h3>
                          {coach.isVerified && (
                            <Badge className="bg-green-500 text-white text-xs">
                              <CheckCircle className="w-3 h-3 mr-1" />
                              Verified
                            </Badge>
                          )}
                        </div>
                        
                        <div className="flex items-center space-x-4 text-sm text-gray-600 mb-3">
                          <div className="flex items-center">
                            <Star className="w-4 h-4 mr-1 fill-current text-yellow-400" />
                            {coach.rating} ({coach.reviewCount} reviews)
                          </div>
                          <div className="flex items-center">
                            <MapPin className="w-4 h-4 mr-1" />
                            {coach.location}
                          </div>
                          <div className="flex items-center">
                            <Users className="w-4 h-4 mr-1" />
                            {coach.studentsCount} students
                          </div>
                        </div>

                        <p className="text-gray-700 mb-3">{coach.bio}</p>

                        {/* Specialties */}
                        <div className="flex flex-wrap gap-2 mb-3">
                          {coach.specialties.map((specialty) => (
                            <Badge key={specialty} variant="outline" className="text-xs">
                              {specialty}
                            </Badge>
                          ))}
                        </div>

                        {/* Languages */}
                        <div className="text-sm text-gray-600 mb-2">
                          <span className="font-medium">Languages:</span> {coach.languages.join(', ')}
                        </div>

                        {/* Session Types */}
                        <div className="text-sm text-gray-600">
                          <span className="font-medium">Session Types:</span> {coach.sessionTypes.join(', ')}
                        </div>
                      </div>
                    </div>

                    {/* Coach Stats & Booking */}
                    <div className="lg:w-80 space-y-4">
                      {/* Stats */}
                      <div className="grid grid-cols-2 gap-4">
                        <div className="text-center p-3 bg-gray-50 rounded-lg">
                          <div className="text-lg font-bold text-black">{coach.experience}</div>
                          <div className="text-xs text-gray-600">Experience</div>
                        </div>
                        <div className="text-center p-3 bg-gray-50 rounded-lg">
                          <div className="text-lg font-bold text-green-600">{coach.successRate}%</div>
                          <div className="text-xs text-gray-600">Success Rate</div>
                        </div>
                      </div>

                      {/* Availability */}
                      <div className="p-3 bg-green-50 rounded-lg">
                        <div className="flex items-center text-green-700 mb-1">
                          <Clock className="w-4 h-4 mr-1" />
                          <span className="text-sm font-medium">{coach.availability}</span>
                        </div>
                        <div className="text-xs text-green-600">
                          Response time: {coach.responseTime}
                        </div>
                      </div>

                      {/* Price */}
                      <div className="text-center">
                        <div className="text-2xl font-bold text-black">${coach.pricePerHour}</div>
                        <div className="text-sm text-gray-600">per hour</div>
                      </div>

                      {/* Action Buttons */}
                      <div className="space-y-2">
                        <Button className="w-full bg-green-500 hover:bg-green-600 text-white">
                          <Calendar className="w-4 h-4 mr-2" />
                          Book Session
                        </Button>
                        <div className="grid grid-cols-3 gap-2">
                          <Button variant="outline" size="sm">
                            <MessageCircle className="w-4 h-4" />
                          </Button>
                          <Button variant="outline" size="sm">
                            <Phone className="w-4 h-4" />
                          </Button>
                          <Button variant="outline" size="sm">
                            <Video className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="programs" className="space-y-6 mt-6">
            <div className="grid gap-6">
              {trainingPrograms.map((program) => (
                <Card key={program.id} className="p-6">
                  <div className="flex flex-col lg:flex-row gap-6">
                    <div className="flex-1">
                      <div className="flex items-start justify-between mb-4">
                        <div>
                          <h3 className="text-xl font-semibold text-black mb-2">{program.title}</h3>
                          <p className="text-gray-600 mb-3">{program.description}</p>
                          
                          <div className="flex items-center space-x-4 text-sm text-gray-600 mb-3">
                            <div className="flex items-center">
                              <Clock className="w-4 h-4 mr-1" />
                              {program.duration}
                            </div>
                            <div className="flex items-center">
                              <BookOpen className="w-4 h-4 mr-1" />
                              {program.sessions} sessions
                            </div>
                            <div className="flex items-center">
                              <Star className="w-4 h-4 mr-1 fill-current text-yellow-400" />
                              {program.rating}
                            </div>
                            <div className="flex items-center">
                              <Users className="w-4 h-4 mr-1" />
                              {program.studentsEnrolled} enrolled
                            </div>
                          </div>

                          <Badge className={getDifficultyColor(program.difficulty)}>
                            {program.difficulty}
                          </Badge>
                        </div>
                      </div>

                      {/* Features */}
                      <div className="mb-4">
                        <h4 className="text-sm font-medium text-black mb-2">What you'll learn:</h4>
                        <div className="grid grid-cols-2 gap-2">
                          {program.features.map((feature) => (
                            <div key={feature} className="flex items-center text-sm text-gray-600">
                              <CheckCircle className="w-4 h-4 mr-2 text-green-500" />
                              {feature}
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Instructor */}
                      <div className="text-sm text-gray-600 mb-2">
                        <span className="font-medium">Instructor:</span> {program.instructor}
                      </div>
                      
                      {/* Next Start */}
                      <div className="text-sm text-gray-600">
                        <span className="font-medium">Next Start:</span> {new Date(program.nextStart).toLocaleDateString()}
                      </div>
                    </div>

                    {/* Price & Enrollment */}
                    <div className="lg:w-64 space-y-4">
                      <div className="text-center p-4 bg-gray-50 rounded-lg">
                        <div className="text-3xl font-bold text-black mb-1">${program.price}</div>
                        <div className="text-sm text-gray-600">Total Program Cost</div>
                        <div className="text-xs text-gray-500 mt-1">
                          ${Math.round(program.price / program.sessions)}/session
                        </div>
                      </div>

                      <Button className="w-full bg-green-500 hover:bg-green-600 text-white">
                        <Play className="w-4 h-4 mr-2" />
                        Enroll Now
                      </Button>
                      
                      <Button variant="outline" className="w-full">
                        <BookOpen className="w-4 h-4 mr-2" />
                        View Curriculum
                      </Button>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="progress" className="space-y-6 mt-6">
            {/* Overall Progress */}
            <Card className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold text-black">Your Progress</h2>
                <Badge className="bg-blue-500 text-white">
                  <Target className="w-3 h-3 mr-1" />
                  {userProgress.level}
                </Badge>
              </div>

              <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
                <div className="text-center">
                  <div className="text-2xl font-bold text-black">{userProgress.skillPoints}</div>
                  <div className="text-sm text-gray-600">Skill Points</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">{userProgress.completedSessions}</div>
                  <div className="text-sm text-gray-600">Sessions Completed</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-black">{userProgress.totalHours}h</div>
                  <div className="text-sm text-gray-600">Training Hours</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">+{userProgress.improvementRate}%</div>
                  <div className="text-sm text-gray-600">Improvement Rate</div>
                </div>
              </div>

              {/* Level Progress */}
              <div className="mb-6">
                <div className="flex justify-between text-sm text-gray-600 mb-2">
                  <span>Progress to next level</span>
                  <span>{userProgress.nextLevelPoints - userProgress.skillPoints} points needed</span>
                </div>
                <Progress 
                  value={(userProgress.skillPoints / userProgress.nextLevelPoints) * 100} 
                  className="h-3"
                />
              </div>

              {/* Strengths & Improvements */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-lg font-semibold text-black mb-3">Strengths</h3>
                  <div className="space-y-2">
                    {userProgress.strengths.map((strength) => (
                      <div key={strength} className="flex items-center text-green-600">
                        <CheckCircle className="w-4 h-4 mr-2" />
                        {strength}
                      </div>
                    ))}
                  </div>
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-black mb-3">Focus Areas</h3>
                  <div className="space-y-2">
                    {userProgress.improvements.map((improvement) => (
                      <div key={improvement} className="flex items-center text-orange-600">
                        <Target className="w-4 h-4 mr-2" />
                        {improvement}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </Card>

            {/* Skill Assessment */}
            <Card className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold text-black">Skill Assessment</h2>
                <div className="text-right">
                  <div className="text-2xl font-bold text-black">{skillAssessment.overall}%</div>
                  <div className="text-sm text-gray-600">Overall Score</div>
                </div>
              </div>

              <div className="space-y-4">
                {skillAssessment.skills.map((skill) => (
                  <div key={skill.name}>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-medium text-black">{skill.name}</span>
                      <div className="flex items-center space-x-2">
                        <span className="text-sm text-green-600">{skill.improvement}</span>
                        <span className="text-sm text-gray-600">{skill.level}%</span>
                      </div>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className={`h-2 rounded-full ${getSkillColor(skill.level)}`}
                        style={{ width: `${skill.level}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="sessions" className="space-y-6 mt-6">
            {/* Upcoming Sessions */}
            <Card className="p-6">
              <h2 className="text-xl font-semibold text-black mb-4">Upcoming Sessions</h2>
              
              <div className="space-y-4">
                {upcomingSessions.map((session) => (
                  <div key={session.id} className="p-4 border border-gray-200 rounded-lg">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-2">
                          <h3 className="font-semibold text-black">{session.coachName}</h3>
                          <Badge variant="outline">{session.type}</Badge>
                          <Badge className="bg-green-500 text-white">
                            <CheckCircle className="w-3 h-3 mr-1" />
                            {session.status}
                          </Badge>
                        </div>
                        
                        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 text-sm text-gray-600 mb-2">
                          <div className="flex items-center">
                            <Calendar className="w-4 h-4 mr-1" />
                            {new Date(session.date).toLocaleDateString()}
                          </div>
                          <div className="flex items-center">
                            <Clock className="w-4 h-4 mr-1" />
                            {session.time} ({session.duration})
                          </div>
                          <div className="flex items-center">
                            <MapPin className="w-4 h-4 mr-1" />
                            {session.location}
                          </div>
                          <div className="flex items-center">
                            <DollarSign className="w-4 h-4 mr-1" />
                            ${session.price}
                          </div>
                        </div>

                        <div className="text-sm">
                          <span className="font-medium text-black">Focus:</span> 
                          <span className="text-gray-600 ml-1">{session.focus}</span>
                        </div>
                      </div>

                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm">
                          Reschedule
                        </Button>
                        <Button variant="outline" size="sm">
                          Cancel
                        </Button>
                        <Button size="sm" className="bg-green-500 hover:bg-green-600 text-white">
                          View Details
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </Card>

            {/* Session History */}
            <Card className="p-6">
              <h2 className="text-xl font-semibold text-black mb-4">Recent Sessions</h2>
              
              <div className="text-center py-8">
                <BarChart3 className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-black mb-2">Track Your Progress</h3>
                <p className="text-gray-600 mb-4">Complete more sessions to see your improvement analytics here</p>
                <Button className="bg-green-500 hover:bg-green-600 text-white">
                  Book Your First Session
                </Button>
              </div>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
