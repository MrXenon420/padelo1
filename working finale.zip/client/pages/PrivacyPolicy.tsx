import React from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Shield, Eye, Lock, Users, Database, Globe, Phone, Mail } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function PrivacyPolicy() {
  const navigate = useNavigate();

  const handleBackClick = () => {
    if (window.history.length > 1) {
      navigate(-1);
    } else {
      navigate('/');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 dark:from-gray-900 dark:to-gray-800 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-6">
          <Button 
            variant="outline" 
            onClick={handleBackClick}
            className="mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          
          <Card className="p-6">
            <div className="flex items-center mb-4">
              <div className="p-3 bg-green-100 rounded-full mr-4">
                <Shield className="w-8 h-8 text-green-600" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-black">Privacy Policy</h1>
                <p className="text-gray-600">Last updated: {new Date().toLocaleDateString()}</p>
              </div>
            </div>
            <p className="text-lg text-gray-700">
              At Padelo, we are committed to protecting your privacy and ensuring the security of your personal information. 
              This policy explains how we collect, use, and safeguard your data.
            </p>
          </Card>
        </div>

        {/* Table of Contents */}
        <Card className="p-6 mb-6">
          <h2 className="text-xl font-semibold text-black mb-4">Table of Contents</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
            <a href="#information-we-collect" className="text-green-600 hover:text-green-500 py-1">1. Information We Collect</a>
            <a href="#how-we-use" className="text-green-600 hover:text-green-500 py-1">2. How We Use Your Information</a>
            <a href="#information-sharing" className="text-green-600 hover:text-green-500 py-1">3. Information Sharing</a>
            <a href="#data-security" className="text-green-600 hover:text-green-500 py-1">4. Data Security</a>
            <a href="#your-rights" className="text-green-600 hover:text-green-500 py-1">5. Your Privacy Rights</a>
            <a href="#cookies" className="text-green-600 hover:text-green-500 py-1">6. Cookies and Tracking</a>
            <a href="#children" className="text-green-600 hover:text-green-500 py-1">7. Children's Privacy</a>
            <a href="#changes" className="text-green-600 hover:text-green-500 py-1">8. Policy Changes</a>
            <a href="#contact" className="text-green-600 hover:text-green-500 py-1">9. Contact Information</a>
          </div>
        </Card>

        {/* Privacy Policy Content */}
        <div className="space-y-6">
          
          {/* Section 1: Information We Collect */}
          <Card className="p-6" id="information-we-collect">
            <div className="flex items-center mb-4">
              <Database className="w-6 h-6 text-green-600 mr-3" />
              <h2 className="text-2xl font-semibold text-black">1. Information We Collect</h2>
            </div>
            
            <div className="space-y-4 text-gray-700">
              <div>
                <h3 className="text-lg font-medium text-black mb-2">Personal Information</h3>
                <ul className="list-disc list-inside space-y-1 ml-4">
                  <li>Name, email address, and phone number</li>
                  <li>Profile information including photo and preferences</li>
                  <li>Payment information (processed securely by third-party providers)</li>
                  <li>Communication history and support interactions</li>
                </ul>
              </div>
              
              <div>
                <h3 className="text-lg font-medium text-black mb-2">Activity Information</h3>
                <ul className="list-disc list-inside space-y-1 ml-4">
                  <li>Court bookings and match participation</li>
                  <li>Tournament registrations and results</li>
                  <li>Training sessions and coaching interactions</li>
                  <li>Marketplace transactions and listings</li>
                </ul>
              </div>
              
              <div>
                <h3 className="text-lg font-medium text-black mb-2">Technical Information</h3>
                <ul className="list-disc list-inside space-y-1 ml-4">
                  <li>Device information and IP address</li>
                  <li>App usage patterns and performance data</li>
                  <li>Location data (when you grant permission)</li>
                  <li>Crash reports and error logs</li>
                </ul>
              </div>
            </div>
          </Card>

          {/* Section 2: How We Use Your Information */}
          <Card className="p-6" id="how-we-use">
            <div className="flex items-center mb-4">
              <Eye className="w-6 h-6 text-green-600 mr-3" />
              <h2 className="text-2xl font-semibold text-black">2. How We Use Your Information</h2>
            </div>
            
            <div className="space-y-4 text-gray-700">
              <div>
                <h3 className="text-lg font-medium text-black mb-2">Service Provision</h3>
                <ul className="list-disc list-inside space-y-1 ml-4">
                  <li>Process court bookings and tournament registrations</li>
                  <li>Facilitate connections between players, coaches, and venues</li>
                  <li>Handle payment processing and financial transactions</li>
                  <li>Provide customer support and resolve issues</li>
                </ul>
              </div>
              
              <div>
                <h3 className="text-lg font-medium text-black mb-2">Communication</h3>
                <ul className="list-disc list-inside space-y-1 ml-4">
                  <li>Send booking confirmations and reminders</li>
                  <li>Notify you of tournament updates and matches</li>
                  <li>Share important service announcements</li>
                  <li>Send promotional offers (with your consent)</li>
                </ul>
              </div>
              
              <div>
                <h3 className="text-lg font-medium text-black mb-2">Platform Improvement</h3>
                <ul className="list-disc list-inside space-y-1 ml-4">
                  <li>Analyze usage patterns to enhance user experience</li>
                  <li>Develop new features and services</li>
                  <li>Prevent fraud and ensure platform security</li>
                  <li>Conduct research and analytics</li>
                </ul>
              </div>
            </div>
          </Card>

          {/* Section 3: Information Sharing */}
          <Card className="p-6" id="information-sharing">
            <div className="flex items-center mb-4">
              <Users className="w-6 h-6 text-green-600 mr-3" />
              <h2 className="text-2xl font-semibold text-black">3. Information Sharing</h2>
            </div>
            
            <div className="space-y-4 text-gray-700">
              <p>We never sell your personal information. We may share your information only in these limited circumstances:</p>
              
              <div>
                <h3 className="text-lg font-medium text-black mb-2">Service Partners</h3>
                <ul className="list-disc list-inside space-y-1 ml-4">
                  <li>Payment processors for secure transaction handling</li>
                  <li>Cloud service providers for data storage and backup</li>
                  <li>Communication services for notifications and emails</li>
                  <li>Analytics providers for service improvement</li>
                </ul>
              </div>
              
              <div>
                <h3 className="text-lg font-medium text-black mb-2">Legal Requirements</h3>
                <ul className="list-disc list-inside space-y-1 ml-4">
                  <li>When required by law or government authorities</li>
                  <li>To protect against fraud and security threats</li>
                  <li>To enforce our terms of service</li>
                  <li>In case of business transfer or merger</li>
                </ul>
              </div>
              
              <div>
                <h3 className="text-lg font-medium text-black mb-2">Community Features</h3>
                <ul className="list-disc list-inside space-y-1 ml-4">
                  <li>Your profile information is visible to other users</li>
                  <li>Match results and tournament participation may be public</li>
                  <li>Marketplace listings include seller information</li>
                  <li>Reviews and ratings you provide are publicly visible</li>
                </ul>
              </div>
            </div>
          </Card>

          {/* Section 4: Data Security */}
          <Card className="p-6" id="data-security">
            <div className="flex items-center mb-4">
              <Lock className="w-6 h-6 text-green-600 mr-3" />
              <h2 className="text-2xl font-semibold text-black">4. Data Security</h2>
            </div>
            
            <div className="space-y-4 text-gray-700">
              <p>We implement comprehensive security measures to protect your personal information:</p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-lg font-medium text-black mb-2">Technical Safeguards</h3>
                  <ul className="list-disc list-inside space-y-1 ml-4">
                    <li>End-to-end encryption for sensitive data</li>
                    <li>Secure SSL/TLS connections</li>
                    <li>Regular security audits and testing</li>
                    <li>Multi-factor authentication options</li>
                  </ul>
                </div>
                
                <div>
                  <h3 className="text-lg font-medium text-black mb-2">Operational Security</h3>
                  <ul className="list-disc list-inside space-y-1 ml-4">
                    <li>Limited access to personal data</li>
                    <li>Employee security training</li>
                    <li>Regular data backups</li>
                    <li>Incident response procedures</li>
                  </ul>
                </div>
              </div>
              
              <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-200">
                <p className="text-yellow-800">
                  <strong>Important:</strong> While we strive to protect your information, no system is 100% secure. 
                  Please use strong passwords and keep your account credentials confidential.
                </p>
              </div>
            </div>
          </Card>

          {/* Section 5: Your Privacy Rights */}
          <Card className="p-6" id="your-rights">
            <div className="flex items-center mb-4">
              <Shield className="w-6 h-6 text-green-600 mr-3" />
              <h2 className="text-2xl font-semibold text-black">5. Your Privacy Rights</h2>
            </div>
            
            <div className="space-y-4 text-gray-700">
              <p>You have the following rights regarding your personal information:</p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-lg font-medium text-black mb-2">Access and Control</h3>
                  <ul className="list-disc list-inside space-y-1 ml-4">
                    <li>View and download your personal data</li>
                    <li>Update or correct your information</li>
                    <li>Delete your account and data</li>
                    <li>Opt out of marketing communications</li>
                  </ul>
                </div>
                
                <div>
                  <h3 className="text-lg font-medium text-black mb-2">Data Portability</h3>
                  <ul className="list-disc list-inside space-y-1 ml-4">
                    <li>Export your data in common formats</li>
                    <li>Transfer data to other services</li>
                    <li>Receive copies of your information</li>
                    <li>Restrict processing of your data</li>
                  </ul>
                </div>
              </div>
              
              <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                <p className="text-blue-800">
                  To exercise these rights, contact us at{' '}
                  <a href="mailto:privacy@padelo.com" className="font-medium underline">privacy@padelo.com</a>
                  {' '}or use the settings in your account.
                </p>
              </div>
            </div>
          </Card>

          {/* Section 6: Cookies and Tracking */}
          <Card className="p-6" id="cookies">
            <div className="flex items-center mb-4">
              <Globe className="w-6 h-6 text-green-600 mr-3" />
              <h2 className="text-2xl font-semibold text-black">6. Cookies and Tracking</h2>
            </div>
            
            <div className="space-y-4 text-gray-700">
              <p>We use cookies and similar technologies to enhance your experience:</p>
              
              <div>
                <h3 className="text-lg font-medium text-black mb-2">Types of Cookies</h3>
                <div className="space-y-3">
                  <div className="flex items-start space-x-3">
                    <div className="w-3 h-3 bg-green-500 rounded-full mt-2"></div>
                    <div>
                      <strong>Essential Cookies:</strong> Required for basic app functionality, authentication, and security.
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-3 h-3 bg-blue-500 rounded-full mt-2"></div>
                    <div>
                      <strong>Performance Cookies:</strong> Help us understand how you use the app and improve its performance.
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-3 h-3 bg-purple-500 rounded-full mt-2"></div>
                    <div>
                      <strong>Functional Cookies:</strong> Remember your preferences and provide personalized features.
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-3 h-3 bg-orange-500 rounded-full mt-2"></div>
                    <div>
                      <strong>Marketing Cookies:</strong> Used for targeted advertising (only with your consent).
                    </div>
                  </div>
                </div>
              </div>
              
              <div>
                <h3 className="text-lg font-medium text-black mb-2">Managing Cookies</h3>
                <p>You can control cookies through your browser settings or app preferences. Note that disabling essential cookies may affect app functionality.</p>
              </div>
            </div>
          </Card>

          {/* Section 7: Children's Privacy */}
          <Card className="p-6" id="children">
            <div className="flex items-center mb-4">
              <Users className="w-6 h-6 text-green-600 mr-3" />
              <h2 className="text-2xl font-semibold text-black">7. Children's Privacy</h2>
            </div>
            
            <div className="space-y-4 text-gray-700">
              <p>
                Padelo is intended for users aged 13 and older. We do not knowingly collect personal information from children under 13.
              </p>
              
              <div>
                <h3 className="text-lg font-medium text-black mb-2">Parental Consent</h3>
                <ul className="list-disc list-inside space-y-1 ml-4">
                  <li>Users aged 13-17 should have parental permission to use our services</li>
                  <li>Parents can contact us to review or delete their child's information</li>
                  <li>We may require age verification for certain features</li>
                  <li>Special protections apply to accounts of minors</li>
                </ul>
              </div>
              
              <div className="bg-red-50 p-4 rounded-lg border border-red-200">
                <p className="text-red-800">
                  If you believe we have collected information from a child under 13, please contact us immediately 
                  at <a href="mailto:privacy@padelo.com" className="font-medium underline">privacy@padelo.com</a>
                </p>
              </div>
            </div>
          </Card>

          {/* Section 8: Policy Changes */}
          <Card className="p-6" id="changes">
            <div className="flex items-center mb-4">
              <Globe className="w-6 h-6 text-green-600 mr-3" />
              <h2 className="text-2xl font-semibold text-black">8. Policy Changes</h2>
            </div>
            
            <div className="space-y-4 text-gray-700">
              <p>
                We may update this privacy policy from time to time to reflect changes in our practices, 
                technology, or legal requirements.
              </p>
              
              <div>
                <h3 className="text-lg font-medium text-black mb-2">How We Notify You</h3>
                <ul className="list-disc list-inside space-y-1 ml-4">
                  <li>Email notification for significant changes</li>
                  <li>In-app notifications and announcements</li>
                  <li>Updated date at the top of this policy</li>
                  <li>Prominent notice on our website</li>
                </ul>
              </div>
              
              <p>
                Your continued use of our services after changes become effective constitutes acceptance of the updated policy.
              </p>
            </div>
          </Card>

          {/* Section 9: Contact Information */}
          <Card className="p-6" id="contact">
            <div className="flex items-center mb-4">
              <Mail className="w-6 h-6 text-green-600 mr-3" />
              <h2 className="text-2xl font-semibold text-black">9. Contact Information</h2>
            </div>
            
            <div className="space-y-4 text-gray-700">
              <p>
                If you have questions about this privacy policy or our data practices, please contact us:
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-lg font-medium text-black mb-2">Privacy Officer</h3>
                  <div className="space-y-2">
                    <div className="flex items-center">
                      <Mail className="w-4 h-4 text-green-600 mr-2" />
                      <a href="mailto:privacy@padelo.com" className="text-green-600 hover:text-green-500">
                        privacy@padelo.com
                      </a>
                    </div>
                    <div className="flex items-center">
                      <Phone className="w-4 h-4 text-green-600 mr-2" />
                      <span>+1 (555) 123-4567</span>
                    </div>
                  </div>
                </div>
                
                <div>
                  <h3 className="text-lg font-medium text-black mb-2">Mailing Address</h3>
                  <div className="text-gray-600">
                    Padelo Inc.<br />
                    123 Sports Avenue<br />
                    Tech City, TC 12345<br />
                    United States
                  </div>
                </div>
              </div>
              
              <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                <p className="text-green-800">
                  <strong>Response Time:</strong> We typically respond to privacy inquiries within 5 business days.
                </p>
              </div>
            </div>
          </Card>

        </div>

        {/* Footer */}
        <div className="mt-8 mb-6">
          <Card className="p-6 text-center">
            <p className="text-gray-600 mb-4">
              Thank you for trusting Padelo with your personal information. We are committed to protecting your privacy 
              and providing you with the best possible padel experience.
            </p>
            <Button 
              onClick={handleBackClick}
              className="bg-green-500 hover:bg-green-600 text-white"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to App
            </Button>
          </Card>
        </div>
      </div>
    </div>
  );
}
