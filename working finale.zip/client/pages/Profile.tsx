import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useAuth } from '../contexts/RoleAuthContext';
import { useNavigate } from 'react-router-dom';
import { 
  User,
  Edit,
  Settings,
  Trophy,
  Calendar,
  MapPin,
  Mail,
  Phone,
  Globe,
  Shield,
  Award,
  Star,
  TrendingUp,
  Users,
  Heart,
  MessageCircle,
  UserPlus,
  UserMinus,
  BarChart3,
  Clock,
  Target,
  CheckCircle,
  AlertCircle,
  Camera,
  Eye,
  Share,
  Flag,
  MoreHorizontal,
  Zap,
  Medal,
  Crown,
  Download,
  Upload,
  Save,
  X,
  Bell,
  Lock,
  Trash2,
  FileText,
  ExternalLink
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Progress } from '@/components/ui/progress';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { ThemeSettings } from '@/components/ThemeSettings';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

export default function Profile() {
  const { t } = useTranslation();
  const { user, updateUser } = useAuth();
  const navigate = useNavigate();
  const [isEditing, setIsEditing] = useState(false);
  const [editForm, setEditForm] = useState({
    name: user?.name || '',
    bio: 'Passionate padel player and coach. Love competitive play and helping others improve their game.',
    location: 'New Cairo, Egypt',
    website: 'www.ahmed-padel.com',
    phone: '+20 123 456 7890'
  });

  // Mock user data - in real app this would come from API
  const userProfile = {
    id: user?.id || 'user123',
    name: user?.name || 'Ahmed Hassan',
    username: '@ahmed_hassan',
    avatar: user?.avatar || '/user1.jpg',
    coverImage: '/cover1.jpg',
    bio: 'Passionate padel player and coach. Love competitive play and helping others improve their game.',
    location: 'New Cairo, Egypt',
    email: user?.email || 'ahmed.hassan@email.com',
    phone: '+20 123 456 7890',
    website: 'www.ahmed-padel.com',
    joinDate: '2023-05-15',
    verified: user?.isVerified || true,
    followers: 234,
    following: 89,
    isPublic: true,
    role: user?.role || 'player'
  };

  // Player stats
  const playerStats = {
    level: 'Advanced',
    tier: 'Elite',
    division: 2,
    leaguePoints: 2850,
    globalRank: 47,
    regionalRank: 12,
    winRate: 78,
    matchesPlayed: 156,
    matchesWon: 122,
    tournamentsWon: 8,
    totalHours: 324,
    improvementRate: 15,
    currentStreak: 5,
    bestStreak: 12,
    coursesCompleted: 3,
    equipmentOwned: 12
  };

  // Recent activity
  const recentActivity = [
    {
      id: '1',
      type: 'tournament_win',
      title: 'Won Spring Championship',
      description: 'First place in Elite Division',
      date: '2024-03-15',
      points: '+150 LP',
      icon: Trophy
    },
    {
      id: '2',
      type: 'match_win',
      title: 'Victory vs. Sarah Mohamed',
      description: 'Competitive match at Elite Padel Club',
      date: '2024-03-12',
      points: '+25 LP',
      icon: Target
    },
    {
      id: '3',
      type: 'level_up',
      title: 'Advanced to Elite Tier',
      description: 'Reached new ranking milestone',
      date: '2024-03-10',
      points: '+200 LP',
      icon: TrendingUp
    }
  ];

  const getTierColor = (tier: string) => {
    const colors = {
      'Rookie': 'bg-gray-500',
      'Beginner': 'bg-green-500',
      'Intermediate': 'bg-blue-500',
      'Advanced': 'bg-purple-500',
      'Elite': 'bg-yellow-500',
      'Master': 'bg-red-500',
      'Pro Players': 'bg-black'
    };
    return colors[tier as keyof typeof colors] || 'bg-gray-500';
  };

  const formatTimeAgo = (date: string) => {
    const days = Math.floor((new Date().getTime() - new Date(date).getTime()) / (1000 * 3600 * 24));
    if (days === 0) return 'Today';
    if (days === 1) return 'Yesterday';
    return `${days} days ago`;
  };

  const handleSaveProfile = async () => {
    if (updateUser) {
      const success = await updateUser({
        name: editForm.name
      });
      
      if (success) {
        setIsEditing(false);
      }
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Profile Header */}
      <div className="relative">
        {/* Cover Image */}
        <div className="h-48 bg-gradient-to-r from-green-400 to-green-600 dark:from-green-600 dark:to-green-700 relative">
          <div className="absolute inset-0 bg-black bg-opacity-30 dark:bg-opacity-50" />
          
          {/* Cover Actions */}
          <div className="absolute top-4 right-4 flex space-x-2">
            <Button variant="outline" size="sm" className="bg-white/90 text-black">
              <Camera className="w-4 h-4 mr-2" />
              Edit Cover
            </Button>
            <Button variant="outline" size="sm" className="bg-white/90 text-black">
              <Share className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Profile Info */}
        <div className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 p-4">
          <div className="relative -mt-16 mb-4">
            <Avatar className="w-32 h-32 border-4 border-white">
              <AvatarImage src={userProfile.avatar} />
              <AvatarFallback className="text-2xl">{userProfile.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
            </Avatar>
            <Button variant="outline" size="sm" className="absolute bottom-0 right-0 w-8 h-8 rounded-full p-0">
              <Camera className="w-4 h-4" />
            </Button>
          </div>

          <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between">
            <div className="flex-1 mb-4 lg:mb-0">
              {isEditing ? (
                <div className="space-y-3">
                  <Input
                    value={editForm.name}
                    onChange={(e) => setEditForm(prev => ({ ...prev, name: e.target.value }))}
                    className="text-xl font-bold"
                    placeholder="Your name"
                  />
                  <Textarea
                    value={editForm.bio}
                    onChange={(e) => setEditForm(prev => ({ ...prev, bio: e.target.value }))}
                    placeholder="Tell us about yourself..."
                    rows={3}
                  />
                  <div className="flex space-x-2">
                    <Button size="sm" onClick={handleSaveProfile} className="bg-green-500 hover:bg-green-600 text-white">
                      <Save className="w-4 h-4 mr-2" />
                      Save
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => setIsEditing(false)}>
                      <X className="w-4 h-4 mr-2" />
                      Cancel
                    </Button>
                  </div>
                </div>
              ) : (
                <>
                  <div className="flex items-center space-x-2 mb-2">
                    <h1 className="text-2xl font-bold text-black">{userProfile.name}</h1>
                    {userProfile.verified && (
                      <CheckCircle className="w-6 h-6 text-green-500" />
                    )}
                    <Badge className={`${getTierColor(playerStats.tier)} text-white`}>
                      <Crown className="w-3 h-3 mr-1" />
                      {playerStats.tier} {playerStats.division}
                    </Badge>
                    <Badge variant="outline" className="capitalize">
                      {userProfile.role.replace('_', ' ')}
                    </Badge>
                  </div>
                  
                  <div className="text-gray-600 mb-2">{userProfile.username}</div>
                  
                  <p className="text-gray-700 mb-3 max-w-2xl">{userProfile.bio}</p>
                  
                  <div className="flex flex-wrap gap-4 text-sm text-gray-600 mb-3">
                    <div className="flex items-center">
                      <MapPin className="w-4 h-4 mr-1" />
                      {userProfile.location}
                    </div>
                    <div className="flex items-center">
                      <Calendar className="w-4 h-4 mr-1" />
                      Joined {new Date(userProfile.joinDate).toLocaleDateString()}
                    </div>
                    {userProfile.website && (
                      <div className="flex items-center">
                        <Globe className="w-4 h-4 mr-1" />
                        <a href={`https://${userProfile.website}`} className="text-green-600 hover:underline">
                          {userProfile.website}
                        </a>
                      </div>
                    )}
                  </div>

                  <div className="flex items-center space-x-6 text-sm">
                    <div>
                      <span className="font-semibold text-black">{userProfile.followers}</span>
                      <span className="text-gray-600 ml-1">followers</span>
                    </div>
                    <div>
                      <span className="font-semibold text-black">{userProfile.following}</span>
                      <span className="text-gray-600 ml-1">following</span>
                    </div>
                    <div className="flex items-center">
                      <Trophy className="w-4 h-4 mr-1 text-yellow-500" />
                      <span className="font-semibold text-black">{playerStats.tournamentsWon}</span>
                      <span className="text-gray-600 ml-1">tournaments won</span>
                    </div>
                  </div>
                </>
              )}
            </div>

            {/* Action Buttons */}
            {!isEditing && (
              <div className="flex space-x-3">
                <Button variant="outline">
                  <MessageCircle className="w-4 h-4 mr-2" />
                  Message
                </Button>
                <Button onClick={() => setIsEditing(true)} className="bg-green-500 hover:bg-green-600 text-white">
                  <Edit className="w-4 h-4 mr-2" />
                  Edit Profile
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="p-4">
        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="stats">Statistics</TabsTrigger>
            <TabsTrigger value="activity">Activity</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
            <TabsTrigger value="policy">Policy</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6 mt-6">
            {/* Quick Stats */}
            <Card className="p-6">
              <h2 className="text-lg font-semibold text-black mb-4">Performance Overview</h2>
              
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
                <div className="text-center">
                  <div className="text-2xl font-bold text-black">#{playerStats.globalRank}</div>
                  <div className="text-sm text-gray-600">Global Rank</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">{playerStats.leaguePoints}</div>
                  <div className="text-sm text-gray-600">League Points</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-black">{playerStats.winRate}%</div>
                  <div className="text-sm text-gray-600">Win Rate</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">{playerStats.currentStreak}</div>
                  <div className="text-sm text-gray-600">Current Streak</div>
                </div>
              </div>
            </Card>

            {/* Recent Activity Preview */}
            <Card className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-black">Recent Activity</h2>
                <Button variant="outline" size="sm">
                  View All
                </Button>
              </div>
              
              <div className="space-y-3">
                {recentActivity.slice(0, 3).map((activity) => (
                  <div key={activity.id} className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                    <div className="p-2 bg-green-100 rounded-full">
                      <activity.icon className="w-4 h-4 text-green-600" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-medium text-black text-sm">{activity.title}</h3>
                      <p className="text-xs text-gray-600">{activity.description}</p>
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-medium text-green-600">{activity.points}</div>
                      <div className="text-xs text-gray-600">{formatTimeAgo(activity.date)}</div>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="stats" className="space-y-6 mt-6">
            {/* Detailed Statistics */}
            <Card className="p-6">
              <h3 className="text-lg font-semibold text-black mb-4">Performance Statistics</h3>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Matches Played</span>
                    <span className="font-semibold text-black">{playerStats.matchesPlayed}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Matches Won</span>
                    <span className="font-semibold text-green-600">{playerStats.matchesWon}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Win Rate</span>
                    <span className="font-semibold text-black">{playerStats.winRate}%</span>
                  </div>
                </div>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Tournaments Won</span>
                    <span className="font-semibold text-green-600">{playerStats.tournamentsWon}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Training Hours</span>
                    <span className="font-semibold text-black">{playerStats.totalHours}h</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Improvement Rate</span>
                    <span className="font-semibold text-green-600">+{playerStats.improvementRate}%</span>
                  </div>
                </div>
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="activity" className="space-y-6 mt-6">
            {/* Activity Feed */}
            <Card className="p-6">
              <h2 className="text-lg font-semibold text-black mb-6">Activity History</h2>
              
              <div className="space-y-4">
                {recentActivity.map((activity) => (
                  <div key={activity.id} className="flex items-start space-x-4 p-4 border border-gray-200 rounded-lg">
                    <div className="p-3 bg-green-100 rounded-full">
                      <activity.icon className="w-5 h-5 text-green-600" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-black mb-1">{activity.title}</h3>
                      <p className="text-gray-600 mb-2">{activity.description}</p>
                      <div className="flex items-center space-x-4 text-sm text-gray-500">
                        <div className="flex items-center">
                          <Calendar className="w-4 h-4 mr-1" />
                          {formatTimeAgo(activity.date)}
                        </div>
                        {activity.points && (
                          <div className="flex items-center">
                            <TrendingUp className="w-4 h-4 mr-1" />
                            {activity.points}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="settings" className="space-y-6 mt-6">
            {/* Basic Settings */}
            <Card className="p-6">
              <h2 className="text-lg font-semibold text-black mb-6">Profile Settings</h2>
              
              <div className="space-y-6">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-black mb-2">Display Name</label>
                    <Input value={userProfile.name} readOnly />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-black mb-2">Email</label>
                    <Input type="email" value={userProfile.email} readOnly />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-black mb-2">Location</label>
                    <Input value={userProfile.location} readOnly />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-black mb-2">Website</label>
                    <Input value={userProfile.website || ''} readOnly />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-black mb-2">Bio</label>
                  <Textarea value={userProfile.bio} rows={3} readOnly />
                </div>

                <div className="flex space-x-4 pt-4 border-t border-gray-200">
                  <Button className="bg-green-500 hover:bg-green-600 text-white">
                    Save Changes
                  </Button>
                  <Button variant="outline">
                    Cancel
                  </Button>
                </div>
              </div>
            </Card>

            {/* Theme Preference */}
            <div>
              <h2 className="text-lg font-semibold text-black dark:text-white mb-6">Appearance</h2>
              <ThemeSettings />
            </div>

            {/* Privacy & Legal */}
            <Card className="p-6">
              <h2 className="text-lg font-semibold text-black dark:text-white mb-6">Privacy & Legal</h2>

              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="p-2 bg-blue-100 rounded-full">
                      <FileText className="w-5 h-5 text-blue-600" />
                    </div>
                    <div>
                      <h3 className="font-medium text-black">Privacy Policy</h3>
                      <p className="text-sm text-gray-600">View our privacy policy and data handling practices</p>
                    </div>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => navigate('/privacy-policy')}
                  >
                    <ExternalLink className="w-4 h-4 mr-2" />
                    View
                  </Button>
                </div>

                <div className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="p-2 bg-green-100 rounded-full">
                      <FileText className="w-5 h-5 text-green-600" />
                    </div>
                    <div>
                      <h3 className="font-medium text-black">Terms of Service</h3>
                      <p className="text-sm text-gray-600">Review our terms and conditions</p>
                    </div>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => navigate('/terms-of-service')}
                  >
                    <ExternalLink className="w-4 h-4 mr-2" />
                    View
                  </Button>
                </div>

                {user?.termsAcceptedAt && (
                  <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                    <div className="flex items-start space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-600 mt-0.5" />
                      <div>
                        <h4 className="font-medium text-green-800">Terms Accepted</h4>
                        <p className="text-sm text-green-700">
                          You accepted our terms on {new Date(user.termsAcceptedAt).toLocaleDateString()}
                        </p>
                        {user.termsVersion && (
                          <p className="text-xs text-green-600 mt-1">
                            Version: {user.termsVersion}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                )}

                {user?.privacyAcceptedAt && (
                  <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                    <div className="flex items-start space-x-3">
                      <CheckCircle className="w-5 h-5 text-blue-600 mt-0.5" />
                      <div>
                        <h4 className="font-medium text-blue-800">Privacy Policy Accepted</h4>
                        <p className="text-sm text-blue-700">
                          You accepted our privacy policy on {new Date(user.privacyAcceptedAt).toLocaleDateString()}
                        </p>
                        {user.privacyVersion && (
                          <p className="text-xs text-blue-600 mt-1">
                            Version: {user.privacyVersion}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="policy" className="space-y-6 mt-6">
            {/* App Usage Policy */}
            <Card className="p-6">
              <h2 className="text-lg font-semibold text-black mb-6">App Usage Policies</h2>

              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="p-2 bg-blue-100 rounded-full">
                      <Users className="w-5 h-5 text-blue-600" />
                    </div>
                    <div>
                      <h3 className="font-medium text-black">App Usage Policy</h3>
                      <p className="text-sm text-gray-600">Detailed policies for players, court owners, and ranking system</p>
                    </div>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => navigate('/app-usage-policy')}
                  >
                    <ExternalLink className="w-4 h-4 mr-2" />
                    View
                  </Button>
                </div>

                <div className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="p-2 bg-green-100 rounded-full">
                      <FileText className="w-5 h-5 text-green-600" />
                    </div>
                    <div>
                      <h3 className="font-medium text-black">Terms of Service</h3>
                      <p className="text-sm text-gray-600">General terms and conditions for using Padelo</p>
                    </div>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => navigate('/terms-of-service')}
                  >
                    <ExternalLink className="w-4 h-4 mr-2" />
                    View
                  </Button>
                </div>

                <div className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="p-2 bg-purple-100 rounded-full">
                      <Shield className="w-5 h-5 text-purple-600" />
                    </div>
                    <div>
                      <h3 className="font-medium text-black">Privacy Policy</h3>
                      <p className="text-sm text-gray-600">How we collect, use, and protect your personal data</p>
                    </div>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => navigate('/privacy-policy')}
                  >
                    <ExternalLink className="w-4 h-4 mr-2" />
                    View
                  </Button>
                </div>

                {/* Policy Highlights */}
                <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Card className="p-4 bg-red-50 border-red-200">
                    <h4 className="font-semibold text-red-800 mb-2">⚠️ Important Reminders</h4>
                    <ul className="text-sm text-red-700 space-y-1">
                      <li>• One account per person only</li>
                      <li>• Cancel 24h+ before session</li>
                      <li>• Arrive 10 minutes early</li>
                      <li>• No-shows result in warnings/bans</li>
                    </ul>
                  </Card>

                  <Card className="p-4 bg-green-50 border-green-200">
                    <h4 className="font-semibold text-green-800 mb-2">🏆 Ranking System</h4>
                    <ul className="text-sm text-green-700 space-y-1">
                      <li>• LP-based tier progression</li>
                      <li>• Official tournaments: 1st & 3rd Friday</li>
                      <li>• Leaderboards with filters</li>
                      <li>• Win rate tracking</li>
                    </ul>
                  </Card>
                </div>

                {/* Court Owner Highlights */}
                {user?.role === 'court_owner' && (
                  <div className="mt-4">
                    <Card className="p-4 bg-yellow-50 border-yellow-200">
                      <h4 className="font-semibold text-yellow-800 mb-2">🏟️ Court Owner Reminders</h4>
                      <ul className="text-sm text-yellow-700 space-y-1">
                        <li>• Maintain court playable conditions</li>
                        <li>• Cancellation penalties apply based on timing</li>
                        <li>• Strike system for violations</li>
                        <li>• "Reliable Court" badge for 0 cancellations in 90 days</li>
                      </ul>
                    </Card>
                  </div>
                )}
              </div>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
