import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useAuth } from '../contexts/RoleAuthContext';
import { 
  User,
  Mail,
  Lock,
  Eye,
  EyeOff,
  LogIn,
  UserPlus,
  Shield,
  Award,
  Building,
  Trophy,
  Crown,
  AlertCircle,
  CheckCircle,
  Loader2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';

export default function Login() {
  const { t } = useTranslation();
  const { login, isLoading } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Demo accounts for testing
  const demoAccounts = [
    {
      email: 'player@example.com',
      role: 'player',
      name: 'Ahmed Hassan',
      description: 'Regular player account with basic access',
      icon: User,
      color: 'bg-blue-500'
    },
    {
      email: 'coach@example.com',
      role: 'coach',
      name: 'Sara Mohamed',
      description: 'Coach account with training and student management',
      icon: Award,
      color: 'bg-green-500'
    },
    {
      email: 'owner@example.com',
      role: 'court_owner',
      name: 'Omar Ali',
      description: 'Court owner with venue management capabilities',
      icon: Building,
      color: 'bg-purple-500'
    },
    {
      email: 'organizer@example.com',
      role: 'tournament_organizer',
      name: 'Layla Ahmed',
      description: 'Tournament organizer with event management access',
      icon: Trophy,
      color: 'bg-orange-500'
    },
    {
      email: 'admin@example.com',
      role: 'owner',
      name: 'Ibrahim Abada',
      description: 'Platform owner with full administrative access',
      icon: Crown,
      color: 'bg-red-500'
    }
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (!email || !password) {
      setError('Please fill in all fields');
      return;
    }

    const loginSuccess = await login(email, password);
    
    if (loginSuccess) {
      setSuccess('Login successful! Redirecting...');
      // In real app, this would redirect using router
      setTimeout(() => {
        window.location.href = '/';
      }, 1500);
    } else {
      setError('Invalid email or password. Please try again.');
    }
  };

  const handleDemoLogin = async (demoEmail: string) => {
    setEmail(demoEmail);
    setPassword('password123');
    setError('');
    setSuccess('');

    const loginSuccess = await login(demoEmail, 'password123');
    
    if (loginSuccess) {
      setSuccess('Demo login successful! Redirecting...');
      setTimeout(() => {
        window.location.href = '/';
      }, 1500);
    } else {
      setError('Demo login failed. Please try again.');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 dark:from-gray-900 dark:to-gray-800 flex items-center justify-center p-4">
      <div className="w-full max-w-6xl grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Login Form */}
        <Card className="p-8">
          <div className="text-center mb-8">
            <div className="flex items-center justify-center mb-4">
              <div className="p-3 bg-green-100 rounded-full">
                <Shield className="w-8 h-8 text-green-600" />
              </div>
            </div>
            <h1 className="text-2xl font-bold text-black mb-2">Welcome to Padelo</h1>
            <p className="text-gray-600">Sign in to your account to continue</p>
          </div>

          {error && (
            <Alert className="mb-6 border-red-200 bg-red-50">
              <AlertCircle className="h-4 w-4 text-red-600" />
              <AlertDescription className="text-red-700">{error}</AlertDescription>
            </Alert>
          )}

          {success && (
            <Alert className="mb-6 border-green-200 bg-green-50">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <AlertDescription className="text-green-700">{success}</AlertDescription>
            </Alert>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-black mb-2">Email Address</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <Input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email"
                  className="pl-12"
                  disabled={isLoading}
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-black mb-2">Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <Input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter your password"
                  className="pl-12 pr-12"
                  disabled={isLoading}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  disabled={isLoading}
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <label className="flex items-center">
                <input type="checkbox" className="mr-2" />
                <span className="text-sm text-gray-600">Remember me</span>
              </label>
              <a href="#" className="text-sm text-green-600 hover:text-green-500">
                Forgot password?
              </a>
            </div>

            <Button 
              type="submit" 
              className="w-full bg-green-500 hover:bg-green-600 text-white h-12"
              disabled={isLoading}
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Signing In...
                </>
              ) : (
                <>
                  <LogIn className="w-5 h-5 mr-2" />
                  Sign In
                </>
              )}
            </Button>
          </form>

          <div className="mt-8 text-center">
            <p className="text-gray-600">
              Don't have an account?{' '}
              <a href="/register" className="text-green-600 hover:text-green-500 font-medium">
                Sign up here
              </a>
            </p>
          </div>
        </Card>

        {/* Demo Accounts */}
        <Card className="p-8">
          <div className="text-center mb-6">
            <h2 className="text-xl font-bold text-black mb-2">Try Demo Accounts</h2>
            <p className="text-gray-600 text-sm">
              Experience different user roles and permissions
            </p>
          </div>

          <div className="space-y-4">
            {demoAccounts.map((account) => {
              const IconComponent = account.icon;
              return (
                <div
                  key={account.email}
                  className="p-4 border border-gray-200 rounded-lg hover:border-green-300 hover:bg-green-50 transition-all cursor-pointer"
                  onClick={() => handleDemoLogin(account.email)}
                >
                  <div className="flex items-start space-x-3">
                    <div className={`p-2 rounded-lg ${account.color} text-white`}>
                      <IconComponent className="w-5 h-5" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-1">
                        <h3 className="font-semibold text-black">{account.name}</h3>
                        <Badge variant="outline" className="text-xs capitalize">
                          {account.role.replace('_', ' ')}
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-600 mb-2">{account.description}</p>
                      <div className="text-xs text-gray-500">
                        Email: {account.email} | Password: password123
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="mt-6 p-4 bg-blue-50 rounded-lg">
            <div className="flex items-start space-x-2">
              <AlertCircle className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
              <div>
                <h4 className="font-medium text-blue-900 mb-1">Demo Information</h4>
                <p className="text-sm text-blue-800">
                  These are demonstration accounts with different access levels. 
                  Click any account to automatically log in and explore the features 
                  available to that user role.
                </p>
              </div>
            </div>
          </div>

          <div className="mt-6 text-center">
            <Button 
              variant="outline" 
              className="w-full"
              onClick={() => window.location.href = '/register'}
            >
              <UserPlus className="w-4 h-4 mr-2" />
              Create New Account
            </Button>
          </div>
        </Card>
      </div>
    </div>
  );
}
