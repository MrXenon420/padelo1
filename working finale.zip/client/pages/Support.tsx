import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { 
  MessageCircle,
  Phone,
  Mail,
  Search,
  HelpCircle,
  Book,
  Video,
  Clock,
  CheckCircle,
  AlertCircle,
  Send,
  Paperclip,
  Smile,
  Star,
  ThumbsUp,
  ThumbsDown,
  Flag,
  User,
  Bot,
  Headphones,
  FileText,
  Download,
  ExternalLink,
  ChevronRight,
  Plus,
  X,
  Mic,
  Image,
  Calendar,
  Settings
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

export default function Support() {
  const { t } = useTranslation();
  const [selectedCategory, setSelectedCategory] = useState('');
  const [chatMessage, setChatMessage] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeChatId, setActiveChatId] = useState<string | null>(null);
  const [ticketSubject, setTicketSubject] = useState('');
  const [ticketMessage, setTicketMessage] = useState('');

  // Mock FAQ data
  const faqCategories = [
    {
      id: 'general',
      title: 'General Questions',
      icon: HelpCircle,
      count: 12
    },
    {
      id: 'tournaments',
      title: 'Tournaments',
      icon: CheckCircle,
      count: 8
    },
    {
      id: 'courts',
      title: 'Court Booking',
      icon: Calendar,
      count: 15
    },
    {
      id: 'payments',
      title: 'Payments & Billing',
      icon: FileText,
      count: 6
    },
    {
      id: 'training',
      title: 'Training & Coaching',
      icon: User,
      count: 9
    },
    {
      id: 'marketplace',
      title: 'Marketplace',
      icon: Star,
      count: 7
    }
  ];

  const faqs = [
    {
      id: 'faq1',
      category: 'general',
      question: 'How do I create an account?',
      answer: 'To create an account, click on the "Register" button and fill in your personal information. You\'ll receive a verification email to complete the process.',
      helpful: 45,
      notHelpful: 3
    },
    {
      id: 'faq2',
      category: 'tournaments',
      question: 'How do I join a tournament?',
      answer: 'Navigate to the Tournaments page, select a tournament that matches your skill level, and click "Join Tournament". Make sure you meet the entry requirements.',
      helpful: 78,
      notHelpful: 5
    },
    {
      id: 'faq3',
      category: 'courts',
      question: 'Can I cancel my court booking?',
      answer: 'Yes, you can cancel your booking up to 24 hours before the scheduled time for a full refund. Cancellations within 24 hours are subject to a 50% fee.',
      helpful: 92,
      notHelpful: 8
    },
    {
      id: 'faq4',
      category: 'payments',
      question: 'What payment methods do you accept?',
      answer: 'We accept all major credit cards, PayPal, and bank transfers. For tournament entries, we also accept cash payments at participating venues.',
      helpful: 67,
      notHelpful: 2
    }
  ];

  // Mock chat conversations
  const chatConversations = [
    {
      id: 'chat1',
      type: 'live',
      agent: {
        name: 'Sarah Ahmed',
        avatar: '/support1.jpg',
        status: 'online',
        rating: 4.9
      },
      subject: 'Tournament Registration Issue',
      lastMessage: 'I\'ve updated your registration. Please try again.',
      timestamp: '2024-03-20T14:30:00Z',
      unread: 0,
      priority: 'normal'
    },
    {
      id: 'chat2',
      type: 'bot',
      agent: {
        name: 'Padelo Assistant',
        avatar: '/bot-avatar.png',
        status: 'online',
        rating: 4.7
      },
      subject: 'General Questions',
      lastMessage: 'How can I help you today?',
      timestamp: '2024-03-20T10:15:00Z',
      unread: 1,
      priority: 'low'
    }
  ];

  // Mock chat messages
  const chatMessages = [
    {
      id: 'msg1',
      sender: 'agent',
      message: 'Hello! I\'m Sarah from Padelo support. How can I help you today?',
      timestamp: '2024-03-20T14:25:00Z',
      type: 'text'
    },
    {
      id: 'msg2',
      sender: 'user',
      message: 'Hi, I\'m having trouble registering for the Spring Championship tournament.',
      timestamp: '2024-03-20T14:26:00Z',
      type: 'text'
    },
    {
      id: 'msg3',
      sender: 'agent',
      message: 'I can help you with that. Could you please provide your registration email?',
      timestamp: '2024-03-20T14:27:00Z',
      type: 'text'
    },
    {
      id: 'msg4',
      sender: 'user',
      message: 'Sure, it\'s ahmed.hassan@email.com',
      timestamp: '2024-03-20T14:28:00Z',
      type: 'text'
    },
    {
      id: 'msg5',
      sender: 'agent',
      message: 'Thank you. I can see the issue - there was a payment processing error. I\'ve updated your registration and you should be able to proceed now.',
      timestamp: '2024-03-20T14:30:00Z',
      type: 'text'
    }
  ];

  // Mock support tickets
  const supportTickets = [
    {
      id: 'ticket1',
      subject: 'Refund Request - Tournament Entry',
      status: 'in_progress',
      priority: 'high',
      category: 'payments',
      created: '2024-03-19T10:00:00Z',
      lastUpdate: '2024-03-20T09:30:00Z',
      agent: 'Omar Ali'
    },
    {
      id: 'ticket2',
      subject: 'Court Booking Issue',
      status: 'resolved',
      priority: 'medium',
      category: 'courts',
      created: '2024-03-18T14:15:00Z',
      lastUpdate: '2024-03-19T11:20:00Z',
      agent: 'Sarah Ahmed'
    },
    {
      id: 'ticket3',
      subject: 'Account Verification Problem',
      status: 'pending',
      priority: 'low',
      category: 'general',
      created: '2024-03-20T08:45:00Z',
      lastUpdate: '2024-03-20T08:45:00Z',
      agent: 'Unassigned'
    }
  ];

  const getStatusColor = (status: string) => {
    const colors = {
      'online': 'bg-green-500',
      'away': 'bg-yellow-500',
      'offline': 'bg-gray-500',
      'resolved': 'bg-green-500 text-white',
      'in_progress': 'bg-blue-500 text-white',
      'pending': 'bg-yellow-500 text-white',
      'closed': 'bg-gray-500 text-white'
    };
    return colors[status as keyof typeof colors] || 'bg-gray-500';
  };

  const getPriorityColor = (priority: string) => {
    const colors = {
      'high': 'bg-red-500 text-white',
      'medium': 'bg-orange-500 text-white',
      'low': 'bg-gray-500 text-white',
      'normal': 'bg-blue-500 text-white'
    };
    return colors[priority as keyof typeof colors] || 'bg-gray-500 text-white';
  };

  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)}h ago`;
    return date.toLocaleDateString();
  };

  const filteredFaqs = selectedCategory 
    ? faqs.filter(faq => faq.category === selectedCategory)
    : faqs;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 p-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-black">Support Center</h1>
            <p className="text-gray-600">Get help and contact support</p>
          </div>
          <div className="flex space-x-3">
            <Button variant="outline">
              <Phone className="w-4 h-4 mr-2" />
              Call Support
            </Button>
            <Button className="bg-green-500 hover:bg-green-600 text-white">
              <MessageCircle className="w-4 h-4 mr-2" />
              Start Chat
            </Button>
          </div>
        </div>
      </div>

      <div className="p-4">
        <Tabs defaultValue="help" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="help">Help Center</TabsTrigger>
            <TabsTrigger value="chat">Live Chat</TabsTrigger>
            <TabsTrigger value="tickets">My Tickets</TabsTrigger>
            <TabsTrigger value="contact">Contact</TabsTrigger>
          </TabsList>

          <TabsContent value="help" className="space-y-6 mt-6">
            {/* Quick Actions */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card className="p-4 cursor-pointer hover:shadow-md transition-shadow">
                <div className="flex items-center space-x-3">
                  <div className="p-3 bg-green-100 rounded-full">
                    <MessageCircle className="w-6 h-6 text-green-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-black">Start Live Chat</h3>
                    <p className="text-sm text-gray-600">Get instant help</p>
                  </div>
                </div>
              </Card>
              
              <Card className="p-4 cursor-pointer hover:shadow-md transition-shadow">
                <div className="flex items-center space-x-3">
                  <div className="p-3 bg-blue-100 rounded-full">
                    <FileText className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-black">Submit Ticket</h3>
                    <p className="text-sm text-gray-600">Report an issue</p>
                  </div>
                </div>
              </Card>
              
              <Card className="p-4 cursor-pointer hover:shadow-md transition-shadow">
                <div className="flex items-center space-x-3">
                  <div className="p-3 bg-purple-100 rounded-full">
                    <Phone className="w-6 h-6 text-purple-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-black">Call Support</h3>
                    <p className="text-sm text-gray-600">+20 123 456 7890</p>
                  </div>
                </div>
              </Card>
            </div>

            {/* Search FAQs */}
            <Card className="p-4">
              <div className="relative mb-4">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <Input
                  placeholder="Search for help articles..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-12 h-12 text-lg"
                />
              </div>
              
              <div className="text-sm text-gray-600">
                Popular searches: tournament registration, court booking, payment issues
              </div>
            </Card>

            {/* FAQ Categories */}
            <div>
              <h2 className="text-xl font-semibold text-black mb-4">Browse by Category</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {faqCategories.map((category) => (
                  <Card 
                    key={category.id} 
                    className={`p-4 cursor-pointer hover:shadow-md transition-all ${
                      selectedCategory === category.id ? 'border-green-500 bg-green-50' : ''
                    }`}
                    onClick={() => setSelectedCategory(selectedCategory === category.id ? '' : category.id)}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <category.icon className="w-6 h-6 text-green-600" />
                        <div>
                          <h3 className="font-semibold text-black">{category.title}</h3>
                          <p className="text-sm text-gray-600">{category.count} articles</p>
                        </div>
                      </div>
                      <ChevronRight className="w-5 h-5 text-gray-400" />
                    </div>
                  </Card>
                ))}
              </div>
            </div>

            {/* FAQ List */}
            {(selectedCategory || searchQuery) && (
              <Card className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-semibold text-black">
                    {selectedCategory 
                      ? faqCategories.find(c => c.id === selectedCategory)?.title 
                      : 'Search Results'
                    }
                  </h2>
                  {selectedCategory && (
                    <Button variant="outline" size="sm" onClick={() => setSelectedCategory('')}>
                      <X className="w-4 h-4 mr-2" />
                      Clear Filter
                    </Button>
                  )}
                </div>
                
                <div className="space-y-4">
                  {filteredFaqs.map((faq) => (
                    <div key={faq.id} className="border border-gray-200 rounded-lg p-4">
                      <h3 className="font-semibold text-black mb-2">{faq.question}</h3>
                      <p className="text-gray-700 mb-4">{faq.answer}</p>
                      
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4">
                          <span className="text-sm text-gray-600">Was this helpful?</span>
                          <div className="flex space-x-2">
                            <Button variant="outline" size="sm">
                              <ThumbsUp className="w-4 h-4 mr-1" />
                              {faq.helpful}
                            </Button>
                            <Button variant="outline" size="sm">
                              <ThumbsDown className="w-4 h-4 mr-1" />
                              {faq.notHelpful}
                            </Button>
                          </div>
                        </div>
                        <Button variant="outline" size="sm">
                          <ExternalLink className="w-4 h-4 mr-2" />
                          View Full Article
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="chat" className="space-y-6 mt-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[600px]">
              {/* Chat List */}
              <Card className="p-4 lg:col-span-1">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-lg font-semibold text-black">Conversations</h2>
                  <Button size="sm" className="bg-green-500 hover:bg-green-600 text-white">
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
                
                <div className="space-y-3">
                  {chatConversations.map((chat) => (
                    <div 
                      key={chat.id}
                      className={`p-3 rounded-lg cursor-pointer transition-colors ${
                        activeChatId === chat.id ? 'bg-green-50 border border-green-200' : 'hover:bg-gray-50'
                      }`}
                      onClick={() => setActiveChatId(chat.id)}
                    >
                      <div className="flex items-start space-x-3">
                        <div className="relative">
                          <Avatar className="w-10 h-10">
                            <AvatarImage src={chat.agent.avatar} />
                            <AvatarFallback>
                              {chat.type === 'bot' ? <Bot className="w-5 h-5" /> : chat.agent.name.split(' ').map(n => n[0]).join('')}
                            </AvatarFallback>
                          </Avatar>
                          <div className={`absolute -bottom-1 -right-1 w-3 h-3 rounded-full border-2 border-white ${getStatusColor(chat.agent.status)}`}></div>
                        </div>
                        
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-medium text-black text-sm truncate">{chat.agent.name}</span>
                            {chat.unread > 0 && (
                              <Badge className="bg-green-500 text-white text-xs">{chat.unread}</Badge>
                            )}
                          </div>
                          <p className="text-xs text-gray-600 truncate">{chat.subject}</p>
                          <p className="text-xs text-gray-500 truncate">{chat.lastMessage}</p>
                          <div className="flex items-center justify-between mt-1">
                            <span className="text-xs text-gray-400">{formatTime(chat.timestamp)}</span>
                            <div className="flex items-center space-x-1">
                              <Star className="w-3 h-3 text-yellow-400 fill-current" />
                              <span className="text-xs text-gray-500">{chat.agent.rating}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>

              {/* Chat Window */}
              <Card className="lg:col-span-2 flex flex-col">
                {activeChatId ? (
                  <>
                    {/* Chat Header */}
                    <div className="p-4 border-b border-gray-200 flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <Avatar className="w-10 h-10">
                          <AvatarImage src={chatConversations.find(c => c.id === activeChatId)?.agent.avatar} />
                          <AvatarFallback>SA</AvatarFallback>
                        </Avatar>
                        <div>
                          <h3 className="font-semibold text-black">
                            {chatConversations.find(c => c.id === activeChatId)?.agent.name}
                          </h3>
                          <div className="flex items-center space-x-2 text-sm">
                            <div className="flex items-center space-x-1">
                              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                              <span className="text-gray-600">Online</span>
                            </div>
                            <span className="text-gray-400">•</span>
                            <span className="text-gray-600">Avg response time: 2 min</span>
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm">
                          <Video className="w-4 h-4" />
                        </Button>
                        <Button variant="outline" size="sm">
                          <Phone className="w-4 h-4" />
                        </Button>
                        <Button variant="outline" size="sm">
                          <Settings className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>

                    {/* Chat Messages */}
                    <div className="flex-1 p-4 overflow-y-auto space-y-4">
                      {chatMessages.map((message) => (
                        <div 
                          key={message.id} 
                          className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                        >
                          <div className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                            message.sender === 'user' 
                              ? 'bg-green-500 text-white' 
                              : 'bg-gray-100 text-black'
                          }`}>
                            <p className="text-sm">{message.message}</p>
                            <p className={`text-xs mt-1 ${
                              message.sender === 'user' ? 'text-green-100' : 'text-gray-500'
                            }`}>
                              {formatTime(message.timestamp)}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Chat Input */}
                    <div className="p-4 border-t border-gray-200">
                      <div className="flex items-center space-x-2">
                        <Button variant="outline" size="sm">
                          <Paperclip className="w-4 h-4" />
                        </Button>
                        <Button variant="outline" size="sm">
                          <Image className="w-4 h-4" />
                        </Button>
                        <Input
                          placeholder="Type your message..."
                          value={chatMessage}
                          onChange={(e) => setChatMessage(e.target.value)}
                          className="flex-1"
                          onKeyPress={(e) => {
                            if (e.key === 'Enter') {
                              // Handle send message
                              setChatMessage('');
                            }
                          }}
                        />
                        <Button variant="outline" size="sm">
                          <Smile className="w-4 h-4" />
                        </Button>
                        <Button size="sm" className="bg-green-500 hover:bg-green-600 text-white">
                          <Send className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </>
                ) : (
                  <div className="flex-1 flex items-center justify-center text-center">
                    <div>
                      <MessageCircle className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                      <h3 className="text-lg font-semibold text-black mb-2">Select a conversation</h3>
                      <p className="text-gray-600">Choose a chat to start messaging</p>
                    </div>
                  </div>
                )}
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="tickets" className="space-y-6 mt-6">
            {/* Create Ticket */}
            <Card className="p-6">
              <h2 className="text-xl font-semibold text-black mb-4">Submit New Ticket</h2>
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="block text-sm font-medium text-black mb-2">Category</label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="general">General Questions</SelectItem>
                      <SelectItem value="tournaments">Tournaments</SelectItem>
                      <SelectItem value="courts">Court Booking</SelectItem>
                      <SelectItem value="payments">Payments & Billing</SelectItem>
                      <SelectItem value="training">Training & Coaching</SelectItem>
                      <SelectItem value="marketplace">Marketplace</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-black mb-2">Priority</label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select priority" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="mb-4">
                <label className="block text-sm font-medium text-black mb-2">Subject</label>
                <Input 
                  placeholder="Brief description of your issue"
                  value={ticketSubject}
                  onChange={(e) => setTicketSubject(e.target.value)}
                />
              </div>
              
              <div className="mb-4">
                <label className="block text-sm font-medium text-black mb-2">Description</label>
                <Textarea 
                  placeholder="Please provide detailed information about your issue..."
                  rows={4}
                  value={ticketMessage}
                  onChange={(e) => setTicketMessage(e.target.value)}
                />
              </div>
              
              <div className="flex items-center space-x-4">
                <Button className="bg-green-500 hover:bg-green-600 text-white">
                  <FileText className="w-4 h-4 mr-2" />
                  Submit Ticket
                </Button>
                <Button variant="outline">
                  <Paperclip className="w-4 h-4 mr-2" />
                  Attach Files
                </Button>
              </div>
            </Card>

            {/* Existing Tickets */}
            <Card className="p-6">
              <h2 className="text-xl font-semibold text-black mb-6">Your Support Tickets</h2>
              
              <div className="space-y-4">
                {supportTickets.map((ticket) => (
                  <div key={ticket.id} className="p-4 border border-gray-200 rounded-lg">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-2">
                          <h3 className="font-semibold text-black">{ticket.subject}</h3>
                          <Badge className={getStatusColor(ticket.status)}>
                            {ticket.status.replace('_', ' ')}
                          </Badge>
                          <Badge className={getPriorityColor(ticket.priority)}>
                            {ticket.priority}
                          </Badge>
                        </div>
                        
                        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 text-sm text-gray-600">
                          <div>
                            <span className="font-medium">Ticket ID:</span> #{ticket.id.toUpperCase()}
                          </div>
                          <div>
                            <span className="font-medium">Agent:</span> {ticket.agent}
                          </div>
                          <div>
                            <span className="font-medium">Created:</span> {new Date(ticket.created).toLocaleDateString()}
                          </div>
                          <div>
                            <span className="font-medium">Last Update:</span> {formatTime(ticket.lastUpdate)}
                          </div>
                        </div>
                      </div>
                      
                      <Button variant="outline" size="sm">
                        <ExternalLink className="w-4 h-4 mr-2" />
                        View Details
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="contact" className="space-y-6 mt-6">
            {/* Contact Options */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="p-6 text-center">
                <div className="p-4 bg-green-100 rounded-full w-fit mx-auto mb-4">
                  <MessageCircle className="w-8 h-8 text-green-600" />
                </div>
                <h3 className="text-lg font-semibold text-black mb-2">Live Chat</h3>
                <p className="text-gray-600 mb-4">Get instant help from our support team</p>
                <div className="text-sm text-gray-500 mb-4">
                  <div>Available 24/7</div>
                  <div>Avg response: 2 minutes</div>
                </div>
                <Button className="w-full bg-green-500 hover:bg-green-600 text-white">
                  Start Chat
                </Button>
              </Card>
              
              <Card className="p-6 text-center">
                <div className="p-4 bg-blue-100 rounded-full w-fit mx-auto mb-4">
                  <Mail className="w-8 h-8 text-blue-600" />
                </div>
                <h3 className="text-lg font-semibold text-black mb-2">Email Support</h3>
                <p className="text-gray-600 mb-4">Send us an email for detailed assistance</p>
                <div className="text-sm text-gray-500 mb-4">
                  <div>support@padelo.com</div>
                  <div>Response within 24 hours</div>
                </div>
                <Button variant="outline" className="w-full">
                  Send Email
                </Button>
              </Card>
              
              <Card className="p-6 text-center">
                <div className="p-4 bg-purple-100 rounded-full w-fit mx-auto mb-4">
                  <Phone className="w-8 h-8 text-purple-600" />
                </div>
                <h3 className="text-lg font-semibold text-black mb-2">Phone Support</h3>
                <p className="text-gray-600 mb-4">Call us for urgent matters</p>
                <div className="text-sm text-gray-500 mb-4">
                  <div>+20 123 456 7890</div>
                  <div>Mon-Fri: 9 AM - 6 PM</div>
                </div>
                <Button variant="outline" className="w-full">
                  Call Now
                </Button>
              </Card>
            </div>

            {/* Support Hours & Resources */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="p-6">
                <h3 className="text-lg font-semibold text-black mb-4">Support Hours</h3>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Live Chat</span>
                    <span className="text-black">24/7</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Phone Support</span>
                    <span className="text-black">Mon-Fri: 9 AM - 6 PM</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Email Support</span>
                    <span className="text-black">24/7 (24h response)</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Emergency Line</span>
                    <span className="text-black">24/7</span>
                  </div>
                </div>
              </Card>
              
              <Card className="p-6">
                <h3 className="text-lg font-semibold text-black mb-4">Helpful Resources</h3>
                <div className="space-y-3">
                  <Button variant="outline" className="w-full justify-start">
                    <Book className="w-4 h-4 mr-2" />
                    User Guide
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <Video className="w-4 h-4 mr-2" />
                    Video Tutorials
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <Download className="w-4 h-4 mr-2" />
                    Download App
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Community Forum
                  </Button>
                </div>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
