import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Logo } from '@/components/Logo';

interface LanguageSelectionProps {
  onLanguageSelected: () => void;
}

export function LanguageSelection({ onLanguageSelected }: LanguageSelectionProps) {
  const [isInitialized, setIsInitialized] = useState(false);

  useEffect(() => {
    // Dynamically import i18n to ensure it's properly initialized
    import('../i18n/config').then(() => {
      setIsInitialized(true);
    }).catch((error) => {
      console.error('Failed to initialize i18n:', error);
      // Still allow the component to render without i18n
      setIsInitialized(true);
    });
  }, []);

  const languages = [
    { 
      code: 'en', 
      name: 'English', 
      flag: '🇺🇸',
      subtitle: 'Continue in English'
    },
    { 
      code: 'ar', 
      name: 'العربية', 
      flag: '🇸🇦',
      subtitle: 'متابعة باللغة العربية'
    }
  ];

  const selectLanguage = async (languageCode: string) => {
    try {
      // Dynamically import i18n to avoid context issues
      const { default: i18n } = await import('../i18n/config');
      await i18n.changeLanguage(languageCode);

      // Update document direction for Arabic
      document.documentElement.dir = languageCode === 'ar' ? 'rtl' : 'ltr';
      document.documentElement.lang = languageCode;
      localStorage.setItem('padelo-language-selected', 'true');
      localStorage.setItem('i18nextLng', languageCode);
      onLanguageSelected();
    } catch (error) {
      console.error('Failed to change language:', error);
      // Fallback: still save the selection and continue
      localStorage.setItem('padelo-language-selected', 'true');
      localStorage.setItem('i18nextLng', languageCode);
      document.documentElement.dir = languageCode === 'ar' ? 'rtl' : 'ltr';
      document.documentElement.lang = languageCode;
      onLanguageSelected();
    }
  };

  if (!isInitialized) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-white dark:from-gray-900 dark:to-gray-800 flex items-center justify-center p-4">
        <Card className="w-full max-w-md p-8 text-center space-y-8">
          <div className="space-y-4">
            <Logo size="lg" className="justify-center" />
            <div className="space-y-2">
              <h1 className="text-2xl font-bold text-black">Loading...</h1>
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-500 mx-auto"></div>
            </div>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-white dark:from-gray-900 dark:to-gray-800 flex items-center justify-center p-4">
      <Card className="w-full max-w-md p-8 text-center space-y-8">
        <div className="space-y-4">
          <Logo size="lg" className="justify-center" />
          <div className="space-y-2">
            <h1 className="text-2xl font-bold text-black">Welcome to Padelo</h1>
            <p className="text-gray-600">Select your preferred language</p>
          </div>
        </div>

        <div className="space-y-4">
          {languages.map((language) => (
            <Button
              key={language.code}
              onClick={() => selectLanguage(language.code)}
              variant="outline"
              size="lg"
              className="w-full flex items-center justify-center space-x-3 h-16 text-lg hover:bg-green-50 hover:border-green-500 group"
            >
              <span className="text-2xl">{language.flag}</span>
              <div className="flex flex-col items-start">
                <span className="font-semibold group-hover:text-green-600">
                  {language.name}
                </span>
                <span className="text-sm text-gray-500 group-hover:text-green-500">
                  {language.subtitle}
                </span>
              </div>
            </Button>
          ))}
        </div>

        <p className="text-xs text-gray-400">
          You can change the language later in settings
        </p>
      </Card>
    </div>
  );
}
