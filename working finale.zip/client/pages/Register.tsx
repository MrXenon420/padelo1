import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useAuth, UserRole } from '../contexts/RoleAuthContext';
import { useNavigate } from 'react-router-dom';
import { 
  User,
  Mail,
  Lock,
  Eye,
  EyeOff,
  UserPlus,
  Shield,
  Award,
  Building,
  Trophy,
  Crown,
  AlertCircle,
  CheckCircle,
  Loader2,
  ArrowLeft,
  Check
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Textarea } from '@/components/ui/textarea';

export default function Register() {
  const { t } = useTranslation();
  const { register, isLoading } = useAuth();
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
    agreeTerms: false,
    agreePrivacy: false
  });
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Role definitions with detailed information
  const roleOptions = [
    {
      id: 'player',
      name: 'Player',
      description: 'Join tournaments, book courts, and improve your game',
      icon: User,
      color: 'bg-blue-500',
      features: [
        'Join tournaments and competitions',
        'Book court sessions',
        'Buy and sell equipment',
        'Connect with other players',
        'Track your progress and rankings'
      ],
      pricing: {
        free: 'Basic features included',
        premium: '$9.99/month - Enhanced features',
        pro: '$19.99/month - All features + priority support'
      }
    },
    {
      id: 'coach',
      name: 'Coach',
      description: 'Teach players, manage training programs, and grow your coaching business',
      icon: Award,
      color: 'bg-green-500',
      features: [
        'Create and manage training programs',
        'Schedule coaching sessions',
        'Track student progress',
        'Marketplace access for equipment',
        'Professional profile and ratings'
      ],
      pricing: {
        free: 'Limited students (up to 5)',
        premium: '$19.99/month - Up to 25 students',
        pro: '$39.99/month - Unlimited students + analytics'
      }
    },
    {
      id: 'court_owner',
      name: 'Court Owner',
      description: 'Manage your venues, handle bookings, and maximize revenue',
      icon: Building,
      color: 'bg-purple-500',
      features: [
        'Manage court facilities',
        'Handle bookings and scheduling',
        'Set pricing and availability',
        'Revenue analytics and reporting',
        'Host tournaments and events'
      ],
      pricing: {
        free: '1 court, basic booking system',
        premium: '$49.99/month - Up to 5 courts + analytics',
        pro: '$99.99/month - Unlimited courts + advanced features'
      }
    },
    {
      id: 'tournament_organizer',
      name: 'Tournament Organizer',
      description: 'Create and manage tournaments, handle registrations, and build communities',
      icon: Trophy,
      color: 'bg-orange-500',
      features: [
        'Create and manage tournaments',
        'Handle participant registration',
        'Automated bracket generation',
        'Prize pool management',
        'Event promotion tools'
      ],
      pricing: {
        free: 'Small tournaments (up to 16 players)',
        premium: '$29.99/month - Medium tournaments (up to 64 players)',
        pro: '$59.99/month - Large tournaments + advanced features'
      }
    }
  ];

  const subscriptionPlans = [
    {
      id: 'free',
      name: 'Free',
      price: '$0',
      description: 'Perfect for getting started',
      features: ['Basic features', 'Limited access', 'Community support']
    },
    {
      id: 'premium',
      name: 'Premium',
      price: 'Starting at $9.99',
      description: 'Enhanced features for serious players',
      features: ['All free features', 'Priority booking', 'Advanced analytics', 'Email support'],
      popular: true
    },
    {
      id: 'pro',
      name: 'Professional',
      price: 'Starting at $19.99',
      description: 'Complete solution for professionals',
      features: ['All premium features', 'Unlimited access', 'Priority support', 'Custom branding']
    }
  ];

  const handleInputChange = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    setError('');
  };

  const handleNextStep = () => {
    if (step === 1) {
      if (!formData.name || !formData.email || !formData.password || !formData.confirmPassword) {
        setError('Please fill in all fields');
        return;
      }
      if (formData.password !== formData.confirmPassword) {
        setError('Passwords do not match');
        return;
      }
      if (formData.password.length < 6) {
        setError('Password must be at least 6 characters long');
        return;
      }
    }

    setError('');
    setStep(step + 1);
  };

  const handleSubmit = async () => {
    if (!formData.agreeTerms) {
      setError('Please accept the terms and conditions');
      return;
    }
    if (!formData.agreePrivacy) {
      setError('Please accept the privacy policy');
      return;
    }

    setError('');
    setSuccess('');

    const registerSuccess = await register({
      name: formData.name,
      email: formData.email,
      password: formData.password
    });

    if (registerSuccess) {
      setSuccess('Registration successful! Welcome to Padelo!');
      setTimeout(() => {
        window.location.href = '/';
      }, 2000);
    } else {
      setError('Registration failed. Email may already be in use.');
    }
  };

  const selectedRole = roleOptions.find(role => role.id === formData.role);

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 dark:from-gray-900 dark:to-gray-800 flex items-center justify-center p-4">
      <div className="w-full max-w-4xl">
        <Card className="p-8">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="flex items-center justify-center mb-4">
              <div className="p-3 bg-green-100 rounded-full">
                <UserPlus className="w-8 h-8 text-green-600" />
              </div>
            </div>
            <h1 className="text-2xl font-bold text-black mb-2">Join Padelo Community</h1>
            <p className="text-gray-600">Create your account and start your padel journey</p>
          </div>

          {/* Progress Indicator */}
          <div className="mb-8">
            <div className="flex items-center justify-center space-x-4">
              {[1, 2].map((stepNumber) => (
                <div key={stepNumber} className="flex items-center">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                    step >= stepNumber
                      ? 'bg-green-500 text-white'
                      : 'bg-gray-200 text-gray-600'
                  }`}>
                    {step > stepNumber ? <Check className="w-4 h-4" /> : stepNumber}
                  </div>
                  {stepNumber < 2 && (
                    <div className={`w-12 h-1 mx-2 ${
                      step > stepNumber ? 'bg-green-500' : 'bg-gray-200'
                    }`} />
                  )}
                </div>
              ))}
            </div>
            <div className="flex justify-center mt-2">
              <div className="text-sm text-gray-600">
                Step {step} of 2: {
                  step === 1 ? 'Account Information' : 'Terms & Conditions'
                }
              </div>
            </div>
          </div>

          {error && (
            <Alert className="mb-6 border-red-200 bg-red-50">
              <AlertCircle className="h-4 w-4 text-red-600" />
              <AlertDescription className="text-red-700">{error}</AlertDescription>
            </Alert>
          )}

          {success && (
            <Alert className="mb-6 border-green-200 bg-green-50">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <AlertDescription className="text-green-700">{success}</AlertDescription>
            </Alert>
          )}

          {/* Step 1: Basic Information */}
          {step === 1 && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-black mb-2">Full Name</label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                    <Input
                      type="text"
                      value={formData.name}
                      onChange={(e) => handleInputChange('name', e.target.value)}
                      placeholder="Enter your full name"
                      className="pl-12"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-black mb-2">Email Address</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                    <Input
                      type="email"
                      value={formData.email}
                      onChange={(e) => handleInputChange('email', e.target.value)}
                      placeholder="Enter your email"
                      className="pl-12"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-black mb-2">Password</label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                    <Input
                      type={showPassword ? 'text' : 'password'}
                      value={formData.password}
                      onChange={(e) => handleInputChange('password', e.target.value)}
                      placeholder="Create a password"
                      className="pl-12 pr-12"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                    >
                      {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-black mb-2">Confirm Password</label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                    <Input
                      type={showConfirmPassword ? 'text' : 'password'}
                      value={formData.confirmPassword}
                      onChange={(e) => handleInputChange('confirmPassword', e.target.value)}
                      placeholder="Confirm your password"
                      className="pl-12 pr-12"
                    />
                    <button
                      type="button"
                      onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                      className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                    >
                      {showConfirmPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Step 2: Terms & Conditions */}
          {step === 2 && (
            <div className="space-y-6">
              <div className="text-center mb-6">
                <h3 className="text-lg font-semibold text-black mb-2">Welcome to Padelo!</h3>
                <p className="text-gray-600">
                  You'll be registered as a <strong>Player</strong>. Owners can assign you additional roles later if needed.
                </p>
              </div>

              <Card className="p-6 bg-blue-50 border-blue-200">
                <div className="flex items-start space-x-3">
                  <div className="p-2 bg-blue-100 rounded-full">
                    <User className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-black mb-2">Player Account Features</h4>
                    <div className="space-y-2 text-sm text-gray-700">
                      <div className="flex items-center">
                        <Check className="w-4 h-4 mr-2 text-green-500" />
                        Join tournaments and competitions
                      </div>
                      <div className="flex items-center">
                        <Check className="w-4 h-4 mr-2 text-green-500" />
                        Book court sessions
                      </div>
                      <div className="flex items-center">
                        <Check className="w-4 h-4 mr-2 text-green-500" />
                        Buy and sell equipment in marketplace
                      </div>
                      <div className="flex items-center">
                        <Check className="w-4 h-4 mr-2 text-green-500" />
                        Connect with other players
                      </div>
                      <div className="flex items-center">
                        <Check className="w-4 h-4 mr-2 text-green-500" />
                        Track your progress and rankings
                      </div>
                    </div>
                  </div>
                </div>
              </Card>

              <div className="space-y-4">
                <div className="flex items-start space-x-2">
                  <input
                    type="checkbox"
                    id="terms"
                    checked={formData.agreeTerms}
                    onChange={(e) => handleInputChange('agreeTerms', e.target.checked)}
                    className="mt-1"
                  />
                  <label htmlFor="terms" className="text-sm text-gray-700">
                    I agree to the{' '}
                    <button
                      type="button"
                      onClick={() => navigate('/terms-of-service')}
                      className="text-green-600 hover:text-green-500 underline"
                    >
                      Terms of Service
                    </button>
                  </label>
                </div>

                <div className="flex items-start space-x-2">
                  <input
                    type="checkbox"
                    id="privacy"
                    checked={formData.agreePrivacy}
                    onChange={(e) => handleInputChange('agreePrivacy', e.target.checked)}
                    className="mt-1"
                  />
                  <label htmlFor="privacy" className="text-sm text-gray-700">
                    I agree to the{' '}
                    <button
                      type="button"
                      onClick={() => navigate('/privacy-policy')}
                      className="text-green-600 hover:text-green-500 underline"
                    >
                      Privacy Policy
                    </button>
                  </label>
                </div>

                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="text-sm text-gray-600">
                    <strong>Note:</strong> All new users start as Players. If you need additional permissions (Coach, Court Owner, etc.),
                    please contact a platform owner after registration.
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Navigation Buttons */}
          <div className="flex justify-between mt-8">
            <div>
              {step > 1 && (
                <Button 
                  variant="outline" 
                  onClick={() => setStep(step - 1)}
                  disabled={isLoading}
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back
                </Button>
              )}
            </div>

            <div className="flex space-x-3">
              <Button 
                variant="outline" 
                onClick={() => window.location.href = '/login'}
                disabled={isLoading}
              >
                Already have an account?
              </Button>
              
              {step < 2 ? (
                <Button
                  onClick={handleNextStep}
                  className="bg-green-500 hover:bg-green-600 text-white"
                  disabled={isLoading}
                >
                  Continue
                </Button>
              ) : (
                <Button
                  onClick={handleSubmit}
                  className="bg-green-500 hover:bg-green-600 text-white"
                  disabled={isLoading || !formData.agreeTerms || !formData.agreePrivacy}
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Creating Account...
                    </>
                  ) : (
                    <>
                      <UserPlus className="w-4 h-4 mr-2" />
                      Create Account
                    </>
                  )}
                </Button>
              )}
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
