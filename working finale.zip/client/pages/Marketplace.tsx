import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { 
  Search,
  Filter,
  Plus,
  Star,
  MapPin,
  Clock,
  DollarSign,
  Heart,
  MessageCircle,
  Share,
  Eye,
  ShoppingCart,
  Package,
  TrendingUp,
  Award,
  CheckCircle,
  AlertCircle,
  Camera,
  Calendar,
  User,
  Shield,
  Zap,
  Tag,
  BarChart3
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Textarea } from '@/components/ui/textarea';

export default function Marketplace() {
  const { t } = useTranslation();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedCondition, setSelectedCondition] = useState('all');
  const [selectedPriceRange, setSelectedPriceRange] = useState('all');
  const [selectedLocation, setSelectedLocation] = useState('all');

  // Mock marketplace data
  const featuredItems = [
    {
      id: '1',
      title: 'Babolat Defiance Pro Racket',
      brand: 'Babolat',
      model: 'Defiance Pro',
      condition: 'Like New',
      price: 280,
      originalPrice: 350,
      images: ['/racket1.jpg', '/racket2.jpg'],
      description: 'Professional grade racket, used for only 3 months. Perfect for intermediate to advanced players.',
      seller: {
        id: 'seller1',
        name: 'Ahmed Hassan',
        avatar: '/user1.jpg',
        rating: 4.8,
        reviewCount: 23,
        verified: true,
        responseTime: '< 2 hours',
        location: 'New Cairo'
      },
      specifications: {
        weight: '365g',
        balance: '265mm',
        shape: 'Round',
        surface: 'Carbon Fiber'
      },
      category: 'rackets',
      postedDate: '2024-03-15',
      viewCount: 47,
      favoriteCount: 12,
      isPromoted: true,
      tags: ['Professional', 'Carbon Fiber', 'Tournament Grade']
    },
    {
      id: '2',
      title: 'Head Delta Elite Racket',
      brand: 'Head',
      model: 'Delta Elite',
      condition: 'Good',
      price: 180,
      originalPrice: 250,
      images: ['/racket3.jpg'],
      description: 'Great racket for beginners to intermediate players. Shows minimal wear.',
      seller: {
        id: 'seller2',
        name: 'Sara Mohamed',
        avatar: '/user2.jpg',
        rating: 4.6,
        reviewCount: 15,
        verified: true,
        responseTime: '< 4 hours',
        location: 'Zamalek'
      },
      specifications: {
        weight: '350g',
        balance: '260mm',
        shape: 'Teardrop',
        surface: 'Fiberglass'
      },
      category: 'rackets',
      postedDate: '2024-03-14',
      viewCount: 32,
      favoriteCount: 8,
      isPromoted: false,
      tags: ['Beginner Friendly', 'Lightweight']
    },
    {
      id: '3',
      title: 'Wilson Pro Staff 97 (Used)',
      brand: 'Wilson',
      model: 'Pro Staff 97',
      condition: 'Fair',
      price: 120,
      originalPrice: 200,
      images: ['/racket4.jpg'],
      description: 'Well-used racket, perfect for practice sessions. Some cosmetic wear but performance intact.',
      seller: {
        id: 'seller3',
        name: 'Omar Ali',
        avatar: '/user3.jpg',
        rating: 4.9,
        reviewCount: 41,
        verified: true,
        responseTime: '< 1 hour',
        location: 'Maadi'
      },
      specifications: {
        weight: '375g',
        balance: '270mm',
        shape: 'Round',
        surface: 'Carbon'
      },
      category: 'rackets',
      postedDate: '2024-03-13',
      viewCount: 28,
      favoriteCount: 5,
      isPromoted: false,
      tags: ['Practice Grade', 'Heavy Weight']
    }
  ];

  // Mock equipment accessories
  const accessories = [
    {
      id: 'acc1',
      title: 'Premium Padel Balls Set (3 balls)',
      brand: 'HEAD',
      price: 25,
      condition: 'New',
      seller: { name: 'Sports Store', verified: true, location: 'Cairo' },
      category: 'balls',
      images: ['/balls1.jpg']
    },
    {
      id: 'acc2',
      title: 'Professional Grip Tape Set',
      brand: 'Wilson',
      price: 15,
      condition: 'New',
      seller: { name: 'Equipment Pro', verified: true, location: 'Alexandria' },
      category: 'accessories',
      images: ['/grip1.jpg']
    },
    {
      id: 'acc3',
      title: 'Padel Court Shoes - Size 42',
      brand: 'Asics',
      price: 80,
      condition: 'Like New',
      seller: { name: 'Ahmed Hassan', verified: true, location: 'Giza' },
      category: 'shoes',
      images: ['/shoes1.jpg']
    }
  ];

  // Mock user's listings
  const userListings = [
    {
      id: 'user1',
      title: 'Bullpadel Vertex 03',
      price: 200,
      condition: 'Good',
      status: 'active',
      viewCount: 15,
      favoriteCount: 3,
      inquiries: 2,
      postedDate: '2024-03-10'
    },
    {
      id: 'user2',
      title: 'Nox ML10 Pro Cup',
      price: 150,
      condition: 'Fair',
      status: 'sold',
      viewCount: 8,
      favoriteCount: 1,
      inquiries: 1,
      postedDate: '2024-03-05'
    }
  ];

  const getConditionColor = (condition: string) => {
    const colors = {
      'New': 'bg-green-500 text-white',
      'Like New': 'bg-blue-500 text-white',
      'Good': 'bg-yellow-500 text-white',
      'Fair': 'bg-orange-500 text-white',
      'Poor': 'bg-red-500 text-white'
    };
    return colors[condition as keyof typeof colors] || 'bg-gray-500 text-white';
  };

  const formatTimeAgo = (date: string) => {
    const days = Math.floor((new Date().getTime() - new Date(date).getTime()) / (1000 * 3600 * 24));
    if (days === 0) return 'Today';
    if (days === 1) return 'Yesterday';
    return `${days} days ago`;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 p-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-black">Marketplace</h1>
            <p className="text-gray-600">Buy and sell padel equipment</p>
          </div>
          <Button className="bg-green-500 hover:bg-green-600 text-white">
            <Plus className="w-4 h-4 mr-2" />
            Sell Item
          </Button>
        </div>
      </div>

      <div className="p-4">
        <Tabs defaultValue="browse" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="browse">Browse</TabsTrigger>
            <TabsTrigger value="my-listings">My Listings</TabsTrigger>
            <TabsTrigger value="favorites">Favorites</TabsTrigger>
            <TabsTrigger value="sell">Sell Item</TabsTrigger>
          </TabsList>

          <TabsContent value="browse" className="space-y-6 mt-6">
            {/* Search and Filters */}
            <Card className="p-4">
              <div className="flex flex-col lg:flex-row gap-3 mb-4">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    placeholder="Search by brand, model, or description..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
                
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger className="w-full lg:w-[140px]">
                    <SelectValue placeholder="Category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    <SelectItem value="rackets">Rackets</SelectItem>
                    <SelectItem value="balls">Balls</SelectItem>
                    <SelectItem value="shoes">Shoes</SelectItem>
                    <SelectItem value="accessories">Accessories</SelectItem>
                    <SelectItem value="clothing">Clothing</SelectItem>
                  </SelectContent>
                </Select>
                
                <Select value={selectedCondition} onValueChange={setSelectedCondition}>
                  <SelectTrigger className="w-full lg:w-[120px]">
                    <SelectValue placeholder="Condition" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Conditions</SelectItem>
                    <SelectItem value="new">New</SelectItem>
                    <SelectItem value="like-new">Like New</SelectItem>
                    <SelectItem value="good">Good</SelectItem>
                    <SelectItem value="fair">Fair</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={selectedPriceRange} onValueChange={setSelectedPriceRange}>
                  <SelectTrigger className="w-full lg:w-[120px]">
                    <SelectValue placeholder="Price" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Prices</SelectItem>
                    <SelectItem value="0-50">$0 - $50</SelectItem>
                    <SelectItem value="50-150">$50 - $150</SelectItem>
                    <SelectItem value="150-300">$150 - $300</SelectItem>
                    <SelectItem value="300+">$300+</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={selectedLocation} onValueChange={setSelectedLocation}>
                  <SelectTrigger className="w-full lg:w-[120px]">
                    <SelectValue placeholder="Location" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Locations</SelectItem>
                    <SelectItem value="cairo">Cairo</SelectItem>
                    <SelectItem value="giza">Giza</SelectItem>
                    <SelectItem value="alexandria">Alexandria</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center space-x-2 text-sm text-gray-600">
                <Filter className="w-4 h-4" />
                <span>Showing {featuredItems.length + accessories.length} items</span>
                <span>•</span>
                <span>Sort by: Most Recent</span>
              </div>
            </Card>

            {/* Featured Items */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-semibold text-black">Featured Rackets</h2>
                <Badge className="bg-yellow-500 text-white">
                  <Star className="w-3 h-3 mr-1" />
                  Premium
                </Badge>
              </div>

              <div className="grid gap-6">
                {featuredItems.map((item) => (
                  <Card key={item.id} className={`p-6 ${item.isPromoted ? 'border-yellow-300 bg-yellow-50' : ''}`}>
                    <div className="flex flex-col lg:flex-row gap-6">
                      {/* Item Image */}
                      <div className="w-full lg:w-64 h-48 bg-gray-200 rounded-lg flex items-center justify-center relative">
                        <Package className="w-12 h-12 text-gray-400" />
                        {item.isPromoted && (
                          <Badge className="absolute top-2 left-2 bg-yellow-500 text-white text-xs">
                            <Zap className="w-3 h-3 mr-1" />
                            Featured
                          </Badge>
                        )}
                        <div className="absolute top-2 right-2 flex space-x-1">
                          <Button variant="outline" size="sm" className="w-8 h-8 p-0">
                            <Heart className="w-4 h-4" />
                          </Button>
                          <Button variant="outline" size="sm" className="w-8 h-8 p-0">
                            <Share className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>

                      {/* Item Details */}
                      <div className="flex-1">
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <div className="flex items-center space-x-2 mb-2">
                              <h3 className="text-xl font-semibold text-black">{item.title}</h3>
                              <Badge className={getConditionColor(item.condition)}>
                                {item.condition}
                              </Badge>
                            </div>
                            
                            <div className="flex items-center space-x-4 text-sm text-gray-600 mb-2">
                              <span>{item.brand} • {item.model}</span>
                              <div className="flex items-center">
                                <Eye className="w-4 h-4 mr-1" />
                                {item.viewCount} views
                              </div>
                              <div className="flex items-center">
                                <Heart className="w-4 h-4 mr-1" />
                                {item.favoriteCount}
                              </div>
                            </div>

                            <p className="text-gray-700 mb-3">{item.description}</p>

                            {/* Tags */}
                            <div className="flex flex-wrap gap-2 mb-3">
                              {item.tags.map((tag) => (
                                <Badge key={tag} variant="outline" className="text-xs">
                                  <Tag className="w-3 h-3 mr-1" />
                                  {tag}
                                </Badge>
                              ))}
                            </div>

                            {/* Specifications */}
                            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-3">
                              <div className="text-xs">
                                <div className="font-medium text-black">Weight</div>
                                <div className="text-gray-600">{item.specifications.weight}</div>
                              </div>
                              <div className="text-xs">
                                <div className="font-medium text-black">Balance</div>
                                <div className="text-gray-600">{item.specifications.balance}</div>
                              </div>
                              <div className="text-xs">
                                <div className="font-medium text-black">Shape</div>
                                <div className="text-gray-600">{item.specifications.shape}</div>
                              </div>
                              <div className="text-xs">
                                <div className="font-medium text-black">Surface</div>
                                <div className="text-gray-600">{item.specifications.surface}</div>
                              </div>
                            </div>
                          </div>
                        </div>

                        {/* Seller Info & Price */}
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <Avatar className="w-10 h-10">
                              <AvatarImage src={item.seller.avatar} />
                              <AvatarFallback>{item.seller.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                            </Avatar>
                            <div>
                              <div className="flex items-center space-x-1">
                                <span className="text-sm font-medium text-black">{item.seller.name}</span>
                                {item.seller.verified && (
                                  <CheckCircle className="w-4 h-4 text-green-500" />
                                )}
                              </div>
                              <div className="flex items-center space-x-2 text-xs text-gray-600">
                                <div className="flex items-center">
                                  <Star className="w-3 h-3 mr-1 fill-current text-yellow-400" />
                                  {item.seller.rating} ({item.seller.reviewCount})
                                </div>
                                <div className="flex items-center">
                                  <MapPin className="w-3 h-3 mr-1" />
                                  {item.seller.location}
                                </div>
                                <div className="flex items-center">
                                  <Clock className="w-3 h-3 mr-1" />
                                  {item.seller.responseTime}
                                </div>
                              </div>
                            </div>
                          </div>

                          <div className="text-right">
                            <div className="flex items-center space-x-2 mb-1">
                              <span className="text-2xl font-bold text-black">${item.price}</span>
                              {item.originalPrice && (
                                <span className="text-sm text-gray-500 line-through">${item.originalPrice}</span>
                              )}
                            </div>
                            <div className="text-xs text-gray-600">
                              Posted {formatTimeAgo(item.postedDate)}
                            </div>
                          </div>
                        </div>

                        {/* Action Buttons */}
                        <div className="flex space-x-3 mt-4">
                          <Button className="flex-1 bg-green-500 hover:bg-green-600 text-white">
                            <MessageCircle className="w-4 h-4 mr-2" />
                            Contact Seller
                          </Button>
                          <Button variant="outline" className="flex-1">
                            <ShoppingCart className="w-4 h-4 mr-2" />
                            Make Offer
                          </Button>
                          <Button variant="outline">
                            <Eye className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </div>

            {/* Accessories Section */}
            <div>
              <h2 className="text-xl font-semibold text-black mb-4">Equipment & Accessories</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {accessories.map((item) => (
                  <Card key={item.id} className="p-4">
                    <div className="w-full h-32 bg-gray-200 rounded-lg flex items-center justify-center mb-3">
                      <Package className="w-8 h-8 text-gray-400" />
                    </div>
                    
                    <div className="space-y-2">
                      <h3 className="font-semibold text-black text-sm">{item.title}</h3>
                      
                      <div className="flex items-center justify-between">
                        <Badge className={getConditionColor(item.condition)} size="sm">
                          {item.condition}
                        </Badge>
                        <span className="text-lg font-bold text-black">${item.price}</span>
                      </div>
                      
                      <div className="flex items-center text-xs text-gray-600">
                        <User className="w-3 h-3 mr-1" />
                        {item.seller.name}
                        {item.seller.verified && <CheckCircle className="w-3 h-3 ml-1 text-green-500" />}
                      </div>
                      
                      <div className="flex items-center text-xs text-gray-600">
                        <MapPin className="w-3 h-3 mr-1" />
                        {item.seller.location}
                      </div>
                      
                      <Button size="sm" className="w-full bg-green-500 hover:bg-green-600 text-white">
                        Contact Seller
                      </Button>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="my-listings" className="space-y-6 mt-6">
            <Card className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold text-black">My Listings</h2>
                <Button className="bg-green-500 hover:bg-green-600 text-white">
                  <Plus className="w-4 h-4 mr-2" />
                  Add New Listing
                </Button>
              </div>

              <div className="space-y-4">
                {userListings.map((listing) => (
                  <div key={listing.id} className="p-4 border border-gray-200 rounded-lg">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-2">
                          <h3 className="font-semibold text-black">{listing.title}</h3>
                          <Badge 
                            className={listing.status === 'active' ? 'bg-green-500 text-white' : 'bg-gray-500 text-white'}
                          >
                            {listing.status}
                          </Badge>
                        </div>
                        
                        <div className="grid grid-cols-2 lg:grid-cols-5 gap-4 text-sm text-gray-600">
                          <div>
                            <div className="font-medium text-black">${listing.price}</div>
                            <div className="text-xs">Price</div>
                          </div>
                          <div>
                            <div className="font-medium text-black">{listing.viewCount}</div>
                            <div className="text-xs">Views</div>
                          </div>
                          <div>
                            <div className="font-medium text-black">{listing.favoriteCount}</div>
                            <div className="text-xs">Favorites</div>
                          </div>
                          <div>
                            <div className="font-medium text-black">{listing.inquiries}</div>
                            <div className="text-xs">Inquiries</div>
                          </div>
                          <div>
                            <div className="font-medium text-black">{formatTimeAgo(listing.postedDate)}</div>
                            <div className="text-xs">Posted</div>
                          </div>
                        </div>
                      </div>

                      <div className="flex space-x-2">
                        {listing.status === 'active' && (
                          <>
                            <Button variant="outline" size="sm">
                              Edit
                            </Button>
                            <Button variant="outline" size="sm">
                              <BarChart3 className="w-4 h-4" />
                            </Button>
                          </>
                        )}
                        <Button variant="outline" size="sm">
                          View
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="favorites" className="space-y-6 mt-6">
            <Card className="p-6">
              <div className="text-center py-8">
                <Heart className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-black mb-2">No favorites yet</h3>
                <p className="text-gray-600 mb-4">Save items you're interested in to see them here</p>
                <Button className="bg-green-500 hover:bg-green-600 text-white">
                  Browse Marketplace
                </Button>
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="sell" className="space-y-6 mt-6">
            <Card className="p-6">
              <h2 className="text-xl font-semibold text-black mb-6">Sell Your Item</h2>
              
              <div className="space-y-6">
                {/* Item Photos */}
                <div>
                  <label className="block text-sm font-medium text-black mb-2">Photos</label>
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                    <Camera className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-600 mb-2">Add up to 8 photos</p>
                    <Button variant="outline">
                      <Camera className="w-4 h-4 mr-2" />
                      Upload Photos
                    </Button>
                  </div>
                </div>

                {/* Item Details */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-black mb-2">Title *</label>
                    <Input placeholder="e.g., Babolat Defiance Pro Racket" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-black mb-2">Category *</label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="rackets">Rackets</SelectItem>
                        <SelectItem value="balls">Balls</SelectItem>
                        <SelectItem value="shoes">Shoes</SelectItem>
                        <SelectItem value="accessories">Accessories</SelectItem>
                        <SelectItem value="clothing">Clothing</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-black mb-2">Brand *</label>
                    <Input placeholder="e.g., Babolat, Head, Wilson" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-black mb-2">Model</label>
                    <Input placeholder="e.g., Defiance Pro" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-black mb-2">Condition *</label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select condition" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="new">New</SelectItem>
                        <SelectItem value="like-new">Like New</SelectItem>
                        <SelectItem value="good">Good</SelectItem>
                        <SelectItem value="fair">Fair</SelectItem>
                        <SelectItem value="poor">Poor</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-black mb-2">Price ($) *</label>
                    <Input type="number" placeholder="0" />
                  </div>
                </div>

                {/* Description */}
                <div>
                  <label className="block text-sm font-medium text-black mb-2">Description *</label>
                  <Textarea 
                    placeholder="Describe your item's condition, features, and any included accessories..."
                    rows={4}
                  />
                </div>

                {/* Location */}
                <div>
                  <label className="block text-sm font-medium text-black mb-2">Location *</label>
                  <Select>
                    <SelectTrigger className="lg:w-64">
                      <SelectValue placeholder="Select your location" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="cairo">Cairo</SelectItem>
                      <SelectItem value="giza">Giza</SelectItem>
                      <SelectItem value="alexandria">Alexandria</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Contact Preferences */}
                <div>
                  <label className="block text-sm font-medium text-black mb-2">Preferred Contact Method</label>
                  <div className="flex space-x-4">
                    <label className="flex items-center">
                      <input type="checkbox" className="mr-2" />
                      Messages
                    </label>
                    <label className="flex items-center">
                      <input type="checkbox" className="mr-2" />
                      Phone
                    </label>
                    <label className="flex items-center">
                      <input type="checkbox" className="mr-2" />
                      WhatsApp
                    </label>
                  </div>
                </div>

                {/* Submit */}
                <div className="flex space-x-4">
                  <Button className="bg-green-500 hover:bg-green-600 text-white">
                    <Package className="w-4 h-4 mr-2" />
                    List Item
                  </Button>
                  <Button variant="outline">
                    Save as Draft
                  </Button>
                </div>
              </div>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
