package com.padelo.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
